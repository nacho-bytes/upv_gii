package problemesExamens;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;
/**
 * Classe ProblemesExamens: problemes d'exàmens del Tema 4 de cursos anteriors.
 *
 * @author PRG
 * @version Curs 2019/20
 */
public class ProblemesExamens {
    private ProblemesExamens() { }
    
    /** P2 - Curs 18/19 */
    public static void sumInt(String fileIn, String fileOut) throws FileNotFoundException {
        Scanner in = new Scanner(new File(fileIn));
        PrintWriter out = new PrintWriter(new File(fileOut));
        int sum = 0;
        while (in.hasNext()) {
            try {
                int n = in.nextInt();
                out.println(n);
                sum += n;
            } catch (InputMismatchException e) {
                out.println("(Error: " + in.next() + ")");
            }
        }
        out.println("Suma: " + sum);
        in.close(); out.close();
    }
    
    /** RecP2 - Curs 18/19 */
    public static void filtraErrors(String fileIn, String fileOut) throws FileNotFoundException {
        Scanner in = new Scanner(new File(fileIn));
        PrintWriter out = new PrintWriter(new File(fileOut));
        int cont = 0;
        while (in.hasNext()) {
            try {
                String linia = in.nextLine(); 
                cont++;
                String[] tokens = linia.split("([ \t])+");
                if (tokens.length != 4) {
                    out.println("Error línia " + cont + ": Incorrecte el nombre de dades.");
                }
                else {
                    int edat = Integer.parseInt(tokens[1]);
                    int punts = Integer.parseInt(tokens[2]);
                    int campionats = Integer.parseInt(tokens[3]);
                    if (edat < 0 || punts < 0 || campionats < 0) {
                        out.println("Error línia " + cont + ": Valor negatiu.");
                    }
                }
            } catch (NumberFormatException e) {
                out.println("Error línia " + cont + ": Format d'enter no vàlid.");
            } 
        }
        in.close(); out.close();
    }
    
    /** P2 - Curs 17/18 */
    public static File fromArrayToTextFile(int[] a) {
        File res = new File("problemesExamens/ArrayElements.txt");
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(res);
            for (int i = 0; i < a.length; i++) {
                pw.println(a[i]);
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error en obrir " + res);
        } finally {
            if (pw != null) { pw.close(); }
        }
        return res;
    }
    
    /** P2 - Curs 16/17 */
    public static void fitxerNou(String ftx) {
        File f = new File(ftx);
        Scanner sc = null; PrintWriter pw = null;
        try {
            sc = new Scanner(f).useLocale(Locale.US);
            pw = new PrintWriter(new File(ftx + "_nou"));
            while (sc.hasNextLine()) {
                // try {
                    // String linia = sc.nextLine().trim();
                    // pw.println(Double.parseDouble(linia));
                // } catch (NumberFormatException n) { }          
                
                try {
                    pw.println(sc.nextDouble());
                } catch (InputMismatchException e) { 
                } finally { sc.nextLine(); }            
            }
        } catch (FileNotFoundException e) {
        } finally {
            if (sc != null) { sc.close(); }
            if (pw != null) { pw.close(); }
        }
    }
    
    /** RecP2 - Curs 16/17 */
    public static int lligISuma(String nomFitxer) {
        int suma = 0;
        Scanner sc = null;
        try {
            sc = new Scanner(new File(nomFitxer));
            while (sc.hasNextLine()) {
                String[] linia = sc.nextLine().trim().split(" ");
                for (int i = 0; i < linia.length; i++) {
                    try {
                        suma += Integer.parseInt(linia[i]);
                    } catch (NumberFormatException e) {
                        System.out.println(linia[i]);
                    }                
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("No s'ha trobat el fitxer");
        } finally {
            if (sc != null) { sc.close(); }
        }
        return suma;
    }
}