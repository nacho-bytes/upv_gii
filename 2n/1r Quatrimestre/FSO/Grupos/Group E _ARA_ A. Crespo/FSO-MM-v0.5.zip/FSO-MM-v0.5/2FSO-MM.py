#!/usr/bin/python

#####################################################
## main scheduler program for FSO scheduling policies
## Autor: Alfons Crespo
## Version 1.0
## date 08/12/20
##
#####################################################

import sys
import os
import random
import getopt
from heapq import heappush, heappop

import Memory as MM

NProc = 0
MINSIZE = 100
MAXSIZE = 5000


def usage ():
    print "Usage: python FSOscheduler.py [-c number] [-p RR|FCFS|SJF|SRTF] [-q number] [-v]\n"

def getOpts(argv):
    policy = "FF"
    coalescence = False

    try:
        opts, args = getopt.getopt(sys.argv[1:], "p:c", ["policy=","coalescence"])
    except getopt.GetoptError as err:
        # print help information and exit:
        print str(err)  # will print something like "option -a not recognized"
        usage()
        sys.exit(2)
    for o, a in opts:
        if o in ("-p", "--policy"):
            policy = a
        elif o in ("-c", "--coalescence"):
            coalescence = True

        else:
            assert False, "unhandled option"
    # ...
    return  (policy, coalescence)

def generateProcess():
    global NProc 

    NProc += 1
    n = str(NProc)
    pid = "P"+ n.zfill(3)
    size = random.randrange(MINSIZE, MAXSIZE, 100)
    ends = random.randint(10, 50)
    return (pid, size, ends)



#-------------------------#
#          MAIN           #
#-------------------------#
def main (argv):

    qRemoval = []
    (policy, coalescence) = getOpts(argv)
    size = 1000

    strategy = "FF"
    
    MM.defineMemory(size, coalescence, strategy)

    MM.allocProcess("OS", 100)
    MM.allocProcess("R0", 150)
    MM.allocProcess("P1", 200)
    MM.allocProcess("R1", 100)
    MM.allocProcess("P2", 200)

    MM.deallocProcess("R0")
    MM.deallocProcess("R1")

    MM.memShow()
    MM.setPolicy(policy)


    MM.allocProcess("P3", 100)
    print "Add P3"
    MM.memShow()

    MM.deallocProcess("P1")
    print "P1 ends"
    MM.memShow() 
      
    ret = MM.allocProcess("P4", 400)
    print "Add P4", ret
    MM.memShow()

    MM.deallocProcess("P2")
    print "P2 ends"
    MM.memShow() 

    MM.allocProcess("P5", 200)
    print "Add P5"
 
    MM.memShow()
    


main (sys.argv)