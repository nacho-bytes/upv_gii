#!/usr/bin/python

#####################################################
## main scheduler program for FSO scheduling policies
## Autor: Alfons Crespo
## Version 1.0
## date 08/12/20
##
#####################################################

import sys
import os
import random
import getopt
from heapq import heappush, heappop
import Memory as MM

NProc = 0
MINSIZE = 100
MAXSIZE = 600

def usage ():
    print "Usage: python FSO-MM.py [-t ticks] [-p FF|BF|WF] [-u util] [-s seed] [-c] [-v]"
    print "       default values"
    print "        p  FF      policy"
    print "        t  100     number of time ticks"
    print "        u  60      utilization"
    print "        c          if flag set => No coalescence"
    print "        s  None    seed initialization for randomize"
    print "        v          if flag set => verbose"

def getOpts(argv):
    util = 60
    seed = None
    verbose = False
    policy = "FF"
    nticks = 100
    coalescence = True

    try:
        opts, args = getopt.getopt(sys.argv[1:], "t:p:u:s:cv", ["ticks=","policy:", "util=","seed=","verbose"])
    except getopt.GetoptError as err:
        # print help information and exit:
        print str(err)  # will print something like "option -a not recognized"
        usage()
        sys.exit(2)
    for o, a in opts:
        if o in ("-p", "--policy"):
            policy = a
        elif o in ("-t", "--ticks"):
            nticks = int(a)
        elif o in ("-u", "--util"):
            util = int(a)
        elif o in ("-s", "--seed"):
            seed = int(a)
        elif o in ("-c", "--NoCoalescence"):
            coalescence = False
        elif o in ("-v", "--verbose"):
            verbose = True
        else:
            assert False, "unhandled option"
    return  (nticks, policy, util, seed, coalescence, verbose)

def generateProcess():
    global NProc 

    NProc += 1
    n = str(NProc)
    pid = "P"+ n.zfill(3)
    size = random.randrange(MINSIZE, MAXSIZE, 10)
    ends = random.randint(10, 50)
    return (pid, size, ends)

#-------------------------#
#          MAIN           #
#-------------------------#
def main (argv):

    (endTime, strategy, util, semilla, coalescence, verbose) = getOpts(argv)

    if (semilla != None):
        random.seed(semilla)
    else:
        semilla = random.randint(0, sys.maxint)
        random.seed(semilla)

    qRemoval = []

    size = 10 * 1024 
    MM.defineMemory(size, coalescence, strategy)

    clk = 0
    while(clk < endTime):
        if (len(qRemoval) > 0):
            (end, pid) = qRemoval[0]
            while (clk == end):
                (ends, pid) = heappop(qRemoval)
                MM.deallocProcess(pid)
                if (verbose):
                    print clk, "Deallocated ", pid, MM.utilization()
                if (len(qRemoval) > 0):
                    (end, pid) = qRemoval[0]
                else:
                    end = 0

        u = MM.utilization()
        if (u < util):
            (pid, size, ends) = generateProcess()
            ret = MM.allocProcess(pid, size)
            if (verbose):
                print clk, "Allocated ", pid, "Size: ", size, "ending:", ends, ret, MM.utilization()
            item = ((clk + ends, pid))
            heappush(qRemoval, item)
        clk += 1

    if (verbose):
        MM.memShow()
    else:
        MM.memInfo()

main (sys.argv)