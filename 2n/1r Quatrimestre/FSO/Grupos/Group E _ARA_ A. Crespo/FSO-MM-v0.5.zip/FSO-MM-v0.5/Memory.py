#module  System:

#####################################################
## module Memory: 
## Autor: Alfons Crespo
## Version 1.0
## date 08/12/20
##
#####################################################


policies = ("FF", "BF", "WF")

initialised = False
coalescence = True
memorySize = None
policy = "FF"
indexFrag = 0
listHoles = []
procDict = {}
maxHole = memorySize
minHole = memorySize
memoryFree = memorySize

def defineMemory(size, mode, strategy):
    global memorySize, minHole, maxHole, memoryFree, indexFrag, policy, coalescence

    memorySize = size
    maxHole = size
    minHole = size
    memoryFree = size
    indexFrag = 0
    policy = strategy
    initialised = True
    coalescence = mode
    listHoles.append((0, size))

def allocProcess(pid, size): 
    global minHole, maxHole, memoryFree, indexFrag

    if (procDict.has_key(pid)):
        return False
    if (maxHole < size):
        return False
    allocated = False
    resort()
    for h in listHoles:
        (offset, slot) = h
        if (slot >= size):
            allocated = True
            listHoles.remove(h) # remove hole
            if (slot > size):
                slot = slot - size
                if (slot > 0):
                    listHoles.append((offset + size, slot))
            procDict[pid] = (offset, size)
            break
    recalculate()
    return True

def deallocProcess(pid):
    if (not procDict.has_key(pid)):
        return False
    (offset, size) = procDict[pid]
    del procDict[pid]
    listHoles.append((offset, size))
    if (coalescence):
        do_coalescence()
    recalculate()

def setPolicy(npolicy):
    global policy
    policy = npolicy
    resort()

def utilization():
    global memorySize, memoryFree
    #recalculate()
    return (float(memorySize - memoryFree) / float(memorySize)) * 100

def memInfo():
    mused = round(utilization(), 3)
    frag = round(100 * indexFrag, 3)
    st = "Policy: " + policy
    st += " Holes:(max, min, sum) = " + str(maxHole) + ", " + str(minHole) + ", " + str(memoryFree)  
    st += " Memory:(used, frag) = "+ str(mused) + ", " + str(frag)
    print st
       
def memMap():
    memInfo()
    l = listHoles
    l.sort(key=lambda x:x[0])
    outDict = {}
    i = 0
    for e in l:
        outDict["EMP"+str(i)] = e
        i += 1
    for p in procDict.keys():
        outDict[p] = procDict[p]

    print "Policy:", policy , "Holes: ", l
    st = ""
    sorted_values = outDict.items()
    sorted_values.sort(key=lambda x:x[1][0])
    for k in sorted_values:
        (pid, (offset, size)) = k
        st += pid + ", " + str(offset) + ", " + str(size)+ ", " + str(offset+size)+"\n"
    print st

def memShow():
    memInfo()
    memMap()

#internals
def resort():
    if (policy == "FF"):
        listHoles.sort(key=lambda x:x[0])
    elif (policy == "BF"):
        listHoles.sort(key=lambda x:x[1])
    elif (policy == "WF"):
        listHoles.sort(reverse=True, key=lambda x:x[1])

def recalculate():
    global minHole, maxHole, memoryFree, indexFrag
    resort()
    maxHole = 0
    minHole = 10000000
    memoryFree = 0
    for h in listHoles:
        if (maxHole < h[1]):
            maxHole = h[1]
        if (minHole > h[1]):
            minHole = h[1]
        memoryFree += h[1]
    if (memoryFree > 0):
        indexFrag = float(1.0 - float(float(maxHole) / float(memoryFree)))       
    #print "maxHole: ", maxHole, " minHole: ", minHole, " total: ", memoryFree, " fragmentation: ", indexFrag

def do_coalescence():
    listHoles.sort(key=lambda x:x[0])
    holes = listHoles
    nholes = len(holes)
    n = nholes - 2
    while (n >= 0):
        if ((holes[n][0] + holes[n][1]) == holes[n+1][0]):
            elem = (holes[n][0], holes[n][1] + holes[n+1][1])
            holes.pop(n+1)
            holes.pop(n)
            holes.insert(n, elem)
            nholes -= 1
        n -= 1

