#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>

#define BLKSIZE 32
#define NEWFILE (O_WRONLY| O_CREAT)
#define MODE600 (S_IRUSR | S_IWUSR) 


int main(int argc, char *argv[]) {
  int fd;
  int count, nbytes, nbw;
  char buf[BLKSIZE];
  char fname[32] = "data.txt";

  strcpy(fname, "data.txt");
  count = 8 *1024;
  if (argc >= 2) {
      strcpy(fname, argv[1]);
  }
  if (argc == 3) {
      count = atoi(argv[2]) * 1024;
  }

  printf("file: %s  nbytes: %d \n", fname, count);
  fd =  open(fname, NEWFILE,MODE600);
  if (fd  == -1) {
    fprintf(stderr,"Could not open %s: %s\n", fname, strerror(errno));
    exit(1);
  }
  strcpy(buf, "0123456789abcdefghijklmnopqrst\n");
  nbytes = 0;
  while (nbytes <= count) {
      nbw = write(fd, buf, 32);
      if (nbw != 32){ 
        fprintf(stderr,"Could not write [err: %s]\n", strerror(errno));
      exit(1); }
      nbytes = nbytes + 32;
    }
    
  printf("Finished\n");
     sleep(100);
  close(fd);

  exit(0);
}
