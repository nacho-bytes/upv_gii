#include <sys/stat.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>

#define BLKSIZE 32
#define OLDFILE (O_RDONLY)
#define MODE600 (S_IRUSR | S_IWUSR) 

long getCurrentMicroseconds() {
	struct timespec currentTime;
	clock_gettime(CLOCK_MONOTONIC, &currentTime);
	return (currentTime.tv_sec)*1000000 + (currentTime.tv_nsec) / 1000;
}

int main(int argc, char *argv[]) {
  int fd;
  int count, nbytes, nbr;
  int i, n, p;
  char buf[BLKSIZE];
  char fname[32] = "data.txt";
  long start, finish, dif;
  long min = 100;
  long max = 0;

  strcpy(fname, "data.txt");
  count = 8 *1024;
  if (argc >= 2) {
      strcpy(fname, argv[1]);
  }


  printf("file: %s \n", fname);
  fd =  open(fname, OLDFILE,MODE600);
  if (fd  == -1) {
    fprintf(stderr,"Could not open %s: %s\n", fname, strerror(errno));
    exit(1);
  }
  nbytes = 0;
  n = 0;
  start = getCurrentMicroseconds();
  nbr = read(fd, buf, 1024);
  finish = getCurrentMicroseconds();
  dif = finish - start;
  while (nbr > 0) {
       nbytes = nbytes + 1024;
       if (n< 100) n++;
       start = getCurrentMicroseconds();
       nbr = read(fd, buf, 1024);
       finish = getCurrentMicroseconds();
       dif = finish - start;
       if (dif > max) {max = dif; p = n;}
       if (dif < min) min = dif;
    }
  
  printf("Finished nbytes read  %d\n", nbytes);
  close(fd);

  printf("min: %ld  max: %ld pos: %d\n", min, max, p);

  exit(0);
}
