public class Cilindro extends Circulo implements Volumen {
    protected double a;
 
    public Cilindro(double x, double y, double radio, double altura){
        super(x,y,radio);
        a = altura;
    }
 
    public Cilindro(Circulo c, double altura) {this(c.x, c.y, c.r, altura);}

    public double volumen() { return super.area()*a;}
    
    // public void ejemplo() {}
    
    public double superficie() {
        double perimetro = 2 * Math.PI * super.r;
        Rectangulo rAux = new Rectangulo(0,0,perimetro,this.a);
        return rAux.area() + 2 * super.area();
    }
    
    public double area() { return this.superficie(); }
    
}
