public class Circulo extends Figura {

    protected double r;

    public Circulo (double x, double y, double radio) {
        super.x = x;
        this.y = y;
        r= radio;
    }


    public String toString() {
        return "Círculo:\n\t"+super.toString()+"\n\tRadio: "+r;
    }
    
    public double area() { return Math.PI*r*r; }
    
    public boolean equals (Object o) {
        boolean iguales = false;
        if (o instanceof Circulo) {
            Circulo otro = (Circulo)o;
            iguales = this.x == otro.x &&
                      this.y == otro.y &&
                      this.r == otro.r;
        }
        return iguales;
    }    
}