public abstract class Figura{
    
    protected double x, y;  // Posición de la figura
    
    public String toString() {return "Posición: ("+x+", "+y+")";}
    
    public abstract double area();
    
    
}