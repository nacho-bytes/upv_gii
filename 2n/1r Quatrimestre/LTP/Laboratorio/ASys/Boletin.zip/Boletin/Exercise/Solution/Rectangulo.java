public class Rectangulo extends Figura{ 

    private double base, altura;

    public Rectangulo (double x, double y, double base, double altura){ 
        this.x = x; 
        this.y = y; 
        this.base= base; 
        this.altura=altura;
    } 

    public String toString (){ 
        return "Rectángulo:"+ "\n\tPosición("+x+","+y+ ")\n\tBase: "+base
            + "\n\tAltura: "+altura;
    }
    
    public double area() { return base*altura; }        
    
    public boolean equals (Object o) {
        boolean iguales = false;
        if (o instanceof Rectangulo) {
            Rectangulo otro = (Rectangulo)o;
            iguales = this.x == otro.x &&
                      this.y == otro.y &&
                      this.base == otro.base &&
                      this.altura == otro.altura;
        }
        return iguales;
    }        
}