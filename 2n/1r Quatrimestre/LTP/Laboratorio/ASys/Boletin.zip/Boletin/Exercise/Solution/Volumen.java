public interface Volumen{
    public double volumen();
    public double superficie();
}
