import java.lang.reflect.Field;

public class Test01
{
	public static double test(double radio, double altura) throws Throwable
	{
		final Circulo circulo = new Circulo(10, 5, radio);
		final Cilindro cilindro = new Cilindro(circulo, altura);

		return cilindro.volumen();
	}
}