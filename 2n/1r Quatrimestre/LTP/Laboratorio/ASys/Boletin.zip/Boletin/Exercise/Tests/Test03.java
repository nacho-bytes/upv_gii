import java.lang.reflect.Field;

public class Test03
{
	public static boolean test(double posX, double posY, double radio, double altura) throws Throwable
	{
		final Class<?> figuraClass = Figura.class;
		final Class<?> circuloClass = Circulo.class;
		final Class<?> cilindroClass = Cilindro.class;

		final Field xField = figuraClass.getDeclaredFields()[0]; //No sabemos el nombre del atributo
		final Field yField = figuraClass.getDeclaredFields()[1]; //No sabemos el nombre del atributo
		final Field radioField = circuloClass.getDeclaredFields()[0]; //No sabemos el nombre del atributo
		final Field alturaField = cilindroClass.getDeclaredFields()[0]; //No sabemos el nombre del atributo

		xField.setAccessible(true);
		yField.setAccessible(true);
		radioField.setAccessible(true);
		alturaField.setAccessible(true);

		final Circulo circulo = new Circulo(posX, posY, radio);
		final Cilindro cilindro = new Cilindro(circulo, altura);
		final double xValue = (Double) xField.get(cilindro);
		final double yValue = (Double) yField.get(cilindro);
		final double radioValue = (Double) radioField.get(cilindro);
		final double alturaValue = (Double) alturaField.get(cilindro);
		        
		return xValue == posX && yValue == posY && radioValue == radio && alturaValue == altura;
	}
}