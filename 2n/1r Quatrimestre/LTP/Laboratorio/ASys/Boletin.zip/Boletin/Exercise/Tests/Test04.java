import java.lang.reflect.Field;

public class Test04
{
	public static double test() throws Throwable
	{
		final GrupoFiguras grupoFiguras = new GrupoFiguras();
		final Circulo circulo = new Circulo(10, 5, 3.0);
		final Cilindro cilindro = new Cilindro(circulo, 5.0);
		final Circulo circulo2 = new Circulo(1.0, 2.0, 5);
		final Triangulo triangulo = new Triangulo(1.0, 2.0, 5, 8);		
		final Rectangulo rectangulo = new Rectangulo(1.0, 2.0, 5, 8);		
		
		grupoFiguras.anyadeFigura(circulo);
		grupoFiguras.anyadeFigura(cilindro);
		grupoFiguras.anyadeFigura(circulo2);
		grupoFiguras.anyadeFigura(triangulo);
		grupoFiguras.anyadeFigura(rectangulo);

		return grupoFiguras.volumen();
	}
}