import java.lang.reflect.Field;

public class Test06
{
	public static boolean test() throws Throwable
	{
		final Circulo circulo1 = new Circulo(10, 5, 1.0);
		final Circulo circulo2 = new Circulo(10, 5, 1.0);
		final Circulo circulo3 = new Circulo(10, 6, 1.0);		
		final Rectangulo rectangulo = new Rectangulo(10, 5, 1.0, 2.0);		
		
		return circulo1.equals(circulo2) 
		   && !circulo1.equals(circulo3)
		   && !circulo1.equals(rectangulo)
		   && !circulo1.equals(1.0);
	}
}