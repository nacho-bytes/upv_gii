import java.lang.reflect.Field;

public class Test07
{
	public static boolean test() throws Throwable
	{
		final Rectangulo rectangulo1 = new Rectangulo(10, 5, 1.0, 2.0);
		final Rectangulo rectangulo2 = new Rectangulo(10, 5, 1.0, 2.0);
		final Rectangulo rectangulo3 = new Rectangulo(10, 6, 1.0, 2.0);		
		final Circulo circulo = new Circulo(10, 5, 1.0);		
		
		return rectangulo1.equals(rectangulo2) 
		   && !rectangulo1.equals(rectangulo3)
		   && !rectangulo1.equals(circulo)
		   && !rectangulo1.equals(1.0);
	}
}