import java.lang.reflect.Field;

public class Test08
{
	public static boolean test() throws Throwable
	{
		final Triangulo triangulo1 = new Triangulo(10, 5, 1.0, 2.0);
		final Triangulo triangulo2 = new Triangulo(10, 5, 1.0, 2.0);
		final Triangulo triangulo3 = new Triangulo(10, 6, 1.0, 2.0);		
		final Circulo circulo = new Circulo(10, 5, 1.0);		
		
		return triangulo1.equals(triangulo2) 
		   && !triangulo1.equals(triangulo3)
		   && !triangulo1.equals(circulo)
		   && !triangulo1.equals(1.0);
	}
}