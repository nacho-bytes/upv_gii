import java.lang.reflect.Field;

public class Test09
{
	public static boolean test() throws Throwable
	{
		final GrupoFiguras g1 = new GrupoFiguras();
		final GrupoFiguras g2 = new GrupoFiguras();		
		final GrupoFiguras g3 = new GrupoFiguras();
				
		g1.anyadeFigura(new Circulo(10,5,3.5));
        g2.anyadeFigura(new Triangulo(10,5,6.5,32));
        
        if (g1.equals(g2) || g2.equals(g1)) {return false;};

		g2.anyadeFigura(new Circulo(10,5,3.5));

        if (g1.equals(g2) || g2.equals(g1)) {return false;};

        g1.anyadeFigura(new Triangulo(10,5,6.5,32));
          
        if (!g1.equals(g2) || !g2.equals(g1)) {return false;};
                        
        g3.anyadeFigura(new Rectangulo(10,5,6.50,320));
        g3.anyadeFigura(new Cilindro(10,5,6.50,36));
        g3.anyadeFigura(new Circulo(10,5,3.5));

        if (g1.equals(g3) || g3.equals(g1)) {return false;};

        g1.anyadeFigura(new Triangulo(10,5,6.5,32));
		g1.anyadeFigura(new Circulo(10,5,3.5));
		g1.anyadeFigura(new Circulo(10,5,3.5));
		g2.anyadeFigura(new Circulo(10,5,3.5));
          
        if (!g1.equals(g2) || !g2.equals(g1)) {return false;};

		return true;
	}
}