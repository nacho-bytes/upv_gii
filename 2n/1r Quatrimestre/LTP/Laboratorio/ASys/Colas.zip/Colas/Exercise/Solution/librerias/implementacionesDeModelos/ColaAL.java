
package librerias.implementacionesDeModelos;

import java.util.*;
/**
 *TAD de una cola implementado con un ArrayList
 * 
 * @author (Professors LTPP) 
 * @version (curso 2014-15)
 */
import librerias.modelos.Cola;

public class ColaAL <T> implements Cola<T> { 
  //Definicion de los atributos necesarios:
  ArrayList<T> elArray;
  
  
  /**Constructor de Cola */
  public ColaAL() {
    //COMPLETAR
    elArray = new ArrayList<T>();
  }//Fin del constructor ColaAC_ArrayList<T>
 
// Implementacion de las operaciones del TAD definido en la interfaz Pila <T>:
// Metodos modificadores del estado de una cola:
/** Inserta el Elemento e en una cola situandolo al final **/  
  public void encolar(T e){
   //COMPLETAR
   this.elArray.add(e);
  }//Fin del metodo void encolar(T)
  
  /** Consulta y extrae el primer elemento, solo si la cola no esta vacia.**/
  public T desencolar(){
    //COMPLETAR
    return this.elArray.remove(0);
  }//Fin del metodo T desencolar()
  
// Metodos consultores del estado de la cola
/** Devuelve la cantidad de elementos  de la cola **/
    public int talla(){
      //COMPLETAR
      return this.elArray.size();
  }//Fin del metodo T talla
  
  /** Solo si la cola no esta vacia, consulta el primer elemento en cabeza,
   * (el primero en orden de insercion) **/
  public T primero() {
     //COMPLETAR
     return elArray.get(0);
  }//Fin del metodo T primero()
  
  /** Comprueba si una cola esta vacia **/
  public boolean esVacia(){
    //COMPLETAR
    return this.elArray.isEmpty();
  }//Fin del metodo boolean esVacia()


  /** Devuelve el contenido de la cola con el formato 
       <-elem0<-elem1<-elem2<-...<-elemN<- donde N = talla()-1
       Cada elemi se devuelve con el formato que este definido para su tipo
       **/ 
 public String toString (){
    //COMPLETAR
    String res = "";
    int num = this.talla();
    for(int k=0; k<num; k++)
        res += "<-"+elArray.get(k);
    return res;
 }//Fin del metodo String toString()
}
