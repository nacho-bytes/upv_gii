import java.util.*;
/**
 * Write a description of interface Ordenadion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public interface Desplazamiento  
{   
    public void desplazaX(double x);
    public void desplazaY(double y);
    public void desplazaXY(double x, double y);
}
