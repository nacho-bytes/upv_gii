public abstract class Figura implements Desplazamiento{    
    protected double x, y; 
    
    public Figura (double x, double y) {
        this.x = x; 
        this.y = y; 
    }
    public String toString(){
     return "Posicion: ("+x+", "+y+")";}
     
     
    public abstract double area();

    public void desplazaX(double incX)
    {
        this.x +=incX;
    };
    
    public void desplazaY(double incY)
    {
        this.y +=incY;
    };    
    public void desplazaXY(double incX, double incY)
    {
        this.x +=incX;
        this.y +=incY;
    };

    
}