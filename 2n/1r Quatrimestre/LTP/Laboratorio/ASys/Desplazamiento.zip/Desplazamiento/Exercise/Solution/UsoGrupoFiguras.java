public class UsoGrupoFiguras {    
    public static void main (String args[]) {
        GrupoFiguras <Figura>g1 = new GrupoFiguras<Figura>();
        g1.anyadeFigura(new Circulo(2,3,5));
        g1.anyadeFigura(new Triangulo(6,7,2,3));
        g1.anyadeFigura(new Triangulo(6,7,2,3));
        System.out.println("Area = "+g1.area());
        System.out.println(g1);
        g1.desplazaXY(1,-1);
        System.out.println("\n"+g1);
        GrupoFiguras <Figura>g2 = new GrupoFiguras<Figura>();
        g1.anyadeFigura(new Circulo(-2,-3,5));
        g1.anyadeFigura(new Triangulo(-6,-7,2,3));
        g1.unir(g2);
        System.out.println("\n"+g1);

    }
}

/* RESULTADO DE LA EJECUCION:
 * Area = 81.53981633974483
Circulo:
	Posicion: (2.0, 3.0)
	Radio: 5.0
Triangulo:
	Posicion: (6.0, 7.0)
	Base: 2.0
	Altura: 3.0


Circulo:
	Posicion: (3.0, 2.0)
	Radio: 5.0
Triangulo:
	Posicion: (7.0, 6.0)
	Base: 2.0
	Altura: 3.0


Circulo:
	Posicion: (3.0, 2.0)
	Radio: 5.0
Triangulo:
	Posicion: (7.0, 6.0)
	Base: 2.0
	Altura: 3.0
Circulo:
	Posicion: (-2.0, -3.0)
	Radio: 5.0
Triangulo:
	Posicion: (-6.0, -7.0)
	Base: 2.0
	Altura: 3.0
*/