import java.lang.reflect.Field;

public class TestFiguraDesplazaXYMethod
{
	public static Boolean test(double posX, double posY, double despX, double despY) throws Throwable
	{
		final Circulo circulo = new Circulo(posX, posY, 2);
		circulo.desplazaXY(despX, despY);
		
		return circulo.x==posX+despX && circulo.y==posY+despY;
	}
}