import java.lang.reflect.Field;

public class TestFiguraDesplazaYMethod
{
	public static Double test(double posX, double posY, double desp) throws Throwable
	{
		final Circulo circulo = new Circulo(posX, posY, 2);
		circulo.desplazaY(desp);
		
		return circulo.y;
	}
}