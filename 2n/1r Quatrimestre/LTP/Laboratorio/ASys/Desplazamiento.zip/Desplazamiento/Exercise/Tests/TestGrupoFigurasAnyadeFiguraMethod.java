import java.lang.reflect.Field;

public class TestGrupoFigurasAnyadeFiguraMethod
{
	public static Boolean test() throws Throwable
	{
		final GrupoFiguras<Figura> grupoFiguras = new GrupoFiguras<Figura>();
				
		grupoFiguras.anyadeFigura(new Triangulo(0,0,1,3));
		if (grupoFiguras.area()!=1.5) return false;
		
		grupoFiguras.anyadeFigura(new Triangulo(0,0,1,3));
		if (grupoFiguras.area()!=1.5) return false;
		
		grupoFiguras.anyadeFigura(new Triangulo(0,0,2,2));
		if (grupoFiguras.area()!=3.5) return false;

		return true;
	}
}