import java.lang.reflect.*;
import java.util.ArrayList;

public class TestGrupoFigurasDesplazaXYMethod
{
	public static Boolean test() throws Throwable
	{
		final GrupoFiguras<Figura> grupoFiguras = new GrupoFiguras<Figura>();
		
		grupoFiguras.anyadeFigura(new Triangulo(0,0,1,3));
		grupoFiguras.anyadeFigura(new Triangulo(0,0,2,2));
		grupoFiguras.desplazaXY(1.0, 2.0);

//		Field field = grupoFiguras.getClass().getField("listaFiguras");
		final Field field = GrupoFiguras.class.getDeclaredField("listaFiguras");

		field.setAccessible(true);
		Object value = field.get(grupoFiguras);
		ArrayList<Figura> lista = (ArrayList<Figura>) value;
		//ArrayList<Figura> lista = (ArrayList<Figura>) field.get(grupoFiguras);
	
		return lista.get(0).x==1.0 && lista.get(0).y==2.0 &&
		       lista.get(1).x==1.0 && lista.get(1).y==2.0;
	}
}