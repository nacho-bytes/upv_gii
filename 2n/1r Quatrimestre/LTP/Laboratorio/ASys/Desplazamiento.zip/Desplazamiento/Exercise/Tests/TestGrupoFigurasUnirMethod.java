import java.lang.reflect.Field;

public class TestGrupoFigurasUnirMethod
{
	public static Boolean test() throws Throwable
	{
		final GrupoFiguras<Figura> grupoFiguras1 = new GrupoFiguras<Figura>();
		final GrupoFiguras<Figura> grupoFiguras2 = new GrupoFiguras<Figura>();

		grupoFiguras1.anyadeFigura(new Triangulo(0,0,1,3));
		grupoFiguras2.anyadeFigura(new Triangulo(0,0,2,2));

		grupoFiguras1.unir(grupoFiguras2);

		return grupoFiguras1.area()==3.5;
	}
}