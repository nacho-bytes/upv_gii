/**
 * Clase utilizada para representar un cubo.
 * 
 * @entity Universitat Politècnica de València
 * @author Josep Silva 
 * @version 12 Octubre 2014
 */

public class Cubo extends Cuadrado implements Volumen
{
    //Constructor
    public Cubo(double cx, double cy, double lado)
    {
        super(cx,cy,lado);
    }

    public double volumen()
    {
        return super.base*super.base*super.base;
    }    
}
