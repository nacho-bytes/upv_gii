
/**
 * Interfaz utilizada para representar figuras con volumen.
 * 
 * @entity Universitat Politècnica de València
 * @author Josep Silva 
 * @version 2 Octubre 2012
 */

public interface Volumen
{
    public double volumen();
}
