import java.lang.reflect.Field;

public class Test01
{
	public static double test(double lado, double altura) throws Throwable
	{
		final Cuadrado cuadrado = new Cuadrado(10, 5, lado);
		final PrismaCuadrangular prismaCuadrangular = new PrismaCuadrangular(cuadrado, altura);

		return prismaCuadrangular.volumen();
	}
}