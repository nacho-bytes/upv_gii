import java.lang.reflect.Field;

public class Test03
{
	public static boolean test(double posX, double posY, double lado, double altura) throws Throwable
	{
		final Class<?> figuraClass = Figura.class;
		final Class<?> rectanguloClass = Rectangulo.class;
		final Class<?> prismaCuadrangularClass = PrismaCuadrangular.class;

		final Field xField = figuraClass.getDeclaredField("x");
		final Field yField = figuraClass.getDeclaredField("y");
		final Field baseField = rectanguloClass.getDeclaredField("base");
		final Field alturaField = prismaCuadrangularClass.getDeclaredFields()[0];

		xField.setAccessible(true);
		yField.setAccessible(true);
		baseField.setAccessible(true);
		alturaField.setAccessible(true);

		final Cuadrado cuadrado = new Cuadrado(posX, posY, lado);
		final PrismaCuadrangular prismaCuadrangular = new PrismaCuadrangular(cuadrado, altura);
		final double xValue = (Double) xField.get(prismaCuadrangular);
		final double yValue = (Double) yField.get(prismaCuadrangular);
		final double baseValue = (Double) baseField.get(prismaCuadrangular);
		final double alturaValue = (Double) alturaField.get(prismaCuadrangular);

		return xValue == posX && yValue == posY && baseValue == lado && alturaValue == altura;
	}
}