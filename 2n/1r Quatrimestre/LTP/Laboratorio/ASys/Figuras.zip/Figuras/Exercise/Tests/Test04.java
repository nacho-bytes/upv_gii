import java.lang.reflect.Field;

public class Test04
{
	public static double test() throws Throwable
	{
		final GrupoFiguras grupoFiguras = new GrupoFiguras();
		final Cuadrado cuadrado = new Cuadrado(10, 5, 2);
		final PrismaCuadrangular prismaCuadrangular = new PrismaCuadrangular(cuadrado, 3);
		final Cubo cubo = new Cubo(2.3, 5.4, 5);
		final Circulo circulo = new Circulo(1.0, 2.0, 5);

		grupoFiguras.anyadeFigura(cuadrado);
		grupoFiguras.anyadeFigura(prismaCuadrangular);
		grupoFiguras.anyadeFigura(cubo);
		grupoFiguras.anyadeFigura(circulo);

		return grupoFiguras.volumen();
	}
}