public class Metodos
{
	public long factorial(int n)
	{
		if (n < 0)
			return -1;
		if (n <= 1)
			return n;
		return n * this.factorial(n - 1);
	}

	public int fibonacci(int indice)
	{
		if (indice <= 0)
			return -1;
		if (indice == 1)
			return 0;
		if (indice == 2)
			return 1;
		return this.fibonacci(indice - 1) + this.fibonacci(indice - 2);
	}

	public int sumaCuadrados(int[] numeros)
	{
		if (numeros.length == 0)
			return 0;

		int numero = numeros[0];
		int[] numeros2 = new int[numeros.length - 1];

		for (int indice = 1; indice < numeros.length; indice++)
			numeros2[indice - 1] = numeros[indice];

		return (numero * numero) + this.sumaCuadrados(numeros2);
	}

	public int nPrimes(int indice)
	{
		if (indice < 0)
			return -1;
		if (indice <= 2)
			return indice;

		int[] primosAnteriores = new int[indice - 2];

		for (int primo = 2; primo < indice; primo++)
			primosAnteriores[primo - 2] = this.nPrimes(primo);

		int ultimoPrimo = primosAnteriores[indice - 3];

		evaluarCandidato:
		for (int candidato = ultimoPrimo + 1; true; candidato++)
		{
			for (int primoAnterior : primosAnteriores)
				if (candidato % primoAnterior == 0)
					continue evaluarCandidato;
			return candidato;
		}
	}
}