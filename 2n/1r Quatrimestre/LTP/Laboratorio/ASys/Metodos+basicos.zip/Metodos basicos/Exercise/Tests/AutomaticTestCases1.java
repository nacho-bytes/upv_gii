// Class = Metodos
// Method = fibonacci(I)I

public class AutomaticTestCases1 {

    public boolean test1() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci(16);
        return int0 == 610;
    }
}