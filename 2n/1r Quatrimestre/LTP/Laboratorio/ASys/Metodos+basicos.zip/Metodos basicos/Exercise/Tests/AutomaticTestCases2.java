// Class = Metodos
// Method = factorial(I)J

public class AutomaticTestCases2 {

    public boolean test1() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(2);
        return long0 == 2;
    }

    public boolean test2() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(3);
        return long0 == 6;
    }

    public boolean test3() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(643);
        return long0 == 0;
    }

    public boolean test4() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(1120);
        return long0 == 0;
    }
}