// Class = Metodos
// Method = nPrimes(I)I

public class AutomaticTestCases3 {

	public boolean test1() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(3);
        return int0 == 3;
    }
}