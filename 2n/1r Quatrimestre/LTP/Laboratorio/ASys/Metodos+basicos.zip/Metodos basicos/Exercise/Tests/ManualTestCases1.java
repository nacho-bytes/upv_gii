public class ManualTestCases1 {

    public boolean test1() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci((-1920));
        return int0 == -1;
    }

    public boolean test2() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci((-1068));
        return int0 == -1;
    }

    public boolean test3() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci(0);
        return int0 == -1;
    }

    public boolean test4() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci(1);
        return int0 == 0;
    }

    public boolean test5() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci(2);
        return int0 == 1;
    }

	public boolean test10() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci(25);
        return int0 == 46368;
    }

    public boolean test11() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci(20);
        return int0 == 4181;
    }

    public boolean test12() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci(12);
        return int0 == 89;
    }

    public boolean test13() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci(22);
        return int0 == 10946;
    }

    public boolean test14() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci(10);
        return int0 == 34;
    }

    public boolean test15() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci(5);
        return int0 == 3;
    }

    public boolean test16() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci(6);
        return int0 == 5;
    }

    public boolean test17() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci(8);
        return int0 == 13;
    }

    public boolean test18() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.fibonacci(14);
        return int0 == 233;
    }
}