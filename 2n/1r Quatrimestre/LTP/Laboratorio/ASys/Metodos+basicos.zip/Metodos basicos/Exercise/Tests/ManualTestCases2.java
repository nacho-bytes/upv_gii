public class ManualTestCases2 {

    public boolean test1() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(-1567);
        return long0 == -1;
    }

    public boolean test2() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(-1);
        return long0 == -1;
    }

    public boolean test3() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(0);
        return long0 == 0;
    }

    public boolean test4() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(1);
        return long0 == 1;
    }

    public boolean test10() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(2);
        return long0 == 2;
    }

    public boolean test11() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(3);
        return long0 == 6;
    }

    public boolean test12() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(4);
        return long0 == 24;
    }

    public boolean test13() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(5);
        return long0 == 120;
    }

    public boolean test14() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(6);
        return long0 == 720;
    }

    public boolean test15() throws Throwable {
        Metodos metodos0 = new Metodos();
        long long0 = metodos0.factorial(7);
        return long0 == 5040;
    }
}