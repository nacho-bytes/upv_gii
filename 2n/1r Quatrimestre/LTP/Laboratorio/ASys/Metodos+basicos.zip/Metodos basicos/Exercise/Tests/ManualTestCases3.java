public class ManualTestCases3 {

    public boolean test1() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes((-963));
        return int0 == -1;
    }

    public boolean test2() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes((-263));
        return int0 == -1;
    }

    public boolean test3() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes((-101));
        return int0 == -1;
    }

    public boolean test4() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(0);
        return int0 == 0;
    }

    public boolean test5() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(1);
        return int0 == 1;
    }

    public boolean test6() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(2);
        return int0 == 2;
    }

    public boolean test10() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(1);
        return int0 == 1;
    }

    public boolean test11() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(2);
        return int0 == 2;
    }

    public boolean test12() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(3);
        return int0 == 3;
    }

    public boolean test13() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(4);
        return int0 == 5;
    }

    public boolean test14() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(5);
        return int0 == 7;
    }

    public boolean test15() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(6);
        return int0 == 11;
    }

    public boolean test16() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(7);
        return int0 == 13;
    }

    public boolean test17() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(8);
        return int0 == 17;
    }

    public boolean test18() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(9);
        return int0 == 19;
    }

    public boolean test19() throws Throwable {
        Metodos metodos0 = new Metodos();
        int int0 = metodos0.nPrimes(10);
        return int0 == 23;
    }
}