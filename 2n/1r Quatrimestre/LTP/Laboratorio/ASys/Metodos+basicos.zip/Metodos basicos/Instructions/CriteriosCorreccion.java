public class Metodos
{
    // Implementar un método que calcula el factorial de un número  (2 puntos)
    public long factorial(int n)
    {
        
        //IMPLEMENTAR AQUI
        
    }
    
    /* CRITERIOS DE CORRECCIÓN
     
     Superar caso de test 1: 0,5 puntos
     Superar caso de test 2: 0,5 puntos
     Superar caso de test 3: 0,5 puntos
     Superar caso de test 4: 0,5 puntos
     
     */
    
    
    // Implementar un método que calcula el enésimo número de Fibonacci (2 puntos)
    // Completar los subrayados con las palabras correspondientes
    public _ fibonacci(_ _)
    {
        
        //IMPLEMENTAR AQUI
        
    }
    
    /* CRITERIOS DE CORRECCIÓN
     
     Tipo devuelto por la función: 0,2 punto
     Tipo del parámetro formal de la función: 0,2 punto
     Nombre (cualquier identificador) del parámetro formal de la función: 0,1 punto
     Superar caso de test 1: 0,5 puntos
     Superar caso de test 2: 0,5 puntos
     Superar caso de test 3: 0,5 puntos
     
     */
    
    
    // Implementar un método que calcula el sumatorio de los cuadrados de todos los elementos de un array (3 puntos)
    // Completar los subrayados con las palabras correspondientes
    _ _ sumaCuadrados(_ _)
    {
        
        //IMPLEMENTAR AQUI
        
    }
    
    /* CRITERIOS DE CORRECCIÓN
     
     Visibilidad de la función (sirve cualquiera: public, private, protected): 0,2 punto
     Tipo devuelto por la función: 0,2 punto
     Tipo del parámetro formal de la función: 0,4 punto
     Nombre (cualquier identificador) del parámetro formal de la función: 0,2 punto
     Superar caso de test 1: 0,5 puntos
     Superar caso de test 2: 0,5 puntos
     Superar caso de test 3: 0,5 puntos
     Superar caso de test 4: 0,5 puntos
     
     */
    
    // Implementar un método que calcula el enésimo número primo                       (3 puntos)
    // El método debe llamarse "nPrimes" y recibe un único parámetro de tipo entero
    
    //IMPLEMENTAR AQUI
    
    
    /* CRITERIOS DE CORRECCIÓN
     
     Visibilidad de la función (sirve cualquiera: public, private, protected): 0,2 punto
     Tipo devuelto por la función: 0,2 punto
     Tipo del parámetro formal de la función: 0,4 punto
     Nombre (cualquier identificador) del parámetro formal de la función: 0,2 punto
     Superar caso de test 1: 0,5 puntos
     Superar caso de test 2: 0,5 puntos
     Superar caso de test 3: 0,5 puntos
     Superar caso de test 4: 0,5 puntos
     
     */
    
    
}


