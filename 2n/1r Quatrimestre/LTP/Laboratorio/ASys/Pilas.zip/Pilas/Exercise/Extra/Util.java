public class Util
{
	public static void error()
	{
		throw new RuntimeException("Error");
	}
}