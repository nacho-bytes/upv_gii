public class Hexaedro extends Poliedro {

   public Hexaedro (double x, double y, double arista) {
      super(x,y,arista);
   }
   
   public double area() {
      return 6 * Math.pow(a,2);
   }
    
   public double volumen() {
      return Math.pow(a,3);
   }
}
