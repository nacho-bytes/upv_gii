public abstract class Poliedro extends Figura implements Volumen {
    protected double a; // longitud de la arista de un poliedro regular
    
    public Poliedro (double x, double y, double arista) {
        super(x,y);
        a = arista;
    }
    
    public boolean soyPoliedro() {
        return true;
    }

}
