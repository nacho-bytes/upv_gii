public class Tetraedro extends Poliedro {

   public Tetraedro (double x, double y, double arista) {
      super(x,y,arista);
   }
   
   public double area() {
      return Math.pow(a,2)*Math.sqrt(3);
   }
    
   public double volumen() {
      return Math.pow(a,3)*Math.sqrt(2)/12;
   }
}
