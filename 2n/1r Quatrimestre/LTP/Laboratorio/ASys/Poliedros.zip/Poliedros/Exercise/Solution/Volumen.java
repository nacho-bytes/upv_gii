public interface Volumen {
   public double area();
   public double volumen();
   public boolean soyPoliedro();
}
