import java.lang.reflect.Field;

public class TestHexaedroAreaMethod
{
	public static double test(double posX, double posY, double arista) throws Throwable
	{
		final Hexaedro hexaedro = new Hexaedro(posX, posY, arista);

		return hexaedro.area();
	}
}