import java.lang.reflect.Field;

public class TestPoliedroSoyPoliedroMethod
{
	public static Boolean test(double posX, double posY, double arista) throws Throwable
	{
		try{
			final Tetraedro tetraedro = new Tetraedro(posX, posY, arista);
			return tetraedro.soyPoliedro();
		}catch(Exception e) { return false;}
	}
}