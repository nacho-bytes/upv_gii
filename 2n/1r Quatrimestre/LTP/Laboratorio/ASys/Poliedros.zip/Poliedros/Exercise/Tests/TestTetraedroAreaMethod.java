import java.lang.reflect.Field;

public class TestTetraedroAreaMethod
{
	public static double test(double posX, double posY, double arista) throws Throwable
	{
		final Tetraedro tetraedro = new Tetraedro(posX, posY, arista);

		return tetraedro.area();
	}
}