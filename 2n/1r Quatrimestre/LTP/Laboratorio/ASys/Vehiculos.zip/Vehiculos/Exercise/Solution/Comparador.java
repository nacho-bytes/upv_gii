
/**
 * Clase utilizada para comparar cosas que tengan posición (x,y).
 * 
 * @entity Universitat Politècnica de València
 * @author Josep Silva 
 * @version 1 Noviembre 2015
 */

public class Comparador<T extends Posicion>
{
    private T elemento1,elemento2;

    /**
     * Constructor for objects of class Comparador
     */
    public Comparador(T a, T b)
    {
        elemento1 = a;
        elemento2 = b;
    }

    /**
     * Comparador de posición
     */
    public boolean compararPosiciones()
    {
        return (elemento1.obtenerCoordenadaX() == elemento2.obtenerCoordenadaX() &&
                elemento1.obtenerCoordenadaY() == elemento2.obtenerCoordenadaY());
    }
}
