

/**
 * Interfaz utilizada para representar objetos que tienen una posición.
 * 
 * @entity Universitat Politècnica de València
 * @author Josep Silva 
 * @version 1 Noviembre 2015
 */

public interface Posicion
{
    public double obtenerCoordenadaX();
    public double obtenerCoordenadaY();
}
