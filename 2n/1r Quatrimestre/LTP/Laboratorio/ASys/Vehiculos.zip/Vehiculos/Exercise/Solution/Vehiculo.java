
/**
 * Clase utilizada para representar un vehículo.
 * 
 * @entity Universitat Politècnica de València
 * @author Josep Silva 
 * @version 1 Noviembre 2015
 */

public abstract class Vehiculo implements Posicion
{
    private double x,y;

    /**
     * Constructor for objects of class Vehículo
     */
    public Vehiculo(double coorX, double coorY)
    {
        this.x = coorX;
        this.y = coorY;
    }
    
    public double obtenerCoordenadaX(){return x;};
    public double obtenerCoordenadaY(){return y;};

}
