import java.lang.reflect.Field;

public class TestCocheConstructor
{
	public static boolean test(double posX, double posY, String marca) throws Throwable
	{
		final Class<?> vehiculoClass = Vehiculo.class;
		final Class<?> cocheClass = Coche.class;

        // Si supieramos el nombre del atributo sería así:
        // final Field yField = figuraClass.getDeclaredField("x");
		final Field xField = vehiculoClass.getDeclaredFields()[0];//No sabemos el nombre del atributo
		final Field yField = vehiculoClass.getDeclaredFields()[1];//No sabemos el nombre del atributo
		final Field marcaField = cocheClass.getDeclaredFields()[0];//No sabemos el nombre del atributo
		
		xField.setAccessible(true);
		yField.setAccessible(true);
		marcaField.setAccessible(true);

		final Coche coche = new Coche(posX, posY, marca);
		final double xValue = (Double) xField.get(coche);
		final double yValue = (Double) yField.get(coche);
		final String marcaValue = (String) marcaField.get(coche);

		return xValue == posX && yValue == posY && marcaValue == marca;
	}
}