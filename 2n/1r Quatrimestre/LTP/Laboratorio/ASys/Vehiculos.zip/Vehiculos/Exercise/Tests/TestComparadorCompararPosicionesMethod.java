
public class TestComparadorCompararPosicionesMethod
{
	public static Boolean test() throws Throwable
	{
		
		final Coche coche1 = new Coche(1,1,"Ford");
		final Coche coche2 = new Coche(5,3,"Peugeot");		
		final Comparador<Coche> comparador = new Comparador<Coche>(coche1,coche2);

		boolean resultadoCorrecto = (coche1.obtenerCoordenadaX() == coche2.obtenerCoordenadaX() &&
									 coche1.obtenerCoordenadaY() == coche2.obtenerCoordenadaY());
		
		return comparador.compararPosiciones() == resultadoCorrecto; 
	}
}