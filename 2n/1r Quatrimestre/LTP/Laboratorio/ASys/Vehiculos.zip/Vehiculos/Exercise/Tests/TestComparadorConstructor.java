import java.lang.reflect.Field;

public class TestComparadorConstructor
{
	public static boolean test() throws Throwable
	{
		final Class<?> comparadorClass = Comparador.class;

        // Si supieramos el nombre del atributo sería así:
        // final Field yField = figuraClass.getDeclaredField("x");
		final Field elemento1Field = comparadorClass.getDeclaredFields()[0];//No sabemos el nombre del atributo
		final Field elemento2Field = comparadorClass.getDeclaredFields()[1];//No sabemos el nombre del atributo
		
		elemento1Field.setAccessible(true);
		elemento2Field.setAccessible(true);

		final Coche coche1 = new Coche(1,1,"Ford");
		final Coche coche2 = new Coche(5,3,"Peugeot");
		final Comparador<Coche> comparador = new Comparador<Coche>(coche1, coche2);		
		final Coche elemento1Value = (Coche) elemento1Field.get(comparador);
		final Coche elemento2Value = (Coche) elemento2Field.get(comparador);

		return elemento1Value.equals(coche1) && elemento2Value.equals(coche2);
	}
}