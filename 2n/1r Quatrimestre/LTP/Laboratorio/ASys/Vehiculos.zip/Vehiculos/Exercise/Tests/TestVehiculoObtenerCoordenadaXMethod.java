
public class TestVehiculoObtenerCoordenadaXMethod
{
	public static Double test(double posX, double posY) throws Throwable
	{
		final Coche coche = new Coche(posX, posY, "Nissan");
		
		return coche.obtenerCoordenadaX();
	}
}