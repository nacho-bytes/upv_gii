package LTP;

public class Herencia
{
	public static void main(String args[])
	{
		A a = new A();
		B b = new B();
		
		a.imprimir();
		b.imprimir();
	}
}



class A {
     int x=1;
     
     void imprimir()
     {
    	 System.out.println("A: "+x);
     }
}


class B extends A {   //Herencia
    int x=2;
    
    void imprimir()   //Sobreescritura
    {
   	 System.out.println("B: "+x);
   	 System.out.println("B: "+super.x);
   	 System.out.print("B: ");super.imprimir();  //Aunque el método imprimir() de A ha sido sobreescrito, puede usarse llamando a super
    }
}
