package LTP;

class UsoInterfaz implements Mi_Interfaz
{
	@Override
	public int sumar(int x, int y) {
		return x+y;
	}

	public static void main(String[] args) {
		UsoInterfaz ui = new UsoInterfaz();
	    
		int suma1 = ui.sumar(1,1);                   //Llamada dinámica a método de la clase
	    int suma2 = Mi_Interfaz.sumarEstatico(1,1);  //Llamada estática a método de la interfaz
	    
	    System.out.println(suma1);
	    System.out.println(suma2);
	}	
	
}


interface Mi_Interfaz {

	int atributo=5;
	
	int sumar(int x, int y);
	
	static int sumarEstatico(int x, int y){return x+y+atributo;};	
}
