package paquete2;

import paquete1.Visibilidad;

class DistintoPaquete {
	
	public static void main(String[] args)
	{
		Visibilidad ltp = new Visibilidad();
		
		System.out.print(ltp.a);   // Distinto paquete: SI tengo acceso a variable public
      //System.out.print(ltp.b);   // Distinto paquete: NO tengo acceso a variable protected
	  //System.out.print(ltp.c);   // Distinto paquete: NO tengo acceso a variable default
      //System.out.print(ltp.d);   // Distinto paquete: NO tengo acceso a variable private
	}
}

class DistintoPaqueteYSubclase extends Visibilidad{
	
	public void main(String[] args)
	{
		Visibilidad ltp = new Visibilidad();
		
		System.out.print(ltp.a);   // Distinto paquete y subclase: SI tengo acceso a variable public
	    System.out.print(ltp.b);   // Distinto paquete y subclase: SI tengo acceso a variable protected
      //System.out.print(ltp.c);   // Distinto paquete y subclase: NO tengo acceso a variable default
      //System.out.print(ltp.d);   // Distinto paquete y subclase: NO tengo acceso a variable private
	}
}