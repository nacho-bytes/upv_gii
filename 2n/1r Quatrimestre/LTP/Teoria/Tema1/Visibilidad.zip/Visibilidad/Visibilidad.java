package paquete1;

public class Visibilidad {

	public int a = 1;     // Variable public
	protected int b = 2;  // Variable protected
    int c = 3;            // Variable default
    private int d = 4;    // Variable private

	public void main(String[] args)
	{
		System.out.print(a);   // Misma clase: SI tengo acceso a variable public
		System.out.print(b);   // Misma clase: SI tengo acceso a variable protected
		System.out.print(c);   // Misma clase: SI tengo acceso a variable default
		System.out.print(d);   // Misma clase: SI tengo acceso a variable private    
	}    
}

class MismoPaquete {
	
	public static void main(String[] args)
	{
		Visibilidad ltp = new Visibilidad();
		
		System.out.print(ltp.a);   // Mismo paquete: SI tengo acceso a variable public
		System.out.print(ltp.b);   // Mismo paquete: SI tengo acceso a variable protected
		System.out.print(ltp.c);   // Mismo paquete: SI tengo acceso a variable default
      //System.out.print(ltp.d);   // Mismo paquete: NO tengo acceso a variable private
	}
}

class MismoPaqueteYSubclase extends Visibilidad{
	
	public void main(String[] args)
	{
		Visibilidad ltp = new Visibilidad();

		//SUBCLASE
		System.out.print(a);   // Mismo paquete y subclase: SI tengo acceso a variable public
		System.out.print(b);   // Mismo paquete y subclase: SI tengo acceso a variable protected
		System.out.print(c);   // Mismo paquete y subclase: SI tengo acceso a variable default
        System.out.print(d);   // Mismo paquete y subclase: NO tengo acceso a variable private

		//MISMO PAQUETE
		System.out.print(ltp.a);   // Mismo paquete y subclase: SI tengo acceso a variable public
		System.out.print(ltp.b);   // Mismo paquete y subclase: SI tengo acceso a variable protected
		System.out.print(ltp.c);   // Mismo paquete y subclase: SI tengo acceso a variable default
      //System.out.print(ltp.d);   // Mismo paquete y subclase: NO tengo acceso a variable private
	}
}