import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

class ServidorEco  {
    static public void main (String args[]) {
       if (args.length!=1) {
            System.err.println("Uso: ServidorEco numPuertoRegistro");
            return;
        }
       
        try {
         
            Registry reg=LocateRegistry.getRegistry(args[0], Integer.parseInt(args[1]));
            ServicioEcoImpl srv = new ServicioEcoImpl();
            reg.rebind("Eco",srv);
            System.out.println("Servidor en marcha");
        }
        catch (RemoteException e) {
            System.err.println("Error de comunicacion: " + e.toString());
            System.exit(1);
        }
        catch (Exception e) {
            System.err.println("Excepcion en ServidorEco:");
            e.printStackTrace();
            System.exit(1);
        }
    }
}
