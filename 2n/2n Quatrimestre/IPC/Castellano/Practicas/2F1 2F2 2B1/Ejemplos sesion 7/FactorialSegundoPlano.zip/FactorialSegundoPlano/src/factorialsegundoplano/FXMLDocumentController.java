/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorialsegundoplano;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;

/**
 *
 * @author jsanchez
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private TextField numero;
    @FXML
    private TextField resultado;
    
    private Factorial miTarea;
    @FXML
    private ProgressBar barraProgreso;
    @FXML
    private Button BotonCalcular;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void bCalcular(ActionEvent event) {
        
    Long factorial;
   // no se comprueban errores de formato en el número introducido
   factorial = Long.parseLong(this.numero.getText()); 
   miTarea = new Factorial(factorial);       
   resultado.textProperty().bind(Bindings.convert(miTarea.valueProperty()));
   barraProgreso.progressProperty().bind(miTarea.progressProperty());
   resultado.visibleProperty().bind(Bindings.not(miTarea.runningProperty())); 
   // texto resultado deshabilitado
   BotonCalcular.disableProperty().bind(miTarea.runningProperty()); 

   Thread th = new Thread(miTarea);
   th.setDaemon(true);
   th.start();
        
    }

    @FXML
    private void bCancelar(ActionEvent event) {
        miTarea.cancel();
    }

    @FXML
    private void bSalir(ActionEvent event) {
        Platform.exit();
    }
    
}
