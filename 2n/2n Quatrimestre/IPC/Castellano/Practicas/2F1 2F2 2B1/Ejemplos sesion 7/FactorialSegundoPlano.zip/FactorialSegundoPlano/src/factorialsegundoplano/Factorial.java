/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorialsegundoplano;

import javafx.concurrent.Task;

/**
 *
 * @author jsanchez
 */
class Factorial extends Task<Long> {

        private Long calculaFactorial; //valor para el que se calcula el factorial
        public Factorial() { }
        public Factorial(Long valor) { calculaFactorial = valor; }
        
        @Override
        protected Long call() throws Exception {
            long f = 1;
            for (long i = 2; i <= calculaFactorial; i++) {
              if (isCancelled()) {
                break;
              }
              f = f * i;
              updateProgress(i, calculaFactorial);
              try { Thread.sleep(100); } 
              catch (InterruptedException e) { if (isCancelled()) break; }
            }
            return f;
            }
}

    

