/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gridcirculo;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Circle;

/**
 *
 * 
 */
public class FXMLDocumentController implements Initializable {
    protected final int numFilas = 5;
    protected final int numColumnas = 5;
    
   
    @FXML
    private GridPane gridPane;
    @FXML
    private Circle CirculoFXID;
    
   
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
   
		EventHandler<KeyEvent> mimanejador = new EventHandler<KeyEvent>(){
			@Override
			public void handle(KeyEvent event) {
				// TODO Auto-generated method stub
				System.out.println("Evento detectado " + event.getEventType().toString());
				
			} };
		
		gridPane.addEventHandler(KeyEvent.ANY, mimanejador);
		
		// TODO Auto-generated method stub
		ChangeListener<? super Number> listenerAnchura = new ChangeListener<Number>(){
			@Override
			public void changed(ObservableValue<? extends Number> arg0, Number antiguo, Number nuevo) {
				// TODO Auto-generated method stub
				double anchura = (nuevo.doubleValue()/numColumnas)/2;         // esto es el radio horizontal
				double alturarejilla = (gridPane.getHeight()/numFilas)/2;    // radio en vertical
				// mínimo de los dos.
				double min = (anchura < alturarejilla) ? anchura : alturarejilla;
				CirculoFXID.setRadius(min);
			} 

                    
                };
		
			
			ChangeListener<? super Number> listenerAltura = new ChangeListener<Number>(){
				@Override
				public void changed(ObservableValue<? extends Number> arg0, Number antiguo, Number nuevo) {
					// TODO Auto-generated method stub
					double altura = (nuevo.doubleValue()/numFilas)/2;   // nuevo radio en altura
					double anchurarejilla = (gridPane.getWidth()/numColumnas)/2; // radio en horizontal
					double min = (altura< anchurarejilla)? altura: anchurarejilla;
					CirculoFXID.setRadius(min);
				} };	
			
		gridPane.widthProperty().addListener(listenerAnchura);
		gridPane.heightProperty().addListener(listenerAltura);
    }  

        
    // tecla presionada, keypressed
    @FXML
    private void teclaPulsada(KeyEvent event) {
    int filaActual = GridPane.getRowIndex(CirculoFXID);
    int columnaActual = GridPane.getColumnIndex(CirculoFXID);
        System.out.println("Tecla pulsada " + event.getCode());
        switch(event.getCode()) {
            case UP: if (filaActual -1 >= 0) GridPane.setRowIndex(CirculoFXID, --filaActual); break;
            case DOWN: if (filaActual +1 <= numFilas -1) GridPane.setRowIndex(CirculoFXID, ++filaActual); break;
            case RIGHT: if (columnaActual +1 <= numColumnas -1) GridPane.setColumnIndex(CirculoFXID, ++columnaActual); break;
            case LEFT: if (columnaActual -1 >= 0) GridPane.setColumnIndex(CirculoFXID, --columnaActual); break;
            default: break;            
        }
        event.consume();
    }

    
    
}
