/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tresenraya;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;

/**
 *
 * @author Juan
 */
public class FXMLDocumentController implements Initializable {
    
    
    @FXML
    private HBox hBox;  // zona superior de la ventana
    @FXML
    private TextField textField1; // puntuaacion jugador 1
    @FXML
    private TextField textField2; // puntuación jugador 2
    @FXML
    private Button B00;
    @FXML
    private Button B01;
    @FXML
    private Button B02;
    @FXML
    private Button B10;
    @FXML
    private Button B11;
    @FXML
    private Button B12;
    @FXML
    private Button B20;
    @FXML
    private Button B21;
    @FXML
    private Button B22;
    @FXML
    private Button bReset;
    @FXML
    private Button bEmpezar;
    @FXML
    private GridPane gridJuego; // el grid con los botones del juego.
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        // Poner borde al hBox inyectado
        // 1. Por código
        // hBox.setBorder(new Border(new BorderStroke(Color.BLACK,BorderStrokeStyle.SOLID, null,new BorderWidths(3))));
        // 2. En CSS Dibuja el borde externo del marcador
        hBox.setStyle("-fx-border-color: black;"+"-fx-border-width: 3;");  // equivalente a lo de arriba.
        // Inicializar a vacío el contenido de los botones.
        // a veces falla el scene builder y no situa correctamente los botones en la fila, columna.
        // lo ponemos por código aquí.
        GridPane.setRowIndex(B00, 0);
        GridPane.setRowIndex(B01, 0);
        GridPane.setRowIndex(B02, 0);
        GridPane.setRowIndex(B10, 1);
        GridPane.setRowIndex(B11, 1);
        GridPane.setRowIndex(B12, 1);
        GridPane.setRowIndex(B20, 2);
        GridPane.setRowIndex(B21, 2);
        GridPane.setRowIndex(B22, 2);
        GridPane.setColumnIndex(B00, 0);
        GridPane.setColumnIndex(B01, 1);
        GridPane.setColumnIndex(B02, 2);
        GridPane.setColumnIndex(B10, 0);
        GridPane.setColumnIndex(B11, 1);
        GridPane.setColumnIndex(B12, 2);
        GridPane.setColumnIndex(B20, 0);
        GridPane.setColumnIndex(B21, 1);
        GridPane.setColumnIndex(B22, 2);  
        // Inicializamos el contenido de cada botón al string vacío.
        gridJuego.getChildren().forEach((Node nodo) -> {
            if(nodo instanceof  Button){
                ((Button)nodo).setText("");
            }
        });
        // no permitir la edición de los campos de marcador de cada jugador
        textField1.setEditable(false);
        textField2.setEditable(false);
        
        
    }    
    
}
