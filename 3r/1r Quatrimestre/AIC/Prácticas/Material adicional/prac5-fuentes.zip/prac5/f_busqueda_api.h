 void fase_IF (void);
