 void cancelar_instrucciones (void);
 boolean prediccion_correcta (void);
 void fase_COM (void);
