/* f_transferencia_alum.c */
 void fase_WB_alum (void);
