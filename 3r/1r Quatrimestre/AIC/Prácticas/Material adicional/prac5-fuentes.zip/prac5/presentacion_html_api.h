 void init_instruc_html ( 
	dword PC,
	ciclo_t orden
	 );
 void muestra_fase_html ( 
	char *fase,
	ciclo_t orden,
	boolean exception
	 );
 void imprime_inicio_html (void);
 void imprime_final_html (void);
 void imprime_estado_html (void);
 void imprime_crono_html (void);
 void imprime_predictor_html (void);
