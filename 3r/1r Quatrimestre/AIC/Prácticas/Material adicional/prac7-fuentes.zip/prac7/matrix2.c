#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <string.h>

#define NMAX 1024

void multMat_ijk( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* ijk */
    
              /* INSERTAR CÓDIGO */

}

void multMat_ikj( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* ikj */
    
              /* INSERTAR CÓDIGO */

}

void multMat_jik( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* jik */
    
              /* INSERTAR CÓDIGO */

}

void multMat_jki( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* jki */
    
              /* INSERTAR CÓDIGO */

}

void multMat_kij( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* kij */
    
              /* INSERTAR CÓDIGO */

}

void multMat_kji( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* kji */
    
              /* INSERTAR CÓDIGO */

}

int main( int argc, char **argv ) {
    int i,n;

    void (*orderings[])(int,float *,float *,float *) = {&multMat_ijk,&multMat_ikj,&multMat_jik,&multMat_jki,&multMat_kij,&multMat_kji};
    char *names[] = {"ijk","ikj","jik","jki","kij","kji"};

    float *A = (float *)malloc( NMAX*NMAX * sizeof(float));
    float *B = (float *)malloc( NMAX*NMAX * sizeof(float));
    float *C = (float *)malloc( NMAX*NMAX * sizeof(float));

    struct timeval start, end;

    for( i = 0; i < NMAX*NMAX; i++ ) A[i] = drand48()*2-1;
    for( i = 0; i < NMAX*NMAX; i++ ) B[i] = drand48()*2-1;
    for( i = 0; i < NMAX*NMAX; i++ ) C[i] = drand48()*2-1;

    for( i = 0; i < 6; i++) {

        gettimeofday( &start, NULL );
        (*orderings[i])( NMAX, A, B, C );
        gettimeofday( &end, NULL );

        double seconds = (end.tv_sec - start.tv_sec) + 1.0e-6 * (end.tv_usec - start.tv_usec);
        double Gflops = 2e-9*NMAX*NMAX*NMAX/seconds;    
        printf( "%s:\tn = %d, %.3f Gflop/s\n", names[i], NMAX, Gflops );
    }

    free( A );
    free( B );
    free( C );

    printf("\n\n");

    return 0;
}
