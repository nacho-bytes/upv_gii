﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EcoScooter.Entities
{
    public partial class EcoScooter
    {
        public EcoScooter()
        {
            People = new List<Person>();
            Employees = new List<Employee>();
            Scooters = new List<Scooter>();
            Stations = new List<Station>();
        }

        public EcoScooter(Double discountYounger, Double fare, Double maxSpeed, Employee employee) : this()
        {
            DiscountYounger = discountYounger;
            Fare = fare;
            MaxSpeed = maxSpeed;
            Employees.Add(employee);
            People.Add(employee);

        }
        /// <summary>
        /// Searchs for an employee with the provided dni. If it exits, returns true and the employee found. False and null otherwise
        /// </summary>
        /// <param name="dni"></param>       
        /// <param name="foundEmployee"></param>
        /// <returns>True and employee 
        /// False and null</returns>
        public bool ExistsEmployee(string dni, out Employee foundEmployee)
        {
            foundEmployee = null;
            foreach (Employee employee in Employees)
            {
                if (employee.EqualsDni(dni))
                {
                    foundEmployee = employee;
                    return true;
                }

            }
            return false;
        }
        /// <summary>
        /// Searchs for an employee with the provided dni and pin. If it exits, returns true and the employee found. False and null otherwise
        /// </summary>
        /// <param name="dni"></param>       
        /// <param name="foundEmployee"></param>
        /// <returns>True and employee or 
        /// False and null</returns>
        public bool ExistsEmployee(string dni, int pin, out Employee foundEmployee)
        {
            if (ExistsEmployee(dni, out foundEmployee))
                return foundEmployee.EqualsPin(pin);
            else
                return false;

        }

        public bool ExistsLogin(string login)
        {
            foreach (Person person in People)
            {
                if (person is User)
                {
                    if ((person as User).EqualsLogin(login))
                        return true;
                }
            }
            return false;

        }
        public bool ExistsUser(string login, string password, out User userFound)
        {
            userFound = null;

            foreach (Person person in People)
            {
                if (person is User)
                {
                    if ((person as User).EqualsLoginData(login, password))
                    {
                        userFound = (person as User);
                        return true;
                    }
                }
            }
            return false;
        }

        public bool ExistsPerson(string dni)
        {
            foreach (Person person in People)
            {
                if (person.EqualsDni(dni))
                    return true;

            }
            return false;
        }

        public void AddUser(DateTime birthDate, string dni, string email, string name, int telephon, int cvv, DateTime expirationDate, string login, int number, string password)
        {
            User user = new User(birthDate, dni, email, name, telephon, cvv, expirationDate, login, number, password);
            People.Add(user);
        }
        public bool ExistsStation(string id)
        {

            foreach (Station station in Stations)
            {
                if (station.EqualsId(id))
                    return true;
            }
            return false;
        }
        public bool ExistsStation(string id, out Station stationFound)
        {
            stationFound = null;
            foreach (Station station in Stations)
            {
                if (station.EqualsId(id))
                {
                    stationFound = station;
                    return true;

                }

            }
            return false;
        }

        public void AddStation(string address, double latitude, double longitude, string stationId)
        {
            Station station = new Station(address, stationId, latitude, longitude);
            this.Stations.Add(station);

        }
        public void AddScooter(DateTime registerDate, ScooterState state, Station station)
        {
            Scooter scooter = new Scooter(registerDate, state);
            scooter.Station = station;
            station.Scooters.Add(scooter);
            this.Scooters.Add(scooter);
        }
        public void AddScooter(DateTime registerDate, ScooterState state)
        {
            Scooter scooter = new Scooter(registerDate, state);
            this.Scooters.Add(scooter);
        }
        //User, Station and Scooter must belong to EcoScooter object.
        public void RentScooter(User user, Station station, Scooter scooter)
        {
            Rental rental = new Rental(null, 0, DateTime.Now, station, scooter, user);
            user.AddRental(rental);
            scooter.MarkInUse();
            scooter.RemoveAnchor();
            scooter.AddRental(rental);
            station.AddOriginRentals(rental);
            station.RemoveScooterAnchor(scooter);

        }

        public void FinishRental(Rental rental, Station station, bool applyDiscount)
        {   if(applyDiscount)
                rental.FinishRental(station, this.Fare,this.DiscountYounger);
            else 
                rental.FinishRental(station, this.Fare);
        }

    }
}
                                    