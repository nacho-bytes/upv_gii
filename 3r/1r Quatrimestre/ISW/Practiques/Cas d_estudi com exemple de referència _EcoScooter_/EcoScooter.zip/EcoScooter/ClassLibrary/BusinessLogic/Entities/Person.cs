﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EcoScooter.Entities
{   
    public partial class Person
    {
        protected static readonly int EQUAL_DATE = 0;
        private static readonly int OVER_AGE = 16;
        private static readonly int YOUNG_AGE = 25;

        //constructors
        public Person() { 
        }
        public Person(DateTime birthDate, String dni, String email, String name, int telephon) {
            Birthdate = birthDate;
            Dni = dni;
            Email = email;
            Name = name;
            Telephon = telephon;
        }
        /// <summary>
        /// Returns true if dni is equal to Dni property of the object
        /// </summary>
        /// <param name="dni"></param>
        /// <returns></returns>
        public bool EqualsDni(string dni)
        {
            return this.Dni.Equals(dni);

        }
        public static bool IsYounger(DateTime birthDate)
        {
            DateTime intervalDate = birthDate.AddYears(YOUNG_AGE);
            if (DateTime.Now.CompareTo(intervalDate)<= EQUAL_DATE)
                return true;
            else
                return false;
        }
        public bool IsYounger()
        {
            return IsYounger(this.Birthdate);

        }
        public static bool IsOverAge(DateTime birthDate)
        {
            DateTime intervalDate = birthDate.AddYears(OVER_AGE);
            if (DateTime.Now.CompareTo(intervalDate) >= EQUAL_DATE)
                return true;
            else
                return false;

         
        }

        public bool IsOverAge()
        {
            return IsOverAge(this.Birthdate);
        }

       
    }
}
