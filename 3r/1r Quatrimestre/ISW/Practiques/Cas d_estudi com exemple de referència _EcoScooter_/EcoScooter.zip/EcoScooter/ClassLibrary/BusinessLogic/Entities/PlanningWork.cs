﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EcoScooter.Entities
{
    public partial class PlanningWork
    {
        public PlanningWork()
        {

        }

        public PlanningWork(string description, int workingTime, Maintenance maintenance, Scooter scooter) 
        {
            Description = description;
            WorkingTime = workingTime;
            Scooter = scooter;
            Maintenance = maintenance;

        }
    }
}
