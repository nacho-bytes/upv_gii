﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EcoScooter.Entities
{
    public partial class Rental
    {
        protected static readonly int EQUAL_DATE = 0;
    public Rental()
        {
            TrackPoints = new List<TrackPoint>();
        }

        public Rental(DateTime? endDate,  Decimal price, DateTime startDate, Station originStation, Scooter scooter, User user) : this()
        {
            EndDate = endDate;

            Price = price;
            StartDate = startDate;
            OriginStation = originStation;
            Scooter = scooter;
            User = user;
        }
        public void RentalPrice(double fare)
        {
            if (this.EndDate != null)
            {
               this.Price = Convert.ToDecimal(this.EndDate.Value.Subtract(this.StartDate).TotalMinutes * fare);
            }
        }
        public void RentalPrice(double fare, double discount)
        {
            RentalPrice(fare);
            //Apply discount
            
            this.Price = this.Price- Convert.ToDecimal(Convert.ToDouble(Price) * discount / 100);
        }
        public void FinishRentalNoPrice(Station destStation)
        {
            this.Scooter.MakeAvailable();
            this.Scooter.AddAnchor(destStation);
            this.DestinationStation = destStation;
            this.EndDate = DateTime.Now;
           

        }
        public void FinishRental(Station destStation, double fare)
        {
            FinishRentalNoPrice(destStation);
            this.RentalPrice(fare);

        }
        public void FinishRental(Station destStation, double fare, double discount)
        {
            FinishRentalNoPrice(destStation);
            this.RentalPrice(fare,discount);

        }
        public void AddIncident(string description, DateTime timeStamp)
        {
            Incident incident = new Incident(description, timeStamp);
            this.Incident=incident;
        }
        public static bool ValidInterval(DateTime startDate, DateTime endDate)
        {
            return (endDate.CompareTo(startDate) >= EQUAL_DATE);
        }
        public void GetRouteDescription(out DateTime startDate, out DateTime endDate, out decimal price, out string originStationId, out string destinationStationId)
        {
            startDate = this.StartDate;
            endDate = Convert.ToDateTime( this.EndDate);
            price = this.Price;
            originStationId = this.OriginStation.Id;
            destinationStationId = this.OriginStation.Id;
        }


    }
}
