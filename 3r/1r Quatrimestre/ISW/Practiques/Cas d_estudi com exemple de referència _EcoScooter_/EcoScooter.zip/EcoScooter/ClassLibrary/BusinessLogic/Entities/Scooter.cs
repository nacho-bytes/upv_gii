﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EcoScooter.Entities
{
    public partial class Scooter
    {
        protected static readonly int EQUAL_DATE = 0;
        public Scooter()
        {
            Rentals = new List<Rental>();
            PlanningWork = new List<PlanningWork>(); //ojo, en el diagrama de diseño teníamos mal el nombre de rol.
        }
        public Scooter( DateTime registerDate, ScooterState state) : this()
        {

            RegisterDate = registerDate;
            State = state;

        }
        public static bool GoodRegisterDate(DateTime registerDate)
        {
            return (DateTime.Now.CompareTo(registerDate) >= EQUAL_DATE); //registerDAte in the past


        }
        public  bool GoodRegisterDate()
        {
            return GoodRegisterDate(this.RegisterDate);


        }
        public void MakeAvailable()
        {
            this.State = ScooterState.available;
        }
        public void MarkInUse()
        {
            this.State = ScooterState.inUse;
        }
        public void AddRental(Rental rental)
        {
            this.Rentals.Add(rental);
        }
        public void RemoveAnchor()
        {
            this.Station = null;
        }
        public void AddAnchor(Station station)
        {
            this.Station = station;
        }
    }
}
