﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EcoScooter.Entities
{
    public partial class Station
    {
        public static readonly int MAX_LATITUDE = 90;
        public static readonly int MAX_LONGITUDE = 180;


        public Station()
        {
            OriginRentals = new List<Rental>();
            DestinationRentals = new List<Rental>();
            Scooters = new List<Scooter>();
        }

        public Station(string address, string id, Double latitude, Double longitude) :this()
        {
            Address = address;
            Id = id;
            Latitude = latitude;
            Longitude = longitude;            
        }
        public static bool GoodLatitude(double latitude)
        {
            return ((latitude >= -MAX_LATITUDE) && (latitude <= MAX_LATITUDE));
         
        }
        public bool GoodLatitude()
        {
            return GoodLatitude(this.Latitude);
        }
        public static bool GoodLongitude(double longitude)
        {
            return ((longitude >= -MAX_LONGITUDE) && (longitude <= MAX_LONGITUDE));

        }
        public  bool GoodLongitude()
        {
            return GoodLongitude(this.Longitude);

        }
        public static bool GoodAddress(string address)
        {
            //No empty....more rules?
            return (address.Length > 0);
        }
        public bool EqualsId(string id)
        {
            return this.Id.Equals(id);
        }
        public bool AvailableScooters(out Scooter scooterAvailable)
        {
            scooterAvailable = null;
            if (Scooters.Count>0)
            {
                scooterAvailable = Scooters.First();
                return true;
            }
                       
            return false;
        }
        public void  AddOriginRentals(Rental rental)
        {
            this.OriginRentals.Add(rental);
        }
        public bool RemoveScooterAnchor(Scooter scooter)
        {  
            return this.Scooters.Remove(scooter);
        }


    }
}
