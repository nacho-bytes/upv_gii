﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EcoScooter.Entities
{
    public partial class User
    {
        public static readonly int NUM_DIGITS = 8;
        public static readonly int NUM_DIGITS_CVV = 3;
        public User() : base() {
            Rentals = new List<Rental>();
        }
        public User(DateTime birthDate, String dni, String email, String name, int telephon, int cvv, DateTime expirationDate, string login, int number, string password) : base(birthDate, dni, email, name, telephon)
        {
            Cvv = cvv;
            ExpirationDate = expirationDate;
            Login = login;
            Number = number;
            Password = password;
            Rentals = new List<Rental>();
        }
        public bool EqualsLogin(string login)
        {
            return this.Login.Equals(login);
        }
        public bool EqualsLoginData(string login, string password)
        {
            return (this.Login.Equals(login) && this.Password.Equals(password));
        }

        public static bool ValidCreditCardNumber(int number)
        {
            //number should contain 9 digits.
            return (number.ToString().Length == NUM_DIGITS);
           
        }

        public bool ValidCreditCardNumber()
        {
            return ValidCreditCardNumber(this.Number);
        }

        public static bool ValidExpirationDate(DateTime expirationDate)
        {
            return (DateTime.Now.CompareTo(expirationDate) < EQUAL_DATE); //expirationDate is in the future
               
        }
        public bool ValidExpirationDate()
        {
            return ValidExpirationDate(this.ExpirationDate);
        }

        public static bool ValidCvv(int cvv)
        {
            return (cvv.ToString().Length == NUM_DIGITS_CVV);
        
        }
        public bool ValidCvv()
        {
            return ValidCvv(this.Cvv);
        }
        public void AddRental(Rental rental)
        {
            this.Rentals.Add(rental);
        }
        public bool ExistsPendingRental(out Rental foundRental)
        {
            foundRental = null;
            //foundRental=this.Rentals.Where<Rental>((rental) => rental.EndDate == null).First();
            foreach (Rental rental in this.Rentals)
            {
                if (rental.EndDate == null)
                {
                    foundRental = rental;
                    return true;
                }

            }
            return false;

        }
        public bool ExistsRental(int rentalId, out Rental foundRental)
        {
            foundRental = null;
            foreach (Rental rental in this.Rentals)
            {
                if (rental.Id == rentalId)
                {
                    foundRental = rental;
                    return true;
                }

            }
            return false;
        }
        public ICollection<string> GetUserRoutesIds(DateTime startDate, DateTime endDate)
        {
            ICollection<string> routesIds = new List<string>();
            foreach (Rental rental in Rentals)
            {
                if ((startDate.CompareTo(rental.StartDate) <= EQUAL_DATE)
                    && (endDate.CompareTo(rental.EndDate) >= EQUAL_DATE))
                {
                    routesIds.Add(rental.Id.ToString());
                }

            }
            return routesIds;
        }


    }
}

