﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EcoScooter.Entities;
using EcoScooter.Persistence;

namespace EcoScooter.Services
{
    public class EcoScooterService : IEcoScooterService
    {
        private readonly IDAL dal; //DAL: access to persistence layer
        private Entities.EcoScooter ecoScooter; //Represents current system data
        private User loggedUser;
        private Employee loggedEmployee;

        /// <summary>
        /// Updates fare, discount and maxspeed of the system 
        /// </summary>
        /// <param name="discountYounger"></param>
        /// <param name="fare"></param>
        /// <param name="maxSpeed"></param>
        public void UpdateEcoScooterData(double discountYounger, double fare, double maxSpeed)
        {
            ecoScooter.DiscountYounger = discountYounger;
            ecoScooter.Fare = fare;
            ecoScooter.MaxSpeed = maxSpeed;

        }
        /// <summary>
        /// Initializes the service Layer
        /// </summary>
        /// <param name="dal"></param>
        public EcoScooterService(IDAL dal) 
        { 
            this.dal = dal;
            //Gets the initial EcoScooter or creates a new one
            try
            {   //We assume we only have one EcoScooter
                ecoScooter = this.dal.GetAll<Entities.EcoScooter>().First();
            }
            catch (InvalidOperationException )
            {  
                ecoScooter = new Entities.EcoScooter(); //Relaxing the model, because there is no employee and data
                UpdateEcoScooterData(10, 15, 30); //15 and not 0.015 for simultion purpouses. 
                dal.Insert(ecoScooter);
                saveChanges();
            }
            
        }
  
        public void GetRouteDescription(int rentalId, out DateTime startDate, out DateTime endDate, out decimal price, out String originStationId, out String destinationStationId)
        {
           
            if (!UserLooged())
                throw new ServiceException("GetRouteDescription error:  You should logged in as user before use this service");
            else {
                Rental rental = dal.GetById<Rental>(rentalId);
                if (rental != null)
                    rental.GetRouteDescription(out startDate, out endDate, out price, out originStationId, out destinationStationId);          
                else //No debería ser alcanzable
                    throw new ServiceException("GetRouteDescription error:  rental is not in the database");

            } 
        }

        public ICollection<string> GetUserRoutes(DateTime startDate, DateTime endDate)
        {
            ICollection<string> routeDescriptions = new List<string>();
               DateTime startDateRental;
            DateTime endDateRental;
            decimal price;
            String originStationId;
            String destinationStationId;
            ICollection<string> routesIds;
            try
            {
               routesIds = GetUserRoutesIds(startDate, endDate);
            }
            catch (ServiceException e)
            {
                throw e;
            }
            foreach (string id in routesIds)
            {
                int rentalId = int.Parse(id);
                GetRouteDescription(rentalId, out startDateRental, out endDateRental, out price, out originStationId, out destinationStationId);
                routeDescriptions.Add(startDateRental.ToString() + ", " + endDateRental.ToString() + ", " + price + "," +
                    originStationId + "," + destinationStationId);

            }

            return routeDescriptions;
            }

        public ICollection<string> GetUserRoutesIds(DateTime startDate, DateTime endDate)
        {
            if (!UserLooged())
                throw new ServiceException("GetUserRoutesIds error:  You should logged in as user before use this service");
            else if (!Rental.ValidInterval(startDate, endDate))
                throw new ServiceException("GetUserRoutesIds error: the interval of dates is incorrect");
            else
            {
                ICollection<string> userRoutesIds =  loggedUser.GetUserRoutesIds(startDate, endDate);
                if (userRoutesIds.Count > 0)
                    return userRoutesIds;
                else
                    throw new ServiceException("GetUserRoutesIds error: there aren't routes in the interval");
            }

        }

        public bool isLoggedAsEmployee(string dni)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Checks if the dni correponds to current logged user
        /// </summary>
        /// <param name="dni"></param>
        /// <returns>Returns true if the user is the current logged user, false otherwise</returns>
        public bool isLoggedAsUser(string dni)
        {
            try 
            {
                return loggedUser.EqualsDni(dni);
            
            }
            catch(Exception) //There is not loggedUSer
            {
                return false;

            }
        }

        public void LoginEmployee(string dni, int pin)
        {
            if (!EmployeeLogged())
            {
                Employee foundEmployee;

                if (ecoScooter.ExistsEmployee(dni, pin, out foundEmployee))
                {
                    loggedEmployee = foundEmployee;
                }
                else
                {
                    throw new ServiceException("Login Employee error: Incorrect dni or pin "); //user doens't exists
                }
            }
            else
            {
                //An employee already loggin
                throw new ServiceException("Login Employee error: an employee already logged in. Please, logout first ");

            }
        }

        public void LoginUser(string login, string password)
        {
            if (!UserLooged())
            {
                User foundUser;

                if (ecoScooter.ExistsUser(login, password, out foundUser))
                {
                    loggedUser = foundUser;
                }
                else
                {
                    throw new ServiceException("Login User error: Incorrect login or password "); //user doens't exists
                }
            }
            else
            {
                //A user already loggin
                throw new ServiceException("Login User error: a user already logged in. Please, logout first ");

            }
        }
        public bool UserLooged()
        {
            return (loggedUser != null);
        }
        public bool EmployeeLogged()
        {
            return (loggedEmployee != null); 
        }
        public void RegisterIncident(string description, DateTime timeStamp, int rentalId)
        {   Rental foundRental;
            if (!UserLooged())
                throw new ServiceException("RegisterIncident error:  You should logged in as user before use this service");
            else if (!loggedUser.ExistsRental(rentalId, out foundRental))
                throw new ServiceException("RegisterIncident error:  rentalId doesn't belong to the user");
            else if(timeStamp.CompareTo(DateTime.Now)>0)
                throw new ServiceException("RegisterIncident error:  timeStamp is in the future");
            else 
            { foundRental.AddIncident( description,  timeStamp);
                this.saveChanges();
            }
        }

        public void RegisterScooter(DateTime registerDate, ScooterState state, string stationId)
        {
            Station station;
            if (!EmployeeLogged())
                throw new ServiceException("RegisterScooter error:  You should logged in as employee before use this service");
            else if (!Scooter.GoodRegisterDate(registerDate))
                throw new ServiceException("RegisterScooter error:  the register date cannot be in the future");
            else if (state == ScooterState.available)
            {
                if (!this.ecoScooter.ExistsStation(stationId, out station))
                    throw new ServiceException("RegisterScooter error:  the StationId must exist if the ScooterState is available " + ScooterState.available);
                else //Add a scooter linked to the station 
                {
                    this.ecoScooter.AddScooter(registerDate, state, station);
                    this.saveChanges();
                }
            }
            else //in use or maintenance
            {  //add a scoter without station
                this.ecoScooter.AddScooter(registerDate, state);
                this.saveChanges();
            }
               

        }

        public void RegisterStation(string address, double latitude, double longitude, string stationId)
        {
            if (!EmployeeLogged())
                throw new ServiceException("RegisterStation error:  You should logged in as employee before use this service");
            else if (!Station.GoodAddress(address))
                throw new ServiceException("RegisterStation error: You must provide an address");
            else if (!Station.GoodLatitude(latitude))
                throw new ServiceException("RegisterStation error: You must provide an existing latitude [-90,90]");
            else if (!Station.GoodLongitude(longitude))
                throw new ServiceException("RegisterStation error: You must provide an existing longitude [-180,180]");
            else if (this.ecoScooter.ExistsStation(stationId))
                throw new ServiceException("RegisterStation error: station id already exists");
            else 
            { //provide the service
                this.ecoScooter.AddStation(address, latitude, longitude, stationId);
                this.saveChanges(); 
            }

        }
            public void RegisterUser(DateTime birthDate, string dni, string email, string name, int telephon, int cvv, DateTime expirationDate, string login, int number, string password)
        {   if(ecoScooter.ExistsPerson(dni))
                throw new ServiceException("RegisterUser error: There is a person in the system already registered with the same dni");
            else if(ecoScooter.ExistsLogin(login))
                throw new ServiceException("RegisterUser error: There is a user in the system already registered with the same login");
            else if(!Person.IsOverAge(birthDate))
                throw new ServiceException("RegisterUser error:User must be over 16 years old");
            else if(!User.ValidCreditCardNumber(number))
                throw new ServiceException("RegisterUser error: Credit card number must cointain " + User.NUM_DIGITS+" digits");
            else if(!User.ValidCvv(cvv))
                throw new ServiceException("RegisterUser error: Credit card cvv code number must cointain " + User.NUM_DIGITS_CVV + " digits");
            else if(!User.ValidExpirationDate(expirationDate))
                throw new ServiceException("RegisterUser error:expiration date should be in the future");
            else //Valid data. Telephone checking is not required
            {
                ecoScooter.AddUser(birthDate, dni, email, name, telephon, cvv, expirationDate, login, number, password);
                saveChanges();
            }
        }

        public void removeAllData()
        {
            dal.RemoveAllData();
        }

        public void RentScooter(string stationId)
        {   Station stationFound;
            Scooter scooterAssigned;
            if (!UserLooged())
                throw new ServiceException("RentScooter error:  You should logged in as user before use this service");
            else if (!ecoScooter.ExistsStation(stationId, out stationFound))
                throw new ServiceException("RentScooter error: the station identifier doesn't exist");
            else if (!stationFound.AvailableScooters(out scooterAssigned))
                throw new ServiceException("RentScooter error: there are not available scooters in the station");
            else
            {
                ecoScooter.RentScooter(loggedUser, stationFound, scooterAssigned);
                this.saveChanges();
            }
        }

        public void ReturnScooter(string stationId)
        {   Rental foundRental;
            Station stationFound;
            if (!UserLooged())
                throw new ServiceException("ReturnScooter error:  You should logged in as user before use this service");
            else if (!ecoScooter.ExistsStation(stationId, out stationFound))
                throw new ServiceException("RentScooter error: the station identifier doesn't exist");
            else if (!loggedUser.ExistsPendingRental(out foundRental))
                throw new ServiceException("RentScooter error: there is not a pending rental");
            else
            {   
                ecoScooter.FinishRental(foundRental,stationFound,loggedUser.IsYounger());
                this.saveChanges();
            }
        }

        public void saveChanges()
        {
            dal.Commit();
        }
    }
}
