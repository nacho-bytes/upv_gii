﻿namespace EcoScooter.Entities
{
   
    public enum ScooterState : int
    {
        inUse,
        available,
        inMaintenance
    }
}
