// Ejemplo de uso de operadores aritmeticos.
// Debe devolver el mismo numero elevado al cuadrado
//--------------------------------------------------
int main ()
{ int a;

  read(a);
  a = (((((2 * a) - a) + a) / 2) * a);
  print(a);

  return 0;
}
