/*
 Traure de 
 cameresIP_OpenCV/funOpenCVTutorials.pdf el códic per a detecció de persones  

//
// opencv_camara.cpp
// 
// Asignatura SMII. 
// Versió 0 (Oct. 2018): M. Agustí.
//
// En este ejemplo se exploran las operaciones de acceso a vídeo, en directo (cámara) o desde fichero con OpenCV:
// * Llegir de càmera, camera IP i de fitxer de vídeo
// * Guardar resultats en mapa de bits
// * Guardar resultats en vídeo
//
// Compilar en
// $ make opencv_camara && opencv_camara
// $ g++ opencv_camara.cpp -o opencv_camar `pkg-config opencv --cflags --libs`
//
// Executar en 
// $ opencv_camara -c 0 --> cámara RGB por defecto
// $ opencv_camara -v laser.avi
// $ opencv_camara -rgbd 0 --> sensor RGBD por defecto
// $ opencv_camara -i http://212.89.9.220:9000/mjpg/video.mjpg
// $ opencv_camara -i "http://oviso.axiscam.net/axis-cgi/mjpg/video.cgi"


 * Està basat en 
 "VideoCapture" i "Reading and Writing Images and Video" <https://docs.opencv.org/2.4/modules/highgui/doc/reading_and_writing_images_and_video.html>

    A basic sample on using the VideoCapture interface can be found at opencv_source_code/samples/cpp/starter_video.cpp
    Another basic video processing sample can be found at opencv_source_code/samples/cpp/video_dmtx.cpp

 // https://docs.opencv.org/3.4/dc/d2c/tutorial_real_time_pose.html



 i modificat per ...

magusti@purpura:~/docencia/2k18-2k19/SMII/practiques/practica2_OpenCV_opsBasiques/codicDeAcompanyament$ less ../samples_opencv_github/opencv-master/samples/cpp/openni_capture.cpp 


*/


#include <stdio.h>
#include <ctime>

// C++ o C?
#ifdef __cplusplus
// Les capsaleres canvien en la V4, ho comprobe'm
#if CV_MAJOR_VERSION == 4
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#else
// Versió 2 i 3 : #elif CV_MAJOR_VERSION == 3 ...
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
#endif
#else
//__STDC__
#include <cv.h>
#include <cxcore.h>
#include <highgui.h>
#endif

//#include <stdlib.h>
//#include <string.h>
//#include <time.h> // clock

#include "comun.h"
using namespace cv;  // The new C++ interface API is inside this namespace. Import it.
using namespace std; // para que "string" sea un tipo


// Nom i titul de la finestra per a la imatge original i la resultat
#define fOriginal "Imatge original"
#define fResultat "Imatge de bordes"
// Converteix en un string en format "AnyMesDiaHoraMinutsSegons" en cv_::format
#define FETXA_HORA(ltm) format("%04d%02d%02d%02d%02d%02d", (1900 + ltm->tm_year), (1 + ltm->tm_mon), ltm->tm_mday, (ltm->tm_hour), (ltm->tm_min), (ltm->tm_sec))


enum TIPO_FONT_VIDEO {CAMARA_IP=-2, FITXER_VIDEO = -1, CAMARA_DIGITAL=0};
/*
   CommandLineParser
   https://docs.opencv.org/3.4/d0/d2e/classcv_1_1CommandLineParser.html#details
*/
string hot_keys =
    "\n\nDurant l'execució es poden gastar les tecles següents: \n"
    "\tESC - acabar!\n"
    "\tv: Grava vídeo / para de gravar el vídeo\n"
    "\tf: Pren una foto del original\n"
    "\tF: Pren una foto del processat\n";

void ajuda( char *nomPrograma )
{
  std::cout << "\nEn este ejemplo se exploran las operaciones de acceso a vídeo, en directo (cámara) o desde fichero con OpenCV:\n" <<
    " * Llegir de càmera i de vídeo\n" <<
    " * Generar resultat de processar vídeo en disc al temps que el mostra en pantalla\n" <<
    "Ús: \n" <<
            nomPrograma << " [--camera=n | -c n] [--video_file ruta | -v n] [--ip_address IP@ | -i IP@]\n";
  std::cout << hot_keys;

  std::cout << "Build information: " << cv::getBuildInformation() << std::endl;

} // Fi de ajuda



//https://stackoverflow.com/questions/9450656/positional-argument-v-s-keyword-argument
// A positional argument is a name that is not followed by an equal sign (=) and default value.
// A keyword argument is followed by an equal sign and an expression that gives its default value.

// "{@camera_number| 0 | camera number}"
// "{@video_file| laser.mpg | fitxer de vídeo a reproduir}"
const char* keys = {
    "{h | help |   | mensatge ajuda}"
    "{c | camera | 0 | capture video from camera (device index starting from 0) }"
    "{v | @video_file |   | use fitxer de video as input }"
    "{i | @ip_addres| 0 | address of IP_camera}"  // p. ex. Droid camera
};
/*
 ./opencv_camara -c 0
 ./opencv_camara --camera=0
 ./opencv_camara -v laser.avi
 ./opencv_camara -v laser.mpg
 ./opencv_camara -i http://192.168.1.14:4747 // No ha funcionat!!!
 ./opencv_camara -i http://192.168.1.14:4747/video
*/

const char* acercaDe = "\nDemo de VideoCapture per a llegit un fluxe d'imatges de diferentes \"video streams\": camera digital, fitxer de vídeo o càmera IP.\n";

vector<int> compression_paramsJPEG, compression_paramsPNG;
VideoCapture cap;                // instantiate VideoCapture
int fontDeVideo = 0;    // >= 0 --> camara, -1 fitxer de vídeo, -2 CameraIP
String rutaVideo;       // argument de la línia d'ordres per a llegir d'ell el vídeo o @IP

/*
 * Inicialitza paràmetres
 *  - de generació de formats de mapes de bits
 *  - gestió de paràmetres de línia d'ordres
 */
int inicializaciones(int argc, char **argv) {

#if CV_MAJOR_VERSION > 2
   // PNG 0..9, JPEG/WebP 0..100, PXM_BINARY 0..1
   // https://docs.opencv.org/3.0-beta/modules/imgcodecs/doc/reading_and_writing_images.html
   compression_paramsJPEG.push_back(CV_IMWRITE_JPEG_QUALITY);
   compression_paramsJPEG.push_back(95); 

   compression_paramsPNG.push_back(CV_IMWRITE_PNG_COMPRESSION);
   compression_paramsPNG.push_back(9);
#endif

   //std::cout << "Build information: " << cv::getBuildInformation() << std::endl;

   
   //
   // Anàlisi de la línia d'ordres: atenció a la versió d'OpenCV
   // 
   CommandLineParser parser(argc, argv, keys);

   // http://answers.opencv.org/question/101515/every-thing-works-fine-except-for-commandlineparser-has-no-member-named-aboutprint-messagehascheck/
   //error: ‘bool cv::CommandLineParser::has(const string&)’ is protected
   //Indeed, if you're using opencv2.4 you can't use any of those functions, all it has is get() and printParams(). (see header )
#if CV_MAJOR_VERSION > 3
   //   parser(argc, argv, keys);
 
   if (parser.has("help")) {
        ajuda( argv[0] );
        return( -3 );
   }
   parser.about( acercaDe );
   parser.printMessage();
   
   if (parser.has("camera")) {
      fontDeVideo = parser.get<int>(0);
      printf("Canviant la camera\n");
      cap.open( fontDeVideo );  
   } else if (parser.has("video_file")) {
      fontDeVideo = -2;
      rutaVideo = parser.get<String>(0);
      printf("Llegint del fitxer de vídeo <%s>\n", rutaVideo.c_str() );
      cap.open( rutaVideo );        
   } else if (parser.has("ip_addres")) {
      fontDeVideo = -3;
      rutaVideo = parser.get<String>(0);
      printf("Conectant en la camera en IP@ <%s>\n", rutaVideo.c_str() );
      cap.open( rutaVideo );        
   }
#else
	 //parser(argc, argv, keys);
    if (argc == 1) {
    printf( "\nDemo de VideoCapture per a llegit un fluxe d'imatges de diferentes \"video streams\": camera digital, fitxer de vídeo o càmera IP.\n");
     ajuda( argv[0] );
     return( -3 );
   }
   else     
    if (argc == 2) {
    if ((argv[1][0] == '-' ) AND (argv[1][1] == 'h' )) {
      //parser.printParams();
      ajuda( argv[0] );
      return( -3 );
     }
     else
     if ((argv[1][4] == ':' ) AND (argv[1][1] == '/' )) {
      fontDeVideo = -3;
      rutaVideo = parser.get<String>(0);
      printf("Conectant en la camera en IP@ <%s>\n", rutaVideo.c_str() );
     }
     else {
      fontDeVideo = -2;
      rutaVideo = parser.get<String>(0);
      printf("Llegint del fitxer de vídeo <%s>\n", rutaVideo.c_str() );
     }      
   }
   else {     
    if (argc == 3) {
     std::cout << hot_keys;

     if ((argv[1][0] == '-' ) AND (argv[1][1] == 'c' )) {
      fontDeVideo = atoi( argv[2] ); //  FITXER_VIDEO CAMARA_DIGITAL
      printf("Arguments: obrir càmera %d\n", fontDeVideo );
      //cap.open( fontDeVideo );  
     }
     else if ((argv[1][0] == '-' ) AND (argv[1][1] == 'v' )) {
       fontDeVideo = FITXER_VIDEO;
       printf("Arguments: obrir fitxer de vídeo >%s<.\n", argv[2] );
       //cap.open( argv[2] );
       rutaVideo = argv[2];
     }				    
     else if ((argv[1][0] == '-' ) AND (argv[1][1] == 'i' )) {
       fontDeVideo = CAMARA_IP;
       printf("Arguments: obrir camera IP des de >%s<.\n", argv[2] );
       //cap.open( argv[2] );  // Start video capture de càmera en la càmera per defecte
       rutaVideo = argv[2];
     }
     //     return( fontDeVideo );
   }// if (argc == 3) 
   else {
     printf("Argument no reconegut %s\n", argv[1] );
     return( -4 );
   }
  } // else { if (argc == 3) 
#endif

    return( fontDeVideo );
} // Fi de  inicializaciones

//
// Prog. ppal.
// Còdics d'eixida
#define ERROR_ARGUMENTS     -4
#define ERROR_FONTDEVIDEO   -5
#define ERROR_CONVERSIOJPEG -6 
#define ERROR_CONVERSIOPNG  -7
#define FI_APLICACIO_OK      0
//
int  main(int argc, char **argv)
{
   Mat frame, edges;
   bool fiDeVideo = false, volSeguirUsuari = true;
   int tecla;
   time_t now;
   tm *ltm;
   String fetxaString,
          rutaFitxerVideo; // a on es gravará el resultat en vídeo
   int gravantVideo = false;
   VideoWriter elFitxerDeVideo;
   int codec;
   int fps;

   if ( inicializaciones( argc, argv ) < CAMARA_IP )
     return( ERROR_ARGUMENTS );

   //Si vols separar la declaració de la inicialització:
   // en conter de fer
   // VideoCapture cap(0); // open the default camera
   // fas
   //cap.open(0);  // Start video capture de càmera en la càmera per defecte
   //i podries haver obert un fitxer igualment en:
   // cap.open( rutavideo_lectura );           // open a recorded video    
   if ( fontDeVideo >= CAMARA_DIGITAL ) {
       printf("Finalment: obrint cam. #%d.\n", fontDeVideo );
      cap.open( fontDeVideo );
   }
   else {
      printf("Finalment: obrint des de >%s<.\n", rutaVideo.c_str() );
      cap.open( rutaVideo );
   }
   
   if(!cap.isOpened()) { // check if we succeeded
     if (fontDeVideo == CAMARA_IP )
       printf("Error obrint camIP des de %s\n", argv[2]);
     else
     if (fontDeVideo == FITXER_VIDEO )
       printf("Error obrint fitxer de vídeo des de %s\n", argv[2]);
     else
       printf("Error obrint camera %d\n", fontDeVideo);
     return( ERROR_FONTDEVIDEO );
   } // Fi de    if(!cap.isOpened()) 
   /* No més és aplicable si és vídeo de càmera ???
   printf("AmplexAlt %dx%d, depth %ud i components  %ud\n",
	  (int)cap.get(CV_CAP_PROP_FRAME_WIDTH), 
	  (int)cap.get(CV_CAP_PROP_FRAME_HEIGHT), 
	  //          CV_MAT_DEPTH( cap.get(CV_CAP_PROP_FORMAT) ) );
	  cap.get(CV_CAP_PROP_FORMAT) & CV_MAT_DEPTH_MASK,
	  chans = 1 + (cap.get(CV_CAP_PROP_FORMAT) >> CV_CN_SHIFT);
   */
   if( cap.grab() ) // Congela la imatge a la càmera
   {
    cap.retrieve(frame, 0 ); // Decodes and returns the grabbed video frame.
    printf("AmplexAlt %dx%d, depth %d i components  %d\n",
           frame.cols, frame.rows, frame.depth(), frame.channels() );
   }
    
	  	    
    namedWindow(fOriginal, WINDOW_NORMAL); //  If this is set, the user can resize the window (no constraint).
   // WINDOW_OPENGL
    moveWindow( fOriginal, 0, 0 );
    namedWindow( fResultat, WINDOW_AUTOSIZE ); //If this is set, the window size is automatically adjusted to fit the displayed image, and you cannot change the window size manually.
    moveWindow( fResultat, frame.cols+10, 0 );

    while ( !fiDeVideo AND volSeguirUsuari )
    {
      // El métode sobrecarregat de lectura, 
      //cap >> frame; // get a new frame from camera
      // inclou "graba i decodifica == grab + retrieve"
      if ( !cap.grab() ) // Congela la imatge a la càmera
	fiDeVideo = true;
      else
      {
        cap.retrieve(frame, 0 ); // Decodes and returns the grabbed video frame.
        cvtColor(frame, edges, CV_BGR2GRAY);
        GaussianBlur(edges, edges, Size(7,7), 1.5, 1.5);
        Canny(edges, edges, 0, 30, 3);
        imshow( fOriginal, frame);
        imshow( fResultat, edges); //         imshow("edges", edges);

        if( gravantVideo ) {
	  printf("."); fflush( stdout );
	  elFitxerDeVideo.write( edges );
	}
 
        tecla = waitKey(25) & 255;  // Espera una tecla los milisegundos que haga falta      
     	now = time(0); // http://answers.opencv.org/question/138871/how-to-add-date-to-a-recorded-video/
	ltm = localtime(&now);
        fetxaString = FETXA_HORA(ltm);
	
        switch ( tecla )
        {
         case ESC:
	 case 'q':
	 case 'Q':    // Si 'ESC', q ó Q, ¡acabar!
          volSeguirUsuari = false;
          break;

 	 case 'h': // Recordar tecles que es poden gastar
	     std::cout << hot_keys;
	   break;
	   
 	 case 'v': // Grava vídeo
	   if( !gravantVideo )
	   {
	     rutaFitxerVideo = "video__" + fetxaString + ".avi"; // ".mpg";
             printf( "Començant a gravar en video: %s\n", rutaFitxerVideo.c_str() );
	     //https://docs.opencv.org/2.4/doc/tutorials/highgui/video-write/video-write.html :: es suposa que MPEG i MJPEG estan soportats directament per OpenCV
	     codec = CV_FOURCC('P','I','M','1'); // is a MPEG-1 codec, ... <http://www.fourcc.org/codecs.php>
             fps = 30;
	     // codec = CV_FOURCC('M','J','P','G'); //  is a motion-jpeg codec, pero no funciona en la instalació final del lab.
	     //fps = 5;
	     //CV_FOURCC('D', 'I', 'V', 'X'), // DivX4
	     elFitxerDeVideo.open( rutaFitxerVideo, 
				   codec, 
 				   fps,
				   cv::Size( frame.cols, frame.rows),
				   edges.channels() == 3 ); //true); // isColor	     			  
	     //			 fps, Size frameSize, bool isColor=true)
	     if ( !elFitxerDeVideo.isOpened() ) {
	       printf("Error al obrir %s\n", rutaFitxerVideo.c_str() );
	       gravantVideo = false;
	     }
	     else
	       gravantVideo = true;
	   }
	   else
	   {
               elFitxerDeVideo.release();
       	       printf( "Tancant la gravació en video: %s\n", rutaFitxerVideo.c_str() );
	       // elFitxerDeVideo = "";
	       gravantVideo = false;
	   }
	   //gravantVideo = !gravantVideo;	   	   
          break;
	 
	 case 'f': // Pren una foto del original
          try {
	    // Ficava > 3, però deu ser > 2 o habilitat el #else
#if CV_MAJOR_VERSION > 2
	    imwrite("original__"+ fetxaString +".jpg", frame, compression_paramsJPEG);
#else
	    imwrite("original__"+ fetxaString +".jpg", frame ); //IMWRITE_JPEG_QUALITY=1 );
#endif
          }
          catch (std::runtime_error& ex) {
           fprintf(stderr, "Exception converting image to JPEG format: %s\n", ex.what());
           return( ERROR_CONVERSIOJPEG );
          }
	  printf("Guardat:: original__%s.jpg\n", fetxaString.c_str() );	  
          break;  

	 case 'F': // Pren una foto del processat
          try {
#if CV_MAJOR_VERSION > 2
	    imwrite("resultat__"+ fetxaString +".png", edges, compression_paramsPNG);
#else
	    imwrite("original__"+ fetxaString +".png", edges ); // IMWRITE_PNG_COMPRESSION =16);
#endif
          }
          catch (std::runtime_error& ex) {
           fprintf(stderr, "Exception converting image to PNG format: %s\n", ex.what());
           return( ERROR_CONVERSIOPNG );
          }
	  printf("Guardat:: resultat__%s.jpg\n", fetxaString.c_str() );
          break;

         default: ;    
         } // Fin de "switch ( tecla )"  

  
	/*
        if(waitKey(30) >= 0)
	  //break;
	  volSeguirUsuari = false;
	*/

	
      }// Fi de if ( !cap.grab() )
    }

    //if ( !elFitxerDeVideo.isOpened() ) 
    //    elFitxerDeVideo.release();
    // the camera will be deinitialized automatically in VideoCapture destructor
     return( FI_APLICACIO_OK ) ;
}



//
// Fi de "opencv_camara.cpp"
//
