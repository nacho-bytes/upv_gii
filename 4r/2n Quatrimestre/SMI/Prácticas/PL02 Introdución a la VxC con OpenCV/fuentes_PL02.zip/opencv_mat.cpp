//
// opencv_mat.cpp (UTF-8)
// 
// Asignatura SMII. 
// Versió 0 (Oct. 2018): M. Agustí:: portar desde la versión OpenCV 2.4.9.1 a OpenCV 3.0
//
// En este ejemplo se describirá cómo crear una imagen, recorrerla y mostrarla en pantalla.
//
//

/*
https://docs.opencv.org/2.4/modules/core/doc/basic_structures.html#mat
OpenCV 2.4.13.7 documentation » OpenCV API Reference » core. The Core Functionality » Basic Structures
I està en el còdic en </usr/include/opencv2/core/core.hpp>.

https://docs.opencv.org/3.0-beta/doc/tutorials/core/mat_the_basic_image_container/mat_the_basic_image_container.html?highlight=mat
OpenCV 3.0.0-dev documentation » OpenCV Tutorials » core module. The Core Functionality » Mat - The Basic Image Container
IplImage vs Mat

https://docs.opencv.org/4.0.0-beta/db/dfa/tutorial_transition_guide.html
OpenCV 4.0.0-beta OpenCV Tutorials > Introduction to OpenCV
Transition guide 
Changes overview 
This document is intended to software developers who want to migrate their code to OpenCV 3.0.

class Mat <https://docs.opencv.org/3.0-beta/modules/core/doc/basic_structures.html?highlight=create>.
<https://docs.opencv.org/2.4/modules/core/doc/basic_structures.html#Mat>
OpenCV C++ n-dimensional dense array class

 C++ --> compilar en g++: g++ opencv_mat.c -o opencv_mat `pkg-config opencv --cflags --libs`
*/
#include <stdio.h>

#include <opencv2/opencv.hpp>
using namespace cv;  // The new C++ interface API is inside this namespace. Import it.
/*
// comment out the define to use only the latest C++ API
#define DEMO_MIXED_API_USE

#ifdef DEMO_MIXED_API_USE
#endif
*/
#include "comun.h"
#define fGRIS "¡Hola, OpenCV en gris!"
#define fRGB  "¡Hola, OpenCV en color!"

#define L MAXPIXEL
#define AMPLE (int)L
#define ALT (int)L



// Declaraciones de prototipos locales
int  inicializarImgGris( Mat *imgOrg );
int  inicializarImgRGB( Mat *imgOrg );


//
// Programa principal
//
int main(int argc, char* argv[]) 
{
 Mat imgOrgGris, imgOrgRGB;
 Scalar colorDst;
 Mat rgbaPlanes[3];

 printf("Versión de OpenCV: %s\n", CV_VERSION);
 //CV_MAJOR_VERSION, CV_MINOR_VERSION, CV_SUBMINOR_VERSION, CV_VERSION


 printf("Creando una imagen y mostrándola en pantalla [Cualquier tecla - Salir].\n");
 //https://docs.opencv.org/3.4.3/d1/dfb/intro.html
 colorDst.val[0] = 128;
 imgOrgGris.create( ALT, AMPLE, CV_8UC1); //, Scalar::all(0));
 imgOrgGris = colorDst; // Mat::zeros(ALT, AMPLE, CV_8UC1), Mat::ones ó Mat::eye
 if (!imgOrgGris.data ) 
 {
   fprintf(stderr, "Problemas al crear la imagen en grises\n");
   return( 1 );
 }
 printf("Se ha creado una imagen de %dx%d, de %d plano/s.\n", 
         imgOrgGris.cols, imgOrgGris.rows, imgOrgGris.channels() );
 inicializarImgGris( &imgOrgGris );
 namedWindow( fGRIS, CV_WINDOW_NORMAL); //WINDOW_NORMAL, AUTOSIZE CV_WINDOW_AUTOSIZE ); 
 imshow(fGRIS, imgOrgGris ); 
 moveWindow( fGRIS, 0, 0 );



 // RGB
 colorDst.val[R] = 255;
 colorDst.val[G] = 255;
 colorDst.val[B] = 255;
 imgOrgRGB.create(imgOrgGris.rows, imgOrgGris.cols, CV_8UC3);
 imgOrgRGB = colorDst;//, Scalar::all(0) );
 //imgOrgRGB = Scalar(255,255,255) - Scalar(128, 64, 32); // cv::Mat::ones(int rows, int cols, int type )		
 
 // Mat gray(color.rows, color.cols, color.th());
 if (!imgOrgRGB.data ) //!imgOrgRGB)
 {
   fprintf(stderr, "Problemas al crear la imagen en color\n");
   return( 2 );
 }
 printf("Se ha creado una imagen de %dx%d, de %d planos.\n", 
         imgOrgRGB.cols, imgOrgRGB.rows, imgOrgRGB.channels() );
 inicializarImgRGB( &imgOrgRGB );
 namedWindow( fRGB, WINDOW_AUTOSIZE ); //cvNamedWindow( fRGB, CV_WINDOW_AUTOSIZE ); 
 imshow( fRGB, imgOrgRGB ); //cvShowImage( fRGB, imgOrgRGB ); 
 moveWindow( fRGB, AMPLE+60, 0 ); //cvMoveWindow( fRGB, AMPLE+30, 0 );


 // Split the Mat
 split(imgOrgRGB, rgbaPlanes);
 printf("Split: ha creado un vector de 3 imágenes de %dx%d, de %d planos.\n", 
         rgbaPlanes[R].cols, rgbaPlanes[R].rows, rgbaPlanes[R].channels() );
 imshow( "R", rgbaPlanes[R] );
 moveWindow( "R", AMPLE+60, ALT+30 ); 
 imshow( "G", rgbaPlanes[G] );
 moveWindow( "G", 2*(AMPLE+60), ALT+30 ); 
 imshow( "B", rgbaPlanes[B] );
 moveWindow( "B", 3*(AMPLE+60), ALT+30 ); 


 waitKey(0); // Espera una tecla los milisegundos que haga falta


 // Se puede cerrar una o todas las ventanas a voluntad
 cvDestroyAllWindows( );

 // Se puede liberar memoria explícitamente o que lo haga el "recolector"
 imgOrgGris.release(); //cvReleaseImage( &imgOrgGris );
 imgOrgRGB.release(); //cvReleaseImage( &imgOrgRGB );

 return 0;
}








//
// Inicializa una imagen de un sólo plano de color (imagen de grises)
// con un gradiente de valores de gris
//
// Entrada: imgOrg - la imagen de partida.
//
// Salida: imgOrg - la imagen resultados que se devuelve modificando la original.
//
int  inicializarImgGris( Mat *imgOrg ) 
{
  int x, // indice de las columnas
      y; // indice de las filas

  if ( imgOrg->channels() != 1)
    return( 1 );
  else
  {

    for ( y = 0; y < imgOrg->rows; y++ )
      for ( x = 0; x < imgOrg->cols; x++ )
   {
    imgOrg->at<uchar>(y, x) = x;
   } // Fin de "   for ( y = 0; y < imgOrg->height; y++ )"
  }// Fin de if-else ( imgOrg.channels() != 1)

} // Fin de "int  inicializarImgGris( Mat *imgOrg )"

/*
http://opencvexamples.blogspot.com/2013/10/assessing-pixel-values-of-image.html
Assessing the pixel values of an image 
*/




int  inicializarImgRGB( Mat *imgOrg ) 
{
  int x, // indice de las columnas
      y; // indice de las filas
  CvScalar colorDst;

  if ( imgOrg->channels() != 3) // -> #nChanels
    return( 1 );
  else
  {

    for ( y = 0; y < imgOrg->rows; y++ )
      for ( x = 0; x < imgOrg->cols; x++ )
   {
     imgOrg->at<Vec3b>(y, x)[R] = y;
     imgOrg->at<Vec3b>(y, x)[G] = x;
     imgOrg->at<Vec3b>(y, x)[B] = (uchar)((y+x) % (int)L);
     // Tb.
     // imgOrg->at<Vec3b>(y, x) = Vec3b( y, x, (uchar)((y+x) % (int)L) );
     //
   } // Fin de "   for ( y = 0; y < imgOrg->height; y++ )"
  }// Fin de if-else ( imgOrg->nChannels != 3)

} // Fin de "int  inicializarImgRGB( Mat *imgOrg )"


//
// Fi del fitxer opencv_mat.cpp
