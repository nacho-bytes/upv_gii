/*
//
// opencv_camara.cpp
// 
// Asignatura SMII. 
// Versió 1.0 (Feb. 2021): M. Agustí: compilacio condicional per unificar el còdic front a les versions d'OpenCV
// Versió 0 (Oct. 2018): M. Agustí.
//
// En este ejemplo se exploran las operaciones de acceso a vídeo, en directo (cámara) o desde fichero con OpenCV:
// * Llegir de càmera, camera IP i de fitxer de vídeo
// * Guardar resultats en mapa de bits
// * Guardar resultats en vídeo
//
// Compilar en
// $ make opencv_camara && opencv_camara
   OpenCV 3.2
// $ g++ opencv_camara.cpp -o opencv_camara `pkg-config opencv --cflags --libs`
   OpenCV 4.2
// $ g++ opencv_camara.cpp -o opencv_camara `pkg-config opencv4 --cflags --libs`

// Executar en: 
   $ opencv_camara -c=0 --> cámara RGB por defecto
   $opencv_camara --camera=2
   $ opencv_camara -v=Imagenes/laser.avi
   $ opencv_camara -video_file=Imagenes/laser.mpg
   $ opencv_camara -rgbd 0 --> sensor RGBD por defecto
   $ opencv_camara -i http://212.89.9.220:9000/mjpg/video.mjpg
 De http://www.insecam.org
   $ opencv_camara -i=http://79.108.129.167:9000/mjpg/video.mjpg
   $ opencv_camara -i=http://158.42.148.154/mjpg/video.mjpg
   $ opencv_camara -i=http://24.172.4.142/mjpg/video.mjpg?COUNTER

 * Està basat en 
  * "VideoCapture" i "Reading and Writing Images and Video" <https://docs.opencv.org/2.4/modules/highgui/doc/reading_and_writing_images_and_video.html>
  * A basic sample on using the VideoCapture interface can be found at opencv_source_code/samples/cpp/starter_video.cpp
  * Another basic video processing sample can be found at opencv_source_code/samples/cpp/video_dmtx.cpp
  * https://docs.opencv.org/3.4/dc/d2c/tutorial_real_time_pose.html
*/


#include <stdio.h>
#include <ctime>

// C++ o C?
#ifdef __cplusplus
// Les capsaleres canvien en la V4, ho comprobe'm
#if CV_MAJOR_VERSION == 4
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#else
// Versió 2 i 3 : #elif CV_MAJOR_VERSION == 3 ...
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
#endif
#else
//__STDC__
#include <cv.h>
#include <cxcore.h>
#include <highgui.h>
#endif

//#include <stdlib.h>
//#include <string.h>
//#include <time.h> // clock

#include "comun.h"
using namespace cv;  // The new C++ interface API is inside this namespace. Import it.
using namespace std; // para que "string" sea un tipo


// Nom i titul de la finestra per a la imatge original i la resultat
#define fOriginal "Imatge original"
#define fResultat "Imatge de bordes"
// Converteix en un string en format "AnyMesDiaHoraMinutsSegons" en cv_::format
#define FETXA_HORA(ltm) format("%04d%02d%02d%02d%02d%02d", (1900 + ltm->tm_year), (1 + ltm->tm_mon), ltm->tm_mday, (ltm->tm_hour), (ltm->tm_min), (ltm->tm_sec))


enum TIPO_FONT_VIDEO {CAMARA_IP=-2, FITXER_VIDEO = -1, CAMARA_DIGITAL=0};
/*
   CommandLineParser
   https://docs.opencv.org/3.4/d0/d2e/classcv_1_1CommandLineParser.html#details
*/
string hot_keys =
    "\n\nDurant l'execució es poden gastar les tecles següents: \n"
    "\tESC - acabar!\n"
    "\tv: Grava vídeo / para de gravar el vídeo\n"
    "\tf: Pren una foto del original\n"
    "\tF: Pren una foto del processat\n";

void ajuda( char *nomPrograma )
{
  std::cout << "\nEn este ejemplo se exploran las operaciones de acceso a vídeo, en directo (cámara) o desde fichero con OpenCV:\n" <<
    " * Llegir de càmera i de vídeo\n" <<
    " * Generar resultat de processar vídeo en disc al temps que el mostra en pantalla\n" <<
    "Ús: \n" <<
            nomPrograma << " [--camera=n | -c n] [--video_file ruta | -v n] [--ip_address IP@ | -i IP@]\n";
  std::cout << hot_keys;

  //
  //std::cout << "Build information: " << cv::getBuildInformation() << std::endl;
  //
} // Fi de ajuda



//https://stackoverflow.com/questions/9450656/positional-argument-v-s-keyword-argument
// A positional argument is a name that is not followed by an equal sign (=) and default value.
// A keyword argument is followed by an equal sign and an expression that gives its default value.

// "{@camera_number| 0 | camera number}"
// "{@video_file| laser.mpg | fitxer de vídeo a reproduir}"
const String keys = {
    "{help h       |  | mensatge ajuda}"
    "{camera c     |  | capture video from camera (device index starting from 0) }"
    "{video_file v |  | use fitxer de video as input }"
    "{ip_address i |  | address of IP_camera}"  // p. ex. Droid camera
/*    
    "{h | help |   | mensatge ajuda}"
    "{c | camera | 0 | capture video from camera (device index starting from 0) }"
    "{v | @video_file |   | use fitxer de video as input }"
    "{i | @ip_addres| 0 | address of IP_camera}"  // p. ex. Droid camera
*/    
};


const char* acercaDe = "\nDemo de VideoCapture per a llegit un fluxe d'imatges de diferentes \"video streams\": camera digital, fitxer de vídeo o càmera IP.\n";

vector<int> compression_paramsJPEG, compression_paramsPNG;
VideoCapture cap;                // instantiate VideoCapture
int fontDeVideo = 0;    // >= 0 --> camara, -1 fitxer de vídeo, -2 CameraIP
String rutaVideo;       // argument de la línia d'ordres per a llegir d'ell el vídeo o @IP




/*
 * Inicialitza paràmetres
 *  - de generació de formats de mapes de bits
 *  - gestió de paràmetres de línia d'ordres
 */
int inicializaciones(int argc, char **argv) {

 // PNG 0..9, JPEG/WebP 0..100, PXM_BINARY 0..1
 // https://docs.opencv.org/4.2.0/d4/da8/group__imgcodecs.html#gabbc7ef1aa2edfaa87772f1202d67e0ce
#if CV_MAJOR_VERSION == 4
   compression_paramsJPEG.push_back(IMWRITE_JPEG_QUALITY);
   compression_paramsJPEG.push_back(95); 

   compression_paramsPNG.push_back(IMWRITE_PNG_COMPRESSION);
   compression_paramsPNG.push_back(9);
#endif

 // https://docs.opencv.org/3.0-beta/modules/imgcodecs/doc/reading_and_writing_images.html    
#if CV_MAJOR_VERSION == 3
   // PNG 0..9, JPEG/WebP 0..100, PXM_BINARY 0..1
   // https://docs.opencv.org/3.0-beta/modules/imgcodecs/doc/reading_and_writing_images.html
   compression_paramsJPEG.push_back(CV_IMWRITE_JPEG_QUALITY);
   compression_paramsJPEG.push_back(95); 

   compression_paramsPNG.push_back(CV_IMWRITE_PNG_COMPRESSION);
   compression_paramsPNG.push_back(9);
#endif

   
   //
   // Anàlisi de la línia d'ordres
   // 
   CommandLineParser parser(argc, argv, keys);  
   //printf("Per a Openc MAJOR_VERSION > %d\n", CV_MAJOR_VERSION);
   
   // http://answers.opencv.org/question/101515/every-thing-works-fine-except-for-commandlineparser-has-no-member-named-aboutprint-messagehascheck/
   //error: ‘bool cv::CommandLineParser::has(const string&)’ is protected
   //Indeed, if you're using opencv2.4 you can't use any of those functions, all it has is get() and printParams(). (see header )
#if CV_MAJOR_VERSION >=3
   parser.about( acercaDe );
   //parser.printMessage();
   if (parser.has("help")) {
        ajuda( argv[0] );
        parser.printMessage();

        return( -3 );
   } 
   
   // Note that there are no default values for help ... so we can check their presence using the has() method.
   // Arguments with default values are considered to be always present. Use the get() method in these cases to check their actual value instead.
   if (parser.has("camera")) {
      fontDeVideo = parser.get<int>("camera");    
      printf("Canviant a la camera %d \n", fontDeVideo);
   } else if (parser.has("video_file")) {
      fontDeVideo = FITXER_VIDEO;      
      rutaVideo = parser.get<String>("video_file"); // rutaVideo = "laser.avi"; 
      printf("Llegint del fitxer de vídeo <%s>\n", rutaVideo.c_str() );
   } else if (parser.has("ip_address")) {
      fontDeVideo = CAMARA_IP;
      rutaVideo = parser.get<String>("ip_address");
      printf("Conectant en la camera en IP@ <%s>\n", rutaVideo.c_str() );
   }
       
#else
   //
	 //parser(argc, argv, keys);
    if (argc == 1) {
      //         printf("Obrint1.1 \n" );
    printf( "\nDemo de VideoCapture per a llegit un fluxe d'imatges de diferentes \"video streams\": camera digital, fitxer de vídeo o càmera IP.\n");
     ajuda( argv[0] );
     return( -3 );
   }
   else     
    if (argc == 2) {
      //          printf("Obrint1.2 \n" );
    if ((argv[1][0] == '-' ) AND (argv[1][1] == 'h' )) {
      //parser.printParams();
      ajuda( argv[0] );
      return( -3 );
     }
     else
     if ((argv[1][4] == ':' ) AND (argv[1][1] == '/' )) {
      fontDeVideo = -3;
      rutaVideo = parser.get<String>(0);
      printf("Conectant en la camera en IP@ <%s>\n", rutaVideo.c_str() );
     }
     else {
      fontDeVideo = -2;
      rutaVideo = parser.get<String>(0);
      printf("Llegint del fitxer de vídeo <%s>\n", rutaVideo.c_str() );
     }      
   }
   else {     
    if (argc == 3) {
      //     printf("Obrint1.3 \n" );
     std::cout << hot_keys;

     if ((argv[1][0] == '-' ) AND (argv[1][1] == 'c' )) {
       //             printf("Obrint càmera\n" );
      fontDeVideo = atoi( argv[2] ); //  FITXER_VIDEO CAMARA_DIGITAL
      printf("Arguments: obrir càmera %d\n", fontDeVideo );
      //cap.open( fontDeVideo );  
     }
     else if ((argv[1][0] == '-' ) AND (argv[1][1] == 'v' )) {
       fontDeVideo = FITXER_VIDEO;
       printf("Arguments: obrir fitxer de vídeo >%s<.\n", argv[2] );
       //cap.open( argv[2] );
       rutaVideo = argv[2];
     }				    
     else if ((argv[1][0] == '-' ) AND (argv[1][1] == 'i' )) {
       fontDeVideo = CAMARA_IP;
       printf("Arguments: obrir camera IP des de >%s<.\n", argv[2] );
       //cap.open( argv[2] );  // Start video capture de càmera en la càmera per defecte
       rutaVideo = argv[2];
     }
     //     return( fontDeVideo );
   }// if (argc == 3) 
   else {
     printf("Argument no reconegut %s\n", argv[1] );
     return( -4 );
   }
  } // else { if (argc == 3) 
#endif

    return( fontDeVideo );
} // Fi de  inicializaciones

//
// Prog. ppal.
// Còdics d'eixida
#define ERROR_ARGUMENTS     -4
#define ERROR_FONTDEVIDEO   -5
#define ERROR_CONVERSIOJPEG -6 
#define ERROR_CONVERSIOPNG  -7
#define FI_APLICACIO_OK      0
//
int  main(int argc, char **argv)
{
   Mat frame, edges;
   bool fiDeVideo = false, volSeguirUsuari = true;
   int tecla;
   time_t now;
   tm *ltm;
   String fetxaString,
          rutaFitxerVideo; // a on es gravará el resultat en vídeo
   int gravantVideo = false;
   VideoWriter elFitxerDeVideo;
   int codec;

   if ( (fontDeVideo = inicializaciones( argc, argv )) < CAMARA_IP )
   {printf("oops %d\n", fontDeVideo);
       return( ERROR_ARGUMENTS );
   }

   //printf("prog. ppal %d\n", fontDeVideo);  
   if ( fontDeVideo >= CAMARA_DIGITAL ) {
       printf("Finalment: obrint cam. #%d.\n", fontDeVideo );
      cap.open( fontDeVideo );
   }
   else {
      printf("Finalment: obrint des de >%s<.\n", rutaVideo.c_str() );
      cap.open( rutaVideo );
   }
   
   if(!cap.isOpened()) { // check if we succeeded
     if (fontDeVideo == CAMARA_IP )
       printf("Error obrint camIP des de %s\n", argv[2]);
     else
     if (fontDeVideo == FITXER_VIDEO )
       printf("Error obrint fitxer de vídeo des de %s\n", argv[2]);
     else
       printf("Error obrint camera %d\n", fontDeVideo);
     return( ERROR_FONTDEVIDEO );
   } // Fi de    if(!cap.isOpened()) 
  
   
   if( cap.grab() ) // Congela la imatge a la càmera
   {
    cap.retrieve(frame, 0 ); // Decodes and returns the grabbed video frame.
    printf("AmplexAlt %dx%d, depth %d i components  %d\n",
           frame.cols, frame.rows, frame.depth(), frame.channels() );
   }   
	  	    
    namedWindow(fOriginal, WINDOW_NORMAL); //  If this is set, the user can resize the window (no constraint).
   // WINDOW_OPENGL
    moveWindow( fOriginal, 0, 0 );
    namedWindow( fResultat, WINDOW_AUTOSIZE );
		//If this is set, the window size is automatically adjusted to fit the displayed image, and you cannot change the window size manually.
    moveWindow( fResultat, frame.cols+10, 0 );

    //for(;;)
    while ( !fiDeVideo AND volSeguirUsuari )
    {
      // El métode sobrecarregat de lectura, 
      //cap >> frame; // get a new frame from camera
      // inclou "graba i decodifica == grab + retrieve"
      if ( !cap.grab() ) // Congela la imatge a la càmera
	    fiDeVideo = true;
      else
      {
        cap.retrieve(frame, 0 ); // Decodes and returns the grabbed video frame.
#if CV_MAJOR_VERSION == 2
       cvtColor(frame, edges, CV_BGR2GRAY);
#elif CV_MAJOR_VERSION >= 3
       cvtColor(frame, edges, COLOR_BGR2GRAY);
#endif
        GaussianBlur(edges, edges, Size(7,7), 1.5, 1.5);
        Canny(edges, edges, 0, 30, 3);
        imshow( fOriginal, frame);
        imshow( fResultat, edges); //         imshow("edges", edges);

        if( gravantVideo ) {
	  printf("."); fflush( stdout );
	  elFitxerDeVideo.write( edges );
	}
 
        tecla = waitKey(25) & 255;  // Espera una tecla los milisegundos que haga falta      
     	now = time(0); // http://answers.opencv.org/question/138871/how-to-add-date-to-a-recorded-video/
	ltm = localtime(&now);
        fetxaString = FETXA_HORA(ltm);
	
        switch ( tecla )
        {
         case ESC:
	 case 'q':
	 case 'Q':    // Si 'ESC', q ó Q, ¡acabar!
          volSeguirUsuari = false;
          break;

 	 case 'h': // Recordar tecles que es poden gastar
	     std::cout << hot_keys;
	   break;
	   
 	 case 'v': // Grava vídeo
	   if( !gravantVideo )
	   {
	     rutaFitxerVideo = "video__" + fetxaString + ".avi"; // ".mpg";
             printf( "Començant a gravar en video: %s\n", rutaFitxerVideo.c_str() );
#if CV_MAJOR_VERSION == 2
         codec = CV_FOURCC('M','J','P','G'); //  is a motion-jpeg codec
#elif CV_MAJOR_VERSION > 2
         codec = VideoWriter::fourcc('M','J','P','G'); //  is a motion-jpeg codec
#endif
         //https://docs.opencv.org/2.4/doc/tutorials/highgui/video-write/video-write.html
	     // CV_FOURCC('P','I','M','1'), // is a MPEG-1 codec, ... <http://www.fourcc.org/codecs.php>
         //https://docs.opencv.org/4.2.0/dd/d9e/classcv_1_1VideoWriter.html
         //ffmpeg -codecs 
         // CV_FOURCC('P','I','M','1'), // is a MPEG-1 codec, ... <http://www.fourcc.org/codecs.php>
	     // CV_FOURCC('D', 'I', 'V', 'X'), // DivX4
         // DIV4
         // DIVX

	     elFitxerDeVideo.open( rutaFitxerVideo, 
				   codec, 
 				   5, //30,
				   cv::Size( frame.cols, frame.rows),
				   edges.channels() == 3 ); //true); // isColor	     			  
	     //			 fps, Size frameSize, bool isColor=true)
	     if ( !elFitxerDeVideo.isOpened() ) {
	       printf("Error al obrir %s\n", rutaFitxerVideo.c_str() );
	       gravantVideo = false;
	     }
	     else
	       gravantVideo = true;
	   }
	   else
	   {
               elFitxerDeVideo.release();
       	       printf( "Tancant la gravació en video: %s\n", rutaFitxerVideo.c_str() );
	       // elFitxerDeVideo = "";
	       gravantVideo = false;
	   }
	   //gravantVideo = !gravantVideo;	   	   
          break;
	 
	 case 'f': // Pren una foto del original
          try {
#if CV_MAJOR_VERSION > 3
	    imwrite("original__"+ fetxaString +".jpg", frame, compression_paramsJPEG);
	    //#else
	    //	    imwrite("original__"+ fetxaString +".jpg", frame, 5);
#endif
          }
          catch (std::runtime_error& ex) {
           fprintf(stderr, "Exception converting image to JPEG format: %s\n", ex.what());
           return( ERROR_CONVERSIOJPEG );
          }
	  printf("Guardat:: original__%s.jpg\n", fetxaString.c_str() );	  
          break;  

	 case 'F': // Pren una foto del processat
          try {
#if CV_MAJOR_VERSION > 3
	    imwrite("resultat__"+ fetxaString +".png", edges, compression_paramsPNG);
	    //#else
	    //	    imwrite("original__"+ fetxaString +".png", edges, 5);
#endif
          }
          catch (std::runtime_error& ex) {
           fprintf(stderr, "Exception converting image to PNG format: %s\n", ex.what());
           return( ERROR_CONVERSIOPNG );
          }
	  printf("Guardat:: resultat__%s.jpg\n", fetxaString.c_str() );
          break;

         default: ;    
         } // Fin de "switch ( tecla )"  

  
	/*
        if(waitKey(30) >= 0)
	  //break;
	  volSeguirUsuari = false;
	*/

	
      }// Fi de if ( !cap.grab() )
    }

    //if ( !elFitxerDeVideo.isOpened() ) 
    //    elFitxerDeVideo.release();
    // the camera will be deinitialized automatically in VideoCapture destructor
     return( FI_APLICACIO_OK ) ;
}



//
// Fi de "opencv_camara.cpp"
//
