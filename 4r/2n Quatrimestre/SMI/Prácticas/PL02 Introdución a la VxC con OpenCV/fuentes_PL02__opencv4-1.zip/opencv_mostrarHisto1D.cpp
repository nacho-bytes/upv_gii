/*
 opencv_Histo1D.cpp
 En este ejemplo se describirá cómo mostrar el histograma de una imagen

 El càlcul i pintat de l'histograma s'ha tret de l'exemple que acompanya a OpenCV: 
  <https://docs.opencv.org/3.2.0/d8/dbc/tutorial_histogram_calculation.html>

 $ g++ opencv_Histo1D.cpp -o opencv_Histo1D $(pkg-config opencv --cflags --libs)
 $ opencv_Histo1D lena.jpg

*/
#include <opencv2/opencv.hpp>
#include "opencv2/highgui.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>

using namespace std;
using namespace cv;

#define fGRIS "¡OpenCV en gris!"
#define fRGB  "¡OpenCV en color!"

void mostrarHistogramaRGB( Mat src );
void mostrarHistogramaGris( Mat src );
void accioRatoli(int event, int x, int y, int flags, void* param  );


int main(int argc, char** argv)
{
  Mat src;
  String imageName( "../data/lena.jpg" ); // by default
  
  if (argc > 1) {
      imageName = argv[1];
  }
  else {
    printf("Uso: %s ruta_imagen\n Calcula y muestra el histograma de una imagen.\n", argv[0] );
    exit( 1 );
  }
  
  src = imread( imageName, IMREAD_UNCHANGED); //Ficava: IMREAD_COLOR );
  
  if( src.empty() )
    { return -1; }

  if ( src.channels() == 3 ) { // RGB
    namedWindow( fRGB, WINDOW_AUTOSIZE );
    imshow( fRGB, src );
    mostrarHistogramaRGB( src );
  }
  else { // GRIS
    namedWindow( fGRIS, WINDOW_AUTOSIZE );
    imshow( fGRIS, src );
    mostrarHistogramaGris( src );    
  }
   
  waitKey(0);
  exit( 0 ); //  return 0;
} // Fi de main


// Ample i alt de la finestra per a mostrar els histogrames
int hist_w = 512; int hist_h = 256; // 400;

void pintarHistogramaRGB( Mat b_hist, Mat g_hist, Mat r_hist, int histSize )
{  
  // Draw the histograms for B, G and R
  //int hist_w = 512; int hist_h = 256; // 400;
  int bin_w = cvRound( (double) hist_w/histSize );
  Mat histImage( hist_h, hist_w, CV_8UC3, Scalar( 0,0,0) );
  normalize(b_hist, b_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat() );
  normalize(g_hist, g_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat() );
  normalize(r_hist, r_hist, 0, histImage.rows, NORM_MINMAX, -1, Mat() );
  for( int i = 1; i < histSize; i++ )
    {
      line( histImage, Point( bin_w*(i-1), hist_h - cvRound(b_hist.at<float>(i-1)) ) ,
	    Point( bin_w*(i), hist_h - cvRound(b_hist.at<float>(i)) ),
	    Scalar( 255, 0, 0), 2, 8, 0  );
      line( histImage, Point( bin_w*(i-1), hist_h - cvRound(g_hist.at<float>(i-1)) ) ,
	    Point( bin_w*(i), hist_h - cvRound(g_hist.at<float>(i)) ),
	    Scalar( 0, 255, 0), 2, 8, 0  );
      line( histImage, Point( bin_w*(i-1), hist_h - cvRound(r_hist.at<float>(i-1)) ) ,
	    Point( bin_w*(i), hist_h - cvRound(r_hist.at<float>(i)) ),
	    Scalar( 0, 0, 255), 2, 8, 0  );
    }
  namedWindow("Histograma de color", WINDOW_AUTOSIZE );
  imshow("Histograma de color", histImage );
} // Fi de  mostrarHistogramaRGB

Mat b_hist, g_hist, r_hist;
void mostrarHistogramaRGB( Mat src )
{
  vector<Mat> bgr_planes;
  int histSize = 256;
  float range[] = { 0, 256 } ;
  const float* histRange = { range };
  bool uniform = true; bool accumulate = false;
  //   Mat b_hist, g_hist, r_hist;
    
  split( src, bgr_planes );
  calcHist( &bgr_planes[0], 1, 0, Mat(), b_hist, 1, &histSize, &histRange, uniform, accumulate );
  calcHist( &bgr_planes[1], 1, 0, Mat(), g_hist, 1, &histSize, &histRange, uniform, accumulate );
  calcHist( &bgr_planes[2], 1, 0, Mat(), r_hist, 1, &histSize, &histRange, uniform, accumulate );
  
  pintarHistogramaRGB( b_hist, g_hist, r_hist, histSize );
} // Fi de  mostrarHistogramaRGB


void pintarHistogramaGris( Mat hist, int histSize, Mat histImage )
{  
  // Dibuixa el histograma
  //int hist_w = 512; int hist_h = 256; // 400;
  int bin_w = cvRound( (double) hist_w/histSize );
  //Mat
  histImage.create( hist_h, hist_w, CV_8UC1);
  histImage = Scalar( 0,0,0);
  normalize(hist, hist, 0, histImage.rows, NORM_MINMAX, -1, Mat() );
  for( int i = 1; i < histSize; i++ )
    {
      line( histImage, Point( bin_w*(i-1), hist_h - cvRound(hist.at<float>(i-1)) ) ,
	    Point( bin_w*(i), hist_h - cvRound(hist.at<float>(i)) ),
	    Scalar( 255, 255, 255), 2, 8, 0  );
    }
  namedWindow("Histograma de grises", WINDOW_AUTOSIZE );
  imshow("Histograma de grises", histImage );
} // Fi de  mostrarHistogramaRGB

Mat hist;
void mostrarHistogramaGris( Mat src )
{
  int histSize = 256;
  float range[] = { 0, 256 } ;
  const float* histRange = { range };
  bool uniform = true; bool accumulate = false;
  Mat histImage;
    
  calcHist( &src, 1, 0, Mat(), hist, 1, &histSize, &histRange, uniform, accumulate );
  
  pintarHistogramaGris( hist, histSize, histImage );
  setMouseCallback( "Histograma de grises", accioRatoli, (void*)&histImage  );
} // Fi de  mostrarHistogramaGris


# define ALT_FILA 30
// Exemples de la font Hershey <https://www.codesofinterest.com/2017/07/more-fonts-on-opencv.html>
void printfXY( Mat *image, char *nomFinestra, char *mensatge )
{
  double hScale = 1.0, 
    vScale = 0.5, 
    lineWidth = 1.0, 
    italicScale = 1.0;
  int tipoLletra = FONT_HERSHEY_SIMPLEX,
/*
#if CV_MAJOR_VERSION == 2
      lineType = CV_AA;  //FILLED, LINE_4 o LINE_8, LINE_AA
#elif CV_MAJOR_VERSION == 3
      lineType = LINE_AA; 
#endif         
*/
#ifdef OPENCV4
      lineType = LINE_AA; 
#else
      lineType = CV_AA; //FILLED, LINE_4 o LINE_8, LINE_AA
#endif


  static int columna = cvRound(hist_w / 3),
              fila = 10; //ALT_FILA;

             
              
#if CV_MAJOR_VERSION == 2
  CvFont font;
  cvInitFont(&font,CV_FONT_HERSHEY_SIMPLEX, hScale,vScale, italicScale, lineWidth, 8);
#endif         
  
  putText( *image, mensatge, 
           Point( columna, fila ),	   
	   tipoLletra, vScale, CV_RGB(255,0,255), lineWidth ); //, lineType);
  imshow(nomFinestra, *image);

  fila += ALT_FILA;
  
}// Fi de "void printfXY( ..."

void accioRatoli( int event, int x, int y, int flags, void* param  ) {

  Mat *histImage = (Mat *) param;
  Mat imgTemporal;
  char textDelMensatge[1024];
  char nomFinestraPpal[1024] = "Histograma de grises";

  
  imgTemporal = *histImage;
  
  switch( event ) {

  case EVENT_MOUSEMOVE: 
    if (imgTemporal.channels() == 3) { //RGB
    }
    else { // GRIS
      line( imgTemporal, Point( (x), 0 ), Point( (x), hist_h ),
	    Scalar( 255, 255, 255), 2, 8, 0  );
      imshow(nomFinestraPpal, imgTemporal );
      sprintf( textDelMensatge,
      	       "Gris (%d): %d", x, cvRound(hist.at<float>(x)) );
	    //textDelMensatge = format("Gris (%d): %d", x, hist.at<int>(x) );
      printfXY( &imgTemporal, nomFinestraPpal, textDelMensatge );
      
    }
    
    //if( estaPintado == CIERTO )
    {
     // Mat guarda en orden BGR
     //image->at<Vec3b>(y, x) = Vec3b( valor[B], valor[G], valor[R] );  
    }
    //imshow( fORG, *image );
    break;
  } // fi del switch
} // Fi de void accióRatolí

