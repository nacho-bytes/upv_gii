/*
  Fichero getch.h
 */
#ifndef GETCH_H
#define GETCH_H

char getch(void);

#endif
/*
  Fin de fichero getch.h
 */
