/*
 * Compilar:
 * $ gcc helloWorld2.c  getch.c -lalut -lopenal -o helloWorld2 && helloWorld2
 *
 * (C) M. Agust�. Oct. 2k9
 *   - Se sustituye la funci�n de leer con eco (getchar) por una versi�n sin echo (getch)
 *   - Cambian nombres de variables y mensajes en pantalla.
 *
 * (C) M. Agust�. Nov. 2k8
 *   - Nov. 2k8. Se a�ade un bucle para consumir caracteres por si se teclea m�s de uno 
 *  como respuesta del usuario.
 */

#include <stdio.h> //getchar, printf
//#include <curses.h> //getch
#include <stdlib.h>
#include <AL/alut.h>
#include "utils.h"   // AND, getch



int main (int argc, char **argv)
{
  ALuint buffers[6], fuente;
  char c;

  alutInit (&argc, argv);
  c = 'h';

   buffers[0] = alutCreateBufferHelloWorld ();
   buffers[1] = alutCreateBufferWaveform(ALUT_WAVEFORM_SINE, 440.0, 0.0, 1.0);
   buffers[2] = alutCreateBufferWaveform(ALUT_WAVEFORM_SQUARE,  440.0, 0.0, 1.0);
   buffers[3] = alutCreateBufferWaveform(ALUT_WAVEFORM_SAWTOOTH,  440.0, 0.0, 1.0);
   buffers[4] = alutCreateBufferWaveform(ALUT_WAVEFORM_WHITENOISE,   440.0, 0.0, 1.0);
   buffers[5] = alutCreateBufferWaveform(ALUT_WAVEFORM_IMPULSE, 440.0, 0.0, 1.0);

   alGenSources (1, &fuente);
   printf("'h'ellow, 's'ine, sq'u'are, sa'w'tooh, white'n'oise, 'i'mpulse ('q' para salir): \n");   
  
   do
   {
    switch ( c )
    {
    case 'h':  alSourcei (fuente, AL_BUFFER, buffers[0]);
             break;
    case 's': alSourcei (fuente, AL_BUFFER, buffers[1]);
             break;
    case 'u':  alSourcei (fuente, AL_BUFFER, buffers[2]);
             break;
    case 'w':  alSourcei (fuente, AL_BUFFER, buffers[3]);
             break;
    case 'n':  alSourcei (fuente, AL_BUFFER, buffers[4]);
             break;
    case 'i':  alSourcei (fuente, AL_BUFFER, buffers[5]);
             break;   
   }// switch
   
   alSourcePlay (fuente);
   alutSleep (1);
//#ifdef _WIN32
//	ch = _getch();
//#else
   c = getch();
//#endif

 
   printf("%c\r", c); fflush(stdout);
   } while ((c != 'q') && (c != 'Q'));

   printf("\nTerminando ... \n");

  alDeleteSources(1, &fuente);
  alDeleteBuffers(6, buffers);

  alutExit ();
  return EXIT_SUCCESS;
}
