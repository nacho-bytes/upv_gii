/*
  Fichero utils.h
 */
#ifndef UTILS_H
#define UTILS_H

#include "getch.h"


#define AND &&
#define OR ||
#define TRUE 1
#define FALSE 0



#endif
/*
  Fin de fichero utils.h
 */
