Dentro del directorio ejemplos_api se dan los ejemplos estudiados de la API de DNN de OpenCV y todos los ficheros necesarios para su puesta en marcha. Se incluye un fichero con comandos de ejecucion con los parametros necesarios para reproducir los resultados expuestos en la memoria del proyecto.

Dentro del directorio botbot se da la aplicacion desarollada, el ejemplo base de detector y reconocedor de caras base y los ficheros necesarios.

Para compilar los ejemplos y Botbot se puede hacer uso de los ficheros Make incluidos en cada directorio.

Para una mejor comprension del codigo se recomienda leer detalladamente la memoria junto el codigo implementado y sus comentarios.La memoria se encuentra incluida en el directorio doc.


Debido al tamaño de de los modelos, estos no se encuentran directamente en la descarga. A continuación se listan los enlaces donde se pueden descargar y a que codigo corresponden.


(Mira el fichero EJECUCIONES_DE_PRUEBA.txt en la carpeta ejemplos_api para los parametros que reproducen las ejecuciones de la memoria de los ejemplos de la API)

PARA LOS EJEMPLOS DENTRO DE LA CARPETA EJEMPLOS_API:
	SE NECESITAN LOS FICEROs models.yml y common.hpp: 
		models.yml: https://github.com/opencv/opencv/blob/4.x/samples/dnn/models.yml
		common.hpp: https://github.com/opencv/opencv/blob/4.x/samples/dnn/common.hpp
	EJEMPLO CAFFE: Todos los archivos indicados en https://docs.opencv.org/4.x/d5/de7/tutorial_dnn_googlenet.html 
		https://github.com/opencv/opencv_extra/blob/4.x/testdata/dnn/bvlc_googlenet.prototxt
		http://dl.caffe.berkeleyvision.org/bvlc_googlenet.caffemodel
		https://github.com/opencv/opencv/blob/4.x/samples/data/dnn/classification_classes_ILSVRC2012.txt
		
	EJEMPLO YOLO: 
		https://github.com/AlexeyAB/darknet/blob/master/cfg/yolov3.cfg
		https://pjreddie.com/media/files/yolov3.weights
		
	EJEMPLO TEXTOS: De https://docs.opencv.org/4.x/d4/d43/tutorial_dnn_text_spotting.html
		crnn_cs.onnx: https://drive.google.com/uc?export=dowload&id=12diBsVJrS9ZEl6BNUiRp9s0xPALBS7kt
		alphabet_94.txt: https://drive.google.com/uc?export=dowload&id=1oKXxXKusquimp7XY1mFvj9nwLzldVgBR
		DB_IC15_resnet18.onnx: https://drive.google.com/uc?export=dowload&id=1vY_KsDZZZb_svd5RT6pjyI8BS1nPbBSX
		DB_IC15_resnet50.onnx: https://drive.google.com/uc?export=dowload&id=17_ABp79PlFt9yPCxSaarVc_DKTmrSGGf
		EAST: https://www.dropbox.com/s/r2ingd0l3zt8hxs/frozen_east_text_detection.tar.gz?dl=1
		Imagenes de test: 
			https://drive.google.com/uc?export=dowload&id=1nMcEy68zDNpIlqAn6xCk_kYcUTIeSOtN
			https://drive.google.com/uc?export=dowload&id=149tAhIcvfCYeyufRoZ9tmc2mZDKE_XrF
					

PARA EL RECONOCEDOR Y DETECTOR DE CARAS BASE Y LA APLICACION BOTBOT:
yunet_120x160.onxx: https://github.com/ShiqiYu/libfacedetection.train/tree/master/tasks/task1/onnx
face_recognizer_fast.onxx: https://drive.google.com/file/d/1ClK9WiB492c5OZFKveF3XiHCejoOxINW/view


