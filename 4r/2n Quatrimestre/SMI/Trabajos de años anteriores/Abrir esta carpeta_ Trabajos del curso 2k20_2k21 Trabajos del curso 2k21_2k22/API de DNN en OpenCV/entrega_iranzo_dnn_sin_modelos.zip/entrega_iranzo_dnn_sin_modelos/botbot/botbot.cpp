#include <opencv2/dnn.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/objdetect.hpp>
#include <iostream>
#include <fstream>
#include <random>
using namespace cv;
using namespace std;

int numLineas=0;

vector<vector<string>> extraerFichero(string fileName)
{
    ifstream file(fileName);
    vector<vector<string>> dataList;
    string line = "";
    while (getline(file, line))
    {
        vector<string> vec;
        stringstream ss (line);
        string item;
        numLineas++;
        while (getline(ss, item, '|')){
            vec.push_back(item);
        }   
        dataList.push_back(vec);
    }
    file.close();
    return dataList;

}

void reconocer(Mat& image1, Mat& image2,Mat& caracteristicas1,Mat& caracteristicas2, Ptr<FaceRecognizerSF> faceRecognizer,array<double,2>& result)
{
    
    // Aligning and cropping facial image through the first face of faces detected.
    Mat aligned_face1, aligned_face2;
    faceRecognizer->alignCrop(image1, caracteristicas1, aligned_face1);
    faceRecognizer->alignCrop(image2, caracteristicas2, aligned_face2);
    // Run feature extraction with given aligned_face
    Mat feature1, feature2;
    faceRecognizer->feature(aligned_face1, feature1);
    feature1 = feature1.clone();
    faceRecognizer->feature(aligned_face2, feature2);
    feature2 = feature2.clone();
    result[0] = faceRecognizer->match(feature1, feature2, FaceRecognizerSF::DisType::FR_COSINE);
    result[1] = faceRecognizer->match(feature1, feature2, FaceRecognizerSF::DisType::FR_NORM_L2);
    feature1.release();
    feature2.release();
    aligned_face1.release();
    aligned_face2.release();

}


static
void visualize(Mat& input, int frame, Mat& faces, double fps, bool verbose,int thickness = 2)
{
    std::string fpsString = cv::format("FPS : %.2f", (float)fps);
    if(verbose)
    { 
        if (frame >= 0)
            cout << "Frame " << frame << ", ";
        cout << "FPS: " << fpsString << endl;
    } 

    for (int i = 0; i < faces.rows; i++)
    {
        // Print results
        if(verbose)
        {   
            cout << "Face " << i
                << ", top-left coordinates: (" << faces.at<float>(i, 0) << ", " << faces.at<float>(i, 1) << "), "
                << "box width: " << faces.at<float>(i, 2)  << ", box height: " << faces.at<float>(i, 3) << ", "
                << "score: " << cv::format("%.2f", faces.at<float>(i, 14))
                << endl;

        circle(input, Point2i(int(faces.at<float>(i, 4)), int(faces.at<float>(i, 5))), 2, Scalar(255, 0, 0), thickness);
        circle(input, Point2i(int(faces.at<float>(i, 6)), int(faces.at<float>(i, 7))), 2, Scalar(0, 0, 255), thickness);
        circle(input, Point2i(int(faces.at<float>(i, 8)), int(faces.at<float>(i, 9))), 2, Scalar(0, 255, 0), thickness);
        circle(input, Point2i(int(faces.at<float>(i, 10)), int(faces.at<float>(i, 11))), 2, Scalar(255, 0, 255), thickness);
        circle(input, Point2i(int(faces.at<float>(i, 12)), int(faces.at<float>(i, 13))), 2, Scalar(0, 255, 255), thickness);

        } 
        // Draw bounding box
        rectangle(input, Rect2i(int(faces.at<float>(i, 0)), int(faces.at<float>(i, 1)), int(faces.at<float>(i, 2)), int(faces.at<float>(i, 3))), Scalar(0, 255, 0), thickness);
        // Draw landmarks
        
    }
    putText(input, fpsString, Point(0, 15), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 255, 0), 2);
}
int main(int argc, char** argv)
{
    CommandLineParser parser(argc, argv,
        "{help  h           |            | Print this message}"
        "{image1 i1         |            | Path to the input image1. Omit for detecting through VideoCapture}"
        "{image2 i2         |            | Path to the input image2. When image1 and image2 parameters given then the program try to find a face on both images and runs face recognition algorithm}"
        "{video v           | 0          | Path to the input video}"
        "{scale sc          | 1.0        | Scale factor used to resize input video frames}"
        "{fd_model fd       | yunet_120x160.onnx | Path to the model. Download yunet.onnx in https://github.com/ShiqiYu/libfacedetection.train/tree/master/tasks/task1/onnx }"
        "{fr_model fr       | face_recognizer_fast.onnx | Path to the face recognition model. Download the model at https://drive.google.com/file/d/1ClK9WiB492c5OZFKveF3XiHCejoOxINW/view}"
        "{score_threshold   | 0.9        | Filter out faces of score < score_threshold}"
        "{nms_threshold     | 0.3        | Suppress bounding boxes of iou >= nms_threshold}"
        "{top_k             | 5000       | Keep top_k bounding boxes before NMS}"
        "{save s            | false      | Set true to save results. This flag is invalid when using camera}"
        "{verbose verb      | false      | Muestra mensajes de ayuda por terminal}"
        "{th_coseno cos     | 0.363      | Determina el threshold para el calculo de similitud por coseno}"
        "{th_l2 l2          | 1.128      | Determina el threshold para el calculo por similitud por distancia Euclidia}"

    );
    if (parser.has("help"))
    {
        parser.printMessage();
        return 0;
    }
    String fd_modelPath = parser.get<String>("fd_model");
    String fr_modelPath = parser.get<String>("fr_model");
    float scoreThreshold = parser.get<float>("score_threshold");
    float nmsThreshold = parser.get<float>("nms_threshold");
    int topK = parser.get<int>("top_k");
    bool save = parser.get<bool>("save");
    bool verbose = parser.get<bool>("verbose");
    double cosine_similar_thresh = parser.get<double>("th_coseno");
    double l2norm_similar_thresh = parser.get<double>("th_l2");
    VideoWriter grabadorOuput;
    bool grabando = false;
    vector<cv::Mat> caras_guardadas;
    vector<String> nombres;
    vector<Mat> cg_caracteristicas;
    String quizFileName="quiz.txt";
    String dirCaras="./caras/";
    vector<vector<string>> quiz;
    quiz=extraerFichero(quizFileName);
    // Initialize FaceDetectorYN
    Ptr<FaceDetectorYN> detector = FaceDetectorYN::create(fd_modelPath, "", Size(320, 320), scoreThreshold, nmsThreshold, topK);
    TickMeter tm;
    // If input is an image
    if (parser.has("image1"))
    {
        String input1 = parser.get<String>("image1");
        Mat image1 = imread(samples::findFile(input1));
        if (image1.empty())
        {
            std::cerr << "ERROR: No se puede abrir image: " << input1 << std::endl;
            return 2;
        }
        tm.start();
        // Set input size before inference
        detector->setInputSize(image1.size());
        Mat faces1;
        detector->detect(image1, faces1);
        if (faces1.rows < 1)
        {
            std::cerr << "ERROR: No se puede encontrar ninguna cara en " << input1 << std::endl;
            return 1;
        }
        tm.stop();
        // Draw results on the input image
        visualize(image1, -1, faces1, tm.getFPS(),verbose);
        // Save results if save is true
        if (save)
        {
            cout << "Guardando result.jpg...\n";
            imwrite("result.jpg", image1);
        }
        // Visualize results
        imshow("image1", image1);
        pollKey();  // handle UI events to show content
        if (parser.has("image2"))
        {
            String input2 = parser.get<String>("image2");
            Mat image2 = imread(samples::findFile(input2));
            if (image2.empty())
            {
                std::cerr << "ERROR: No se puede abrir image2: " << input2 << std::endl;
                return 2;
            }
            tm.reset();
            tm.start();
            detector->setInputSize(image2.size());
            Mat faces2;
            detector->detect(image2, faces2);
            if (faces2.rows < 1)
            {
                std::cerr << "ERROR: No se puede encontrar ninguna cara en  " << input2 << std::endl;
                return 1;
            }
            tm.stop();
            visualize(image2, -1, faces2, tm.getFPS(),verbose);
            if (save)
            {
                cout << "Guardando result2.jpg...\n";
                imwrite("result2.jpg", image2);
            }
            imshow("image2", image2);
            pollKey();
            // Initialize FaceRecognizerSF
            Ptr<FaceRecognizerSF> faceRecognizer = FaceRecognizerSF::create(fr_modelPath, "");
            array<double,2> scores; 
            reconocer(image1,image2,faces1,faces2,faceRecognizer,scores);
            double cos_score = scores[0];
            double L2_score = scores[1];

            if (cos_score >= cosine_similar_thresh)
            {
                std::cout << "Tienen la misma identidad;";
            }
            else
            {
                std::cout << "Tienen identidades diferentes;";
            }
            std::cout << " Similitud por coseno: " << cos_score << ", threshold: " << cosine_similar_thresh << ". (Mayor el valor, mayor la similitud max 1.0)\n";
            if (L2_score <= l2norm_similar_thresh)
            {
                std::cout << "Tienen la misma identidad;";
            }
            else
            {
                std::cout << "Tienen identidades diferentes;";
            }
            std::cout << " Similitud por distancia Euclidia: " << L2_score << ", threshold: " << l2norm_similar_thresh << ". (Menor el valor, mayor la similitud, min 0.0)\n";
        }
        cout << "Dale a cualquier tecla para salir" << endl;
        waitKey(0);
    }
    else
    {
        int frameWidth, frameHeight;
        float scale = parser.get<float>("scale");
        VideoCapture capture;
        bool abiertoFicheroVideo=false;
        Mat IquizRespuesta,facesRespuestaCaract;
        string nombrequizCelebridad = "";
        std::string video = parser.get<string>("video");
        if (video.size() == 1 && isdigit(video[0]))         //Si es camara
            capture.open(parser.get<int>("video"));
        else{
            capture.open(samples::findFileOrKeep(video));  // Si es video de fichero
            abiertoFicheroVideo=true;
            }
        if (capture.isOpened())
        {
            frameWidth = int(capture.get(CAP_PROP_FRAME_WIDTH) * scale);
            frameHeight = int(capture.get(CAP_PROP_FRAME_HEIGHT) * scale);
            if(verbose)
            cout << "Video " << video
                << ": width=" << frameWidth
                << ", height=" << frameHeight
                << endl;
        }
        else
        {
            cout << "ERROR: No se pudo inicilizar la captura de video. " << video << "\n";
            return 1;
        }
        detector->setInputSize(Size(frameWidth, frameHeight));
        ifstream file("dibujo.txt");
        string line = "";
        while (getline(file, line)) cout << line << "\n";
        if(abiertoFicheroVideo) cout << " > Procesando el fichero de video. Sesion interactiva descativada (_^^_).\n";
        else cout <<" > ¡Dime algo que hacer!\n";
        int nFrame = 0;
        // Initialize FaceRecognizerSF
        Ptr<FaceRecognizerSF> faceRecognizer = FaceRecognizerSF::create(fr_modelPath, "");
        array<double,2> scores; 
        for (;;)
        {
            // Get frame
            Mat frame;
            if (!capture.read(frame))
            {
                cerr << "> Fin del video.\n";
                break;
            }
            resize(frame, frame, Size(frameWidth, frameHeight));
            // Inference
            Mat faces;
            tm.start();
            detector->detect(frame, faces);
            tm.stop();
            
            //Reconocimiento frame a frame de caras mediante 'C'
            Mat result = frame.clone();
            if ((faces.rows > 0) && (caras_guardadas.size() > 0))
            {   
                for(int i=0;i<faces.rows;i++)
                {   
                    Mat frow=faces.row(i);
                    for(int j=0;j<caras_guardadas.size();j++)
                    {                        
                        reconocer(frame, caras_guardadas[j],frow, cg_caracteristicas[j],faceRecognizer,scores);
                        if ( (scores[0] >= cosine_similar_thresh) && ( scores[1]<= l2norm_similar_thresh) )
                        {
                            putText(result, nombres[j], Point2i(int(faces.at<float>(i, 0)), int(faces.at<float>(i, 1))+10), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 0, 255), 1);   
                        }
                    }  
                }   
            }

            //Quiz activado
            if ((faces.rows > 0) && (!IquizRespuesta.empty()) )
            {  
                Mat actualCaract= faces.row(0);
                reconocer(frame,IquizRespuesta ,actualCaract, facesRespuestaCaract,faceRecognizer,scores); 
                if ( (scores[0] >= cosine_similar_thresh) && ( scores[1]<= l2norm_similar_thresh) )
                    {
                      cout << " > ¡Correcto, es " << nombrequizCelebridad <<"! Un aplauso de mi parte (_oo_)//\n";
                      nombrequizCelebridad="";
                      IquizRespuesta = Mat(); //Limpia la matriz y acaba el modo "quiz"
                    }   
            }

            // Draw results on the input image
            visualize(result, nFrame, faces, tm.getFPS(),verbose);
            // Visualize results
            imshow("Botbot Vision", result);

            // Si hemos abierto un fichero de video y deseamos grabar el resultado
            if(save && abiertoFicheroVideo) 
            {                  
                 if(!grabando){grabadorOuput.open( "./output_grabacion_fichero.avi", 
                                            VideoWriter::fourcc('M','J','P','G'), 
                                            tm.getFPS(),
                                            cv::Size( result.cols, result.rows),
                                            result.channels() == 3 );
                               grabando=true;
                              } 
                else grabadorOuput.write(result);
             waitKey(20);
            }
            else // Si no, procesamos los frames de la camara 
            {
                if(grabando){grabadorOuput.write(result);}
                int key = waitKey(1);
                switch(key){

                    case ' ':
                    {
                        std::string frame_name = cv::format("frame_%05d.png", nFrame);
                        std::string result_name = cv::format("result_%05d.jpg", nFrame);
                        cout << "Saving '" << frame_name << "' and '" << result_name << "' ...\n";
                        imwrite(frame_name, frame);
                        imwrite(result_name, result);
                        break;
                    }

                    case 'V':
                    case 'v':
                        if(!grabando){
                            cout<< " > Grabando... ᕕ(_oo_)ᕗ \n";
                            grabadorOuput.open( "./output_grabacion.avi", 
                                                VideoWriter::fourcc('M','J','P','G'), 
                                                tm.getFPS(),
                                                cv::Size( result.cols, result.rows),
                                                result.channels() == 3 );
                            grabando=true; 
                            grabadorOuput.write(result);  
                        }
                        else
                        {
                            cout << " > Fin de la grabación. (_oo_)✓ " << endl;
                            grabando=false; 
                            grabadorOuput.release();
                        }
                        break;

                    case 'C':
                    case 'c':
                        if (faces.rows == 0)
                        {
                            std::cerr << " > No se puedo detectar una cara. Por favor, pruebe de nuevo. (_xx_)\n";
                        }
                        else
                        {
                        
                        String nombre;
                        Mat cara;
                        // Se coge la primera cara detectada
                        Rect myROI(int(faces.at<float>(0, 0)), int(faces.at<float>(0, 1)), int(faces.at<float>(0, 2)), int(faces.at<float>(0, 3)));
                        frame(myROI).copyTo(cara);
                        cout << " > Escriba su nombre:\n"; 
                        cin >> nombre;
                        imshow(nombre, cara);
                        // Queremos que se guarda la imagen COMPLETA, no la RECORTADA que se muestra por pantalla
                        // porque las cordenadas de los puntos caracteristicos de la cara estan bajo las coordenadas
                        // de la imagen completa y necesitamos estas para que el reconocedor alinea bien las caras.     
                        caras_guardadas.push_back(frame);
                        nombres.push_back(nombre);
                        cg_caracteristicas.push_back(faces.row(0));
                        }
                        break; 

                    case 'G':
                    case 'g':
                        {
                            if(caras_guardadas.size()==0)
                            {
                                cout <<" > No hay ninguna cara disponible para guardar. (_xx_)\n";
                                break;
                            } 
                            cout <<" > Guardando caras actuales... ᕕ(_oo_)ᕗ\n";
                            Mat cara;
                            for(int i=0;i<caras_guardadas.size();i++)
                            {
                                //Rect myROI(int(faces.at<float>(0, 0)), int(faces.at<float>(0, 1)), int(faces.at<float>(0, 2)), int(faces.at<float>(0, 3)));
                                Rect myROI(int(cg_caracteristicas[i].at<float>(0, 0)),int(cg_caracteristicas[i].at<float>(0, 1)),int(cg_caracteristicas[i].at<float>(0, 2)),int(cg_caracteristicas[i].at<float>(0, 3))) ;
                                caras_guardadas[i](myROI).copyTo(cara);

                                imwrite(dirCaras+nombres[i]+"_rec.jpg",cara);
                                imwrite(dirCaras+nombres[i]+".jpg",caras_guardadas[i]);
                            }                        
                            cout <<" > ¡Caras guardadas! (_oo_)✓✓✓\n";
                        }
                        break;

                    case 'Q':
                    case 'q':
                        {
                        // Generador de numero aleatorio tipo "Mersenne twister"
                        std::random_device rd; // conseguir un numero aleatorio de hardware
                        std::mt19937 gen(rd()); // generar la "seed" 
                        std::uniform_int_distribution<> distr(0, numLineas-1); // definir el rango
                        int nAleatorio= distr(gen);
                        nombrequizCelebridad = quiz[nAleatorio][0];
                        IquizRespuesta = imread(samples::findFile(dirCaras + quiz[nAleatorio][1]));
                        string pregunta= quiz[nAleatorio][2];
                        cout << " > PREGUNTA: "<< pregunta << endl;
                        // Cambiamos el tamaño del input del detector al de la imagen del fichero.
                        detector->setInputSize(IquizRespuesta.size());
                        detector->detect(IquizRespuesta, facesRespuestaCaract);
                        // Volvemos a poner el tamaño correspondiente de la imagen de entrada de la camara.
                        detector->setInputSize(Size(frameWidth, frameHeight)); 
                        break;
                        }
                    case 27:
                        exit(0);
                        break;

                    default: 
                        break;
                }
            }
            nFrame++;
        }



        cout << " > Se han procesado " << nFrame << " frames" << endl;
    }
    cout << " > Fin." << endl;
    return 0;
}
