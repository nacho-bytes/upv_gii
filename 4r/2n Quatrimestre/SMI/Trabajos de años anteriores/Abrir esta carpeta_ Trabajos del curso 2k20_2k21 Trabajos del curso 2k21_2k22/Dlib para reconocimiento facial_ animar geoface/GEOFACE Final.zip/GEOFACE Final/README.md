##Programa Geoface en Python

En este documento se explica ejecutar el programa del geoface con reconocimiento de cara.

Este proyecto esta hecho enterro en Python, no necesita pre-compilacion.


Las librerias OpenGL, OpenCV y DLIB son necesitas para la ejecucion del prog, se puede referar al
informe del proyecto para conocer las versiones de las librerias instaladas y instalarlas con la
herramienta Homebrew

/!\ Este Proyecto fue desarollado y ejecutado sobre una maquina MacOS (Intel), algunos cambios en
las cabeceras pueden ser necesitadas para el buen foncionamiento en otro OS.

Para ejecutar el codigo, se debe utilizar python3 con el orden siguiente : 

    /usr/local/bin/python3 "[camino]/faceLandmark.py"