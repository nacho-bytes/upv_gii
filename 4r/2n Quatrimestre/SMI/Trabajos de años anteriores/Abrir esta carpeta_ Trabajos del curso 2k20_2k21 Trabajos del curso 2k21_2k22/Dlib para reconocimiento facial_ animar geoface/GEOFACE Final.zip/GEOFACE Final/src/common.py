from numpy import array, zeros

class TAG():
    def __init__(self): 
        self.poly = int()
        self.vert = int()

class EXPRESSION():
    def __init__(self):
        self.name= str()
        self.m = zeros(20) 
        self.bias = float()

class MUSCLE ():
    def __init__(self):
        self.name = str()
        self.active = int()
        self.head = zeros(3)
        self.tail = zeros(3)
        self.zone  = float()
        self.fs = float()
        self.fe = float()
        self.mval = float()
        self.clampv = float()
        self.mstat = float()

class VERTEX ():
    def __init__(self):
        self.xyz = zeros(3)
        self.nxyz = zeros(3) 
        self.np = 0
        self.plist = zeros(30, dtype = int)
        self.norm = zeros(3)

class POLYGON ():
    def __init__(self, taille=3):
        self.vertex = []
        if (taille > 0):
            for i in range (taille):
                temp = VERTEX()
                self.vertex.append(temp)
        

class HEAD() : 
    def __init__(self) :
        self.npindices = int() # number of polygon indices
        self.indexlist = [] # integer index list of size npindices*4    
        self.npolylinenodes  = int() # number of nodes in the poly line          
        self.polyline  = [] # xyz nodes in the poly line                
        self.npolygons  = int() # total number of polygons                  
        self.polygon = []     # pointer to the polygon list               

        self.neyelidtags = int() # number of eyelid tags                     
        self.eyelidtag = []     #pointer to the eyelid tags                
        self.eyelidang  = float()    # rotation of the eyelids                   

        self.njawtags   = int() # number of jaw tags                        
        self.jawtag = []   # pointer to the eyelid tags                
        self.jawang   = float()      # rotation of the jaw                       

        self.nmuscles   = int() # number of muscles in the face             
        self.muscle = []    # pointer to the muscle list 

        self.nexpressions = int() # number of expressions in the		   
        self.expression = []    # point to an expression vector

