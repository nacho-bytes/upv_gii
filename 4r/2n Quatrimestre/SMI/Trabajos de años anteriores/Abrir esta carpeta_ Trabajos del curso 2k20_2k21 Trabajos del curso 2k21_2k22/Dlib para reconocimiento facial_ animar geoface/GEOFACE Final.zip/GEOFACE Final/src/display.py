from numpy import sqrt, zeros
import common, make_face

#import opengl
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

PAINT_MUSCLES_DEBUG  = 0

def paint_muscles(face) :
    v1 = zeros(3)
    v2 = zeros(3)
    glLineWidth(3.0)
    glColor3f(100.0,200.0,200.0)
    for i in range (face.nmuscles):
        v1 = face.muscle[i].head
        v2 = face.muscle[i].tail
        glBegin ( GL_LINE_STRIP )
        glVertex3f ( v1[0], v1[1], v1[2] )
        glVertex3f ( v2[0], v2[1], v2[2] )
        glEnd()
    glLineWidth(1.0)

def paint_polyline(face):
    v1 = zeros(3)
    r = float()
    glClear    	( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT )
    glLineWidth   ( 1.0 )
    glColor3f     ( 100.0, 100.0, 0.0 )
    glPushMatrix  ( )
    glRotatef	( r, 1.0, 1.0, 1.0 )
    glBegin (GL_LINE_STRIP)
    for i in range (face.npolylinenodes) :
        cnt=0
        for j in range(3) : 
            v1[j] = face.polyline[cnt]
            cnt = cnt + 1
        glVertex3f ( v1[0], v1[1], v1[2] )
    glEnd()
    glPopMatrix()
    glFlush()
  
def paint_polygons (face : common.HEAD, type, normals):
    v1 = zeros(3)
    v2 = zeros(3)
    v3 = zeros(3)
    norm1 = zeros(3)
    norm2 = zeros(3)
    norm3 = zeros(3)
    vn1 = zeros(3)
    vn2 = zeros(3)
    vn3 = zeros(3)
    glLineWidth(2.0)  
    for i in range (face.npolygons) :
        for j in range (3) :
            v1[j] = face.polygon[i].vertex[0].xyz[j] 
            v2[j] = face.polygon[i].vertex[1].xyz[j] 
            v3[j] = face.polygon[i].vertex[2].xyz[j]
    
        if ( type == 0 ) :
            for j in range (3) :
                norm1[j] = face.polygon[i].vertex[0].norm[j]
                norm2[j] = face.polygon[i].vertex[1].norm[j]
                norm3[j] = face.polygon[i].vertex[2].norm[j]
            glBegin ( GL_LINE_LOOP )
            glNormal3f ( norm1[0], norm1[1], norm1[2] )
            glVertex3f ( v1[0],    v1[1],    v1[2]    )
            glNormal3f ( norm2[0], norm2[1], norm2[2] )
            glVertex3f ( v2[0],    v2[1],    v2[2]    )
            glNormal3f ( norm3[0], norm3[1], norm3[2] )
            glVertex3f ( v3[0],    v3[1],    v3[2]    )
            glEnd ( )
        if ( type == 1 ) :
            norm1 = face.polygon[i].vertex[0].norm     
            norm2 = face.polygon[i].vertex[1].norm
            norm3 = face.polygon[i].vertex[2].norm
            glBegin ( GL_TRIANGLES )
            glNormal3f ( norm1[0], norm1[1], norm1[2] ) 
            glVertex3f ( v1[0],    v1[1],    v1[2]    ) 
            glNormal3f ( norm2[0], norm2[1], norm2[2] ) 
            glVertex3f ( v2[0],    v2[1],    v2[2]    ) 
            glNormal3f ( norm3[0], norm3[1], norm3[2] ) 
            glVertex3f ( v3[0],    v3[1],    v3[2]    ) 
            glEnd ( ) 
        elif(type == 2) :
            make_face.averaged_vertex_normals ( face, i, norm1, norm2, norm3 )
        
        if (type) :
            glBegin ( GL_TRIANGLES )
            glNormal3f ( norm1[0], norm1[1], norm1[2] )
            glVertex3f ( v1[0],    v1[1],    v1[2]    )
            glNormal3f ( norm2[0], norm2[1], norm2[2] )
            glVertex3f ( v2[0],    v2[1],    v2[2]    )
            glNormal3f ( norm3[0], norm3[1], norm3[2] )
            glVertex3f ( v3[0],    v3[1],    v3[2]    )
            glEnd ()
        
        if (normals) :
            for j in range(3) :
                vn1[j] = face.polygon[i].vertex[0].xyz[j] + norm1[j]
                vn2[j] = face.polygon[i].vertex[1].xyz[j] + norm2[j]
                vn3[j] = face.polygon[i].vertex[2].xyz[j] + norm3[j]

            glBegin ( GL_LINE_STRIP )
            glVertex3f ( v1[0],    v1[1],    v1[2]     )
            glVertex3f ( vn1[0],  vn1[1],    vn1[2]    ) 
            glEnd()

            glBegin ( GL_LINES )
            glVertex3f ( v2[0],    v2[1],    v2[2]     )
            glVertex3f ( vn2[0],  vn2[1],    vn2[2]    )
            glEnd()

            glBegin ( GL_LINES )
            glVertex3f ( v3[0],    v3[1],    v3[2]     )
            glVertex3f ( vn3[0],  vn3[1],    vn3[2]    )
            glEnd ( )
    glLineWidth ( 1.0 ) ;  

def calculate_polygon_vertex_normal (face : common.HEAD) : 
    p1 = zeros(3)
    p2 = zeros(3)
    p3 = zeros(3)
    norm = zeros(3)
    for i in range(face.npolygons) :
        for j in range(3):
            p1[j] = face.polygon[i].vertex[0].xyz[j]
        for j in range (3):
            p2[j] = face.polygon[i].vertex[1].xyz[j]
        for j in range (3):
            p3[j] = face.polygon[i].vertex[2].xyz[j]

        calc_normal ( p1, p2, p3, norm )

        for j in range (3) :
	        for k in range(3) :
	            face.polygon[i].vertex[j].norm[k] = norm[k]

def calc_normal(p1, p2, p3, norm) :
    px1 = p1[0]
    py1 = p1[1]
    pz1 = p1[2]
    
    px2 = p2[0]
    py2 = p2[1]
    pz2 = p2[2]
    
    px3 = p3[0]
    py3 = p3[1]
    pz3 = p3[2]
    
    coa = -(py1 * (pz2-pz3) + py2*(pz3-pz1) + py3*(pz1-pz2))
    cob = -(pz1 * (px2-px3) + pz2*(px3-px1) + pz3*(px1-px2))
    coc = -(px1 * (py2-py3) + px2*(py3-py1) + px3*(py1-py2))
    
    absvec = sqrt (((coa*coa) + (cob*cob) + (coc*coc)))
    
    norm[0] = coa/absvec
    norm[1] = cob/absvec
    norm[2] = coc/absvec

