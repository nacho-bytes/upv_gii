#import
import cv2, dlib, math
import geoface

from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

class Position() : 
    def __init__(self):
        self.tab = {    "boucheGauche" : [None,None],           #49 -> 0
                        "boucheDroit" : [None,None],            #55 -> 1
                        "levreGaucheSup" : [None,None],         #51 -> 10
                        "levreDroitSup" : [None,None],          #53 -> 11
                        "nezGauche" : [None,None],              #32 -> 12
                        "nezDroit" : [None,None],               #36 -> 13
                        "arcadeGaucheExterne" : [None,None],       #22-> 4
                        "arcadeDroiteExterne" : [None,None],        #23 -> 5
                        "arcadeGaucheCentre" : [None,None],         #20 -> 6
                        "arcadeDroiteCentre" : [None,None]         #25 -> 7
        }

class Main():

    pos = Position()
    model = geoface.Geoface()
    tableLEFT = {
        48 : [0, "boucheGauche"],
        50 : [10,"levreGaucheSup"],
        31 : [12, "nezGauche"],
        21 : [4, "arcadeGaucheExterne"],
        19 : [6, "arcadeGaucheCentre"]
    }
    tableRIGHT = {
        54 : [1, "boucheDroit"],
        52 : [11, "levreDroitSup"],
        35 : [13, "nezDroit"],
        22 : [5, "arcadeDroiteExterne"],
        24 : [7, "arcadeDroiteCentre"]
    }

    def initValuesPos(self):
        _, frame = self.cap.read()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.hog_face_detector(gray)
        distance = 0
        while (not faces) :
            _, frame = self.cap.read()
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = self.hog_face_detector(gray)
        for face in faces:
            face_landmarks = self.dlib_facelandmark(gray, face)
            for n in range(20, 56): #16,68
                x = face_landmarks.part(n).x
                y = face_landmarks.part(n).y               
                if (n == 20):
                    self.pos.tab["arcadeGaucheCentre"] = [x,y]
                    x1 = x
                    y1 = y
                elif (n == 22):
                    self.pos.tab["arcadeGaucheExterne"] = [x,y]
                    x2 = x
                    y2 = y
                elif (n == 23):
                    self.pos.tab["arcadeDroiteExterne"] = [x,y]
                elif (n == 25):
                    self.pos.tab["arcadeDroiteCentre"] = [x,y]
                elif (n == 32):
                    self.pos.tab["nezGauche"] = [x,y]
                elif (n == 36):
                    self.pos.tab["nezDroit"] = [x,y]
                elif (n == 49):
                    self.pos.tab["boucheGauche"] = [x,y]
                elif (n == 51):
                    self.pos.tab["levreGaucheSup"] = [x,y]
                elif (n == 53):
                    self.pos.tab["levreDroitSup"] = [x,y]
                elif (n == 55):
                    self.pos.tab["boucheDroit"] = [x,y]
            distance = math.sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1))
            distance = int(0.1 * distance)
        return distance        

    def movementLEFT(self, x, y, muscle, name, ecart = 4) : 
        self.model.muscle_select(muscle)
        if ((x + ecart < self.pos.tab[name][0])) :
            while ((x + ecart < self.pos.tab[name][0])):
                x = x + ecart
                self.model.main_menu_select(3)
            self.pos.tab[name] = [x, y]
        elif ((x - ecart > self.pos.tab[name][0]))  :
            while ((x - ecart > self.pos.tab[name][0])) :
                self.model.main_menu_select(4)
                x = x - ecart
            self.pos.tab[name] = [x,y]
            
    def movementRIGHT(self, x, y, muscle, name, ecart = 4) : 
        self.model.muscle_select(muscle)
        if ((x - ecart > self.pos.tab[name][0])):
            while ((x - ecart > self.pos.tab[name][0])):   
                self.model.main_menu_select(3)
                x = x - ecart
            self.pos.tab[name] = [x, y]
        elif ((x + ecart < self.pos.tab[name][0])) :
            while ((x + ecart < self.pos.tab[name][0])):
                self.model.main_menu_select(4)
                x = x + ecart
            self.pos.tab[name] = [x,y]

    def movementEYE(self, x, y, muscle, name, ecart = 4): 
        self.model.muscle_select(muscle)
        ecart = ecart * 2
        if ((y - ecart > self.pos.tab[name][1])) :
            while ((y - ecart > self.pos.tab[name][1])):
                self.model.main_menu_select(3)
                y = y - ecart
            self.pos.tab[name] = [x, y]
        elif ((y + ecart < self.pos.tab[name][1]))  :
            while ((y - ecart < self.pos.tab[name][1])) :
                self.model.main_menu_select(4)
                y = y + ecart
            self.pos.tab[name] = [x,y]

    def cameraGrab(self, distance) :
        while True:
            _, frame = self.cap.read()
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = self.hog_face_detector(gray)
            for face in faces:
                face_landmarks = self.dlib_facelandmark(gray, face)
                x1 = 0
                y1 = 0
                x2 = 0
                y2 = 0
                for n in range(49, 56): #20,56
                    x = face_landmarks.part(n).x
                    y = face_landmarks.part(n).y   
                    # if (n == 20):
                    #      self.movementEYE(x, y, 6, "arcadeGaucheCentre", distance)
                    #      x1 = x
                    #      y1 = y
                    # elif (n == 22):
                    #      self.movementLEFT(x, y, 4, "arcadeGaucheExterne", distance)
                    #      x2 = x
                    #      y2 = y
                    # elif (n == 23):
                    #     self.movementRIGHT(x, y, 5, "arcadeDroiteExterne", distance)
                    # elif (n == 25):
                    #     self.movementEYE(x, y, 7, "arcadeDroiteCentre", distance)
                    # if (n == 32):
                    #     self.movementLEFT(x, y, 12, "nezGauche", distance)
                    # elif (n == 36):
                    #     self.movementRIGHT(x, y, 13, "nezDroit")
                    if (n == 49):
                        self.movementLEFT(x, y, 0, "boucheGauche", distance)
                        x1 = x
                        y1 = y
                    # elif (n == 51):
                    #      self.movementLEFT(x, y, 10,"levreGaucheSup", distance)
                    # elif (n == 53):
                    #     self.movementRIGHT(x, y, 11, "levreDroitSup", distance)
                    elif (n == 55):
                        self.movementRIGHT(x, y, 1, "boucheDroit", distance)
                        x2 = x
                        y2 = y
            if (x1 != 0 and x2 != 0 and y1 != 0 and y2 != 0):
                distance = math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1))
                distance = int(0.1 * distance)   
            glutMainLoopEvent()


    def __init__(self):
        glutInitWindowSize(400,600)
        glutInit()
        glutInitDisplayMode	(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH | GLUT_MULTISAMPLE)
        glutCreateWindow("Geoface - Initialization...")
        self.hog_face_detector = dlib.get_frontal_face_detector()
        self.dlib_facelandmark = dlib.shape_predictor("DATA/shape_predictor_68_face_landmarks.dat")
        self.model.myinit()
        self.model.faceinit()
        glutMouseFunc(self.model.mouse)
        glutMotionFunc(self.model.motion)
        glutKeyboardFunc(self.model.Key) 	
        glutSpecialFunc(self.model.special)
        glutReshapeFunc(self.model.myReshape) 
        glutDisplayFunc(self.model.display)
        self.model.make_menus()
        self.cap = cv2.VideoCapture(0)
        glutSetWindowTitle("Geoface - Waiting for a face...")
        glutMainLoopEvent()
        distance = self.initValuesPos()
        glutSetWindowTitle("Geoface")
        glutMainLoopEvent()
        self.cameraGrab(distance)
        self.cap.release()
        self.cv2.destroyAllWindows()


__name__=="__main__"
prog = Main()