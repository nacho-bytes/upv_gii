from genericpath import exists
from pickle import FALSE

from numpy import zeros
import common
import os

def read_polygon_indices (FileName, face : common.HEAD) : 
    ii = 0
    if os.path.isfile('./'+FileName):
        filin = open(FileName, "r")
        face.npindices = int(filin.readline()) 
        face.indexlist = zeros(face.npindices * 4, dtype = int)
        for i in range (face.npindices):
            ligne = filin.readline()
            ligne = ligne.split()
            for x in range (4):
                face.indexlist[ii+x] = ligne[x]
            ii = ii + 4
        filin.close()
    else :
        print("Impossible to open the file "+FileName)
        exit(-1)

def read_polygon_line (FileName, face : common.HEAD) :
    ii = 0
    if os.path.isfile('./'+FileName):
        filin = open(FileName, "r")
        face.npolylinenodes = int(filin.readline())
        face.polyline = zeros(face.npolylinenodes*3)
        for i in range(face.npolylinenodes):
            ligne = filin.readline()
            ligne = ligne.split()
            for x in range(3):
                face.polyline[ii+x] = float(ligne[x])
            ii = ii + 3
        filin.close()
    else :
        print("Impossible to open the file " + FileName)
        exit(-1)

def read_muscles (FileName, face : common.HEAD):
    if os.path.isfile('./'+FileName):
        filin = open(FileName, "r")
        nm = int(filin.readline())
        #we read the blank line
        ligne = filin.readline()
        for i in range(nm):
            m = common.MUSCLE()
            ligne = filin.readline()
            ligne = ligne.split()
            m.name = ligne[0]
            ligne = filin.readline()
            ligne = ligne.split()
            m.head[0] = ligne[0]
            m.head[1]= ligne[1]
            m.head[2]= ligne[2]
            ligne = filin.readline()
            ligne = ligne.split()
            m.tail[0]= ligne[0]
            m.tail[1]= ligne[1]
            m.tail[2]= ligne[2]
            ligne = filin.readline()
            ligne = ligne.split()
            m.fs= ligne[0]
            m.fe= ligne[1]
            m.zone= ligne[2]
            m.clampv= ligne[3]
            m.active = False
            m.mstat = 0.0
            add_muscle_to_face(m, face)
            ligne= filin.readline()
        filin.close()
    else :
        print("Impossible to open the file " + FileName)
        exit(-1)


def read_expression_vectors (FileName, face : common.HEAD ) :
    if os.path.isfile('./'+FileName):
        e = common.EXPRESSION()
        allocated = 0
        filin = open(FileName, "r")
        nexpressions = filin.readline()
        face.nexpressions = nexpressions
        for i in range (face.nexpressions) :        
            if (allocated == 0) :
                face.expression[i] = common.EXPRESSION()  
            e = face.expression[i]
            e.name = filin.readline()
            for j in range (17) : 
                ligne = filin.readline()
                e.m[j] = float(ligne)
        filin.close()
        allocated = 1
    else :
        print("Impossible to open the file " + FileName) 
        face.expression = None

def add_muscle_to_face(m : common.MUSCLE , face : common.HEAD) : 
    face.muscle.append(m)
    face.nmuscles = face.nmuscles + 1