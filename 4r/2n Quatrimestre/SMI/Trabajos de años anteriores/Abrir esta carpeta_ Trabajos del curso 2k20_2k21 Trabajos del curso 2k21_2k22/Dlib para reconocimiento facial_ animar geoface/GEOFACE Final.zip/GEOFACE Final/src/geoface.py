#!/usr/bin/env python

#import python
import sys
import common, display, fileio, muscle, make_face

#import opengl
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *


class Geoface():

    ##VAR
    spinxlight = 0
    spinylight = 0
    spinxface = 0
    spinyface = 0
    DRAW_MODE = 2
    rotate = 0
    movelight = 0
    face = common.HEAD()
    origx = 0
    origy = 0   
    m = 0
    e = 0

    def motion(self, x,y) :
        if (self.rotate) :
            self.spinyface = ( self.spinyface + (x - self.origx)) % 360
            self.spinxface = (self.spinxface + (y - self.origy) ) % 360
            self.origx = x
            self.origy = y
            glutPostRedisplay()
        if (self.movelight):
            self.spinylight = (self.spinylight + (x - self.origx ) ) % 360 
            self.spinxlight = (self.spinxlight + (y - self.origy ) ) % 360 
            self.origx = x
            self.origy = y
            glutPostRedisplay()

    def mouse(self, button, state, x, y) : 
        if button == GLUT_LEFT_BUTTON :
            if (state == GLUT_DOWN) :
                self.origx = x
                self.origy = y
                self.rotate = 1
            else :
                self.rotate = 0
        elif button == GLUT_MIDDLE_BUTTON:
            if (state == GLUT_DOWN) :
                self.origx = x
                self.origy = y
                self.movelight = 1
            else :
                self.movelight = 0
    
    def myinit(self) :
        glEnable    (GL_LIGHTING)
        glEnable    (GL_LIGHT0)
        glDepthFunc (GL_LEQUAL)
        glEnable    (GL_DEPTH_TEST)

    def faceinit(self) :
        self.face = make_face.create_face("DATA/index.dat","DATA/faceline.dat")
        fileio.read_muscles("DATA/muscle.dat",self.face)
        make_face.data_struct(self.face)

    def read_expressions(self) :
        fileio.read_expression_vectors("DATA/expression-vectors.dat",self.face)

    def display (self):
        position = [30.0, 70.0, 100.0, 1.0]
        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
        glPushMatrix()
        glTranslatef(0.0,0.0,-30.0)    
        glRotated(self.spinxface,1.0,0.0,0.0)
        glRotated(self.spinyface,0.0,1.0,0.0)    
        glPushMatrix()
        glRotated(self.spinxlight,1.0,0.0,0.0)
        glRotated(self.spinylight,0.0,1.0,0.0)
        glLightfv(GL_LIGHT0,GL_POSITION,position)
        glTranslated(0.0,0.0,50.0)
        glDisable(GL_LIGHTING)
        glColor3f(0.0,1.0,1.0)
        glutWireCube(0.1)
        glEnable(GL_LIGHTING)
        glPopMatrix()
        display.calculate_polygon_vertex_normal(self.face)
        display.paint_polygons(self.face, self.DRAW_MODE, 0)	
        if (self.DRAW_MODE==0):
            display.paint_muscles(self.face)
        glPopMatrix()
        glutSwapBuffers()
    
    def myReshape(self, w : GLsizei, h : GLsizei) :
        glViewport(0,0,w,h)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(40.0, w/h, 1.0, 100.0 )
        glMatrixMode  ( GL_MODELVIEW )

    def error_exit(error_message ) :
        print (error_message)
        sys.exit(1)

    def usage(name):
        print(
        "usage: ", name, " [options]\n\n",
        "  Options:\n",
        "    -display  displayname  specify an X server connection\n",
        "    -geometry geometry     specify window geometry in pixels\n",
        "    -rgba                  ask for rgba visual\n",
        "    -index                 ask for color index visual\n",
        "    -doublebuffer          ask for double buffered visual\n",
        "    -singlebuffer          ask for single buffered visual\n",
        "    -accum                 ask for accumulation buffer\n",
        "    -alpha                 ask for alpha buffer\n",
        "    -depth                 ask for depth buffer\n",
        "    -stencil               ask for stencil buffer\n",
        "    -aux nauxbuf           specify number of aux buffers\n",
        "    -level planes          specify planes (0=main,>0=overlay,<0=underlay\n",
        "    -transparent           ask for transparent overlay\n",
        "    -opaque                ask for opaque overlay\n"
        )
        sys.exit(1)

    def Key (self, key, x, y) :
        if (key == 27) or key == 'q' or key == 'Q' :
            sys.exit(0)
        elif (key=='r') or (key == 'R') :
            print("Rereading expression file\n")
            self.read_expressions()
            self.e = 0
            glutPostRedisplay()
        elif (key == 'a') :
            print("increment muscle:" +  self.face.muscle[self.m].name)
            self.face.muscle[self.m].mstat += 0.1
            muscle.activate_muscle(self.face, 
			 self.face.muscle[self.m].head, 
			 self.face.muscle[self.m].tail, 
			 self.face.muscle[self.m].fs,
			 self.face.muscle[self.m].fe,
			 self.face.muscle[self.m].zone,
			 0.1 )
            glutPostRedisplay()
        elif (key == 'A'):
            print("decrement muscle: ", self.face.muscle[self.m].name)
            self.face.muscle[self.m].mstat -= 0.1
            muscle.activate_muscle(self.face, 
			 self.face.muscle[self.m].head, 
			 self.face.muscle[self.m].tail, 
			 self.face.muscle[self.m].fs,
			 self.face.muscle[self.m].fe,
			 self.face.muscle[self.m].zone,
			 -0.1 )
            glutPostRedisplay()
        elif (key == 'b'):
            self.DRAW_MODE = self.DRAW_MODE +1
            if ( self.DRAW_MODE >= 3 ) : 
                DRAW_MODE = 0
            print("draw mode:", self.DRAW_MODE )
            glutPostRedisplay()
        elif (key == 'c') :
            make_face.face_reset(self.face)
            glutPostRedisplay()	
        elif (key == 'n') :
            self.m = self.m +1
            if ( self.m >= self.face.nmuscles ) :
                self.m = 0
            print(self.title, "geoface", self.face.muscle[self.m].name)
            glutSetWindowTitle(self.title)
        elif (key ==  'e') :
            if (self.face.expression) :
                make_face.face_reset(self.face)
                make_face.expressions(self.face, self.e)
                self.e = self.e +1
                if (e >= self.face.nexpressions ) :
                    e = 0
                glutPostRedisplay()
        elif (key == 'h') :
            self.print_mesg()
    
    def special(self, key,x, y) :
        if (key == GLUT_KEY_RIGHT) :
            self.m = self.m +1
            if ( self.m >= self.face.nmuscles ) :
                self.m = 0 
            print(self.face.muscle[self.m].name)
        elif (key == GLUT_KEY_LEFT):
            self.m = self.m -1
            if (self.m < 0 ) :
                self.m = self.face.nmuscles - 1
            print(self.face.muscle[self.m].name) 
        elif (key==GLUT_KEY_UP):
            self.face.muscle[self.m].mstat += 0.1
            muscle.activate_muscle(self.face, 
			 self.face.muscle[self.m].head, 
			 self.face.muscle[self.m].tail, 
			 self.face.muscle[self.m].fs,
			 self.face.muscle[self.m].fe,
			 self.face.muscle[self.m].zone,
			 0.1)
            glutPostRedisplay()
        elif (key == GLUT_KEY_DOWN ):
            self.face.muscle[self.m].mstat -= 0.1
            muscle.activate_muscle ( self.face, 
			 self.face.muscle[self.m].head, 
			 self.face.muscle[self.m].tail, 
			 self.face.muscle[self.m].fs,
			 self.face.muscle[self.m].fe,
			 self.face.muscle[self.m].zone,
			 -0.1 )
            glutPostRedisplay()


    def print_mesg(self) :
        print("a:       draw mode (to `pull' the current facial muscle)\n")
        print("A:       draw mode (to `contract' current facial muscle)\n")
        print("c:       face reset\n")
        print("n:       next muscle (to select another facial muscle to manipulate)\n")
        print("e:       next expression\n")
        print("b:       to change draw mode: wireframe->polygonal patches->smooth surface\n")
        print("r,R:     reread the expression file (../face-data/expression-vectors.dat)\n         (Note: this resets the expression sequence to the beginning)\n")
        print("q,Q,Esc: quit\n")
        print("h:       outputs this message\n")
        print("\n")
    
    def muscle_select(self, value : int) :
        self.m = value

    def main_menu_select(self, value) :
        if value == 1:
            make_face.face_reset(self.face)
            glutPostRedisplay()
        elif value ==  2:
            self.print_mesg()
        elif value ==  3:
            self.face.muscle[self.m].mstat += 0.25
            muscle.activate_muscle( self.face, 
            self.face.muscle[self.m].head, 
            self.face.muscle[self.m].tail, 
            self.face.muscle[self.m].fs,
            self.face.muscle[self.m].fe,
            self.face.muscle[self.m].zone,
            +0.25 )
            glutPostRedisplay()
        elif value == 4:
            self.face.muscle[self.m].mstat -= 0.25
            muscle.activate_muscle(self.face, 
            self.face.muscle[self.m].head, 
            self.face.muscle[self.m].tail, 
            self.face.muscle[self.m].fs,
            self.face.muscle[self.m].fe,
            self.face.muscle[self.m].zone,
            -0.25 )
            glutPostRedisplay()
        elif value == 5:
            self.m = self.m +1
            if (self.m >= self.face.nmuscles ) :
                self.m = 0
            print(self.face.muscle[self.m].name)
        elif value == 666:
            sys.exit(0)

    def draw_mode_select(self,value):
        self.DRAW_MODE = value
        glutPostRedisplay()
    
    def make_menus(self) :
        muscle_menu = glutCreateMenu(self.muscle_select)
        for i in range (self.face.nmuscles):
            entry = self.face.muscle[i].name
            entry = entry.replace('_', ' ')
            glutAddMenuEntry(entry, i)
        draw_mode_menu = glutCreateMenu(self.draw_mode_select)
        glutAddMenuEntry("Wireframe", 0)
        glutAddMenuEntry("Polygonal patches", 1)
        glutAddMenuEntry("Smooth surface", 2)
        glutCreateMenu(self.main_menu_select)
        glutAddMenuEntry("Pull muscle up", 3)
        glutAddMenuEntry("Pull muscle down", 4)
        glutAddMenuEntry("Next muscle", 5)
        glutAddSubMenu("Select muscle", muscle_menu)
        glutAddSubMenu("Draw mode", draw_mode_menu)
        glutAddMenuEntry("Face reset", 1)
        glutAddMenuEntry("Print help", 2)
        glutAddMenuEntry("Quit", 666)
        glutAttachMenu(GLUT_RIGHT_BUTTON)
