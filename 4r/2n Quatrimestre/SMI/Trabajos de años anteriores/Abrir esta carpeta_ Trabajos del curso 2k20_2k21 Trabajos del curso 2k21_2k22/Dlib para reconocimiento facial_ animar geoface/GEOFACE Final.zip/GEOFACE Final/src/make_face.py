from numpy import array, zeros
import common, muscle, fileio


def face_reset (face : common.HEAD ) : 
    for i in range (face.npolygons): 
        for j in range (3):
            for k in range (3):
                face.polygon[i].vertex[j].xyz[k] = face.polygon[i].vertex[j].nxyz[k]

def expressions (face : common.HEAD, e) : 
    for i in range (face.nmuscles):
        m_val = face.expression[e].m[i]
        m_diff = m_val - face.muscle[i].mstat
        face.muscle[i].mstat = m_val
        muscle.activate_muscle(face, face.muscle[i].head, face.muscle[i].tail, face.muscle[i].fs, face.muscle[i].fe, face.muscle[i].zone, m_diff)

def create_face (f1, f2) :
    h = common.HEAD()
    h.npolygons = 0
    h.npindices = 0
    h.npolylinenodes = 0
    h.nmuscles = 0
    fileio.read_polygon_indices(f1,h)
    fileio.read_polygon_line(f2,h)
    make_face(h)
    return (h)

def make_face (face : common.HEAD ) : 
    parray = zeros(4, dtype = int)
    ii = 0
    for i in range(face.npindices) :
        p1 = face.indexlist[ii]-1
        p2 = face.indexlist[ii+1]-1
        p3 = face.indexlist[ii+2]-1
        p4 = face.indexlist[ii+3]-1
        for j in range (4):
            parray[j] = face.indexlist[ii+j] -1 
        if (p1 == 999): 
            p = common.POLYGON(3)
            for j in range(3):
                p.vertex[0].nxyz[j] = face.polyline[ p2*3 + j ]
                p.vertex[0].xyz[j] = face.polyline[ p2*3 + j ]
                p.vertex[1].nxyz[j] = face.polyline[ p3*3 + j ]
                p.vertex[1].xyz[j] = face.polyline[ p3*3 + j ]
                p.vertex[2].nxyz[j] = face.polyline[ p4*3 + j ]
                p.vertex[2].xyz[j] = face.polyline[ p4*3 + j ]            
            add_polygon_to_face(p,face)
            reflect_polygon(p,face)
        else :
            p = common.POLYGON(3)          
            for k in range(3):
                for j in range(3):
                    p.vertex[k].nxyz[j] = face.polyline[parray[k] * 3 + j]
                    p.vertex[k].xyz[j] = face.polyline[parray[k] * 3 + j]
            add_polygon_to_face(p,face)
            reflect_polygon(p,face)
            p = common.POLYGON(3)
            for j in range(3):
                p.vertex[0].nxyz[j] = face.polyline[(p1*3)+j]
                p.vertex[0].xyz[j] = face.polyline[(p1*3)+j]
                p.vertex[1].nxyz[j] = face.polyline[(p3*3)+j]
                p.vertex[1].xyz[j] = face.polyline[(p3*3)+j]
                p.vertex[2].nxyz[j] = face.polyline[(p4*3)+j]
                p.vertex[2].xyz[j] = face.polyline[(p4*3)+j]
            add_polygon_to_face(p,face)
            reflect_polygon(p,face)
        ii = ii + 4


def add_polygon_to_face (p : common.POLYGON, face : common.HEAD ) : 
    face.polygon.append(p)
    face.npolygons = face.npolygons + 1

def reflect_polygon(poly : common.POLYGON, face : common.HEAD) : 
    temp = zeros(3)
    newp = common.POLYGON(3)
    for i in range(3):
        for j in range(3):
            newp.vertex[i].nxyz[j] = poly.vertex[i].xyz[j] 
            newp.vertex[i].xyz[j] = poly.vertex[i].xyz[j]
    for i in range(3) : 
        newp.vertex[i].nxyz[0] = -newp.vertex[i].xyz[0]
        newp.vertex[i].xyz[0] = -newp.vertex[i].xyz[0]
    for j in range(3): 
        temp[j] = newp.vertex[0].xyz[j]
    for j in range (3):
        newp.vertex[0].nxyz[j] = newp.vertex[1].xyz[j]
        newp.vertex[0].xyz[j] = newp.vertex[1].xyz[j]
    for j in range (3):
        newp.vertex[1].nxyz[j] = temp[j]
        newp.vertex[1].xyz[j] = temp[j]
    add_polygon_to_face(newp, face)

def averaged_vertex_normals (face : common.HEAD, p, n1, n2, n3 ) : 
    norm = zeros(3)
    np = face.polygon[p].vertex[0].np
    for i in range (np) : 
        pt = face.polygon[p].vertex[0].plist[i]
        for j in range (3) : 
            norm[j] = norm[j] + face.polygon[pt].vertex[0].norm[j]
    for i in range(3) : 
        norm[i] = norm[i] / np
        n1[i] = norm[i]
        norm[i] = 0.0
    
    np = face.polygon[p].vertex[1].np
    for i in range (np) : 
        pt = face.polygon[p].vertex[1].plist[i]
        for j in range (3) : 
            norm[j] = norm[j] + face.polygon[pt].vertex[1].norm[j]
    for i in range(3) : 
        norm[i] = norm[i] / np
        n2[i] = norm[i]
        norm[i] = 0.0
    
    np = face.polygon[p].vertex[2].np
    for i in range (np) : 
        pt = face.polygon[p].vertex[2].plist[i]
        for j in range (3) : 
            norm[j] = norm[j] + face.polygon[pt].vertex[2].norm[j] 
    for i in range(3) : 
        norm[i] = norm[i] / np
        n3[i] = norm[i]
    
def data_struct (face : common.HEAD ) : 
    for i in range (face.npolygons) : 
        x1 = face.polygon[i].vertex[0].xyz[0]
        y1 = face.polygon[i].vertex[0].xyz[1]
        z1 = face.polygon[i].vertex[0].xyz[2]

        x2 = face.polygon[i].vertex[1].xyz[0]
        y2 = face.polygon[i].vertex[1].xyz[1]
        z2 = face.polygon[i].vertex[1].xyz[2]

        x3 = face.polygon[i].vertex[2].xyz[0]
        y3 = face.polygon[i].vertex[2].xyz[1]
        z3 = face.polygon[i].vertex[2].xyz[2]
        j = 0
        while (j < face.npolygons) :
            tx1 = face.polygon[j].vertex[0].xyz[0]
            ty1 = face.polygon[j].vertex[0].xyz[1]
            tz1 = face.polygon[j].vertex[0].xyz[2]

            tx2 = face.polygon[j].vertex[1].xyz[0]
            ty2 = face.polygon[j].vertex[1].xyz[1]
            tz2 = face.polygon[j].vertex[1].xyz[2]

            tx3 = face.polygon[j].vertex[2].xyz[0]
            ty3 = face.polygon[j].vertex[2].xyz[1]
            tz3 = face.polygon[j].vertex[2].xyz[2]

            if ((x1 == tx1 and y1 == ty1 and z1 == tz1) 
            or (x1 == tx2 and y1 == ty2 and z1 == tz2)
            or (x1 == tx3 and y1 == ty3 and z1 == tz3)) :
                n = face.polygon[i].vertex[0].np
                face.polygon[i].vertex[0].plist[n] = j
                face.polygon[i].vertex[0].np = face.polygon[i].vertex[0].np + 1    
            j = j+1

        j = 0 
        while (j<face.npolygons) :
            tx1 = face.polygon[j].vertex[0].xyz[0]
            ty1 = face.polygon[j].vertex[0].xyz[1]
            tz1 = face.polygon[j].vertex[0].xyz[2]

            tx2 = face.polygon[j].vertex[1].xyz[0]
            ty2 = face.polygon[j].vertex[1].xyz[1]
            tz2 = face.polygon[j].vertex[1].xyz[2]

            tx3 = face.polygon[j].vertex[2].xyz[0]
            ty3 = face.polygon[j].vertex[2].xyz[1]
            tz3 = face.polygon[j].vertex[2].xyz[2]

            if ( x2 == tx1 and y2 == ty1 and z2 == tz1 or
                x2 == tx2 and y2 == ty2 and z2 == tz2 or
                x2 == tx3 and y2 == ty3 and z2 == tz3) :
                
                n = face.polygon[i].vertex[1].np
                face.polygon[i].vertex[1].plist[n] = j
                face.polygon[i].vertex[1].np = face.polygon[i].vertex[1].np + 1
            j = j + 1

        j = 0
        while (j<face.npolygons) :
            tx1 = face.polygon[j].vertex[0].xyz[0]
            ty1 = face.polygon[j].vertex[0].xyz[1]
            tz1 = face.polygon[j].vertex[0].xyz[2]

            tx2 = face.polygon[j].vertex[1].xyz[0]
            ty2 = face.polygon[j].vertex[1].xyz[1]
            tz2 = face.polygon[j].vertex[1].xyz[2]

            tx3 = face.polygon[j].vertex[2].xyz[0]
            ty3 = face.polygon[j].vertex[2].xyz[1]
            tz3 = face.polygon[j].vertex[2].xyz[2]
            if ( x3 == tx1 and  y3 == ty1 and  z3 == tz1 or
            x3 == tx2 and  y3 == ty2 and  z3 == tz2 or
            x3 == tx3 and  y3 == ty3 and  z3 == tz3) :
                n = face.polygon[i].vertex[2].np
                face.polygon[i].vertex[2].plist[n] = j
                face.polygon[i].vertex[2].np = face.polygon[i].vertex[2].np + 1
            j = j+1