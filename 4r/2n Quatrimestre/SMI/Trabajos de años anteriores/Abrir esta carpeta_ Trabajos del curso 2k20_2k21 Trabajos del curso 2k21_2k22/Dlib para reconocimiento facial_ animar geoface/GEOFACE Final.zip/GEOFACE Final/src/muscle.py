from numpy import sqrt, zeros, pi, cos, deg2rad
import common

def VecLen (v) :
    return ( sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]) )

def CosAng (v1, v2) :
    a = VecLen (v1)
    b = VecLen (v2)
    ang = ((v1[0]*v2[0]) + (v1[1]*v2[1] ) + (v1[2]*v2[2])) / (a*b)
    return (ang)

def activate_muscle (face : common.HEAD, vt, vh, fstart, fin, ang : float, val) :
    newp = zeros(3)
    va = zeros(3)
    vb = zeros(3)
    radf  = 180.0/ pi
    the   = float(ang) / radf
    thet  = cos ( the )

    cosa = 0.0

    for i in range(3):
        va[i] = vt [i] - vh[i]
    valen = float(VecLen(va))

    for i in range(face.npolygons) :
        for j in range(3) :
            for k in range(3) :
                vb[k] = face.polygon[i].vertex[j].xyz[k] - vh[k]   
            vblen = VecLen(vb)
            if ( valen > 0.0 and vblen > 0.0) :
                cosa = CosAng(va, vb)
                if (cosa >= thet) :
                    if ( vblen <= float(fin) ):
                        cosv = val * (1.0 - (cosa/thet))
                        if( vblen >= float(fstart) and vblen <= float(fin)):
                            dif = float(vblen) - float(fstart)
                            tot = float(fin) - float(fstart)
                            percent = float(dif)/float(tot)
                            newv = cos(deg2rad(percent*90.0))
                            for l in range(3): 
                                newp[l] = (vb[l] * cosv) * newv
                        else :
                            for l in range(3) : 
                                newp[l] = vb[l] * cosv
                        for l in range(3) :
	                        face.polygon[i].vertex[j].xyz[l] = face.polygon[i].vertex[j].xyz[l] + newp[l]

def act_muscles (face : common.HEAD ): 
    for i in range (face.nmuscles) :
        if (face.muscle[i].active != 0) :
            activate_muscle ( face, face.muscle[i].head,
                            face.muscle[i].tail,
                            face.muscle[i].fs,
                            face.muscle[i].fe,
                            face.muscle[i].zone,
                            face.muscle[i].mval)
            face.muscle[i].active = 1

def reset_muscles (face : common.HEAD ) : 
    for i in range (face.npolygons) :
        for j in range (3) :
            for k in range (3) :
                face.polygon[i].vertex[j].xyz[k] = face.polygon[i].vertex[j].nxyz[k]