//v2.1 Redeclaradas algunas variables y métodos para que mejorar el rendimiento (en mono iba ligeramente calado, porque 
//usaba el doble de muestras al pintar). Implementada ecualización.
// gcc EspectroFrecuencias_v2.5.c -o EspectroFrecuencias_v2.5 `pkg-config openal --cflags --libs`  -lalut  -lglut -lGLU -lGL -lm


//===========================================================================================
//Dependencias
//===========================================================================================

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <GL/gl.h>//OpenGL32 Library Header
#include <GL/glu.h>//The GLu32 Library Header
#include <AL/alut.h>
#include <AL/al.h>
#include <AL/alc.h>
#include <GL/freeglut.h>
#include <limits.h>
#include <math.h>
#include <string.h>
#include <IL/il.h>


//===========================================================================================
//Constantes
//===========================================================================================

// ---- Constantes de Audio y OpenAl ----------------------------------------------

#define NUM_BUFFERS 3
#define NUM_MUESTRAS_MONO 1024
#define NUM_MUESTRAS_STEREO 1024
#define NUM_AMPLITUDES_MONO (NUM_MUESTRAS_MONO / 2)
#define NUM_AMPLITUDES_STEREO (NUM_MUESTRAS_STEREO / 4)
#define TAM_BUFFER_MONO   (NUM_MUESTRAS_MONO * sizeof(int16_t))
#define TAM_BUFFER_STEREO   (NUM_MUESTRAS_STEREO * sizeof(int16_t))

// ---- Constantes de OpenGL ----------------------------------------------

#define VENTANA_ANCHO 800
#define VENTANA_ALTO 600
#define NUM_BARRAS (32*16)
#define DIV_ALTURA_BARRA 6.0 //Constante para reducir el numero que representa la altura de una barra
#define SEPARACION_BARRAS 0.07

// ---- Constantes de FFT    ----------------------------------------------

#define PI 3.1415
#define TWOPI (2.0*PI)
#define _USE_MATH_DEFINES
//#define PI  M_PI  /* pi to machine precision, defined in math.h */

// ---- Constantes de Ecualizacion    ----------------------------------------------

#define NUM_BANDAS_ECUALIZACION 16

//===========================================================================================
//Variables Globales
//===========================================================================================

// ---- Variables de OpenAL -----------------------------------------------
 
ALuint buffers[NUM_BUFFERS];
ALuint alsource;
ALenum formatoAudio; //mono o stereo (1 o 2 canales)
ALCdevice *dev;
ALCcontext *ctx;

// ---- Información de Audio ----------------------------------------------
int numCanales;
int bitsMuestra;
int frecuenciaMuestreo;
int16_t audioBufferMono[NUM_MUESTRAS_MONO]; //Vector donde se almacenan las muestras de audio (Mono)
int16_t audioBufferStereo[NUM_MUESTRAS_STEREO]; //Vector donde se almacenan las muestras de audio (Stereo)
//FILE* Fprueba;

// ---- Ecualizador ------------------------------------------------------

/*Tenemos 16 bandas de ecualización. Es un vector de doubles que indican la ganancia que se le va a aplicar
al vector de sonido. Las dieciseis ganancias se aplicarán de forma equitativa al vector (en la función ecualizar, linea 256),
es decir, dividimos el vector en 16 secciones y a cada una le aplicamos su correspondiente modificador de ganancia.Cada
sección se corresponde con un rango de frecuencias determinado. */
double bandasEcualizacion[NUM_BANDAS_ECUALIZACION]={
    1.0,
    1.0,
    1.0,
    1.0,
    1.0,
    1.0,
    1.0,
    1.0,
    1.0,
    1.0,
    1.0,
    1.0,
    1.0,
    1.0,
    1.0,
    1.0,
  };
int ecualizadorActivo = 0;
int frecuenciasPorBanda;

// ---- Variables para Representación (OPENGL) ----------------------------
int GLwin, GLwin2;
//Camara
float camOrigenX = NUM_BARRAS * SEPARACION_BARRAS *0.5;
float camOrigenY = 5;
float camOrigenZ = 71.5;

double barrasFrecuencia[NUM_BARRAS];//vector con las barras de frecuencia(amplitudes) que se pintarán finalmente
double Vertices[NUM_BARRAS][2]; //matriz de vertices (los de las alturas de las barras, uno por barra)

// ---- Pipeline entre procesos -------------------------------------------
int descPipeline[2];

// ---- Calculo de la nota ----------------------------------------
#define N_ARMCS 10 //Número de armónicos obtenidos de cada nota
double gDo[N_ARMCS],  gRe[N_ARMCS],  gMi[N_ARMCS],  gFa[N_ARMCS],  gSol[N_ARMCS],  gLa[N_ARMCS],  gSi[N_ARMCS];
double gvDo[N_ARMCS], gvRe[N_ARMCS], gvMi[N_ARMCS], gvFa[N_ARMCS], gvSol[N_ARMCS], gvLa[N_ARMCS], gvSi[N_ARMCS];
double gtotal[N_ARMCS], gvtotal[N_ARMCS];
double gmedia[N_ARMCS], gvmedia[N_ARMCS];
int g[N_ARMCS]; double gv[N_ARMCS];
int nmuestras = 1;
int insertarValores = 0; //False

// ---- Visualizacion de la nota ----------------------------------------
GLuint image1, image2, image3, image4, image5, image6, image7, image8, imagenActual;
int loadImage;
int numeroImagen = 8;
int numeroFallosImagen = 0;
int width  = 100;//640;
int height = 100;//480;


//===========================================================================================
//Error
//===========================================================================================

  void Error(char* mensaje)
{
   fputs(mensaje, stderr);
   exit(1);
}

//===========================================================================================
//Funciones en relación aĺ Espectro Frecuencias (cálculos y dibujado)
//===========================================================================================

//Camara2D sitúa la camara para la representación
void Camara2D()
{
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslated(-camOrigenX, -camOrigenY, -camOrigenZ / 2.5 );
}



/* Load an image using DevIL and return the devIL handle (-1 if failure) */
int LoadImage(char *filename)
{
    ILboolean success; 
     ILuint image; 

    ilGenImages(1, &image); /* Generation of one image name */
     ilBindImage(image); /* Binding of image name */
     success = ilLoadImage(filename); /* Loading of the image filename by DevIL */
     
    if (success) /* If no error occured: */
    {
        /* Convert every colour component into unsigned byte. If your image contains alpha channel you can replace IL_RGB with IL_RGBA */
           success = ilConvertImage(IL_RGBA, IL_UNSIGNED_BYTE); 
   
        if (!success)
           {
                 return -1;
           }
    }
    else
        return -1;

    return image;
}


void texturas()
{
    
    if (ilGetInteger(IL_VERSION_NUM) < IL_VERSION)
     {
           printf("wrong DevIL version ");
           exit(1);
     }
    
    ilInit();
    
    //loadImage = LoadImage("lena.jpg"); if ( loadImage == -1 ) { printf("Can't load picture file lena.jpg by DevIL "); exit(1);}  //else { printf("Image loaded = %d", loadImage); exit(1);}
    //loadImage = LoadImage(argv[2]); if ( loadImage == -1 ) { printf("Can't load picture file %s by DevIL ", argv[2]); exit(1);} 
    
    if( numeroImagen == 1 ) {
    
    loadImage = LoadImage("notasFlauta/NotaDo.PNG"); if ( loadImage == -1 ) { printf("Can't load picture file NotaDo.PNG by DevIL "); exit(1);}
    
           /* OpenGL texture binding of the image loaded by DevIL  */
       glGenTextures(1, &image1); /* Texture name generation */
       glBindTexture(GL_TEXTURE_2D, image1); /* Binding of texture name */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); /* We will use linear interpolation for magnification filter */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); /* We will use linear interpolation for minifying filter */
       glTexImage2D(GL_TEXTURE_2D, 0, ilGetInteger(IL_IMAGE_BPP), ilGetInteger(IL_IMAGE_WIDTH), ilGetInteger(IL_IMAGE_HEIGHT), 0, ilGetInteger(IL_IMAGE_FORMAT), GL_UNSIGNED_BYTE, ilGetData()); /* Texture specification */
    }
    
    if( numeroImagen == 2 ) {
    
    loadImage = LoadImage("notasFlauta/NotaRe.PNG"); if ( loadImage == -1 ) { printf("Can't load picture file NotaRe.PNG by DevIL "); exit(1);}
    
           /* OpenGL texture binding of the image loaded by DevIL  */
       glGenTextures(1, &image2); /* Texture name generation */
       glBindTexture(GL_TEXTURE_2D, image2); /* Binding of texture name */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); /* We will use linear interpolation for magnification filter */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); /* We will use linear interpolation for minifying filter */
       glTexImage2D(GL_TEXTURE_2D, 0, ilGetInteger(IL_IMAGE_BPP), ilGetInteger(IL_IMAGE_WIDTH), ilGetInteger(IL_IMAGE_HEIGHT), 0, ilGetInteger(IL_IMAGE_FORMAT), GL_UNSIGNED_BYTE, ilGetData()); /* Texture specification */
    }
    
    if( numeroImagen == 3 ) {
    
    loadImage = LoadImage("notasFlauta/NotaMi.PNG"); if ( loadImage == -1 ) { printf("Can't load picture file NotaMi.PNG by DevIL "); exit(1);}
    
           /* OpenGL texture binding of the image loaded by DevIL  */
       glGenTextures(1, &image3); /* Texture name generation */
       glBindTexture(GL_TEXTURE_2D, image3); /* Binding of texture name */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); /* We will use linear interpolation for magnification filter */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); /* We will use linear interpolation for minifying filter */
       glTexImage2D(GL_TEXTURE_2D, 0, ilGetInteger(IL_IMAGE_BPP), ilGetInteger(IL_IMAGE_WIDTH), ilGetInteger(IL_IMAGE_HEIGHT), 0, ilGetInteger(IL_IMAGE_FORMAT), GL_UNSIGNED_BYTE, ilGetData()); /* Texture specification */
    }
    
    if( numeroImagen == 4 ) {
    
    loadImage = LoadImage("notasFlauta/NotaFa.PNG"); if ( loadImage == -1 ) { printf("Can't load picture file NotaFa.PNG by DevIL "); exit(1);}
    
           /* OpenGL texture binding of the image loaded by DevIL  */
       glGenTextures(1, &image4); /* Texture name generation */
       glBindTexture(GL_TEXTURE_2D, image4); /* Binding of texture name */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); /* We will use linear interpolation for magnification filter */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); /* We will use linear interpolation for minifying filter */
       glTexImage2D(GL_TEXTURE_2D, 0, ilGetInteger(IL_IMAGE_BPP), ilGetInteger(IL_IMAGE_WIDTH), ilGetInteger(IL_IMAGE_HEIGHT), 0, ilGetInteger(IL_IMAGE_FORMAT), GL_UNSIGNED_BYTE, ilGetData()); /* Texture specification */
    }
    
    if( numeroImagen == 5 ) {
    
    loadImage = LoadImage("notasFlauta/NotaSol.PNG"); if ( loadImage == -1 ) { printf("Can't load picture file NotaSol.PNG by DevIL "); exit(1);}
    
           /* OpenGL texture binding of the image loaded by DevIL  */
       glGenTextures(1, &image5); /* Texture name generation */
       glBindTexture(GL_TEXTURE_2D, image5); /* Binding of texture name */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); /* We will use linear interpolation for magnification filter */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); /* We will use linear interpolation for minifying filter */
       glTexImage2D(GL_TEXTURE_2D, 0, ilGetInteger(IL_IMAGE_BPP), ilGetInteger(IL_IMAGE_WIDTH), ilGetInteger(IL_IMAGE_HEIGHT), 0, ilGetInteger(IL_IMAGE_FORMAT), GL_UNSIGNED_BYTE, ilGetData()); /* Texture specification */
    }
    
    if( numeroImagen == 6 ) {
    
    loadImage = LoadImage("notasFlauta/NotaLa.PNG"); if ( loadImage == -1 ) { printf("Can't load picture file NotaLa.PNG by DevIL "); exit(1);}
    
           /* OpenGL texture binding of the image loaded by DevIL  */
       glGenTextures(1, &image6); /* Texture name generation */
       glBindTexture(GL_TEXTURE_2D, image6); /* Binding of texture name */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); /* We will use linear interpolation for magnification filter */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); /* We will use linear interpolation for minifying filter */
       glTexImage2D(GL_TEXTURE_2D, 0, ilGetInteger(IL_IMAGE_BPP), ilGetInteger(IL_IMAGE_WIDTH), ilGetInteger(IL_IMAGE_HEIGHT), 0, ilGetInteger(IL_IMAGE_FORMAT), GL_UNSIGNED_BYTE, ilGetData()); /* Texture specification */
    }
    
    if( numeroImagen == 7 ) {
    
    loadImage = LoadImage("notasFlauta/NotaSi.PNG"); if ( loadImage == -1 ) { printf("Can't load picture file NotaSi.PNG by DevIL "); exit(1);}
    
           /* OpenGL texture binding of the image loaded by DevIL  */
       glGenTextures(1, &image7); /* Texture name generation */
       glBindTexture(GL_TEXTURE_2D, image7); /* Binding of texture name */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); /* We will use linear interpolation for magnification filter */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); /* We will use linear interpolation for minifying filter */
       glTexImage2D(GL_TEXTURE_2D, 0, ilGetInteger(IL_IMAGE_BPP), ilGetInteger(IL_IMAGE_WIDTH), ilGetInteger(IL_IMAGE_HEIGHT), 0, ilGetInteger(IL_IMAGE_FORMAT), GL_UNSIGNED_BYTE, ilGetData()); /* Texture specification */
    }
    
    if( numeroImagen == 8 ) {
    
    loadImage = LoadImage("notasFlauta/NotaNoDetectada.PNG"); if ( loadImage == -1 ) { printf("Can't load picture file NotaNoDetectada.PNG by DevIL "); exit(1);}       
       
       /* OpenGL texture binding of the image loaded by DevIL  */
       glGenTextures(1, &image8); /* Texture name generation */
       glBindTexture(GL_TEXTURE_2D, image8); /* Binding of texture name */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); /* We will use linear interpolation for magnification filter */
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); /* We will use linear interpolation for minifying filter */
       glTexImage2D(GL_TEXTURE_2D, 0, ilGetInteger(IL_IMAGE_BPP), ilGetInteger(IL_IMAGE_WIDTH), ilGetInteger(IL_IMAGE_HEIGHT), 0, ilGetInteger(IL_IMAGE_FORMAT), GL_UNSIGNED_BYTE, ilGetData()); /* Texture specification */  
    }  
       
       
       //ilDeleteImages(1, &loadImage); /* Because we have already copied image data into texture data we can release memory used by image. */
       //glDeleteTextures(1, &imagenActual);
}




void resetParametros(){
    for(int i = 0; i<N_ARMCS; i++) { gtotal[i] = 0; gmedia[i] = 0; gvtotal[i] = 0; gvmedia[i] = 0;}
    nmuestras = 1;
}



void inicializarNotas() {
    gDo[0]=6.000000;gDo[1]=5.000000;gDo[2]=7.000000;gDo[3]=4.065000;gDo[4]=7.065000;gDo[5]=6.815000;gDo[6]=7.015000;gDo[7]=9.380000;gDo[8]=6.965000;gDo[9]=5.770000;
    gvDo[0]=7.308780;gvDo[1]=6.533252;gvDo[2]=5.410242;gvDo[3]=5.162188;gvDo[4]=4.661969;gvDo[5]=4.472167;gvDo[6]=4.251913;gvDo[7]=4.124359;gvDo[8]=3.951548;gvDo[9]=3.844542;  //Do
    
    gRe[0]=6.000000;gRe[1]=7.000000;gRe[2]=5.000000;gRe[3]=8.485294;gRe[4]=9.691176;gRe[5]=10.058824;gRe[6]=9.352941;gRe[7]=6.544118;gRe[8]=6.044118;gRe[9]=8.750000;
    gvRe[0]=7.504621;gvRe[1]=5.781333;gvRe[2]=5.088728;gvRe[3]=4.573873;gvRe[4]=4.298500;gvRe[5]=4.102858;gvRe[6]=3.873597;gvRe[7]=3.680960;gvRe[8]=3.498845;gvRe[9]=3.327063;  //Re
    
    gMi[0]=7.000000;gMi[1]=21.000000;gMi[2]=13.737374;gMi[3]=41.565657;gMi[4]=37.393939;gMi[5]=76.616162;gMi[6]=224.878788;gMi[7]=109.202020;gMi[8]=64.030303;gMi[9]=64.313131;
    gvMi[0]=8.053205;gvMi[1]=4.983212;gvMi[2]=3.870266;gvMi[3]=3.316062;gvMi[4]=3.159547;gvMi[5]=2.706070;gvMi[6]=2.544274;gvMi[7]=2.395713;gvMi[8]=2.195744;gvMi[9]=2.045022;  //Mi
    
    gFa[0]=7.237069;gFa[1]=7.762931;gFa[2]=7.396552;gFa[3]=7.603448;gFa[4]=7.392241;gFa[5]=6.702586;gFa[6]=8.275862;gFa[7]=10.672414;gFa[8]=9.530172;gFa[9]=7.823276;
    gvFa[0]=7.469323;gvFa[1]=7.339905;gvFa[2]=5.899156;gvFa[3]=5.726468;gvFa[4]=5.216000;gvFa[5]=4.947014;gvFa[6]=4.774586;gvFa[7]=4.585378;gvFa[8]=4.458861;gvFa[9]=4.352391;  //Fa
    
    gSol[0]=8.000000;gSol[1]=9.000000;gSol[2]=7.375000;gSol[3]=9.625000;gSol[4]=7.805556;gSol[5]=9.194444;gSol[6]=8.384259;gSol[7]=8.074074;gSol[8]=10.333333;gSol[9]=8.578704;
    gvSol[0]=7.840422;gvSol[1]=7.371589;gvSol[2]=6.082158;gvSol[3]=5.914229;gvSol[4]=5.346787;gvSol[5]=5.169271;gvSol[6]=4.892422;gvSol[7]=4.695599;gvSol[8]=4.558151;gvSol[9]=4.403557;  //Sol
    
    gLa[0]=9.000000;gLa[1]=10.000000;gLa[2]=8.098361;gLa[3]=10.901639;gLa[4]=8.885246;gLa[5]=10.114754;gLa[6]=9.098361;gLa[7]=8.284153;gLa[8]=10.846995;gLa[9]=12.043716;
    gvLa[0]=8.148029;gvLa[1]=7.648135;gvLa[2]=6.370018;gvLa[3]=6.203316;gvLa[4]=5.624791;gvLa[5]=5.464139;gvLa[6]=5.161489;gvLa[7]=4.960468;gvLa[8]=4.815397;gvLa[9]=4.646657;  //La
    
    gSi[0]=10.994565;gSi[1]=10.005435;gSi[2]=11.706522;gSi[3]=9.293478;gSi[4]=11.125000;gSi[5]=9.875000;gSi[6]=10.994565;gSi[7]=10.657609;gSi[8]=10.190217;gSi[9]=10.646739;
    gvSi[0]=8.225837;gvSi[1]=7.772522;gvSi[2]=6.469219;gvSi[3]=6.312324;gvSi[4]=5.727535;gvSi[5]=5.569457;gvSi[6]=5.265778;gvSi[7]=5.068261;gvSi[8]=4.920396;gvSi[9]=4.735904;  //Si
    
    resetParametros();
}

/*void inicializarNotasVacias() {
    for(int i = 0; i<N_ARMCS; i++) { gDo[i] = 0; gRe[i] = 0; gMi[i] = 0; gFa[i] = 0; gSol[i] = 0; gLa[i] = 0; gSi[i] = 0; gvDo[i] = 0; gvRe[i] = 0; gvMi[i] = 0; gvFa[i] = 0; gvSol[i] = 0; gvLa[i] = 0; gvSi[i] = 0;}
    resetParametros();
}*/

void insertarParametros(int num){
    switch(num)
    {
      case 0: {for( int j = 0; j < N_ARMCS; j++) { gDo[j]=gmedia[j];} for( int j = 0; j < N_ARMCS; j++) { gvDo[j]=gvmedia[j];} break;} //Do
      case 1: {for( int j = 0; j < N_ARMCS; j++) { gRe[j]=gmedia[j];} for( int j = 0; j < N_ARMCS; j++) { gvRe[j]=gvmedia[j];} break;} //Re
      case 2: {for( int j = 0; j < N_ARMCS; j++) { gMi[j]=gmedia[j];} for( int j = 0; j < N_ARMCS; j++) { gvMi[j]=gvmedia[j];} break;} //Mi
      case 3: {for( int j = 0; j < N_ARMCS; j++) { gFa[j]=gmedia[j];} for( int j = 0; j < N_ARMCS; j++) { gvFa[j]=gvmedia[j];} break;} //Fa
      case 4: {for( int j = 0; j < N_ARMCS; j++) { gSol[j]=gmedia[j];}for( int j = 0; j < N_ARMCS; j++) { gvSol[j]=gvmedia[j];}break;} //Sol
      case 5: {for( int j = 0; j < N_ARMCS; j++) { gLa[j]=gmedia[j];} for( int j = 0; j < N_ARMCS; j++) { gvLa[j]=gvmedia[j];} break;} //La
      case 6: {for( int j = 0; j < N_ARMCS; j++) { gSi[j]=gmedia[j];} for( int j = 0; j < N_ARMCS; j++) { gvSi[j]=gvmedia[j];} break;} //Si
    }
}


//Funciones que compruban la cercanía de unos "valores característicos" del sonido a una nota conocida de la flauta
double testNota(double g[], double gmedia[], double gv[], double gvmedia[])
{
    double distancia = 0;
    for( int i = 0; i < N_ARMCS; i++) { distancia += pow((g[i] - gmedia[i] * 1),2); distancia += pow((gv[i] - gvmedia[i] * 1),2); }
    return distancia;   
}


//void calculoNota(int g[], double gv[])
void calculoNota()
{     
    glutSetWindow(GLwin2);
    glClearColor(0.15f, 0.15f, 0.13f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);     

    // Establecer camara.
    //Camara2D();
    
    glMatrixMode(GL_MODELVIEW);
    
    
    
    for( int i = 0; i < N_ARMCS; i++) {
        gtotal[i] += g[i]; gmedia[i] = gtotal[i] / nmuestras;
        gvtotal[i] += gv[i]; gvmedia[i] = gvtotal[i] / nmuestras;
    }
    
    nmuestras++;
    
    if (nmuestras > 100) {resetParametros();}
    
    /*for( int j = 0; j < N_ARMCS; j++) { printf("Media1 %f con intensidad %f, que son los totales %f con intensidad %f con %d muestras\n", gmedia[j], gvmedia[j], gtotal[j], gvtotal[j], nmuestras); }
    
    for( int j = 0; j < N_ARMCS; j++) { printf("gDo[%d]=%f;",j,gmedia[j]);} printf("\n"); for( int j = 0; j < N_ARMCS; j++) { printf("gvDo[%d]=%f;",j,gvmedia[j]);} printf("\n");
    for( int j = 0; j < N_ARMCS; j++) { printf("gRe[%d]=%f;",j,gmedia[j]);} printf("\n"); for( int j = 0; j < N_ARMCS; j++) { printf("gvRe[%d]=%f;",j,gvmedia[j]);} printf("\n");
    for( int j = 0; j < N_ARMCS; j++) { printf("gMi[%d]=%f;",j,gmedia[j]);} printf("\n"); for( int j = 0; j < N_ARMCS; j++) { printf("gvMi[%d]=%f;",j,gvmedia[j]);} printf("\n");
    for( int j = 0; j < N_ARMCS; j++) { printf("gFa[%d]=%f;",j,gmedia[j]);} printf("\n"); for( int j = 0; j < N_ARMCS; j++) { printf("gvFa[%d]=%f;",j,gvmedia[j]);} printf("\n");
    for( int j = 0; j < N_ARMCS; j++) { printf("gSol[%d]=%f;",j,gmedia[j]);}printf("\n"); for( int j = 0; j < N_ARMCS; j++) { printf("gvSol[%d]=%f;",j,gvmedia[j]);}printf("\n");
    for( int j = 0; j < N_ARMCS; j++) { printf("gLa[%d]=%f;",j,gmedia[j]);} printf("\n"); for( int j = 0; j < N_ARMCS; j++) { printf("gvLa[%d]=%f;",j,gvmedia[j]);} printf("\n");
    for( int j = 0; j < N_ARMCS; j++) { printf("gSi[%d]=%f;",j,gmedia[j]);} printf("\n"); for( int j = 0; j < N_ARMCS; j++) { printf("gvSi[%d]=%f;",j,gvmedia[j]);} printf("\n");*/
    
    
  
  double valorMin = 200000;
  double distancia = 0; //printf("distancia reseteada d = %f\n", distancia);
  char* nota = "vacio";
  int nuevaImagen = 8;
  
  distancia = testNota( gDo, gmedia, gvDo, gvmedia ); if (distancia < valorMin)  { valorMin = distancia; nota = "Do"; nuevaImagen = 1; } //printf("distancia Do %f\n", distancia);
  distancia = testNota( gRe, gmedia, gvRe, gvmedia ); if (distancia < valorMin)  { valorMin = distancia; nota = "Re"; nuevaImagen = 2; } //printf("distancia Re %f\n", distancia);
  distancia = testNota( gMi, gmedia, gvMi, gvmedia ); if (distancia < valorMin)  { valorMin = distancia; nota = "Mi"; nuevaImagen = 3; } //printf("distancia Mi %f\n", distancia);
  distancia = testNota( gFa, gmedia, gvFa, gvmedia ); if (distancia < valorMin)  { valorMin = distancia; nota = "Fa"; nuevaImagen = 4; } //printf("distancia Fa %f\n", distancia);
  distancia = testNota( gSol,gmedia, gvSol,gvmedia ); if (distancia < valorMin)  { valorMin = distancia; nota = "Sol";nuevaImagen = 5; } //printf("distancia Sol %f\n",distancia);
  distancia = testNota( gLa, gmedia, gvLa, gvmedia ); if (distancia < valorMin)  { valorMin = distancia; nota = "La"; nuevaImagen = 6; } //printf("distancia La %f\n", distancia);
  distancia = testNota( gSi, gmedia, gvSi, gvmedia ); if (distancia < valorMin)  { valorMin = distancia; nota = "Si"; nuevaImagen = 7; } //printf("distancia Si %f\n", distancia);
  
  
  //printf("distancia min %f", valorMin);
  
  //printf("Seguramente sea %s", nota);
  //printf("\n");
  
  if ( nuevaImagen != numeroImagen ) { numeroFallosImagen = numeroFallosImagen + 1;} else { numeroFallosImagen = numeroFallosImagen/2;}
  
  if (numeroFallosImagen > 20) {numeroImagen = nuevaImagen; texturas(); }
  
    glBegin(GL_QUADS);
        glTexCoord2i(0, 0); glVertex2i(0,   0);
        glTexCoord2i(0, 1); glVertex2i(0,   height);
        glTexCoord2i(1, 1); glVertex2i(width, height);
        glTexCoord2i(1, 0); glVertex2i(width, 0);
    glEnd();
  
  // Finalizar dibujado.
    
    glutPostRedisplay();
    
    glutSwapBuffers();
    
    glutSetWindow(GLwin);
  
    
  
}

/*La función dibujar espectro se encarga de dibujar en la ventana de GLUT las barras de frecuencia
calculadas en la funcion fft, teniendo como referencia el vector de intensidades para dibujar la altura 
de cada barra*/
void dibujarEspectro2D()
{ 
    glClearColor(0.15f, 0.15f, 0.13f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);     

    // Establecer camara.
    Camara2D();
    
    //int g[N_ARMCS]; double gv[N_ARMCS];
    //double act = 0;
    double arr[NUM_BARRAS]; int arrc[NUM_BARRAS];
    float temp = 0; int tempc = -1;

    // Calcular posicion de los vertices y colores.
    int x;
    for (x = 0; x < NUM_BARRAS; x++)
    {
        Vertices[x][0] = x * SEPARACION_BARRAS +1 ;
        Vertices[x][1] += barrasFrecuencia[x];
        Vertices[x][1] *= 0.5;
        /*
        ColorHsv(COLOR_BASE + bufBarras[0][x] * COLOR_INC_ALTURA,
                   1.0,
                   1.0,
                   bufColores[0][x][0],
                   bufColores[0][x][1],
                   bufColores[0][x][2]);*/
    }

    // Dibujar las barras sobre el plano XY.
    glBegin(GL_QUADS);
    for (x = 0; x < NUM_BARRAS - 1; x++)
    {
        //glColor3d(bufColores[0][x][0], bufColores[0][x][1], bufColores[0][x][2]);
        glColor3d(1.0f,1.0f,0.5f);
        glVertex2d(Vertices[x][0], Vertices[x][1]);
        glVertex2d(Vertices[x][0], 0);
        glVertex2d(Vertices[x][0] + SEPARACION_BARRAS * 0.5, 0);
        glVertex2d(Vertices[x][0] + SEPARACION_BARRAS * 0.5, Vertices[x][1]);
        
        arr[x] = Vertices[x][1];
        arrc[x] = x;
    }
    
    glEnd();
    
    //Sort the array in ascending order    
    for (int i = 0; i < NUM_BARRAS; i++) {     
        for (int j = i+1; j < NUM_BARRAS; j++) {     
           if(arr[i] > arr[j]) {    
               temp = arr[i];    
               arr[i] = arr[j];    
               arr[j] = temp;
               
               tempc = arrc[i];    
               arrc[i] = arrc[j];    
               arrc[j] = tempc; 
           }     
        }     
    }
    
    //printf("Las 10 Barras por orden de mayor a menor valor\n");
    for(int i = NUM_BARRAS-1, j = 0; i>= NUM_BARRAS - N_ARMCS; i--, j++) {
        //printf("La barra %d con valor %f\n", arrc[i], arr[i]);
        g[j] = arrc[i];
        gv[j] = arr[i];
        
    }
    
  
    // Finalizar dibujado.
    glFinish();
    glutSwapBuffers();
    
    calculoNota();
}



//===========================================================================================
//Transformada de Fourier
//===========================================================================================

/*Nueva función FFT que pretendemos usar con el objeto de ecualizar. Documentación sobre la función:
  Inputs:
    data[] : array of complex* data points of size 2*NFFT+1.
      data[0] is unused,
      * the n'th complex number x(n), for 0 <= n <= length(x)-1, is stored as:
        data[2*n+1] = real(x(n))
        data[2*n+2] = imag(x(n))
      if length(NUM_MUESTRAS) < NFFT, the remainder of the array must be padded with zeros

    nn : FFT order NFFT. This MUST be a power of 2 and >= length(x).
    isign:  if set to 1, 
          computes the forward FFT
        if set to -1, 
          computes Inverse FFT - in this case the output buffersLibresues have
          to be manually normalized by multiplying with 1/NFFT.
  Outputs:
   data[] : The FFT or IFFT results are stored in data, overwriting the input.*/
void FFT(double data[], size_t nn, int isign)
{
    int n, mmax, m, j, istep, i;
    double wtemp, wr, wpr, wpi, wi, theta;
    double tempr, tempi;
    
    double act = 0; int g = 0;
    
    n = nn << 1;
    j = 1;
    for (i = 1; i < n; i += 2) 
    {
      if (j > i) 
      {
        tempr = data[j];     data[j] = data[i];     data[i] = tempr;
        tempr = data[j+1]; data[j+1] = data[i+1]; data[i+1] = tempr;
      }
      m = n >> 1;
      while (m >= 2 && j > m) 
      {
        j -= m;
        m >>= 1;
      }
      j += m;
    }
    mmax = 2;
    while (n > mmax) 
    {
      istep = 2*mmax;
      theta = TWOPI/(isign*mmax);
      wtemp = sin(0.5*theta);
      wpr = -2.0*wtemp*wtemp;
      wpi = sin(theta);
      wr = 1.0;
      wi = 0.0;
      for (m = 1; m < mmax; m += 2) 
      {
        for (i = m; i <= n; i += istep) 
        {
          j =i + mmax;
          tempr = wr*data[j]   - wi*data[j+1];
          tempi = wr*data[j+1] + wi*data[j];
          data[j]   = data[i]   - tempr;
          data[j+1] = data[i+1] - tempi;
          data[i] += tempr;
          data[i+1] += tempi;
          
        }
        wr = (wtemp = wr)*wpr - wi*wpi + wr;
        wi = wi*wpr + wtemp*wpi + wi;
      }
      mmax = istep;
    }
    
}

//===========================================================================================
//Funciones de Ecualización
//===========================================================================================

void ecualizarMono(double *audioBufferComplejos)
{
  int i = 0;
  int j = 1;
  frecuenciasPorBanda = NUM_MUESTRAS_MONO / NUM_BANDAS_ECUALIZACION;

  for(i = 0; i < NUM_BANDAS_ECUALIZACION; i++)
  {   
      while(j < ((i + 1) * frecuenciasPorBanda)+1)
      {
          audioBufferComplejos[j] *= bandasEcualizacion[i];
          audioBufferComplejos[j+1] *= bandasEcualizacion[i];
          audioBufferComplejos[(NUM_MUESTRAS_MONO*2)+2-j] *= bandasEcualizacion[i];
          audioBufferComplejos[(NUM_MUESTRAS_MONO*2)+2-1-j] *= bandasEcualizacion[i];
          j+=2;
      }
  }
  
}

void ecualizarCanalStereo(double *audioBufferComplejos, int numMuestrasPorCanal)
{
  int i = 0;
  int j = 1;
  frecuenciasPorBanda = numMuestrasPorCanal / NUM_BANDAS_ECUALIZACION;

  for(i = 0; i < NUM_BANDAS_ECUALIZACION; i++)
  {   
      while(j < ((i + 1) * frecuenciasPorBanda)+1)
      {
          audioBufferComplejos[j] *= bandasEcualizacion[i];
          audioBufferComplejos[j+1] *= bandasEcualizacion[i];
          audioBufferComplejos[(NUM_MUESTRAS_MONO*2)+2-j] *= bandasEcualizacion[i];
          audioBufferComplejos[(NUM_MUESTRAS_MONO*2)+2-1-j] *= bandasEcualizacion[i];
          j+=2;
      }
  }
}

/*Las funciones de subir y bajar, se encargan de modificar el vector de bandasEcualizacion para
darle o quitarle ganancia a las frecuencias, agrupadas como graves, medias y agudas, de forma 
equitativa(5 bandas para los graves, 6 para las medias y 5 para las agudas)*/

void bajarGraves()
{
  int i = 0; int b = NUM_BARRAS/3;
  for(i = 0;i < b ; i++)
  {
    bandasEcualizacion[i]-=0.1;
    if(bandasEcualizacion[i]<0)bandasEcualizacion[i]=0;
  }
}

void subirGraves()
{
  int i = 0; int b = NUM_BARRAS/3;
  for(i = 0;i < b ; i++)
  {
    bandasEcualizacion[i]+=0.05;
    if(bandasEcualizacion[i]>1.5)bandasEcualizacion[i]=1.5;
  }
}

void subirMedias()
{
  int i = 0; int b = NUM_BARRAS/3;
  for(i = b;i < 2*b ; i++)
  {
    bandasEcualizacion[i]+=0.2;
    if(bandasEcualizacion[i]>2.5)bandasEcualizacion[i]=2.5;
  }
}
void bajarMedias()
{
  int i = 0; int b = NUM_BARRAS/3;
  for(i = b;i < 2*b ; i++)
  {
    bandasEcualizacion[i]-=0.2;
    if(bandasEcualizacion[i]<0)bandasEcualizacion[i]=0;
  }
}

void subirAgudas()
{
  int i = 0; int b = NUM_BARRAS/3;
  for(i = 2*b;i <= NUM_BARRAS ; i++)
  {
    bandasEcualizacion[i]+=0.2;
    if(bandasEcualizacion[i]>3.5)bandasEcualizacion[i]=3.5;
  }
}
void bajarAgudas()
{
    int i = 0; int b = NUM_BARRAS/3;
    for(i = 2*b;i <= NUM_BARRAS ; i++)
    {
      bandasEcualizacion[i]-=0.2;
      if(bandasEcualizacion[i]<0)bandasEcualizacion[i]=0;
    }
}

//===========================================================================================
//Funciones de manipulación de muestras
//===========================================================================================


/*La función agruparFrecuenciasEnBarras tiene como objetivo simplificar la representación del espectro, agrupando las amplitudes de las frecuencias 
que tenemos inicialmente en un número menor de barras y sacando la media. También se dividen estos valores por una constante para
que sean valores mas pequeños, de cara a la representación.*/
void agruparFrecuenciasEnBarras(double *amplitudes, double *barrasFrecuencia, int numFrecuencias)
{
  int i = 0;
  int j = 0;
  int contadorBarra = 0;
  int FrecPorBarra = numFrecuencias / NUM_BARRAS;
  double sumatorio = 0.0;

  for(i = 0; i < numFrecuencias; i = i+FrecPorBarra)
  {
      for(j = i; j < (i + FrecPorBarra); j++)
      {
          sumatorio += amplitudes[j];
      }
      if(sumatorio < 0)
          sumatorio = 0;
        
      barrasFrecuencia[contadorBarra] = sumatorio/FrecPorBarra/DIV_ALTURA_BARRA;
      barrasFrecuencia[contadorBarra]-= 4;
      if(barrasFrecuencia[contadorBarra]<0)barrasFrecuencia[contadorBarra]=0.2;

      contadorBarra++;
      sumatorio = 0.0;
  }
}

/*La función calculoAmplitudes se ejecuta entre la FFT y la IFFT. Recorre el vector resultante de la FFT (buffer), calcula las amplitudes
para cada par real-imaginario (que se corresponden con una frecuencia) y lo almacena en el vector amplitudes. */
void calculoAmplitudes(double *bufComplejos, double *amplitudes, int numAmplitudes)
{
  int i ,j;
  
  for (i = 1, j = 0; j <= numAmplitudes; i += 2, j++)
    {
        amplitudes[j] = 10 * log10(bufComplejos[i] * bufComplejos[i] + bufComplejos[i+1] * bufComplejos[i+1]);
    }
}

//construirBufferComplejos copia el buffer del vector bufferMuestras a otro que cumple las condiciones de la nueva FFT 
//(vector de doubles, la posicion 0 no se utiliza, y las posiciones impares tienen dato, las pares 0.0f)
void construirBufferComplejos(int16_t* bufferMuestras, double bufferComplejos[], int numMuestras)
{
  bufferComplejos[0] = 0.0f;
  int contador;
  for(contador = 0; contador < numMuestras; contador++)
  {
      bufferComplejos[(2*contador)+1] = (double)bufferMuestras[contador];
      bufferComplejos[(2*contador)+2] = 0.0f;
  }
}

//construirBufferMuestras realiza la operación inversa de construirBufferComplejos. Dado un buffer con muestras de Audio
//de tipo double, con la distribución que pide la FFT, que trabaja con complejos ({muestra, 0.0f, muestra, 0.0f, ect}), 
//obtiene el vector correspondiente de muestras de Audio de tipo int16_t, que es el que se encola finalmente a openAl.
void construirBufferMuestras(int16_t* bufferMuestras, double bufferComplejos[], int numMuestras)
{
  int i = 0;
  for(i = 0; i <= numMuestras; i++)
  {
    bufferMuestras[i] = (int16_t)bufferComplejos[(i*2)+1];
  }
}

void normalizarVectorComplejos(double bufferComplejos[], int numMuestras)
{
  int cont;
  for(cont = 0; cont < numMuestras; cont++)
  {
      bufferComplejos[2*cont+1] /= numMuestras;
      bufferComplejos[2*cont+2] /= numMuestras;
  }
}

//procesarMuestrasMono y procesarMuestrasStereo invocarán a la FFT sobre el buffer, aplicarán los cambios necesarios 
//para la ecualización (todavia no hace ningun cambio),calcularán las amplitudes a partir del vector resultante, 
//y luego reconstruirán la señal de sonido con la inversa.
void procesarMuestrasMono(int16_t* bufferMuestras, double amplitudesMono[])
{
  double audioBufferComplejos[NUM_MUESTRAS_MONO * 2 + 1]; //la fft utiliza el tipo double, este vector es para pasarselo a la FFT
  //pasamos las muestras a un vector de complejos (posiciones imaginarias a 0), para que lo use la FFT
  construirBufferComplejos(bufferMuestras, audioBufferComplejos, NUM_MUESTRAS_MONO); 
  
  //Invocamos la FFT
  FFT(audioBufferComplejos, NUM_MUESTRAS_MONO, 1);

  //Normalizamos el vector
  normalizarVectorComplejos(audioBufferComplejos, NUM_MUESTRAS_MONO);
  

  if(ecualizadorActivo == 1)
  {
    ecualizarMono(audioBufferComplejos);
  }
  calculoAmplitudes(audioBufferComplejos, amplitudesMono, NUM_AMPLITUDES_MONO);

  //Invocamos la inversa de la FFT (con el tercer argumento a -1 hace la inversa)
  FFT(audioBufferComplejos, NUM_MUESTRAS_MONO, -1);

  construirBufferMuestras(bufferMuestras, audioBufferComplejos, NUM_MUESTRAS_MONO);
  
}

//separarCanalesLR se usa en el caso de que el audio sea Estéreo (en estéreo las muestras vienen intercaladas),
//en cuyo caso separamos los canáles izquierdo y derecho para procesarlos por separado (debido al funcionamiento 
//de la FFT, que devuelve los datos en forma de espejo)
void separarCanalesLR(int16_t* bufferMuestras, int16_t* bufferMuestrasL, int16_t* bufferMuestrasR)
{
  int i, j;
  for (i = 0, j = 0; i < NUM_MUESTRAS_STEREO; i += 2, j++ )
  {
    bufferMuestrasL[j] = bufferMuestras[i];
    bufferMuestrasR[j] = bufferMuestras[i + 1];
  }
}

//recomponerCanalesLR realiza la inversa de separarCanalesLR
void recomponerCanalesLR(int16_t* bufferMuestrasL, int16_t* bufferMuestrasR, int16_t* bufferMuestras)
{
  int i, j;
  for (i = 0, j = 0; i < NUM_MUESTRAS_STEREO; i += 2, j++)
  {
    bufferMuestras[i] = bufferMuestrasL[j];
    bufferMuestras[i + 1] = bufferMuestrasR[j];
  }
}

//calcularAmplitudesMediaLR almacena en un vector de amplitudes la media entre el canar izquierdo y el derecho
void calcularAmplitudesMediaLR(double* amplitudesMediaLR, double* amplitudesL, double* amplitudesR, int numAmplitudes )
{
  int i;  
  for (i=0; i<numAmplitudes; i++)
  {
    amplitudesMediaLR[i] = (amplitudesL[i] + amplitudesR[i]) / 2;
  }
}

//procesarMuestrasStereo es esencialmente igual que procesarMuestrasMono, solo que trata los dos canales por separado
void procesarMuestrasStereo(int16_t* bufferMuestras, double* amplitudesMediaLR)
{
  int numMuestrasPorCanal = NUM_MUESTRAS_STEREO / 2;
  //el numero de amplitudes es siempre la mitad de las muestras que procesemos (FFT devuelve vector en espejo)
  int numAmplitudes = numMuestrasPorCanal / 2; 
  int16_t bufferMuestrasL[numMuestrasPorCanal];
  int16_t bufferMuestrasR[numMuestrasPorCanal];
  double bufferComplejosL[numMuestrasPorCanal * 2 + 1];
  double bufferComplejosR[numMuestrasPorCanal * 2 + 1];
  double amplitudesL[numAmplitudes];
  double amplitudesR[numAmplitudes];

  //separamos los canales en dos vectores distintos
  separarCanalesLR(bufferMuestras, bufferMuestrasL, bufferMuestrasR);

  //A partir de estos, creamos dos vectores de complejos para que los pueda usar la FFT
  construirBufferComplejos(bufferMuestrasL, bufferComplejosL, numMuestrasPorCanal); 
  construirBufferComplejos(bufferMuestrasR, bufferComplejosR, numMuestrasPorCanal); 

  //Invocamos la FFT
  FFT(bufferComplejosL, numMuestrasPorCanal, 1);
  FFT(bufferComplejosR, numMuestrasPorCanal, 1);

  //Normalizamos los vectores resultantes
  normalizarVectorComplejos(bufferComplejosL, numMuestrasPorCanal);
  normalizarVectorComplejos(bufferComplejosR, numMuestrasPorCanal);

  //Ecualizamos
  if(ecualizadorActivo == 1)
  {
    ecualizarCanalStereo(bufferComplejosL,numMuestrasPorCanal);
    ecualizarCanalStereo(bufferComplejosR,numMuestrasPorCanal);
  }
  //calculamos las amplitudes para cada canal
  calculoAmplitudes(bufferComplejosL, amplitudesL, numAmplitudes);
  calculoAmplitudes(bufferComplejosR, amplitudesR, numAmplitudes);
  calcularAmplitudesMediaLR(amplitudesMediaLR, amplitudesL, amplitudesR, numAmplitudes);

  //Invocamos la inversa IFFT
  FFT(bufferComplejosL, numMuestrasPorCanal, -1);
  FFT(bufferComplejosR, numMuestrasPorCanal, -1);

  //reconstruimos los vectores de muestras (sin componente imaginaria)
  construirBufferMuestras(bufferMuestrasL, bufferComplejosL, numMuestrasPorCanal);     
  construirBufferMuestras(bufferMuestrasR, bufferComplejosR, numMuestrasPorCanal);     

  recomponerCanalesLR(bufferMuestrasL, bufferMuestrasR, bufferMuestras);
}

//===========================================================================================
//Interacción usuario
//===========================================================================================

/* Instrucciones:
===============================
-Esc para detener la aplicación
-Espacio para Detener/Activar la ecualización
-G para subir graves (con Ecualizador:On)*/
void keyboard(unsigned char key, int x, int y)
{
    //printf("key %c\n", key);
  switch(key)
    {
      case 27://Tecla Esc
       
        exit(0) ;
      break ;

      case 'G': //71:
      {
        if(ecualizadorActivo == 1)
        subirGraves();
        printf("subirGraves()\n");
        break;
      }
      case 'g': //103:
      { 
        if(ecualizadorActivo == 1)
        bajarGraves();
        printf("bajarGraves()\n");
        break;
      }
      case 'M': //77:
      {
        if(ecualizadorActivo == 1)
        subirMedias();
        printf("subirMedias()\n");
        break;
      }
      case 'm': //109 :
      { 
        if(ecualizadorActivo == 1)
        bajarMedias();
        printf("bajarMedias()\n");
        break;
      }
      case 'A': //65: 
      { 
        if(ecualizadorActivo == 1)
        subirAgudas();
        printf("subirAgudas()\n");
        break;
      }
      case 'a': //97:
      { 
        if(ecualizadorActivo == 1)
        bajarAgudas();
        printf("bajarAgudas()\n");
        break;
      }
      case 'r':
      {
        resetParametros();
        break;
      }
      case 'i':
      {
        insertarValores = 1; //True
        break;
      }
      case '0': { if(insertarValores == 1) insertarParametros(0); insertarValores = 0; break;}
      case '1': { if(insertarValores == 1) insertarParametros(1); insertarValores = 0; break;}
      case '2': { if(insertarValores == 1) insertarParametros(2); insertarValores = 0; break;}
      case '3': { if(insertarValores == 1) insertarParametros(3); insertarValores = 0; break;}
      case '4': { if(insertarValores == 1) insertarParametros(4); insertarValores = 0; break;}
      case '5': { if(insertarValores == 1) insertarParametros(5); insertarValores = 0; break;}
      case '6': { if(insertarValores == 1) insertarParametros(6); insertarValores = 0; break;}
      case ' ': //32://Tecla Espacio
      {
        ecualizadorActivo = 1 - ecualizadorActivo;
        if(ecualizadorActivo == 1)
        {
          printf("Ecualizador : ON\n");
          printf("================================\n");
        }else
          {
            printf("Ecualizador : OFF\n");
            printf("================================\n");
          }
      }break;
        
    default:break ;
    }
}

//===========================================================================================
//Funciones de control de la aplicación
//===========================================================================================

//=====OPENGL=====//

void reshape(int w, int h)
{
  glViewport(0,0,(GLsizei)w,(GLsizei)h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(50.0,(GLfloat)w/(GLfloat)h,1.0,30.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glTranslatef(0.0,0.0,-6.6);
}

void RedimensionarOpenGL(int ancho, int alto)
{
    float aspecto = (float) ancho / (float) alto;

    glViewport(0, 0, ancho, alto);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0f, aspecto, 0.1f, 1000.0f);
    glMatrixMode(GL_MODELVIEW);    
}

void reshape2(GLsizei newwidth, GLsizei newheight) 
{  
    // Set the viewport to cover the new window
     glViewport(0, 0, width=newwidth, height=newheight);
     glMatrixMode(GL_PROJECTION);
     glLoadIdentity();
     glOrtho(0.0, width, height, 0.0, 0.0, 100.0);
     glMatrixMode(GL_MODELVIEW);

     glutPostRedisplay();
}

static void idle(void)
{
  glutPostRedisplay();
}


/* Initialize OpenGL Graphics */
void initGL(int w, int h) 
{
     glViewport(0, 0, w, h); // use a screen size of WIDTH x HEIGHT
     glEnable(GL_TEXTURE_2D);     // Enable 2D texturing
 
    glMatrixMode(GL_PROJECTION);     // Make a simple 2D projection on the entire window
     glLoadIdentity();
     glOrtho(0.0, w, h, 0.0, 0.0, 100.0);

     glMatrixMode(GL_MODELVIEW);    // Set the matrix mode to object modeling

     glClearColor(0.0f, 0.0f, 0.0f, 0.0f); 
     glClearDepth(0.0f);
     glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Clear the window
}



void inicializarOpenGL(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    
    
    glEnable(GL_TEXTURE_2D);
    
    
    glutInitWindowSize( VENTANA_ANCHO, VENTANA_ALTO );
    glutInitWindowPosition(340,110);
    GLwin = glutCreateWindow("Especto frecuencias") ;
    
    glutInitWindowSize( VENTANA_ANCHO+200, VENTANA_ALTO+100 );
    glutInitWindowPosition(0,0);
    GLwin2 = glutCreateWindow("Nota Musical") ;
    glutReshapeFunc(reshape2) ;
    initGL(VENTANA_ANCHO+200, VENTANA_ALTO+100);
    
    texturas();
    
    glutSetWindow(GLwin);
    glutDisplayFunc(dibujarEspectro2D);
    glutReshapeFunc(RedimensionarOpenGL) ;
    
    
    glutKeyboardFunc(keyboard);
    glutIdleFunc(idle);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
}


//=====OPENAL=====//

void inicializarOpenAl()
{
  //inicializar el dispositivo
  dev = alcOpenDevice(NULL);
  if(!dev)
  Error("Error al inicializar el dispositivo de openAL");

  //inicializar el contexto
  ctx = alcCreateContext(dev, NULL);
  if(!ctx)
  Error("Error al inicializar el contexto de openAL");
  alcMakeContextCurrent(ctx);
 
  //Generar buffers y fuentes de openAL (1 fuente)
  alGenBuffers(NUM_BUFFERS, buffers);
  alGenSources(1, &alsource);
  if(alGetError() != AL_NO_ERROR)
  Error("Error generando buffers");
}

void inicializarBuffersOpenAl()
{
  // Limpiamos buffer de entrada, por si acaso.
  memset(audioBufferMono, 0, TAM_BUFFER_MONO);

  //enviamos datos vacios (aun no se ha leido informacion desde mplayer) a los buffers de openAl
  int i = 0;
  for(i = 0; i < NUM_BUFFERS; i++)
  {
    alBufferData(buffers[i], formatoAudio, audioBufferMono, TAM_BUFFER_MONO, frecuenciaMuestreo);
  }
  //encolamos los buffers y empezamos a reproducir
  alSourceQueueBuffers(alsource,NUM_BUFFERS,buffers);

  if(alGetError() != AL_NO_ERROR)
  Error("Error encolando buffer");
  
  alSourcePlay(alsource);
}

void cerrarOpenAl()
{
  alDeleteSources(1, &alsource);
  alDeleteBuffers(NUM_BUFFERS, buffers); 
  alcMakeContextCurrent(NULL);
  alcDestroyContext(ctx);
  alcCloseDevice(dev);
}

void existeFichero(char* ruta)
{
  struct stat statbuf;
  if(stat(ruta, &statbuf) != 0 || !S_ISREG(statbuf.st_mode))
  {
    Error("No existe el fichero dado");
  }
}

void imprimirFormato()
{
  printf("\n================================\n");
  if(numCanales == 1) printf("\nFormato: Mono\n");
  if(numCanales == 2) printf("\nFormato: Estéreo\n");
  printf("Tamaño Muestra: %d bits\n", bitsMuestra);
  printf("Frecuencia de Muestreo: %d \n", frecuenciaMuestreo);
  printf("\n================================\n");
}
    

void leerCabeceraWAV(FILE* f,FILE* Fprueba)
{
  uint8_t buf[100]; //buffer para almacenar datos de cabecera

  //Ignoramos los primeros 12 bytes
  fread(buf, 1, 12, f);
  fwrite(buf,1,12,Fprueba);

  //Determinamos si la cabecera que indica el formato (debe ser fmt) es correcta (siguientes 8 bytes)
  fread(buf, 1, 8, f);
  fwrite(buf,1,8,Fprueba);
  if(buf[0] != 'f' || buf[1] != 'm' || buf[2] != 't' || buf[3] != ' ')
  {
    Error("El formato de Audio no es correcto"); 
  }

  //Comprobamos el formato de WAV (siguientes 2 bytes)
  fread(buf, 1, 2, f);
  fwrite(buf,1,2,Fprueba);
  if(buf[1] != 0 || buf[0] != 1)
  {
   Error("No es PCM");
  }

  //Leemos el número de canales (siguientes 2 bytes)
  fread(buf, 1, 2, f);
  fwrite(buf,1,2,Fprueba);
  numCanales  = buf[1]<<8;
  numCanales |= buf[0];

  //Leemos la frecuencia de muestreo (siguientes 4 bytes)
  fread(buf, 1, 4, f);
  fwrite(buf,1,4,Fprueba);
  frecuenciaMuestreo  = buf[3]<<24;
  frecuenciaMuestreo |= buf[2]<<16;
  frecuenciaMuestreo |= buf[1]<<8;
  frecuenciaMuestreo |= buf[0];

  //Los siguientes 6 bytes indican tamaño de bloque y bytes por segundo. Los ignoramos
  fread(buf, 1, 6, f);
  fwrite(buf,1,6,Fprueba);

  //Leemos los bits por muestra (siguientes 2 bytes)
  fread(buf, 1, 2, f);
  fwrite(buf,1,2,Fprueba);
  bitsMuestra  = buf[1]<<8;
  bitsMuestra |= buf[0];

  //Asignamos el tipo de formato para pasarselo a openAL dependiendo del número de canales y los bits de muestra
  formatoAudio = 0;
  if(bitsMuestra == 8)
  {
   if(numCanales == 1)
   formatoAudio = AL_FORMAT_MONO8;
   else if(numCanales == 2)
   formatoAudio = AL_FORMAT_STEREO8;
  }
  else if(bitsMuestra == 16)
  {
   if(numCanales == 1)
   formatoAudio = AL_FORMAT_MONO16;
   else if(numCanales == 2)
   formatoAudio = AL_FORMAT_STEREO16;
  }
  if(!formatoAudio)
  Error("Formato incompatible \n");
  
  numCanales = 1;
  //formatoAudio = AL_FORMAT_MONO16;
  
  //Ahora leemos la última cabecera que indica el comienzo de los datos de audio (siguientes 8 bytes)
  fread(buf, 1, 8, f);
  fwrite(buf,1,8,Fprueba);
  if(buf[0] != 'd' || buf[1] != 'a' || buf[2] != 't' || buf[3] != 'a')
  {
   Error("No se encontró 'data'");
  }else{
    imprimirFormato();
  }
  //Volcamos la cabecera al fichero Fprueba para mas tarde poder comparar el fichero con el original
//fseek(f, 0, SEEK_SET);
//fread(buf, 1, 45, f);
//fwrite(buf,1,45,Fprueba);

}

void procesoMPlayer(const char* ruta)
{
 //cerramos el descriptor de lectura
 close(descPipeline[0]);

 //cambiamos la salida estandar stdout al descriptor de escritura
 close(STDOUT_FILENO);
 dup2(descPipeline[1], STDOUT_FILENO);

 //ejecutamos MPlayer
 execlp("mplayer", "-nogui", "-really-quiet", "-novideo",
          "-noconsolecontrols", "-ao", "pcm:file=/dev/stdout",ruta, (char*)NULL);
}

void procesoPrincipal()
{
  //limpiamos la salida estandar por si acaso
  fflush(stdout);

  //Cerramos el descriptor de escritura
  close(descPipeline[1]);
  
  //Abrimos el descriptor de lectura y lo asignamos a f para leer de el
  FILE* f = fdopen(descPipeline[0], "rb");
  FILE* Fprueba = fopen("pruebaWAV.wav", "wb");

  //Iniciamos la lectura
  leerCabeceraWAV(f,Fprueba);
  inicializarOpenGL(0,NULL);
  inicializarOpenAl();
  inicializarBuffersOpenAl();
  inicializarNotas();

  //Declaramos variables locales (Amplitud)
  //Mono
  double amplitudesMono[NUM_AMPLITUDES_MONO];//vector con todas las amplitudes ya calculadas
  //Stereo
  double amplitudesMediaLR[NUM_AMPLITUDES_STEREO];
     
  //Comenzamos.
  //Mientras quede información por leer desde el descriptor de lectura... 
  while(!feof(f))
  {    
     ALint buffersLibres;

     //Consultamos a openAl si tiene buffers libres, si no tiene ninguno, continua reproduciendo.
     alGetSourcei(alsource, AL_BUFFERS_PROCESSED, &buffersLibres);
     if(buffersLibres <= 0)
     continue;


     //Cuando se libera algun buffer, se decrementa buffersLibres, y se encola el siguiente trozo
     //a leer desde el descriptor de lectura (f)
     while(buffersLibres--)
     {      
        if(numCanales==1) //Mono
        { 
          //se lee el siguiente trozo desde el descriptor de fichero
          fread(audioBufferMono, 1, TAM_BUFFER_MONO, f);
          //procesamos dicho trozo de audio (FFT, ecualización, cálculo de amplitudes)
          procesarMuestrasMono(audioBufferMono,  amplitudesMono);
          //Volcamos los datos de audio al ficherto Fprueba (para comprobarlo mas tarde con el fichero original)
          fwrite(audioBufferMono,sizeof(int16_t),NUM_MUESTRAS_MONO,Fprueba);
          //Agrupamos frecuencias para simplificar la representación                   
          agruparFrecuenciasEnBarras(amplitudesMono, barrasFrecuencia, NUM_AMPLITUDES_MONO);

          //lo encolamos a openAl
          ALuint buffer;
          alSourceUnqueueBuffers(alsource, 1, &buffer);
          alBufferData(buffer, formatoAudio, audioBufferMono, TAM_BUFFER_MONO, frecuenciaMuestreo);
          alSourceQueueBuffers(alsource, 1, &buffer);
        }
        if(numCanales==2)//Stereo
        {
          //se lee el siguiente trozo desde el descriptor de fichero
          fread(audioBufferStereo, 1, TAM_BUFFER_STEREO, f);
          //procesamos dicho trozo de audio (FFT, ecualización, cálculo de amplitudes)
          procesarMuestrasStereo(audioBufferStereo, amplitudesMediaLR); 
          //Agrupamos frecuencias para simplificar la representación                   
          agruparFrecuenciasEnBarras(amplitudesMediaLR, barrasFrecuencia, NUM_AMPLITUDES_STEREO);
          //lo encolamos a openAl
          ALuint buffer;
          alSourceUnqueueBuffers(alsource, 1, &buffer);
          alBufferData(buffer, formatoAudio, audioBufferStereo, TAM_BUFFER_STEREO, frecuenciaMuestreo);
          alSourceQueueBuffers(alsource, 1, &buffer);
        }

        


        //Pintamos
        glutMainLoopEvent();
        glutPostRedisplay();

     }

     //Nos aseguramos de que la fuente se sigue reproduciendo, y se reanuda la reproducción si es necesario
     ALint estado;
     alGetSourcei(alsource, AL_SOURCE_STATE, &estado);
     if (estado != AL_PLAYING) alSourcePlay(alsource); 
     
  }

  //Hemos terminado. Cerramos el pipeline y liberamos la memoria del buffer 
  fclose(f);
  fclose(Fprueba);
  
  //En este punto MPlayer ha terminado de decodificar, pero openAl puede que aun tenga
  //que terminar de reproducir los buffers restantes 
  ALint estado;
  do {
      alGetSourcei(alsource, AL_SOURCE_STATE, &estado);
     } while(estado == AL_PLAYING);
    
  //free(audioBuffer);
//   if(numCanales==1) // Mono
//           free(audioBufferMono);
//   else
//           free(audioBufferStereo);

  //Cerramos openAl y openGL
  //TO DO
  cerrarOpenAl();
}


//===========================================================================================
//Punto de entrada de la aplicación
//===========================================================================================


int main (int argc, char **argv)
{  
    
  //Mostrar uso en caso de que se le pasen menos de dos parametros
  if(argc < 2)
  {
   fprintf(stderr, "Uso: %s <Archivo de Audio>\n", argv[0]);
   return 0;
  }

  //Determinar si existe el fichero
  existeFichero(argv[1]);

  //Hacemos la llamada para crear la tuberia, le pasamos el descriptor de
  //fichero 

  if(pipe(descPipeline) != 0)
  Error("No se ha podido crear el pipeline");
        
     
  switch(fork()) {
    case -1:
      Error("El fork ha fallado");
  	  break;

    case 0:
      procesoMPlayer(argv[1]);
  	

    default:
      procesoPrincipal();
      break;
 };
 
 cerrarOpenAl();
 
 }

 
 
