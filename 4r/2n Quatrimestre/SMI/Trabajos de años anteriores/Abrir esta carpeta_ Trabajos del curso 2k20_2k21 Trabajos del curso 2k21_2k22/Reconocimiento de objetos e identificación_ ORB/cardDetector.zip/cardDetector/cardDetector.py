import imutils
import cv2 as cv
import os
import numpy as np
import sys
try:
	arg = sys.argv[1]
except:
	print('-'*60)
	print("inserta E o e para seleccionar baraja ESPAÑOLA")
	print("inserta cualquier otra tecla para seleccionar baraja INGLESA")
	print('-'*60)
	exit()
deck = "SpanishDeck" if (arg == 'E' or arg == 'e') else "EnglishDeck"
print('-'*60)
print(f"baraja seleccionada : {deck}")
print('-'*60)
img_path = os.path.dirname(os.path.abspath(__file__)) + f'/{deck}/'
font = cv.FONT_HERSHEY_PLAIN
cap = cv.VideoCapture(1) # puede ser necesario añadir un time.sleep para abrir cam

orb = cv.ORB_create(nfeatures=1000)
# orb = cv.SIFT_create()
# orb = cv.FastFeatureDetector_create()

bf = cv.BFMatcher()
GREEN = (0,255,0)
RED = (0,0,255)
BLUE = (255,0,0)
WHITE = (255,255,255)
THRESH_CARD_VALUE_CAM = 160


class Card:
	"""Structure to store information about cards in the camera image."""
	def __init__(self):
		self.contour = [] # Contour of card
		self.center = [] # Center point of card
		self.warp = [] # 200x300, flattened image
		self.guess = "" # Card guessed

def prepareFrame(img):
	gray = cv.cvtColor(img,cv.COLOR_BGR2GRAY)
	blur = cv.GaussianBlur(gray,(5,5),0)
	_,tresh = cv.threshold(blur,THRESH_CARD_VALUE_CAM,255,0)
	return tresh

# https://pyimagesearch.com/2014/08/25/4-point-opencv-getperspective-transform-example/
def four_point_transform(image, pts):
	rect = np.zeros((4, 2), dtype = "float32")
	s = np.sum(pts,axis = 2)
	rect[0] = pts[np.argmin(s)]
	rect[2] = pts[np.argmax(s)]

	diff = np.diff(pts, axis =-1)
	rect[1] = pts[np.argmin(diff)]
	rect[3] = pts[np.argmax(diff)]
	(tl, tr, br, bl) = rect
	widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
	widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
	maxWidth = max(int(widthA), int(widthB))
	heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
	heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
	maxHeight = max(int(heightA), int(heightB))
	dst = np.array([[0, 0],[maxWidth - 1, 0],[maxWidth - 1, maxHeight - 1],[0, maxHeight - 1]], dtype = "float32")
	M = cv.getPerspectiveTransform(rect, dst)
	warped = cv.warpPerspective(image, M, (maxWidth, maxHeight))
	warp = imutils.resize(warped, height=650)
	return warp

def findAllCardsContours(img):
	cnts,_ = cv.findContours(img,cv.RETR_TREE,cv.CHAIN_APPROX_SIMPLE)
	cnts_sort = sorted(cnts, key=cv.contourArea,reverse=True)
	# If there are no contours, do nothing
	if len(cnts) == 0:
		return [], []
	good_cart = []
	for cnt in cnts_sort:
		peri = cv.arcLength(cnt,True)
		approx = cv.approxPolyDP(cnt,0.01*peri,True)
		if (len(approx) == 4):
			good_cart.append(cnt)
	return good_cart

def detectCard(img):
	global descriptors
	good=[]
	try:
		(_, des2) = orb.detectAndCompute(img, None)
		for des in descriptors:
			matches = bf.knnMatch(des,des2,k=2)
			decent = []
			for m,n in matches:
				if m.distance < 0.75*n.distance:
					decent.append([m])
			good.append(len(decent))
	except : pass
	cardName = getCardName(good)
	return cardName

def getListOfCards():
	dir = os.listdir(img_path)
	names = []
	descriptors = []
	for file in dir:
		src = cv.imread(f'{img_path}{file}')
		(_, des1) = orb.detectAndCompute(src, None)
		descriptors.append(des1)
		names.append(os.path.splitext(file)[0])
	return names, descriptors

def getCardName(resultList):
	global names
	max = -1
	index = -1
	GOOD_MATCHES = 80
	for i, num  in enumerate(resultList):
		if(num > max and num >= GOOD_MATCHES):
			max = num
			index = i
	cardName = "" if index < 0 else names[index]  
	return cardName

def getCardInfo(contour, image):
	card = Card()
	card.contour = contour
	peri = cv.arcLength(contour,True)
	approx = cv.approxPolyDP(contour,0.01*peri,True)
	pts = np.float32(approx)
	card.warp = four_point_transform(image, pts)
	M = cv.moments(card.contour)
	if M["m00"] != 0:
		cX = int(M["m10"] / M["m00"])
		cY = int(M["m01"] / M["m00"])
	else:
		cX, cY = 0, 0
	card.center = [cX, cY]
	card.guess = detectCard(card.warp)
	return card

def drawResults(image, card):
	x , y = card.center
	if (card.guess != ""):
		cv.drawContours(image,[card.contour],-1,GREEN,2)
		cv.rectangle(image,(x-60,y-40),(x+80,y+5),WHITE,-1)
		cv.putText(image,(card.guess),(x-60,y-10),font,1.5,RED,2,cv.LINE_8)
	return image

names , descriptors = getListOfCards()
while(True):
	ret,frame = cap.read()
	prepared = prepareFrame(frame)

	cardsCnts = findAllCardsContours(prepared)

	if len(cardsCnts) != 0:
		for posibleCard in cardsCnts:
			card = getCardInfo(posibleCard, frame)
			frame = drawResults(frame, card)

	cv.imshow("Card Detector",frame)
	key = cv.waitKey(1) & 0xFF
	if key == ord("p"):
		break
