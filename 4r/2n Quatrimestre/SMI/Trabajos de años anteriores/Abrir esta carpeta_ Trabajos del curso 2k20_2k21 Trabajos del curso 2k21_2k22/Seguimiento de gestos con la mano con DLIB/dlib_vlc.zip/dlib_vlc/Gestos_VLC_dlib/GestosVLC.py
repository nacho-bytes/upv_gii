import dlib
import cv2
import os
import sys
import time
import signal
import pyautogui as pyg
import numpy as np
import vlc


def main(args):
    if(len(args) < 2):
        print("Hay que introducir por linea de órdenes al menos 1 detector")
        return

    nombres = []

    # Crear una lista con los nombres de los detectores ¡¡QUE COMPRUEBE QUE ES .SVM!!
    for svm in args[1:5]:
        if(not svm.endswith(".svm")):
            print("Hay que introducir un detector válido")
        nombres.append(svm)
    
    cv2.namedWindow('frame', cv2.WINDOW_NORMAL)
    cap = cv2.VideoCapture(0)

    # Para detección más rápida, se establece un factor de downscaling
    # A más pequeño, más preciso pero más lento
    scale_factor = 2.0

    # Inicializar el centro
    center_x = 0

    # Variables para el cálculo de FPS (quitar?)
    start_time = time.time()

    gestos = []
    
    # media = vlc.MediaPlayer("demo.mp4")
 
    # media.play()

    # Carga los detectores usando esta función de dlib
    
    for nombre in nombres:
        gestos.append(dlib.fhog_object_detector(nombre))
        
    # sonidos = createBuffers(nombres)

    print("q para salir o ctrl+c")
    
    # Bucle infinito
    while(True):
        # Leer cada frame
        ret, frame = cap.read()

        if not ret:
            break

        # Girar el frame lateralmente
        frame = cv2.flip( frame, 1 )

        # Copia del frame
        copy = frame.copy()

        # Reduce el tamaño del frame
        new_width = int(frame.shape[1]/scale_factor)
        new_height = int(frame.shape[0]/scale_factor)
        resized_frame = cv2.resize(copy, (new_width, new_height))

        # Deteccion
        [detections, confidences, detector_idxs] = dlib.fhog_object_detector.run_multiple(gestos, resized_frame, upsample_num_times=1)

        # Obtenemos el gesto más preciso
        if (confidences):
            max_value = max(confidences)
            i = confidences.index(max_value)
            
            # Reescalar la imagen para obtener las coordenadas correctas
            x1 = int(detections[i].left() * scale_factor )
            y1 =  int(detections[i].top() * scale_factor )
            x2 =  int(detections[i].right() * scale_factor )
            y2 =  int(detections[i].bottom()* scale_factor )

            # Mínimo de precisión, quitar si queremos más imprecisión
            if (confidences[i]*100 > 10):
                # Dibuja una bounding box
                cv2.rectangle(frame,(x1,y1),(x2,y2),(50,255,50), 2 )
                cv2.putText(frame, '{}: {:.2f}%'.format(nombres[detector_idxs[i]], confidences[i]*100), (x1,y2+20), cv2.FONT_HERSHEY_COMPLEX, 0.6, (0,0,255),2)
                

                # Calcula el centro vertical de la mano
                center_x = (y1 + y2) // 2
                
                # Determina si está abajo o arriba
                posicionAbajo = (center_x > 240)
                
                # Toca la nota que le corresponda al gesto
                # if(not estaSonando(sonidos)):
                    # Si hay que sumar una posición al sonido
                #suma = 0
                #if (posicionAbajo):
                #    suma = 1
                
                if(nombres[detector_idxs[i]].__eq__('gestos/parar_reanudar.svm')):
                    print(nombres[detector_idxs[i]])
                    if (posicionAbajo):
                        pyg.press("space")
                        
                    else:
                        pyg.press("space")
                       
                         
                if(nombres[detector_idxs[i]].__eq__('gestos/subir_bajar.svm')):
                    print(nombres[detector_idxs[i]])
                    if (posicionAbajo):
                        pyg.press("down")
                        
                    else:
                         pyg.press("up")
                         
                         
                if(nombres[detector_idxs[i]].__eq__('gestos/avanzar_retroceder.svm')):
                    print(nombres[detector_idxs[i]])
                    if (posicionAbajo):
                        pyg.press("left")
                        
                    else:
                         pyg.press("right")   
                         
                # Obtén el índice del gesto y la posición del sonido
                #j = nombres.index(nombres[detector_idxs[i]]) * 2 + suma

                    # Reproduce el sonido
                    # sonidos[j].play()

        # Dibuja dos lineas horizontales
        cv2.line(frame, (0,238), (640,238), (255,255,255), 2)
        cv2.line(frame, (0,242), (640,242), (0,0,0), 2)
    

        # Display el centro y el tamaño de la mano
        cv2.putText(frame, 'Center: {}'.format(center_x), (540, 20), cv2.FONT_HERSHEY_COMPLEX, 0.5, (233, 100, 25))

        # Muestra la imagen por pantalla
        cv2.imshow('frame',frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            salida(None, None)
            break

    # Relase the webcam and destroy all windows
    cap.release()
    cv2.destroyAllWindows()


# Asigna dos sonidos a cada gesto
# def createBuffers(models):
#   sonidos = [None] * (len(models)*2)
 #   i = 0
  #  while i < len(models):
   #     sonidos[i*2] = oalOpen("notas_piano/audio{}.wav".format(i*2))
    #    sonidos[i*2+1] = oalOpen("notas_piano/audio{}.wav".format(i*2+1))
     #   i += 1
  #  return sonidos

# Para que no se solapen las notas
# def estaSonando(sonidos):
  #  for sonido in sonidos:
   #     if sonido.get_state() == AL_PLAYING:
    #        return True
  #  return False

# Cierra openal al salir
def salida(signal, frame):
    oalQuit()
    sys.exit(0)

if __name__ == "__main__":
    signal.signal(signal.SIGINT, salida)
    main(sys.argv)
