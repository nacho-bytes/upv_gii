import dlib
import glob
import cv2
import os
import sys
import time
import numpy as np
import shutil



def main(args):
    
    if(len(args) < 4):
        print("Modo de uso:\n   python3 prpANDtrain.py <arg1> <arg2> <arg3>\n   arg1: directorio donde están las imágenes\n   arg2:archivo de texto donde estan las coordenadas de cada imagen\n   arg3: nombre del detector con extension .svm")
        return


    # directorio donde guardaremos las imagenes y las bounding box
    # carpeta/gestoX
    directory = args[1] #'./train_images/gesto1'
    box_file = args[2] #'./train_images/boxes_gesto1.txt'
    file_name = args[3] #'Gesto1_detector_v1.svm'
    data = preprocess(directory, box_file)
    training(data, file_name)


def preprocess(directory, box_file):
    ''' 
    Parte 1: preprocesado de imágenes
    17-54
    '''
    # dictionary para guardar las imágenes y las anotaciones
    data = {}

    # índices de todas las imágenes
    image_indexes = [int(img_name.split('.')[0]) for img_name in os.listdir(directory)]
    #print(image_indexes) # DEBUG 

    # mezcla los índices
    np.random.shuffle(image_indexes)

    # lee el contenido de box_file
    f = open(box_file, "r")
    box_content = f.read()

    # formato del dictionary: 'index: (x1,y1,x2,y2)' ... '...'
    box_dict = eval( '{' + box_content + '}' )
    #print(box_dict) # DEBUG

    f.close()

    for index in image_indexes:
        # lee la imagen y enlazala a la lista
        img = cv2.imread(os.path.join(directory, str(index) + '.png'))

        # lee la bounding box
        bounding_box = box_dict[index]

        # convierte la bounding box a formato dlib
        x1, y1, x2, y2 = bounding_box
        dlib_box = [ dlib.rectangle(left = x1, top = y1, right = x2, bottom = y2) ]

        # guarda la imagen y la box juntas
        data[index] = (img, dlib_box)

    ''' 
    FIN DEL PREPROCESADO 
    '''

    print('Total: {}'.format(len(data)))
    
    return data


def training(data, file_name):
    '''
    ETAPA DE ENTRENAMIENTO
    '''
    # porcentaje de imágenes usado para entrenar, el resto será usado para validar
    percent = 1
    split = int(len(data) * percent)
    print('training data: {}'.format(split))
    # separar las imágenes y las bounding boxes en listas diferentes
    images = [tuple_value[0] for tuple_value in data.values()]
    bounding_boxes = [tuple_value[1] for tuple_value in data.values()]

    # inicializar Object Detection Options de dlib
    options = dlib.simple_object_detector_training_options()

    # desactivar el volteado horizontal: el detector se puede confundir así 
    # que solo se detectará la mano que se haya entrenado (izquierda o derecha)
    # en nuestro caso izquierda
    options.add_left_right_image_flips = False

    # ajustar el valor C del SVM
    # "A bigger C encourages the model to better fit the training data, it can lead to overfitting." via http://dlib.net/python/index.html#dlib.simple_object_detector_training_options 
    # probar otros valores
    options.C = 5

    # instante en el que empezamos a entrenar
    start = time.time()

    # a entrenar
    detector = dlib.train_simple_object_detector(images[:split], bounding_boxes[:split], options)

    # total time
    print('Training Completed, Total time taken: {:.2f} seconds'.format(time.time() - start))

    # guardar el detector
    
    detector.save(file_name)

    # check the hog descriptor
    win_det = dlib.image_window()
    win_det.set_image(detector)

    # comprobar precision entrenamiento
    print("Training metrics: {}".format(dlib.test_simple_object_detector(images[:split], bounding_boxes[:split], detector)))

    # comprobar precision entrenamiento
    #print("Testing metrics: {}".format(dlib.test_simple_object_detector(images[split:], bounding_boxes[split:], detector)))


if __name__ == "__main__":
    main(sys.argv)
