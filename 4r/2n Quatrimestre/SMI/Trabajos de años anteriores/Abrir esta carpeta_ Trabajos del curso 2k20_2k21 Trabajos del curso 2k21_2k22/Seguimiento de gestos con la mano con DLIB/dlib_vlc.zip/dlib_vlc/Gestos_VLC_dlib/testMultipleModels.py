import dlib
import glob
import cv2
import os
import sys
import time
import numpy as np
import shutil



def main(args):
    if(len(args) < 2):
        print("Hay que introducir por linea de órdenes al menos 1 detector")
        return
    
    cv2.namedWindow('frame', cv2.WINDOW_NORMAL)
    cap = cv2.VideoCapture(0)

    # Setting the downscaling size, for faster detection
    # If you're not getting any detections then you can set this to 1
    scale_factor = 2.0

    # Initially the size of the hand and its center x point will be 0
    size, center_x = 0,0

    # Variables para el cálculo de FPS (quitar?)
    fps = 0 
    frame_counter = 0
    start_time = time.time()

    nombres = []
    gestos = []

    # Crear una lista con los nombres de los detectores
    for svm in args[1:]:
        nombres.append(svm)

    # Carga los detectores usando esta función de dlib
    i = 0
    while i < len(nombres):
        gestos.append(dlib.fhog_object_detector(nombres[i]))
        i += 1

    print("Ctrl + q para salir o ctrl+c")
    
    # Bucle infinito
    while(True):
        # Leer cada frame
        ret, frame = cap.read()

        if not ret:
            break

        # Girar el frame lateralmente
        frame = cv2.flip( frame, 1 )

        # Cálculo de FPS medio
        frame_counter += 1
        fps = (frame_counter / (time.time() - start_time))

        # Copia del frame
        copy = frame.copy()

        # Reduce el tamaño del frame
        new_width = int(frame.shape[1]/scale_factor)
        new_height = int(frame.shape[0]/scale_factor)
        resized_frame = cv2.resize(copy, (new_width, new_height))

        # Deteccion
        [detections, confidences, detector_idxs] = dlib.fhog_object_detector.run_multiple(gestos, resized_frame, upsample_num_times=1)

        # Obtenemos el gesto más preciso
        if (confidences):
            max_value = max(confidences)
            i = confidences.index(max_value)
            
            # Reescalar la imagen para obtener las coordenadas correctas
            x1 = int(detections[i].left() * scale_factor )
            y1 =  int(detections[i].top() * scale_factor )
            x2 =  int(detections[i].right() * scale_factor )
            y2 =  int(detections[i].bottom()* scale_factor )

            # Mínimo de precisión, quitar si queremos más imprecisión
            if (confidences[i]*100 > 15):
                # Dibuja una bounding box
                cv2.rectangle(frame,(x1,y1),(x2,y2),(0,255,0), 2 )
                cv2.putText(frame, '{}: {:.2f}%'.format(nombres[detector_idxs[i]], confidences[i]*100), (x1,y2+20), cv2.FONT_HERSHEY_COMPLEX, 0.6, (0,0,255),2)

                # Calcula tamaño de la mano 
                size = int( (x2 - x1) * (y2-y1) )
    
                # Calcula centro de la mano
                center_x = x2 - x1 // 2

        # # Detectar varios gestos a la vez, puede traer conflictos entre gestos
        # # loop
        # for i in range(len(detections)):
        #     # Reescalar la imagen para obtener las coordenadas correctas
        #     x1 = int(detections[i].left() * scale_factor )
        #     y1 =  int(detections[i].top() * scale_factor )
        #     x2 =  int(detections[i].right() * scale_factor )
        #     y2 =  int(detections[i].bottom()* scale_factor )


        #     # Mínimo de precisión, quitar si queremos más imprecisión
        #     if (confidences[i]*100 > 15):
        #         # Dibuja una bounding box
        #         cv2.rectangle(frame,(x1,y1),(x2,y2),(0,255,0), 2 )
        #         cv2.putText(frame, '{}: {:.2f}%'.format(nombres[detector_idxs[i]], confidences[i]*100), (x1,y2+20), cv2.FONT_HERSHEY_COMPLEX, 0.6, (0,0,255),2)

        #         # Calcula tamaño de la mano 
        #         size = int( (x2 - x1) * (y2-y1) )
    
        #         # Calcula centro de la mano
        #         center_x = x2 - x1 // 2
        
        # Muestra FPS y tamaño de la mano
        cv2.putText(frame, 'FPS: {:.2f}'.format(fps), (20, 20), cv2.FONT_HERSHEY_COMPLEX, 0.6, (0, 0, 255),2)

        # Información útil para la siguiente parte del trabajo
        cv2.putText(frame, 'Center: {}'.format(center_x), (540, 20), cv2.FONT_HERSHEY_COMPLEX, 0.5, (233, 100, 25))
        cv2.putText(frame, 'size: {}'.format(size), (540, 40), cv2.FONT_HERSHEY_COMPLEX, 0.5, (233, 100, 25))

        # Muestra la imagen por pantalla
        cv2.imshow('frame',frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Relase the webcam and destroy all windows
    cap.release()
    cv2.destroyAllWindows()


        

if __name__ == "__main__":
    main(sys.argv)