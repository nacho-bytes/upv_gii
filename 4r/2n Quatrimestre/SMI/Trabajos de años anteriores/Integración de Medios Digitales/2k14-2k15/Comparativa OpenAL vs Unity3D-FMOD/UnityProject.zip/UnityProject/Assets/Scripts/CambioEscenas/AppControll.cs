﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class AppControll : MonoBehaviour {
	private static Text texto;
	private static bool activo = true;
	private static GameObject canvas;
	private static AppControll controlador;



	public static AppControll getInstance()
	{
		if (controlador == null) {
			GameObject AppController = new GameObject ("AppController");
			DontDestroyOnLoad (AppController);
			controlador = AppController.AddComponent<AppControll> ();
			canvas = Instantiate<GameObject>(Resources.Load<GameObject>("Canvas"));
			texto = GameObject.Find ("Text").GetComponent<Text> ();
			DontDestroyOnLoad (canvas);
		}
		return controlador;
	}

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {

		if(Input.GetKeyDown(KeyCode.Escape))
	   	{
			Application.Quit();
		}

		if(Input.GetKeyDown(KeyCode.H))
		{
			if(activo)
				activo=false;
			else
				activo = true;
			canvas.SetActive(activo);
		}
	}

	public void setText(string info)
	{
		texto.text = info;
	}
}
