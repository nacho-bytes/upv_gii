﻿using UnityEngine;
using System.Collections;

public class TeleporScene3 : MonoBehaviour {
	private AppControll controlador;
	
	void Start()
	{
		//AppControll singleton = AppControll.instance;
		controlador = AppControll.getInstance ();
		controlador.setText("Escena 4" +
			"\n\nTeclas del 1 al 3 para reproducir/parar la reproduccion de los distintos ficheros");
	}

	void OnCollisionEnter(Collision collision)
	{
		if(collision.gameObject.name == "TP")
			Application.LoadLevel ("Escena5");
		if (collision.gameObject.name == "TP 1")
			Application.LoadLevel ("Escena3.4");
	}
}
