﻿using UnityEngine;
using System.Collections;

public class TeleporScene4 : MonoBehaviour {
	private AppControll controlador;
	
	void Start()
	{
		//AppControll singleton = AppControll.instance;
		controlador = AppControll.getInstance ();
		controlador.setText("Escena 5" +
			"\n\nSaleccionar fuentes F1 a F11" +
			"\nReproducir 'barra espaciadora'" +
			"\nAumentar Pitch 'I'" +
			"\nReducir Pitch 'K'" +
			"\nAumentar Gain 'U'" +
			"\nReducir Gain 'J'" +
			"\nRotar derecha 'O'" +
			"\nRotar izquierda 'L'" +
			"\nMover fuente 'M'" +
			"\nTerminar mover fuente 'M'");
	}

	void OnCollisionEnter(Collision collision)
	{
		if (collision.gameObject.name == "TP 1")
			Application.LoadLevel ("Escena4");
		if (collision.gameObject.name == "TP")
			Application.LoadLevel ("Escena6");
	}
}
