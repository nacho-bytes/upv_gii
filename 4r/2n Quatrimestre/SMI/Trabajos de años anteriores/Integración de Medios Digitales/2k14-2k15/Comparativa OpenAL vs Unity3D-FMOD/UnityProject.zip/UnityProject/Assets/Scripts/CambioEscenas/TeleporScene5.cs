﻿using UnityEngine;
using System.Collections;

public class TeleporScene5 : MonoBehaviour {
	private AppControll controlador;
	
	void Start()
	{
		//AppControll singleton = AppControll.instance;
		controlador = AppControll.getInstance ();
		controlador.setText("Escena 6" +
			"\n\n'R' grabar/detener grabacion" +
			"\nSi se detiene la grabacion se generara un .WAV con lo grabado hasta el momento" +
			"\n'Espacio' para reproducir lo que se esta grabando");
	}
	
	void OnCollisionEnter(Collision collision)
	{
		if (collision.gameObject.name == "TP 1")
			Application.LoadLevel ("Escena5");
	}
}
