﻿using UnityEngine;
using System.Collections;

public class TeleportScene0 : MonoBehaviour {
	private AppControll controlador;

	void Start()
	{
		controlador = AppControll.getInstance ();

		controlador.setText("Escena 3.3.1" +
				"\n\nTodas las escenas incorporan una cámara junto a un cubo con la posibilidad de moverse mediante las teclas 'W', 'A', 'S' y 'D' o las flechas de direción." +
				"\n\nCon la tecla 'Esc' se saldrá de la aplicación." +
				"\n\nLos cubos con particulas verdes avanzan un nivel, los de particulas rojas retroceden." +
				"\n\nCon la tecla 'H' se mostrará la ayuda especifica a cada nivel.");
	}
	void OnCollisionEnter(Collision collision)
	{
		if (collision.gameObject.name == "TP")
			Application.LoadLevel ("Escena3.3.2");
	}
}
