﻿using UnityEngine;
using System.Collections;

public class TeleportScene1 : MonoBehaviour {
	private AppControll controlador;
	
	void Start()
	{
		//AppControll singleton = AppControll.instance;
		controlador = AppControll.getInstance ();
		controlador.setText( "Escena 3.3.2" +
			"\n\n'Barra espaciadora' para parar/reproducir el sonido");
	}

	void OnCollisionEnter(Collision collision)
	{
		if(collision.gameObject.name == "TP")
			Application.LoadLevel ("Escena3.4");
		if (collision.gameObject.name == "TP 1")
			Application.LoadLevel ("Escena3.3.1");
	}
}
