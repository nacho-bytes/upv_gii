﻿using UnityEngine;
using System.Collections;

public class TeleportScene2 : MonoBehaviour {
	private AppControll controlador;
	
	void Start()
	{
		//AppControll singleton = AppControll.instance;
		controlador = AppControll.getInstance ();
		controlador.setText( "Escena 3.4" +
			"\n\nTeclas del 1 al 8 para reproducir distintas frecuencias");
	}

	void OnCollisionEnter(Collision collision)
	{
		if(collision.gameObject.name == "TP")
			Application.LoadLevel ("Escena4");
		if (collision.gameObject.name == "TP 1")
			Application.LoadLevel ("Escena3.3.2");
	}
}
