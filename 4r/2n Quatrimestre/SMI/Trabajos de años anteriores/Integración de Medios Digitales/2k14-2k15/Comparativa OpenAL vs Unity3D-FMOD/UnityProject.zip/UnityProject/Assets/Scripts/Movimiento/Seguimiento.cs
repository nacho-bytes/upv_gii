﻿using UnityEngine;
using System.Collections;

public class Seguimiento : MonoBehaviour {
	public float velocidad = 0.1f;
	private Vector3 direccion;
	Transform trans;
	// Use this for initialization
	void Start () {
		trans = this.GetComponent<Transform> ();
	}
	
	// Update is called once per frame
	void Update () {
		movimiento ();
	}
	
	private void movimiento()
	{
		direccion = trans.position;
		if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey (KeyCode.W))
		{
			direccion.z +=velocidad;
		}
		
		if (Input.GetKey (KeyCode.LeftArrow) || Input.GetKey (KeyCode.A))
		{
			direccion.x -=velocidad;
		}
		
		if (Input.GetKey (KeyCode.RightArrow) || Input.GetKey (KeyCode.D))
		{
			direccion.x +=velocidad;
		}
		
		if (Input.GetKey (KeyCode.DownArrow) || Input.GetKey (KeyCode.S))
		{
			direccion.z -=velocidad;
		}
		trans.position = direccion;
	}
}