﻿using UnityEngine;
using System.Collections;


public class Ejercicios : MonoBehaviour {
	const int numSources = 11;
	private int position = 0;
	public int samplerate = 44100;
	private float[] frequency = {262, 294, 330, 349, 392, 415, 440 ,494};
	private int contador = 0;

	private GainModifier[] gain = new GainModifier[numSources];
	private AudioClip[] simple = new AudioClip[numSources];
	private AudioSource[] fuente = new AudioSource[numSources];

	private int seleccion = 0;
	private bool movSel = false;

	// Use this for initialization
	void Start () {
		int i;

		simple[0] = AudioClip.Create("Simple 0",samplerate * 2, 1, samplerate, true, OnAudioRead0);
		simple[1] = AudioClip.Create("Simple 1",samplerate * 2, 1, samplerate, true, OnAudioRead1);
		simple[2] = AudioClip.Create("Simple 2",samplerate * 2, 1, samplerate, true, OnAudioRead2);
		simple[3] = AudioClip.Create("Simple 3",samplerate * 2, 1, samplerate, true, OnAudioRead3);
		simple[4] = AudioClip.Create("Simple 4",samplerate * 2, 1, samplerate, true, OnAudioRead4);
		simple[5] = AudioClip.Create("Simple 5",samplerate * 2, 1, samplerate, true, OnAudioRead5);
		simple[6] = AudioClip.Create("Simple 6",samplerate * 2, 1, samplerate, true, OnAudioRead6);
		simple[7] = AudioClip.Create("Simple 7",samplerate * 2, 1, samplerate, true, OnAudioRead7);

		for (i=0; i < 8; i++) 
		{
			GameObject.Find ("Cube " + i).AddComponent<Movimiento> ().enabled = false;
			gain[i] = GameObject.Find ("Cube " + i).AddComponent<GainModifier>();
			fuente[i] = GameObject.Find ("Cube " + i).GetComponent<AudioSource> ();
			fuente[i].spatialBlend = 1;
			fuente[i].clip = simple[i];
		}

		GameObject.Find ("Cube 9").AddComponent<Movimiento> ().enabled = false;
		GameObject.Find ("Cube 10").AddComponent<Movimiento> ().enabled = false;
		GameObject.Find ("Cube 8").AddComponent<Movimiento> ().enabled = false;

		gain[8] = GameObject.Find ("Cube 8").AddComponent<GainModifier> ();
		gain[9] = GameObject.Find ("Cube 9").AddComponent<GainModifier> ();
		gain[10] = GameObject.Find ("Cube 10").AddComponent<GainModifier> ();

		fuente[8] = GameObject.Find ("Cube 8").GetComponent<AudioSource> ();
		fuente[9] = GameObject.Find ("Cube 9").GetComponent<AudioSource> ();
		fuente[10] = GameObject.Find ("Cube 10").GetComponent<AudioSource> ();


	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetKey (KeyCode.I)) {
			fuente [seleccion].pitch += 0.1f;
		}

		if (Input.GetKey (KeyCode.K)) {
			fuente [seleccion].pitch -= 0.1f;
		}

		if (Input.GetKey (KeyCode.U)) {
			gain [seleccion].gain += 0.1f;
		}

		if (Input.GetKey (KeyCode.J)) {
			if (gain [seleccion].gain < 0.2f)
				gain [seleccion].gain = 0.1f;
			else
				gain [seleccion].gain -= 0.1f;
		}

		if (Input.GetKeyDown(KeyCode.M))
		{
			if (!movSel)
			{
				movSel = true;
				GameObject.Find("Main Camera").GetComponent<Seguimiento>().enabled = false;
				GameObject.Find("Cube").GetComponent<Movimiento>().enabled = false;
				GameObject.Find("Cube "+seleccion).GetComponent<Movimiento>().enabled = true;
			}
			else{
				movSel = false;
				GameObject.Find("Main Camera").GetComponent<Seguimiento>().enabled = true;
				GameObject.Find("Cube").GetComponent<Movimiento>().enabled = true;
				GameObject.Find("Cube "+seleccion).GetComponent<Movimiento>().enabled = false;
			}
		}
		if (!movSel) {

			if (Input.GetKey (KeyCode.F1)) {
				seleccion = 0;
			}

			if (Input.GetKeyDown (KeyCode.F2)) {
				seleccion = 1;
			}

			if (Input.GetKeyDown (KeyCode.F3)) {
				seleccion = 2;
			}

			if (Input.GetKeyDown (KeyCode.F4)) {
				seleccion = 3;
			}

			if (Input.GetKeyDown (KeyCode.F5)) {
				seleccion = 4;
			}

			if (Input.GetKeyDown (KeyCode.F6)) {
				seleccion = 5;
			}

			if (Input.GetKeyDown (KeyCode.F7)) {
				seleccion = 6;
			}

			if (Input.GetKeyDown (KeyCode.F8)) {
				seleccion = 7;
			}

			if (Input.GetKeyDown (KeyCode.F9)) {
				seleccion = 8;
			}

			if (Input.GetKeyDown (KeyCode.F10)) {
				seleccion = 9;
			}

			if (Input.GetKeyDown (KeyCode.F11)) {
				seleccion = 10;
			}
		}
		if (Input.GetKeyDown (KeyCode.Space)) 
		{
			fuente[seleccion].Play();
		}
	}

	void OnAudioRead0(float[] data)
	{
		int count = 0;
		while (count < data.Length) 
		{
			data[count] = Mathf.Sign(Mathf.Sin(2 * Mathf.PI * frequency[0] * position / samplerate));
			position++;
			count++;
		}
		contador++;
	}

	void OnAudioRead1(float[] data)
	{
		int count = 0;
		while (count < data.Length) 
		{
			data[count] = Mathf.Sign(Mathf.Sin(2 * Mathf.PI * frequency[1] * position / samplerate));
			position++;
			count++;
		}
		contador++;
	}

	void OnAudioRead2(float[] data)
	{
		int count = 0;
		while (count < data.Length) 
		{
			data[count] = Mathf.Sign(Mathf.Sin(2 * Mathf.PI * frequency[2] * position / samplerate));
			position++;
			count++;
		}
		contador++;
	}

	void OnAudioRead3(float[] data)
	{
		int count = 0;
		while (count < data.Length) 
		{
			data[count] = Mathf.Sign(Mathf.Sin(2 * Mathf.PI * frequency[3] * position / samplerate));
			position++;
			count++;
		}
		contador++;
	}

	void OnAudioRead4(float[] data)
	{
		int count = 0;
		while (count < data.Length) 
		{
			data[count] = Mathf.Sign(Mathf.Sin(2 * Mathf.PI * frequency[4] * position / samplerate));
			position++;
			count++;
		}
		contador++;
	}

	void OnAudioRead5(float[] data)
	{
		int count = 0;
		while (count < data.Length) 
		{
			data[count] = Mathf.Sign(Mathf.Sin(2 * Mathf.PI * frequency[5] * position / samplerate));
			position++;
			count++;
		}
		contador++;
	}

	void OnAudioRead6(float[] data)
	{
		int count = 0;
		while (count < data.Length) 
		{
			data[count] = Mathf.Sign(Mathf.Sin(2 * Mathf.PI * frequency[6] * position / samplerate));
			position++;
			count++;
		}
		contador++;
	}

	void OnAudioRead7(float[] data)
	{
		int count = 0;
		while (count < data.Length) 
		{
			data[count] = Mathf.Sign(Mathf.Sin(2 * Mathf.PI * frequency[7] * position / samplerate));
			position++;
			count++;
		}
		contador++;
	}
}
