﻿using UnityEngine;
using System.Collections;

public class GainModifier : MonoBehaviour {

	public float gain = 1;
	
	void OnAudioFilterRead(float[] data,int channels) {
		for (int i = 0; i < data.Length; ++i)
			data[i] = data[i] * gain;			
	}
}
