﻿using UnityEngine;
using System.Collections;

public class Grabar : MonoBehaviour {
	private AudioSource aud;
	private bool grabando = false;
	private int numGrab = 0;
	// Use this for initialization
	void Start () {
		aud = GetComponent<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.R)) {
			if(!grabando)
			{
				aud.clip = Microphone.Start ("Built-in Microphone", true, 360, 44100);
				grabando = true;
			}
			else
			{
				Microphone.End("Built-in Microphone");
				SavWav.Save("audio"+numGrab,aud.clip);
				numGrab++;
			}
		}

		if (Input.GetKeyDown (KeyCode.Space)) {
			aud.Play();
		}
	}
}
