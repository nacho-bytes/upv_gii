﻿using UnityEngine;
using System.Collections;

public class Script332 : MonoBehaviour {
	GameObject sol;
	Light luzSolar;

	GameObject cubo;
	AudioSource sonido;
	// Use this for initialization
	void Start () {

		/*//Creacion de objeto vacio con el nombre "Sol"
		sol = new GameObject ("Sol");
		//Translacion de la poscion de 0, 0, 0 a 0, 0, -5
		sol.GetComponent<Transform> ().Translate (0f, 0f, -5f);
		//Rotacion de 0, 0, 0, a 50, 330, 0
		sol.GetComponent<Transform> ().Rotate (50f, 330f, 0.0f);
		//Insercion de propiedades luminosas al objeto
		//Guardar un puntero a la propiedad luminosa en el objeto
		luzSolar = sol.AddComponent<Light> ();
		//Cambiar el tipo de luz, por defecto Puntual a Direccional
		luzSolar.type = LightType.Directional;*/

		//Localizacion del objeto ya creado con nombre "Cube" a la variable cubo
		cubo = GameObject.Find ("Cube");
		//Translacion del objeto a la posicion 0, 0, -5
		cubo.GetComponent<Transform> ().Translate (0f, 0f, -5f);
		//Inserccion de una fuente de audio al objeto cubo
		//Puntero a la fuente de audio de cubo
		sonido = cubo.AddComponent<AudioSource> ();
		//Asignacion del audio seleccionado anteriormente a la fuente
		sonido.clip = Resources.Load<AudioClip> ("Audio/Sound1");
		//Ejecucion del audio
		sonido.Play ();
	}

	// Update is called once per frame
	void Update () {
		//Deteccion de si es pulsada la barra espaciadora
		if (Input.GetKeyDown (KeyCode.Space)) 
		{
			//Si el audio se esta reproduciendo
			if(sonido.isPlaying)
				//Pausar la reproduccion
				sonido.Pause();
			else
				//Reproducir audio
				sonido.Play();
		}
	}
}