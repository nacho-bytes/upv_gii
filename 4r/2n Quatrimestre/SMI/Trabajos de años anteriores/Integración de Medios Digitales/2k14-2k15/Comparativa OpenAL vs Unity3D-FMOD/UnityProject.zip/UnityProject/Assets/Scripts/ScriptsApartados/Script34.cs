﻿using UnityEngine;
using System.Collections;

public class Script34 : MonoBehaviour {

	public int position = 0;
	public int samplerate = 44100;
	public float frequency = 440;
	private AudioClip simple;
	private AudioSource fuente;

	private GameObject cubo;
	// Use this for initialization
	void Start () {		
		//Localizacion del objeto ya creado con nombre "Cube" a la variable cubo
		cubo = GameObject.Find ("Cube");
		//Translacion del objeto a la posicion 0, 0, -5
		cubo.GetComponent<Transform> ().Translate (0f, 0f, -5f);

		//Inicializacion del clip
		simple = AudioClip.Create ("Simple", samplerate * 2, 1, samplerate, true, OnAudioRead);

		//Inserccion de una fuente de audio al objeto cubo
		//Puntero a la fuente de audio de cubo
		fuente = cubo.AddComponent<AudioSource> ();

		fuente.clip = simple;
	}

	void OnAudioRead(float[] data)
	{
		int count = 0;
		while (count < data.Length) 
		{
			data[count] = Mathf.Sign(Mathf.Sin(2 * Mathf.PI * frequency * position / samplerate));
			position++;
			count++;
		}
	}

	// Update is called once per frame
	void Update () {
		//Deteccion de si es pulsada la barra espaciadora
		if(Input.GetKeyDown(KeyCode.Alpha1) || Input.GetKeyDown(KeyCode.Keypad1))
		{
			frequency = 262;
			fuente.Play();
		}
		if(Input.GetKeyDown(KeyCode.Alpha2) || Input.GetKeyDown(KeyCode.Keypad2))
		{
			frequency = 294;
			fuente.Play();
		}
		if(Input.GetKeyDown(KeyCode.Alpha3) || Input.GetKeyDown(KeyCode.Keypad3))
		{
			frequency = 330;
			fuente.Play();
		}
		if(Input.GetKeyDown(KeyCode.Alpha4) || Input.GetKeyDown(KeyCode.Keypad4))
		{
			frequency = 349;
			fuente.Play();
		}
		if(Input.GetKeyDown(KeyCode.Alpha5) || Input.GetKeyDown(KeyCode.Keypad5))
		{
			frequency = 392;
			fuente.Play();
		}
		if(Input.GetKeyDown(KeyCode.Alpha6) || Input.GetKeyDown(KeyCode.Keypad6))
		{
			frequency = 415;
			fuente.Play();
		}
		if(Input.GetKeyDown(KeyCode.Alpha7) || Input.GetKeyDown(KeyCode.Keypad7))
		{
			frequency = 440;
			fuente.Play();
		}
		if(Input.GetKeyDown(KeyCode.Alpha8) || Input.GetKeyDown(KeyCode.Keypad8))
		{
			frequency = 494;
			fuente.Play();
		}

	}
}