﻿using UnityEngine;
using System.Collections;

public class SoundMaster : MonoBehaviour {
	AudioSource red, green , blue;
	// Use this for initialization
	void Start () {
		red = GameObject.Find ("Red").GetComponent<AudioSource> ();
		green = GameObject.Find ("Green").GetComponent<AudioSource> ();
		blue = GameObject.Find ("Blue").GetComponent<AudioSource> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.Alpha1) || Input.GetKeyDown (KeyCode.Keypad1))
			if (green.isPlaying)
				green.Stop ();
			else
				green.Play ();

		if (Input.GetKeyDown (KeyCode.Alpha2) || Input.GetKeyDown (KeyCode.Keypad2))
			if (blue.isPlaying)
				blue.Stop ();
			else
				blue.Play ();

		if (Input.GetKeyDown (KeyCode.Alpha3) || Input.GetKeyDown (KeyCode.Keypad3))
			if (red.isPlaying)
				red.Stop ();
		else
			red.Play ();
	}
}
