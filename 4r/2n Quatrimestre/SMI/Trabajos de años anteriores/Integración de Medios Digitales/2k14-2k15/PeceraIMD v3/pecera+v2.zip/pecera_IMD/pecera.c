//
//  pecera.c
//  pecera_IMD
//
//  Created by Isa on 13/03/15.
//  Copyright (c) 2015 Isa. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GLUT/glut.h>
#include <OpenGL/gl.h>
#include "pecera.h"
#include "detectarCara.h"
//#include "sonidoBubble.h"

int alto, ancho, fish_num = 0, bubble = 0, drawMedBubble = 1, drawSmaBubble = 1, drawPez = 1, provisional = 0, visualizar = 0, sonido = 0, mover = 0, cor = 0;
double x_fish1=0, y_fish1=0, z_fish1=0, x_fish2=0, y_fish2=0, z_fish2=0, x_fish3=0, y_fish3=0, z_fish3=0, y_bubblem=0, y_bubbles=0, z_bubblem=0, z_bubbles=0, y_meal=0, X1 = 0, Y1 = 0, x1 = 0, y_nueva=0, u = 0, w = 0;
static GLuint fish_1, fish_2, fish_3, cofre, coral, fondo, burbuja;


void cargarTexturas(){
    // Texturas pez tipo 1
    glGenTextures(1, &fish_1);
    glBindTexture(GL_TEXTURE_2D, fish_1);
    loadImageFile("imagenes/fish1_black.png");
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    
    // Texturas pez tipo 2
    glGenTextures(1, &fish_2);
    glBindTexture(GL_TEXTURE_2D, fish_2);
    loadImageFile("imagenes/fish2.png");
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    
    // Texturas pez tipo 3
    glGenTextures(1, &fish_3);
    glBindTexture(GL_TEXTURE_2D, fish_3);
    loadImageFile("imagenes/fish3.png");
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    
    // Textura cofre
    glGenTextures(1, &cofre);
    glBindTexture(GL_TEXTURE_2D, cofre);
    loadImageFile("imagenes/Cofre.png");
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    
    // Textura coral
    glGenTextures(1, &coral);
    glBindTexture(GL_TEXTURE_2D, coral);
    loadImageFile("imagenes/Coral.png");
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    
    // Textura burbuja
    glGenTextures(1, &burbuja);
    glBindTexture(GL_TEXTURE_2D, burbuja);
    loadImageFile("imagenes/burbuja.png");
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    
    glGenTextures(1, &fondo);
    glBindTexture(GL_TEXTURE_2D, fondo);
    loadImageFile("imagenes/fondo.jpeg");
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glEnable(GL_TEXTURE_2D);
}

void Init(){    
    // Color de borrado
    glClearColor(1.0, 1.0, 1.0, 1.0);
    // Habilitar la visibilidad (z-buffer)
    glEnable(GL_DEPTH_TEST);
    
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    
    // Texturas
    cargarTexturas();
}

void drawFish1(){
    glBindTexture(GL_TEXTURE_2D, fish_1);
    glPushAttrib(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
        glTexCoord2d(0,0);
        glVertex3f(-6, -8, -1.0);
        glTexCoord2d(0, 1);
        glVertex3f(-6, -5, -1.0);
        glTexCoord2d(1,1);
        glVertex3f(-2, -5, -1.0);
        glTexCoord2d(1,0);
        glVertex3f(-2, -8, -1.0);
    glEnd();
    glPopAttrib();
}

void drawFish2(){
    glBindTexture(GL_TEXTURE_2D, fish_2);
    glPushAttrib(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
        glTexCoord2d(0,0);
        glVertex3f(-1.0, 3.0, -3.0);
        glTexCoord2d(0, 1);
        glVertex3f(-1.0, 7.0, -3.0);
        glTexCoord2d(1,1);
        glVertex3f(5.0, 7.0, -2.0);
        glTexCoord2d(1,0);
        glVertex3f(5.0, 3.0, -2.0);
    glEnd();
    glPopAttrib();
}

void drawFish3(){
    glBindTexture(GL_TEXTURE_2D, fish_3);
    glPushAttrib(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
        glTexCoord2d(0,0);
        glVertex3f(6, -9, -8);
        glTexCoord2d(0,1);
        glVertex3f(6, -1, -8);
        glTexCoord2d(1,1);
        glVertex3f(16, -1, -8);
        glTexCoord2d(1,0);
        glVertex3f(16, -9, -8);
    glEnd();
    glPopAttrib();
}

void drawFish(){    
    if(fish_num < 15){
        // Añadir un pez al azar
        int x = rand () % (20-1+1) + 1;
        if(x <= 12){
            drawFish1();
            printf("Dibujando pez pequeño\n");
            fish_num = fish_num + 1;
        }else if(x <= 18){
            drawFish2();
            printf("Dibujando pez mediano\n");
            fish_num = fish_num + 1;
        }else{
            drawFish3();
            printf("Dibujando pez grande\n");
            fish_num = fish_num + 1;
        }
    }else{
        printf("Has alcanzado el número máximo de peces en la pecera = %d\n", fish_num);
    }
    glutPostRedisplay();
}

void drawMediumBubble(){
    glBindTexture(GL_TEXTURE_2D, burbuja);
    glBegin(GL_QUADS);
        glTexCoord2d(0,0);
        glVertex3f(30, -15, -4);
        glTexCoord2d(0,1);
        glVertex3f(30, -11, -4);
        glTexCoord2d(1,1);
        glVertex3f(34, -11, -4);
        glTexCoord2d(1,0);
        glVertex3f(34, -15, -4);
    glEnd();
}

void drawSmallBubble(){
    glBindTexture(GL_TEXTURE_2D, burbuja);
    glBegin(GL_QUADS);
        glTexCoord2d(0,0);
        glVertex3f(30, -16, -3);
        glTexCoord2d(0,1);
        glVertex3f(30, -18, -3);
        glTexCoord2d(1,1);
        glVertex3f(32, -18, -3);
        glTexCoord2d(1,0);
        glVertex3f(32, -16, -3);
    glEnd();
}

void drawBubble(){
    if(bubble <= 20){
        int x = rand() % 11;
        // dibujar burbuja random
        if(x <= 5){
            drawSmallBubble();
            printf("Dibujando burbuja pequeña\n");
            bubble = bubble + 1;
        }else{
            drawMediumBubble();
            printf("Dibujando burbuja mediana\n");
            bubble = bubble + 1;
        }
    }else{
        printf("Demasiadas burbujas en la pecera\n");
    }
    
    glutPostRedisplay();
}

void drawMeal(GLint x, GLint y){
    // Dibujar papelitos comida peces + movimiento
    glPushAttrib(GL_COLOR_BUFFER_BIT);
    glPushMatrix();
        glColor4f(1.0, 1.0, 1.0, 1.0);
        glBegin(GL_TRIANGLES);
            glVertex3f(x, y, -5);
            glVertex3f(x - 3, y - 2, -5);
            glVertex3f(x + 1, y - 4, -4);
        glEnd();
    glPopMatrix();
    glPopAttrib();
}

void drawChest(){
    // Dibujar cofre
    glBindTexture(GL_TEXTURE_2D, cofre);
    glBegin(GL_POLYGON);
        glTexCoord2d(1, 1);
        glVertex3f(-20.0, -17.0, -6.0);
        glTexCoord2d(1, 0);
        glVertex3f(-20.0, -22.0, -6.0);
        glTexCoord2d(0, 0);
        glVertex3f(-30.0, -22.0, -6.0);
        glTexCoord2d(0, 1);
        glVertex3f(-30.0, -17.0, -6.0);
    glEnd();
}

void drawCoral(){
    // Dibujar coral
    glBindTexture(GL_TEXTURE_2D, coral);
    for(cor = 0; cor < 77; cor = cor+5){
        glBegin(GL_POLYGON);
            glTexCoord2d(1, 1);
            glVertex3f(-35.0+cor, -17.0, -6.0);
            glTexCoord2d(1, 0);
            glVertex3f(-35.0+cor, -22.0, -6.0);
            glTexCoord2d(0, 0);
            glVertex3f(-30.0+cor, -22.0, -6.0);
            glTexCoord2d(0, 1);
            glVertex3f(-30.0+cor, -17.0, -6.0);
        glEnd();
    }
}

void pecesCerca(int x, int y){
    // los peces se acerca a la zona donde se ha clickado
    mover = 1;
    drawPez = 0;
    if(u+x_fish1-2 != x){
        if(u < x){
            u = u + 1;
        }else{
            u = u - 1;
        }
    }
    if(w != y){
        if(w < y){
            w = w + 1;
        }else{
            w = w - 1;
        }
    }
    printf("u: %f, w: %f\n", u, w);
    glutPostRedisplay();
}

void pecesAsustados(){
    // los peces se alejan hacia el fondo de la pecera
    printf("Los peces se han asustado\n");
    drawPez = 0;
    
    glutPostRedisplay();
    
}

void pecesComen(int x, int y){
    // igual que pecesCerca pero con una z negativa porque están dentro de la pecera
    printf("Damos de comer a los peces\n");
    
    
    
}

void display(){
    /*  clear all pixels  */
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    // Seleccionar la matrix del modelo
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    // Situo y oriento la camara
    gluLookAt(	0, 0, 20 /* ojo */,
              0.0, 0.0, 0.0 /* punto al que miro */,
              0.0, 1.0, 0.0 /* vertical subjetiva */);
    
    glBindTexture(GL_TEXTURE_2D, fondo);
    texturarFondo();
    
    if(drawPez){
        glPushMatrix();
            glTranslatef(x_fish1, 0, 0);
            drawFish1();
        glPopMatrix();

        glPushMatrix();
            glTranslatef(x_fish2, 0, 0);
            drawFish2();
        glPopMatrix();
    
        glPushMatrix();
            glTranslatef(x_fish3, 0, 0);
            drawFish3();
        glPopMatrix();
    }
    
    drawChest();
    drawCoral();
    
    
    if (drawMedBubble){
        glPushMatrix();
            glTranslatef(0, y_bubblem, 0);
            drawMediumBubble();
        glPopMatrix();
    }
    if (drawSmaBubble){
        glPushMatrix();
            glTranslatef(0, y_bubbles, 0);
            drawSmallBubble();
        glPopMatrix();
    }
    
    if(provisional){
        detectarCara(visualizar);
        if(prox > 500){
            pecesAsustados();
            printf("Has asustado a los peces, por favor, aléjate");
        }
    }
    
    if(mover){
        glPushMatrix();
            glTranslatef(u+x_fish1, 0, 0);
            glTranslatef(0, w, 0);
            drawFish1();
        glPopMatrix();
        glPushMatrix();
            glTranslatef(u+x_fish2, 0, 0);
            glTranslatef(0, w, 0);
            drawFish2();
        glPopMatrix();
        glPushMatrix();
            glTranslatef(u+x_fish3, 0, 0);
            glTranslatef(0, w, 0);
            drawFish3();
        glPopMatrix();
    }
    
    if(sonido){
        printf("Activamos el sonido");
        //bubbleSound();
    }
    glutSwapBuffers();
}


void reshape(int w, int h){
    // Definir el marco
    glViewport(0, 0, w, h);
    
    // Configurar la c·mara
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    
    ancho = glutGet(GLUT_WINDOW_WIDTH);
    alto = glutGet(GLUT_WINDOW_HEIGHT);
    
    // Mantener la isotopria
    float razon = (float)w/h;
    
    // Camara Perspectiva
    gluPerspective(90/*fovy*/, razon/*razÛn de aspecto*/, 0.1, 1000);
}

void onKey(unsigned char key, int x, int y){
    switch (key) {
        case 27:           /* Esc, q, Q will quit */
            printf("Exit\n");
            exit(0);
            break;
        case 'q':
        case 'Q':
            printf("Exit\n");
            exit(0);
            break;
        case 'a':
        case 'A':
            drawFish1();
            break;
    }
    
    // Algo ha cambiado y hay que redibujar
    glutPostRedisplay();
}

void onMenu(int value){
    switch (value){
        case 1:
            drawFish();
            break;
        case 2:
            drawBubble();
            break;
        case 3:
            provisional = 0;
            break;
            
        case 4:
            visualizar = 1;
            break;
        case 5:
            exit(0);
            break;
    }
}

void mouse(int button, int state, int x, int y){
    ancho = glutGet(GLUT_WINDOW_WIDTH);
    alto = glutGet(GLUT_WINDOW_HEIGHT);
    double X = 77.0;
    double Y = 52.0;
    X1 = ancho/X;
    Y1 = alto/Y;
    if(state == GLUT_DOWN){
        if(button == GLUT_LEFT_BUTTON){
            x1 = ((x- (ancho/2)) / X1);
            y_nueva = -((y- (alto/2)) / Y1);
            printf("Coordenadas: x:%f, y:%f\n", x1, y_nueva);
            if(y < 0.05*alto){ // Si el ratón arriba de la pantalla, dar de comer a los peces
                pecesComen(x, y_nueva);
                drawMeal(x,y_nueva);
                // Hay problemas porque es una función temporal y s destruye todo cuando acaba el click
            }else{
                pecesCerca(x, y_nueva);
            }
        }
    }
    glutPostRedisplay();
}


void onSpecialUp(int tecla, int x, int y){
    if(tecla == GLUT_KEY_UP){
        printf("Se ha dibujado un pez nuevo");
        drawFish();
    }
    
    glutPostRedisplay();
}

void update(){
    
    if(drawSmaBubble == 0){
        drawSmaBubble = 1;
    }
    
    if(drawMedBubble == 0){
        drawMedBubble = 1;
    }
    
    int fovy = 90;

    // Actualizamos la x, y y la z de los translate peces
    if(x_fish1 > -60){
        x_fish1 = x_fish1 - 0.4;
    }else{
        x_fish1 = 1+fovy/2;
    }
    if(x_fish2 < 60){
        x_fish2 = x_fish2 + 0.3;
    }else{
        x_fish2 = -5-fovy/2;
    }
    if(x_fish3 > -60){
        x_fish3 = x_fish3 - 0.2;
    }else{
        x_fish3 = 6+fovy/2;
    }
    if(y_bubblem < 40){
        y_bubblem = y_bubblem + 0.2;
        z_bubblem = -3;
    }else{
        y_bubblem = 0;
        z_bubblem = -3;
    }
    if(y_bubbles < 40){
        y_bubbles = y_bubbles + 0.4;
        z_bubbles = -3;
    }else{
        y_bubbles = 0;
        z_bubblem = -3;
    }
    
    if(y_meal > 30){
        y_meal = y_meal - 0.2;
        //drawMeal();
    }
    
    if(x_fish1-6 > 12 && x_fish1-6 < 16){
        if(x_fish1-6 < 16 && y_bubblem-11 > -8 && y_bubblem-11 < -5){
            printf("Colision entre pez1 y burbuja mediana\n");
            printf("valor de x_fish1: %f\n", x_fish1-16);
            printf("valor de y_bubblem: %f\n", y_bubblem-11);
            y_bubblem = 0;
            drawMedBubble = 0;
        }
        if(x_fish1-6 < 14 && y_bubbles-16 > -8 && y_bubbles-16 < -5){
            printf("Colision entre pez1 y burbuja pequeña\n");
            printf("valor de x_fish1: %f\n", x_fish1-16);
            printf("valor de y_bubbles: %f\n", y_bubbles-16);
            y_bubbles = 0;
            drawSmaBubble = 0;
        }
    }
    
    if(x_fish2+5 > 30 && x_fish2+5 < 34){
        if(x_fish2+5 < 34 && y_bubblem-11 > 3 && y_bubblem-11 < 7){
            printf("Colision entre pez2 y burbuja mediana\n");
            printf("valor de x_fish2: %f\n", x_fish2+5);
            printf("valor de y_bubblem: %f\n", y_bubblem-11);
            y_bubblem = 0;
            drawMedBubble = 0;
        }
        
        if(x_fish2+5 < 32 && y_bubbles-16 > 3 && y_bubbles-16 < 7){
            printf("Colision entre pez2 y burbuja pequeña\n");
            printf("valor de x_fish2: %f\n", x_fish2+5);
            printf("valor de y_bubblem: %f\n", y_bubblem-16);
            y_bubbles = 0;
            drawSmaBubble = 0;
        }
    }
    
    if(x_fish3+6 > 21 && x_fish3+6 < 25){
        if(x_fish3+6 < 23 && y_bubbles-16 > -9 && y_bubbles-16 < -1){
            printf("Colision entre pez3 y burbuja pequeña\n");
            printf("valor de x_fish3: %f\n", x_fish3+6);
            printf("valor de y_bubbles: %f\n", y_bubbles-16);
            y_bubbles = 0;
            drawSmaBubble = 0;
        }
        if(x_fish3+6 < 25 && y_bubblem-11 > -9 && y_bubblem-11 < -1){
            printf("Colision entre pez3 y burbuja mediana\n");
            printf("valor de x_fish3: %f\n", x_fish3+6);
            printf("valor de y_bubbles: %f\n", y_bubblem-11);
            y_bubblem = 0;
            drawMedBubble = 0;
        }
    }
    // Mandar el evento de display
    glutPostRedisplay();
}

int main(int argc, char **argv){
    FreeImage_Initialise(0);
    
    // Inicializar la glut y los buffers
    glutInit(&argc, argv);
    // Inicializar alut
    //alutInit(&argc, argv);
    
    // Frame buffer doble y z-buffer
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    
    // Construir la ventana
    //glutInitWindowSize(600, 600);
    //glutPositionWindow(20,20);
    glutCreateWindow("Pecera");
    glutFullScreen();
    
    Init();
    InitAlut();

    
    // Registro de callbacks
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutSpecialFunc(onSpecialUp);
    glutKeyboardFunc(onKey);
    glutMouseFunc(mouse);
    glutIdleFunc(update);
    
    // Crear un menu
    glutCreateMenu(onMenu);
    glutAddMenuEntry("Add Fish", 1);
    glutAddMenuEntry("Add bubbles", 2);
    glutAddMenuEntry("Usar OpenCV (No disponible)", 3);
    glutAddMenuEntry("Ver ventana camara", 4);
    glutAddMenuEntry("Quit", 5);
    glutAttachMenu(GLUT_RIGHT_BUTTON);
    
    
    
    // Poner en marcha el bucle de eventos
    glutMainLoop();
    
    FreeImage_DeInitialise();
    
    return 0;
}
