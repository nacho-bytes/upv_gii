//
//  detectarCara.h
//  pecera_IMD
//
//  Created by Isa on 08/04/15.
//  Copyright (c) 2015 Isa. All rights reserved.
//

#include "cv.h"
#include "highgui.h"
#include "types_c.h"
#include "core_c.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static CvHaarClassifierCascade* cascade = 0;
const char* cascade_name ="haarcascade_frontalface_alt.xml";
CvRect rect,rect2 ;
CvPoint pt1, pt2;
IplImage *imgOrg;

int  i, j, scale, prox, width, height;

// memoria para calculos
static CvMemStorage* storage0 = 0;

// Metodo para detectar cara
void detectarCara(int visualizar){
    // Estructura per agafar video
    CvCapture* capture = 0;
    
    // Carrega l'arxiu HaarClassifierCascade
    cascade = (CvHaarClassifierCascade*)cvLoad(cascade_name, 0, 0, 0);
    
    // Comprova si s'ha carregat, sino mostra per pantalla l'error de que no ix el video
    if( !cascade)
    {
        fprintf( stderr, "ERROR: No se ha podido cargar\n" );
    }
    
    // Crea una nova finestra, es diu: WebCam
    cvNamedWindow( "WebCam", 1 );
    
    // Comprovem si pot obrir la webcam, sino ix l'error.

    capture = cvCaptureFromCAM(0); // extraer al programa principal
    /*if (!capture){
        capture = cvCaptureFromCAM(1);*/
    if (!capture){
        fprintf(stderr, "No se puede abrir la webcam!\n");
    }else{
        imgOrg = cvQueryFrame(capture);
        
        if(visualizar){
            cvShowImage("WebCam", imgOrg);
        }
    }
    //}
    
    
    if(cascade){
        CvSeq* faces = cvHaarDetectObjects(imgOrg, cascade, storage0, 1.1, 2, CV_HAAR_DO_CANNY_PRUNING, cvSize(10, 10), cvSize(40, 40));
        //printf("Caras detectadas: %d\n", faces->total);
        
        for( j = 0; j < (faces ? faces->total : 0); j++ ){
            // Crea un rectangulo para dibujar la cara
            CvRect* r = (CvRect*)cvGetSeqElem( faces, j );
            
            // Dimensiones del rectangulo, escalado y calculo de proximidad
            pt1.x = r->x*scale;
            pt2.x = (r->x+r->width)*scale;
            pt1.y = r->y*scale;
            pt2.y = (r->y+r->height)*scale;
            width = abs( pt2.x-pt1.x);
            height = abs(pt2.y-pt1.y);
            prox = width+height;
            
            cvRectangle( imgOrg, pt1, pt2, CV_RGB(255,0,0), 3, 8, 0 );
        }
    }
}