//
//  pecera.h
//  pecera_IMD
//
//  Created by Isa on 13/03/15.
//  Copyright (c) 2015 Isa. All rights reserved.
//

#include "FreeImage.h"

void loadImageFile(char* nombre){
    // Detecci�n del formato, lectura y conversion a BGRA
    FREE_IMAGE_FORMAT formato = FreeImage_GetFileType(nombre,0);
    FIBITMAP* imagen = FreeImage_Load(formato, nombre,0);
    if(imagen==NULL) printf("Error al cargar la imagen\n");
    FIBITMAP* imagen32b = FreeImage_ConvertTo32Bits(imagen);
    
    // Lectura de dimensiones y colores
    int w = FreeImage_GetWidth(imagen32b);
    int h = FreeImage_GetHeight(imagen32b);
    GLubyte* texeles = FreeImage_GetBits(imagen32b);
    
    // Carga como textura actual
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_BGRA_EXT, GL_UNSIGNED_BYTE, texeles);
    
    // Liberar recursos
    FreeImage_Unload(imagen);
    FreeImage_Unload(imagen32b);
}

void texturarFondo(){
    glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT | GL_TEXTURE_BIT);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
    glDisable(GL_TEXTURE_GEN_S);
    glDisable(GL_TEXTURE_GEN_T);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);		//Texel menor que pixel
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);		//Texel mayor que pixel
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);			//La textura se repite en abcisas
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);			//La textura se repite en ordenadas
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);				//Asigna solo el color de la textura al fragmento
    
    //Cargar el fondo con la textura corriente
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glOrtho(-1,1,-1,1,-10,10);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glBegin(GL_POLYGON);
    glTexCoord2f(0,0);
    glVertex3f(-1,-1,0);
    glTexCoord2f(1,0);
    glVertex3f(1,-1,0);
    glTexCoord2f(1,1);
    glVertex3f(1,1,0);
    glTexCoord2f(0,1);
    glVertex3f(-1,1,0);
    glEnd();
    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    
    glPopAttrib();
}






