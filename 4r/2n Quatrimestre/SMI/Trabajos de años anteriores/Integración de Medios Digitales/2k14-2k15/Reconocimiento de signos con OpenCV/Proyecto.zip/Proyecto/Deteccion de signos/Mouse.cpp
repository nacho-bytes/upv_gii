#include "Mouse.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

//Se definen los metods staticos de Mouse

//Mover el mouse al punto deseado en la pantalla
void Mouse::moverMouse(Point p){
	if(p.x<0) p.x=0;
	if(p.y<0) p.y=0;
	if(p.x>=Global::width_screen) p.x = Global::width_screen-1;
	if(p.y>=Global::height_screen) p.y = Global::height_screen-1;

	//Se suaviza el movimiento
	Point src;
    //GetCursorPos(&src);
	double a = (src.y-p.y)*1.0/(src.x-p.x);
	double b = src.y - a*src.x;
	
	while(src.x!=p.x || src.y!=p.y){
		if(src.x==p.x){
			if(src.y<p.y) src.y++;
			else src.y--;
		} else{
			if(src.y==p.y){
				if(src.x<p.x) src.x++;
				else src.x--;
			}else{
				if(src.x<p.x) src.x++;
				else src.x--;
				src.y = (int)(a*src.x + b);
			}
		}
                Display *displayMain = XOpenDisplay(NULL);
                if(displayMain==NULL){
                    fprintf(stderr, "Error al abrir el Display!!!\n");
                    exit(0);
                }
                XWarpPointer(displayMain, None, None, 0, 0, 0, 0, src.x, src.y);
                XCloseDisplay(displayMain);
		//SetCursorPos(src.x, src.y);
		sleep(DELTA);
	}
}
//Mover el mouse con un desplazamiento relativo
void Mouse::moverMouse(int dx, int dy){
	//Point cursor;//320-240 = 640-400
    //GetCursorPos(&cursor);
        //Adapta el punto del frame al de la pantalla
	Point src = Point(0, 0);
	src.x += sensibilidad_mouse*dx*Global::width_screen/Global::width_frame;
	src.y += sensibilidad_mouse*dy*Global::height_screen/Global::height_frame;
	moverMouse(src);
    
        
}
//Click izquierdo
void Mouse::clickLeft(){
	//mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, GetMessageExtraInfo());
	//mouse_event(MOUSEEVENTF_LEFTUP,   0, 0, 0, GetMessageExtraInfo());
}
//Mover al punto y Click izquierdo
void Mouse::clickLeft(Point p){
	moverMouse(p);
	clickLeft();
}
//Click Derecho
void Mouse::clickRight(){
	//mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, GetMessageExtraInfo());
	//mouse_event(MOUSEEVENTF_RIGHTUP,   0, 0, 0, GetMessageExtraInfo());
}
//Mover al punto y Click Derecho
void Mouse::clickRight(Point p){
	moverMouse(p);
	clickRight();
}

//CLick Izquierdo Sostenido
void Mouse::clickLeftSostenido(bool &isClicked){
	if(isClicked==false) 
	{
		//mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, GetMessageExtraInfo());
		isClicked=true;
	}
	else 
		{
		//mouse_event(MOUSEEVENTF_LEFTUP,   0, 0, 0, GetMessageExtraInfo());
		isClicked=false;	
	}
}
//Doble CLick 
void Mouse::doubleClick(){
	//UINT doubleClickTime = GetDoubleClickTime();
	//SetDoubleClickTime(1);
	clickLeft();
	clickLeft();
	//SetDoubleClickTime(doubleClickTime);
}