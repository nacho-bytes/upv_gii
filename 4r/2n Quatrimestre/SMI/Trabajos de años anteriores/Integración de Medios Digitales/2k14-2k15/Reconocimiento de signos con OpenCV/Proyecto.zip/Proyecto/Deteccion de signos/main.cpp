#include "Global.h"
#include "Mouse.h"
#include "Camera.h"
#include "ImageProcessing.h"
#include "HandProcessing.h"
#include <opencv2/opencv.hpp>
#include <stdlib.h>
#include <AL/alut.h>
#include <stdio.h>
#include <GL/glut.h>



Mat frame, fondo;

int main(int argc, const char **argv){
	//Se accede a la camara y se configura
	Camera cam = Camera();
  
	//Captura el fondo
	while(true){
		cam.getFrame(frame);
                if(frame.empty()){return -1;}
                flip(frame, fondo, 1);
                putText(fondo, "SE VA A PROCEDER A CAPTURA DE FONDO", Point(25,380), 20, 0.8, CV_RGB(0,0,0));
                putText(fondo, "POR FAVOR APARTESE DE LA CAMARA", Point(60,420), 20, 0.8, CV_RGB(0,0,0));
                putText(fondo, "PRESIONE LA TECLA         PARA CAPTURAR", Point(8,460), 20, 0.8, CV_RGB(0,0,0));
                putText(fondo, "                  SPACE               ", Point(8,460), 20, 1, CV_RGB(255,0,0));
                imshow("bgd", fondo);
		if(waitKey(30) == 32) break; //Si una tecla se presiona se sale del loop
	}
	
	
    ALuint buffer[5], fuente;
    alutInit (0, NULL);
  buffer[0] = alutCreateBufferFromFile( "A.wav");
  buffer[1] = alutCreateBufferFromFile( "B.wav" );
  buffer[2] = alutCreateBufferFromFile( "C.wav" );
  buffer[3] = alutCreateBufferFromFile( "D.wav" );
  buffer[4] = alutCreateBufferFromFile( "E.wav" );
    /*buffer[0] = alutCreateBufferWaveform(ALUT_WAVEFORM_SAWTOOTH, 262.0, 0.0, 1.0);
    buffer[1] = alutCreateBufferWaveform(ALUT_WAVEFORM_SAWTOOTH, 294.0, 0.0, 1.0);
    buffer[2] = alutCreateBufferWaveform(ALUT_WAVEFORM_SAWTOOTH, 330.0, 0.0, 1.0);
    buffer[3] = alutCreateBufferWaveform(ALUT_WAVEFORM_SAWTOOTH, 349.0, 0.0, 1.0);
    buffer[4] = alutCreateBufferWaveform(ALUT_WAVEFORM_SAWTOOTH, 392.0, 0.0, 1.0);*/
    alGenSources (1, &fuente);
	//Elimina ruido del fondo y suaviza la imagen
	blur(fondo, fondo, Size(3,3));
	destroyWindow("bgd");

	ImageProcessing imageProcessing = ImageProcessing();
	imageProcessing.setBackground(fondo);

	HandProcessing handProcessing = HandProcessing();
	//Variables Necesarias para las acciones detectadas, y para la imagen a mostar al usuario
	int countIzq=0,countDer=0,countDouble=0,countSostenido=0;
	bool isClicked=false;
	Mat imagen;
	//Loop principal
	while(true){
		cam.getFrame(frame);
                flip(frame, frame, 1);
                putText(frame, "Tecla ESC para salir", Point(8,460), 20, 0.8, CV_RGB(0,0,0));
		blur(frame, frame, Size(3,3));//Elimina ruido del fondo y suaviza la imagen
		
		Hand aux = imageProcessing.detectHand(frame);
		aux.draw(frame);
		
		//Guardamos los dedos detectados	
		vector<Point> fingersAux = aux.getFingers();
		//if((int)fingersAux.size()!=5) {int num=(int)fingersAux.size(); printf("%d",num);}
		
		if((int)fingersAux.size()==1){alSourcei(fuente, AL_BUFFER, buffer[0]);countSostenido++;}
		else countSostenido=0;
		
		//Aumenta el contador para hacer double click si detecta 2 dedos
		if((int)fingersAux.size()==2){alSourcei(fuente, AL_BUFFER, buffer[1]);countSostenido++;}
		else countSostenido=0;
		
		//Aumenta el contador para hacer click derecho si detecta 3 dedos
		if((int)fingersAux.size()==3){alSourcei(fuente, AL_BUFFER, buffer[2]); countDer++;}
		else countDer=0;
		
		//Aumenta el contador para hacer double click si detecta 4 dedos
		if((int)fingersAux.size()==4){alSourcei(fuente, AL_BUFFER, buffer[3]); countDouble++;}
		else countDouble=0;
		
		//Aumenta el contador para hacer click izquierdo si detecta 5 dedos
		if((int)fingersAux.size()==5) {alSourcei(fuente, AL_BUFFER, buffer[4]); countIzq++;}
		else countIzq=0;
		
		//if((int)fingersAux.size()==0) alSourcei(fuente, AL_BUFFER, buffer[0]);
		

		//Halla la imagen segun los dedos detectados en el frame actual
		imagen = imageProcessing.findInterfaceImage((int)fingersAux.size(),imageProcessing);
		
		//Muestra la ventana con la imagen segun la cantidad de dedos detectada, y la fija a la parte superior izquierda de la pantalla
		imshow("Dedos",imagen);
		//HWND ventana = FindWindow(NULL,L"Dedos");
		//SetWindowPos(ventana,HWND_TOPMOST,0,0,0,0,0x0040 | 0x10 |0x1);
		//Muestra la ventana con la imagen de lo que esta detectando y la fija a la parte inferior derecha de la pantalla
		imshow("Deteccion", frame);
		//HWND ventana2 = FindWindow(NULL,L"Deteccion");
		//SetWindowPos(ventana2,HWND_TOPMOST,Global::width_screen-Global::width_frame,Global::height_screen-(Global::height_frame+50),0,0,0x0040 | 0x10 |0x1);
		//Procesa la Mano
		alSourcePlay (fuente);
		alutSleep (1);
		handProcessing.process(aux,countIzq,countDer,countDouble,countSostenido,isClicked);
		if(waitKey(30) == 27) break;//Si una tecla se presiona se sale del loop
	}
	
		
	alDeleteBuffers(5, buffer);
	alutExit ();
	//Libera Memoria
	frame.release();
	cam.~Camera();
	imageProcessing.~ImageProcessing();
	handProcessing.~HandProcessing();
	destroyAllWindows();
	return 0;
}