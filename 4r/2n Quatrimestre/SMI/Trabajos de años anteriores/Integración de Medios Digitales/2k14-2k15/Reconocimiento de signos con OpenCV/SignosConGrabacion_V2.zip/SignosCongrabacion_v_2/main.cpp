#include "Global.h"
#include "Camera.h"
#include "ImageProcessing.h"
#include <opencv2/opencv.hpp>
#include <stdlib.h>
#include <AL/alut.h>
#include <stdio.h>
#include <GL/glut.h>
#include <iostream>
#include <string>

Mat frame, fondo;

int main(int argc, const char **argv){
	//Se accede a la camara y se configura
	Camera cam = Camera();
  
	//Captura el fondo
	while(true){
		cam.getFrame(frame);
                if(frame.empty()){return -1;}
                flip(frame, fondo, 1);
                putText(fondo, "SE VA A PROCEDER A CAPTURA DE FONDO", Point(25,380), 20, 0.8, CV_RGB(0,0,0));
                putText(fondo, "POR FAVOR APARTESE DE LA CAMARA", Point(60,420), 20, 0.8, CV_RGB(0,0,0));
                putText(fondo, "PRESIONE LA TECLA         PARA CAPTURAR", Point(8,460), 20, 0.8, CV_RGB(0,0,0));
                putText(fondo, "                  SPACE               ", Point(8,460), 20, 1, CV_RGB(255,0,0));
                imshow("Detectar Fondo", fondo);
		if(waitKey(30) == 32) break; //Si una tecla se presiona se sale del loop
	}
	
    ALuint buffer[27], fuente;
    alutInit (0, NULL);
    buffer[0] = alutCreateBufferFromFile( "sonidos/A.wav");
    buffer[1] = alutCreateBufferFromFile( "sonidos/B.wav" );
    buffer[2] = alutCreateBufferFromFile( "sonidos/C.wav" );
    buffer[3] = alutCreateBufferFromFile( "sonidos/D.wav" );
    buffer[4] = alutCreateBufferFromFile( "sonidos/E.wav" );
    buffer[5] = alutCreateBufferFromFile( "sonidos/F.wav" );
    buffer[6] = alutCreateBufferFromFile( "sonidos/G.wav" );
    buffer[7] = alutCreateBufferFromFile( "sonidos/H.wav" );
    buffer[8] = alutCreateBufferFromFile( "sonidos/I.wav" );
    buffer[9] = alutCreateBufferFromFile( "sonidos/J.wav" );
    buffer[10] = alutCreateBufferFromFile( "sonidos/K.wav" );
    buffer[11] = alutCreateBufferFromFile( "sonidos/L.wav" );
    buffer[12] = alutCreateBufferFromFile( "sonidos/M.wav" );
    buffer[13] = alutCreateBufferFromFile( "sonidos/N.wav" );
    buffer[14] = alutCreateBufferFromFile( "sonidos/Ñ.wav" );
    buffer[15] = alutCreateBufferFromFile( "sonidos/O.wav" );
    buffer[16] = alutCreateBufferFromFile( "sonidos/P.wav" );
    buffer[17] = alutCreateBufferFromFile( "sonidos/Q.wav" );
    buffer[18] = alutCreateBufferFromFile( "sonidos/R.wav" );
    buffer[19] = alutCreateBufferFromFile( "sonidos/S.wav" );
    buffer[20] = alutCreateBufferFromFile( "sonidos/T.wav" );
    buffer[21] = alutCreateBufferFromFile( "sonidos/U.wav" );
    buffer[22] = alutCreateBufferFromFile( "sonidos/V.wav" );
    buffer[23] = alutCreateBufferFromFile( "sonidos/W.wav" );
    buffer[24] = alutCreateBufferFromFile( "sonidos/X.wav" );
    buffer[25] = alutCreateBufferFromFile( "sonidos/Y.wav" );
    buffer[26] = alutCreateBufferFromFile( "sonidos/Z.wav" );
    
    int contFingers=0;//Variable para contar dedos.
    int  contMovs=0;//Variable para contar dedos.
    int numdedos = 0;

    alGenSources (1, &fuente);
	//Elimina ruido del fondo y suaviza la imagen
	blur(fondo, fondo, Size(3,3));
	destroyWindow("Detectar Fondo");
	ImageProcessing imageProcessing = ImageProcessing();
	imageProcessing.setBackground(fondo);

	//HandProcessing handProcessing = HandProcessing();
	//Variables Necesarias para las acciones detectadas, y para la imagen a mostar al usuario
	int countIzq=0,countDer=0,countDouble=0,countSostenido=0;
	bool isClicked=false;
	Mat imagen;
	//Loop principal
	while(true){
		cam.getFrame(frame);
                flip(frame, frame, 1);
                putText(frame, "Tecla ESC para salir", Point(8,460), 20, 0.8, CV_RGB(0,0,0));
		blur(frame, frame, Size(3,3));//Elimina ruido del fondo y suaviza la imagen
		
		Hand aux = imageProcessing.detectHand(frame);
		aux.draw(frame);
		
		//Guardamos los dedos detectados	
		vector<Point> fingersAux = aux.getFingers();
		//if((int)fingersAux.size()!=5) {int num=(int)fingersAux.size(); printf("%d",num);}
		numdedos = (int)fingersAux.size();
		//Si detectamos cero dedos decimos la letra
		if(numdedos==0){
			alSourcei(fuente, AL_BUFFER, buffer[contFingers-1]);
			//Reiniciamos contadores.
			contMovs=0;
			contFingers=0;
			
		}
		else{
		  contMovs++;
			contFingers=contFingers+numdedos;
			//Halla la imagen segun los dedos detectados en el frame actual
			imagen = imageProcessing.findInterfaceImage(numdedos,imageProcessing);
			//Muestra la ventana con la imagen segun la cantidad de dedos detectada, y la fija a la parte superior izquierda de la pantalla
			imshow("Dedos",imagen);
			//Muestra la ventana con la imagen de lo que esta detectando y la fija a la parte inferior derecha de la pantalla
			imshow("Deteccion", frame);
		}
		//Procesa la Mano
		alSourcePlay (fuente);
		alutSleep (1);	
		//handProcessing.process(aux,countIzq,countDer,countDouble,countSostenido,isClicked);
		if(waitKey(30) == 27) break;//Si una tecla se presiona se sale del loop
	}
	
		
	alDeleteBuffers(27, buffer);
	alutExit ();
	//Libera Memoria
	frame.release();
	cam.~Camera();
	imageProcessing.~ImageProcessing();
	//handProcessing.~HandProcessing();
	destroyAllWindows();
	return 0;
}