/*
* Programa diseñado para calibrar el mando de la Wii.
* Básicamente cada vez que pulsemos un cuadrado éste cambiará de color blanco a rojo
* y se encenderá un led del mando para comprobar el correcto funcionamiento.
* Al acabar de pulsar los cuatro se cierra el programa y se apagan los leds.
*
* Creado por Samuel Villaescusa Vinader IMD 2015
*/

#include <GL/gl.h>
#include <GL/glut.h>
#include <stdio.h>

#include <cwiid.h>



void display(void)
{
/*  Limpia los pixeles de la pantalla  */
    glClear (GL_COLOR_BUFFER_BIT);

/*
* Dibuja cuatro polígonos en cada esquina de la pantalla de dibujo, los cuales se usarán para calibrar el mando.
*/
    glColor3f (1.0, 1.0, 1.0);

    /*
    *Cuadrado situado en la esquina superior izquierda.
    */
    glBegin(GL_POLYGON);
        glVertex3f (0.05, 0.95, 0.0);
        glVertex3f (0.10, 0.95, 0.0);
        glVertex3f (0.10, 0.90, 0.0);
        glVertex3f (0.05, 0.90, 0.0);
    glEnd();

    /*
    *Cuadrado situado en la esquina inferior izquierda.
    */
    glBegin(GL_POLYGON);
        glVertex3f (0.05, 0.05, 0.0);
        glVertex3f (0.10, 0.05, 0.0);
        glVertex3f (0.10, 0.10, 0.0);
        glVertex3f (0.05, 0.10, 0.0);
    glEnd();

    /*
    *Cuadrado situado en la esquina inferior derecha.
    */
    glBegin(GL_POLYGON);
        glVertex3f (0.95, 0.05, 0.0);
        glVertex3f (0.90, 0.05, 0.0);
        glVertex3f (0.90, 0.10, 0.0);
        glVertex3f (0.95, 0.10, 0.0);
    glEnd();

    /*
    *Cuadrado situado en la esquina superior derecha.
    */
    glBegin(GL_POLYGON);
        glVertex3f (0.95, 0.95, 0.0);
        glVertex3f (0.90, 0.95, 0.0);
        glVertex3f (0.90, 0.90, 0.0);
        glVertex3f (0.95, 0.90, 0.0);
    glEnd();

/*  
 *  Se comienza a procesar las rutinas de openGL
 */
    glFlush ();
}

void cambiarColorIS(void) {
	
	glColor3f (1.0, 0.0, 0.0);

    glBegin(GL_POLYGON);
        glVertex3f (0.05, 0.95, 0.0);
        glVertex3f (0.10, 0.95, 0.0);
        glVertex3f (0.10, 0.90, 0.0);
        glVertex3f (0.05, 0.90, 0.0);
    glEnd();

	glFlush();

}

void cambiarColorII() {

	glColor3f (1.0, 0.0, 0.0);


    glBegin(GL_POLYGON);
        glVertex3f (0.05, 0.05, 0.0);
        glVertex3f (0.10, 0.05, 0.0);
        glVertex3f (0.10, 0.10, 0.0);
        glVertex3f (0.05, 0.10, 0.0);
    glEnd();

	glFlush();

}

void cambiarColorDS() {

    glColor3f (1.0, 0.0, 0.0);

    glBegin(GL_POLYGON);
        glVertex3f (0.95, 0.95, 0.0);
        glVertex3f (0.90, 0.95, 0.0);
        glVertex3f (0.90, 0.90, 0.0);
        glVertex3f (0.95, 0.90, 0.0);
    glEnd();

	glFlush ();

//Encendemos la tercera luz led

}

void cambiarColorDI() {

	glColor3f (1.0, 0.0, 0.0);

    glBegin(GL_POLYGON);
        glVertex3f (0.95, 0.05, 0.0);
        glVertex3f (0.90, 0.05, 0.0);
        glVertex3f (0.90, 0.10, 0.0);
        glVertex3f (0.95, 0.10, 0.0);
    glEnd();

	glFlush ();

}


/*
* Controla la pulsación del ratón sobre los distintos cuadrados.
*/
static void Mouse(int button, int state, int mouseX, int mouseY)
{
 
  if (state == GLUT_DOWN) {
	printf("Coordenada X --> %d\n", mouseX);
	printf("Coordenada Y --> %d\n", mouseY);
      if (button == GLUT_LEFT_BUTTON) {

	if(mouseX >= 50 && mouseX <= 100 && mouseY >= 37 && mouseY <= 70) {
			printf("Cuadrado izquierdo superior pulsado\n");
			glutDisplayFunc(cambiarColorIS);

		} else if(mouseX >= 900 && mouseX <= 950 && mouseY >= 37 && mouseY <= 70) {
			printf("Cuadrado derecho superior pulsado\n");
			cambiarColorDS();		

		} else if(mouseX >= 50 && mouseX <= 100 && mouseY >= 630 && mouseY <= 665 ) {
			printf("Cuadrado izquierdo inferior pulsado\n");
			cambiarColorII();

		} else if(mouseX >= 900 && mouseX <= 950 && mouseY >= 630 && mouseY <= 665 ) {
			printf("Cuadrado derecho inferior pulsado\n");
			cambiarColorDI();

		}
        
	}
      
      glutPostRedisplay();
  }
}

void init (void) 
{
/*  Limpia el color del fondo de la pantalla   */
    glClearColor (0.0, 0.0, 0.0, 0.0);

/*  Se inicializan los valores a ver en la pantalla  */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
}

/* 
 *  Se declara la inicialización del programa, en el que se carga el tamaño de la pantalla,
 *  la posición de la misma, se inicializa y se crea la pantalla y muestra los cuadrados.
 */
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (1000, 700); 
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("Calibrar Mando Wii");
    init ();
    glutMouseFunc(Mouse);
    glutDisplayFunc(display); 
    glutMainLoop();
    return 0;   /* ISO C requires main to return int. */
}
