/*
 *Programa desarrollado para probar la funcionalidad de la libreria cwiid
 * El Mando se conecta, y una vez conectado tenemos la opción de encender
 * cada uno de los leds para comprobar su funcionamiento.
 * 
 * Desarrollado por Samuel Villaescusa Vinader a partir de la libreria cwiid 
 */

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

#include <bluetooth/bluetooth.h>
#include <cwiid.h>

#define toggle_bit(bf,b)	\
	(bf) = ((bf) & b)		\
	       ? ((bf) & ~(b))	\
	       : ((bf) | (b))

#define MENU \
	"1: toggle LED 1\n" \
	"2: toggle LED 2\n" \
	"3: toggle LED 3\n" \
	"4: toggle LED 4\n" \
	"5: exit\n"

void set_led_state(cwiid_wiimote_t *wiimote, unsigned char led_state)
{
	if (cwiid_set_led(wiimote, led_state)) {
		fprintf(stderr, "Error setting LEDs \n");
	}
}


int main(int argc, char *argv[])
{
	cwiid_wiimote_t *wiimote;	/* wiimote variable para manejador. */
	struct cwiid_state state;	/* wiimote variable para el estado */
	bdaddr_t bdaddr;	/* dirección de los dispositivos bluetooth */
	unsigned char led_state = 0;
	int exit = 0;

	/* Si se le pasa directamente la dirección del mando se conecta. */
	if (argc > 1) {
		str2ba(argv[1], &bdaddr);
	}
	else {
		bdaddr = *BDADDR_ANY;
	}

	/* Función por la cual nos conectamos al dispositivo wii */
	printf("Put Wiimote in discoverable mode now (press 1+2)...\n");
	if (!(wiimote = cwiid_open(&bdaddr, 0))) {
		fprintf(stderr, "Unable to connect to wiimote\n");
		return -1;
	}

	/* Menu para encender cada uno de los leds */
	printf("%s", MENU);

	while (!exit) {
		switch (getchar()) {
		case '1':
			toggle_bit(led_state, CWIID_LED1_ON);
			set_led_state(wiimote, led_state);
			break;
		case '2':
			toggle_bit(led_state, CWIID_LED2_ON);
			set_led_state(wiimote, led_state);
			break;
		case '3':
			toggle_bit(led_state, CWIID_LED3_ON);
			set_led_state(wiimote, led_state);
			break;
		case '4':
			toggle_bit(led_state, CWIID_LED4_ON);
			set_led_state(wiimote, led_state);
			break;
		case '5':
			exit = -1;
			break;
			default: break;

	}
		
	}
	return 0;
}


