/*
Módulo en el que se cargan las opciones del programa.


Creado por Samuel Villaescusa Vinader para IMD 2015
*/


#include <stdio.h>
#include <stdlib.h>

#include "llamadasWii.h"

#define DIRECCION_MAC_WII 00:00:00:00:00:00

/*
Método que hace una llamada a la herramienta hcitool para comprobar 
los dispositivos bluetooth conectados.
*/
void reconocerMandoWii() {

	//FILE *respuesta;

	system("hcitool scan \n");

	//respuesta = popen("hcitool scan \n", "w"); --> Obtiene el resultado de hcitool scan en la variable respuesta.

}

/*
 * Permite mover el cursor mediante el acelerómetro del mando de la Wii.
 */ 
void moverCursor() {

	system("sudo wminput");

}

/*Ejecuta el fichero de configuración para wminput y poder usar el mando de la Wii
para pasar las transparencias.
*/
void pasarTransparencias() {

	system("sudo wminput -w -c ~/.CWiid/diapositivas.conf");	

}

//Ejecuta el juego desarrollado para probar la funcionalidad del mando de la Wii.
void ejecutarPong() {
	
	system("firefox https://scratch.mit.edu/projects/32654442/ &");
	
	system("sudo wminput -w -c ~/.CWiid/pong.conf");
	
}

//Función que se encarga de llamar al programa calibrar (el cual se encarga de calibrar el mando de la Wii).
void calibrarMando() {
	
	system("./calibrar &");
	
	system("sudo wminput -w");
	
}

//Función que llama al programa para probar el funcionamiento de los leds del mando wii.
void ejecutarLeds() {

	system("./conexionWii");

	//Permite el paso por parámetros de la mac del mando, previamente consultada mediante hcitool scan.
	// system("./conexionWii DIRECCIÓN_MAC_WII);

}

