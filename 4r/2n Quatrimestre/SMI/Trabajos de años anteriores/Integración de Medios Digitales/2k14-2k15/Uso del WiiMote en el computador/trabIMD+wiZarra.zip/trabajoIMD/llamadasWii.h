/*
Módulo en el que se cargan las opciones del programa.


Creado por Samuel Villaescusa Vinader para IMD 2015
*/


#include <stdio.h>
#include <stdlib.h>


#ifndef  __LLAMADASWII_H__
#define  __LLAMADASWII_H__


void reconocerMandoWii();

void moverCursor();

void pasarTransparencias();

void ejecutarPong();

void calibrarMando();

void ejecutarLeds();

#endif  /* llamadasWii */
