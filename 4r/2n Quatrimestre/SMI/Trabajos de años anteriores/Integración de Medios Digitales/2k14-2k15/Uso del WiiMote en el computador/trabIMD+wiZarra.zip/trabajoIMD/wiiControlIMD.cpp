/*

Aplicación que se encarga del control del ratón del ordenador y poder pasar transparencias gracias al uso del mando de la wii
y al uso de la libreria cwiid. (Se hace uso de wminput para controlar el ratón y las transparencias).

Creado por Samuel Villaescusa Vinader IMD 2015

*/


#include <stdio.h>
#include <stdlib.h>

#include "llamadasWii.h"




void menu(int opcion) 
{
	switch(opcion)
	{
		case 1:
			reconocerMandoWii();
			break;
		case 2: 
			ejecutarLeds();
			break;
		case 3:
			moverCursor();
			break;
		case 4:
			calibrarMando();
			break;
		case 5:
			pasarTransparencias();
			break;
		case 6:
			ejecutarPong();
			break;
                default: break;
	}


}//Fin de menu


int main() {

int opcion;

while(opcion != 9) {

printf("\n***APLICACIÓN wiiControlIMD by Samuel Villaescusa Vinader IMD***\n");

printf("\n***MENÚ***\n");
printf("1--> Reconocer mando de la wii\n");
printf("2--> Probar el funcionamiento del mando mediante leds\n");
printf("3--> Usar el mando de la wii para controlar el ratón\n");
printf("4--> Probar el funcionamiento del mando con un pequeño juego(calibrar)\n");
printf("5--> Pasar transparencias con el mando de la wii\n");
printf("6--> Juego Pong(Desarrollado mediante Scratch)\n");


printf("Elija una opción(pulse 9 para salir):\n");

scanf("%d", &opcion);

menu(opcion);

}

return 0;

}//Fin de main



	

