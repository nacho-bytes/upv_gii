/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#include "calibrado.h"


/*
 * Calibrado del punto abajo derecha
 */
void VentanaCalibracion::calibrado_boton_derecho_abajo(WiiDatosEvento const& datos)
{
    MENSAJE_DEBUG(1, "Boton derecho, registrando posicion #%d en %dx%d\n", datos_calibrado.punto_activo, datos.ir_pos.x, datos.ir_pos.y);
    datos_calibrado.p_wii.p[datos_calibrado.punto_activo++] = datos.ir_pos;
}

/*
 * El raton se ha movido y se calibra
 */
void VentanaCalibracion::calibrado_raton_movido(WiiDatosEvento const& datos)
 {
    //MENSAJE_DEBUG(1, "Mouse movido");
    datos_calibrado.ir_pos = datos.ir_pos;
    datos_calibrado.esperado = datos.esperado;
    datos_calibrado.tolerancia_mov = datos.tolerancia_mov;
}

/*
 * Calibrado del boton abajo, espera a hacer un click (tiempo de espera config antes)
 */
void VentanaCalibracion::calibrado_raton_abajo(WiiDatosEvento const& datos)
{
    MENSAJE_DEBUG(1, "Raton abajo, esperando evento click derecho");
    datos_calibrado.ir_raton_abajo = datos.ir_raton_abajo;
    datos_calibrado.borde_cruzado = false;
}

/*
 * Calibrado raton acabada
 */
void VentanaCalibracion::calibrado_raton_arriba(WiiDatosEvento const& datos)
{
    MENSAJE_DEBUG(1, "Raton abajo, esperando al final");

    datos_calibrado.ir_pos.x = POSICION_IR_INVALIDA;
    if (datos_calibrado.punto_activo == WIIMOTE_NUM_PUNTOS_CALIBRADOS)
    {
        MENSAJE_DEBUG(1, "Todos los puntos calibrados, saliendo...");
        quit();
    }
}

/*
 * Calibrando se ha movido demasiado y se invalida
 */
void VentanaCalibracion::calibrado_empieza_click_y_arrastre(WiiDatosEvento const& datos)
{
    MENSAJE_DEBUG(1, "Raton movido, calibracion invalidada");
    datos_calibrado.borde_cruzado = true;
}

/*
 * Dibuja los puntos para calibrar
 */
void dibuja_puntos_calibracion(Cairo::RefPtr<Cairo::Context>& cr, point_t const puntos[WIIMOTE_NUM_PUNTOS_CALIBRADOS], unsigned int activo, bool luz_activa)
{
    // 4 puntos calibrado y Radio = 10

    double const tamanyo_hecho = 16.0;
    Punto<double> const trans_ratio(4.0, 3.0);
    Punto<double> const trans[4] = {
	Punto<double>(1.0, 1.0), Punto<double>(-1.0, 1.0),
	Punto<double>(-1.0, -1.0), Punto<double>(1.0, -1.0) };
    double const colores_hecho[3] = {1.0, 1.0, 0.0};
    std::string const mensaje_hecho("Hecho!");

    unsigned int const RADIO = 10;
    for (unsigned int i = 0; i != sizeof(puntos); ++i)
    {
        cr->set_source_rgb(1.0, 1.0, 1.0);
        { // Dibuja una cruz dentro del rectangulo
            cr->move_to(puntos[i].x-RADIO, puntos[i].y-RADIO);
            cr->line_to(puntos[i].x+RADIO, puntos[i].y+RADIO);
            cr->move_to(puntos[i].x+RADIO, puntos[i].y-RADIO);
            cr->line_to(puntos[i].x-RADIO, puntos[i].y+RADIO);
        }
        Punto<double> const punto_centro(puntos[i].x-RADIO, puntos[i].y-RADIO);
        if ((i < activo) || ((i == activo) && luz_activa))
            cr->rectangle(punto_centro.x, punto_centro.y, RADIO*2, RADIO*2);
        // Dibuja el mensaje de los activos (ya calibrados)
        if (i < activo)
        {
            Punto<double> const msg_centro(punto_centro.x+trans[i].x*trans_ratio.x*tamanyo_hecho, punto_centro.y+trans[i].y*trans_ratio.y*tamanyo_hecho);
            cr->select_font_face("", Cairo::FONT_SLANT_NORMAL, Cairo::FONT_WEIGHT_BOLD);
            dibuja_texto( cr, mensaje_hecho, tamanyo_hecho, msg_centro, trans[(i+2)%4], Punto<double>(-1.0, -1.0), colores_hecho );
            cr->select_font_face("", Cairo::FONT_SLANT_NORMAL, Cairo::FONT_WEIGHT_NORMAL);
        }
    }
}

/*
 *  Tecla apretada en la calibracion
 */
bool VentanaCalibracion::area_calibracion_tecla_apretada(GdkEventKey* evento)
{
    MENSAJE_DEBUG(1, "Ventana de calibracion: Tecla apretada");

    if (evento->keyval == GDK_Escape)
    {
        MENSAJE_DEBUG(1, "Ventana de calibracion: ESC apretado, saliendo...");
        quit();
    }

    // Aviso: siempre devuelve true
    return true;
}

/*
 *  Dibuja el texto en un punto
 */
void dibuja_texto(Cairo::RefPtr<Cairo::Context>& cr, std::string const& texto, double tamanyo, Punto<double> const& traducciones, Punto<double> const& justificar, Punto<double> const& alinear)
{
    double const colores[3] = {1.0, 1.0, 1.0};
    dibuja_texto(cr, texto, tamanyo, traducciones, justificar, alinear, colores);
}

/*
 * Dibuja el texto de un cierto color
 */
void dibuja_texto(Cairo::RefPtr<Cairo::Context>& cr, std::string const& texto, double tamanyo, Punto<double> const& traducciones, Punto<double> const& justificar, Punto<double> const& alinear, double const colores[3])
{
    point_t const tam_pantalla = tamanyo_pantalla();
    point_t const centro_pantalla( tam_pantalla.x/2, tam_pantalla.y/2 );
    point_t const& tam_med_pantalla = centro_pantalla;

    cr->set_font_size(tamanyo);
    Cairo::TextExtents texto_extents;
    cr->get_text_extents(texto, texto_extents);
    Punto<double> const texto_medio_tamanyo(texto_extents.width/2.0, texto_extents.height/2.0);
    Punto<double> const texto_posicion(centro_pantalla.x+alinear.x*tam_med_pantalla.x-texto_extents.x_bearing-texto_medio_tamanyo.x+justificar.x*texto_medio_tamanyo.x+traducciones.x,centro_pantalla.y+alinear.y*tam_med_pantalla.y-texto_extents.y_bearing-texto_medio_tamanyo.y+justificar.y*texto_medio_tamanyo.y+traducciones.y);
    cr->move_to(texto_posicion.x, texto_posicion.y);
    cr->set_source_rgb(colores[0], colores[1], colores[2]);
    cr->show_text(texto);
}

/*
 *
 */
bool VentanaCalibracion::area_calibracion_expuesta(GdkEventExpose* evento)
{
    MENSAJE_DEBUG(5, "Ventana calibracion: Empezando a dibujar");

    Glib::RefPtr<Gdk::Window> window = gtkmm_area_calibrado->get_window();
    Cairo::RefPtr<Cairo::Context> cr = window->create_cairo_context();
    point_t const tam_pantalla = tamanyo_pantalla();
    point_t const centro_pantalla(tam_pantalla.x/2, tam_pantalla.y/2);

    dibuja_texto(cr, mensaje_usuario, 32.0, Punto<double>(0.0, 200.0), Punto<double>(), Punto<double>(0.0, -1.0));

    // Escape
    std::string const escape_message("Presiona 'Escape' [ESC] para salir del calibrado");
    dibuja_texto(cr, escape_message, 16.0, Punto<double>(0.0, -40.0), Punto<double>(), Punto<double>(0.0, 1.0));
    // calibrado
    std::string const calibrate_message("Pon el poli en los puntos parpadeantes y espera hasta que se calibre");
    dibuja_texto(cr, calibrate_message, 16.0, Punto<double>(0.0, -70.0), Punto<double>(), Punto<double>(0.0, 1.0));


    // area vision wiimote
    cr->set_source_rgb(1.0, 1.0, 1.0);
    cr->set_line_width(2.0);
    unsigned int const WII_VIEWING_AREA_RADIUS = 100;
    cr->rectangle(centro_pantalla.x-WII_VIEWING_AREA_RADIUS, centro_pantalla.y-WII_VIEWING_AREA_RADIUS,WII_VIEWING_AREA_RADIUS*2, WII_VIEWING_AREA_RADIUS*2);
    cr->stroke();

    // Posicion actual IR
    point_t const& ir_pos = datos_calibrado.ir_pos;
    if (ir_pos.x != POSICION_IR_INVALIDA)
    {
        cr->set_source_rgb(1.0, 1.0, 0.0);
        cr->set_line_width(2.0);
        point_t const ir_pointer_center(wii_ir_pos_to_screen_pos(centro_pantalla, WII_VIEWING_AREA_RADIUS, ir_pos));
        cr->rectangle(ir_pointer_center.x-1.0, ir_pointer_center.y-1.0, 1.0, 1.0);
        cr->stroke();
    }

    // Pintado de las lineas que conectan las esquinas IR
    cr->set_source_rgb(1.0, 1.0, 0.25);
    cr->set_line_width(2.0);
    for (unsigned int i = 0; i != datos_calibrado.punto_activo; ++i)
    {
        point_t const wii_ir_pos_actual(wii_ir_pos_to_screen_pos(centro_pantalla, WII_VIEWING_AREA_RADIUS, datos_calibrado.p_wii.p[i]));
        cr->line_to(wii_ir_pos_actual.x, wii_ir_pos_actual.y);
    }
    if (datos_calibrado.punto_activo == WIIMOTE_NUM_PUNTOS_CALIBRADOS)
    {
        point_t const wii_ir_pos_first(wii_ir_pos_to_screen_pos(centro_pantalla, WII_VIEWING_AREA_RADIUS, datos_calibrado.p_wii.p[0]) );
        cr->line_to(wii_ir_pos_first.x, wii_ir_pos_first.y);
    }
    cr->stroke();

    // Puntos de calibrado
    cr->set_source_rgb(1.0, 1.0, 1.0);
    cr->set_line_width(2.0);
    datos_calibrado.luz_activa = !datos_calibrado.luz_activa;
    point_t p_pantalla[WIIMOTE_NUM_PUNTOS_CALIBRADOS];
    esquinas_pantalla(p_pantalla);
    dibuja_puntos_calibracion(cr, p_pantalla, datos_calibrado.punto_activo, datos_calibrado.luz_activa);
    cr->stroke();

    // Dibuja cajas en las esquinas de la pantalla
    unsigned int const BOX_THICKNESS = 3;
    unsigned int const NUMBER_OF_BOXES = 3;
    cr->set_line_width(BOX_THICKNESS);
    for (unsigned int i = 0; i != NUMBER_OF_BOXES; ++i)
    {
        cr->set_source_rgb(i*0.25, 1.0, 1.0-i*0.25);
        cr->rectangle(i*BOX_THICKNESS, i*BOX_THICKNESS, tam_pantalla.x-i*BOX_THICKNESS*2, tam_pantalla.y-i*BOX_THICKNESS*2);
        cr->stroke();
    }

    // Un circulo muestra el tiempo que pasa durante el 'click' del raton
    double const CIRCULO_ENTERO = 2*M_PI;
    unsigned int const RADIO_CIRCULO = 50;
    point_t const posicion_circulo_tiempo(centro_pantalla.x-RADIO_CIRCULO*1.5, centro_pantalla.y+WII_VIEWING_AREA_RADIUS*2);

    cr->set_source_rgb(0.0, 1.0, 0.0);
    cr->set_line_width(3.0);
    cr->arc(posicion_circulo_tiempo.x, posicion_circulo_tiempo.y, RADIO_CIRCULO, 0, CIRCULO_ENTERO);
    cr->stroke();

    double const tolerancia_espera = get_configurador().tolerancia_espera();
    double const angulo = CIRCULO_ENTERO * static_cast<double>(datos_calibrado.esperado) / tolerancia_espera;
    cr->set_source_rgb(0.75, 1.0, 1.0);
    cr->set_line_width(2.0);
    cr->move_to(posicion_circulo_tiempo.x, posicion_circulo_tiempo.y);
    cr->arc(posicion_circulo_tiempo.x, posicion_circulo_tiempo.y, RADIO_CIRCULO, -CIRCULO_ENTERO/4.0, angulo-CIRCULO_ENTERO/4.0);
    cr->fill();

    // Otro circulo que nos muestra como de lejos está el puntero IR desde su posición original
    point_t const pos_mov_circulo(centro_pantalla.x+RADIO_CIRCULO*1.5, centro_pantalla.y+WII_VIEWING_AREA_RADIUS*2);
    unsigned int const MAX_NUMERO_POSICIONES = 7;
    double const circle_radius_move = MAX_NUMERO_POSICIONES * datos_calibrado.tolerancia_mov;

    if (!datos_calibrado.borde_cruzado)
        cr->set_source_rgb(0.0, 1.0, 1.0);
    else
        cr->set_source_rgb(1.0, 0.0, 0.0);
    cr->set_line_width(3.0);
    cr->arc(pos_mov_circulo.x, pos_mov_circulo.y, circle_radius_move, 0, CIRCULO_ENTERO);
    cr->stroke();
    // posicion IR relativa

    unsigned int const RADIO_PUNTO = 4;
    point_t const pos_puntos(pos_mov_circulo.x+static_cast<int>(circle_radius_move/datos_calibrado.tolerancia_mov)*(datos_calibrado.ir_pos.x-datos_calibrado.ir_raton_abajo.x),	pos_mov_circulo.y+static_cast<int>(circle_radius_move/datos_calibrado.tolerancia_mov)*(datos_calibrado.ir_pos.y-datos_calibrado.ir_raton_abajo.y));

    if (!datos_calibrado.borde_cruzado)
    {
        cr->set_source_rgb(1.0, 1.0, 0.0);
        cr->set_line_width(3.0);
        cr->arc(pos_puntos.x, pos_puntos.y, RADIO_PUNTO, 0, CIRCULO_ENTERO);
        cr->fill();
    }

    // Wiimote leds parpadeando
    if ( (wiimote_led_parpadeante == 3) || (wiimote_led_parpadeante == 0) )
        wiimote_led_parpadeante_direccion = -wiimote_led_parpadeante_direccion;

    unsigned int const leds[4] = {CWIID_LED1_ON, CWIID_LED2_ON, CWIID_LED3_ON, CWIID_LED4_ON};
    poner_estado_led(datos_thread.wiimotes.front().wiimote, leds[wiimote_led_parpadeante]);
    wiimote_led_parpadeante += wiimote_led_parpadeante_direccion;

    MENSAJE_DEBUG(5, "Ventana calibracion: dibujo acabado");

    //Aviso: siempre devuelve true
    return true;
}

/*
 *  Redibuja el area de calibrado entera
 */
bool VentanaCalibracion::redibujar_area_calibrado()
{
    gtkmm_area_calibrado->queue_draw();

    //Aviso: siempre devuelve true
    return true;
}

/*
 *  sale de la ventana de calibracion
 */
void VentanaCalibracion::quit()
{
    acabar_wiicursor_thread(datos_thread);
    MENSAJE_DEBUG(1, "Esconde ventana de calibrado");
    gtkmm_ventana->hide();
}

/*
 * Construccion de la clase
 */
VentanaCalibracion::VentanaCalibracion(cwiid_wiimote_t* wiimote, char const* mensaje_usuario) :
    gtkmm_ventana(0),
    gtkmm_area_calibrado(0),
    wiimote_led_parpadeante(0),
    wiimote_led_parpadeante_direccion(-1),
    mensaje_usuario(mensaje_usuario),
    datos_thread(vec_datos_wiimote)
{
    MENSAJE_DEBUG(1, "Inicializando ventana de calibrado");
    Glib::RefPtr<Gnome::Glade::Xml> refXml = Gnome::Glade::Xml::create("calibrado.glade");

    refXml->get_widget("ventana-calibrado", gtkmm_ventana);
    refXml->get_widget("area-calibrado", gtkmm_area_calibrado);

    MENSAJE_DEBUG(2, "Ventana de calibrado: widgets cogidos");

    gtkmm_area_calibrado->modify_bg( Gtk::STATE_NORMAL, Gdk::Color("black") );
    gtkmm_area_calibrado->signal_expose_event().connect( sigc::mem_fun(*this, &VentanaCalibracion::area_calibracion_expuesta));


    gtkmm_ventana->set_icon_from_file("iconos/icono-wiiz.png");
    gtkmm_ventana->signal_key_press_event().connect( sigc::mem_fun(*this, &VentanaCalibracion::area_calibracion_tecla_apretada));
    gtkmm_ventana->fullscreen();
    gtkmm_ventana->show();

    MENSAJE_DEBUG(2, "Ventana de calibrado: propiedades cambiadas");

    // Datos
    vec_datos_wiimote.push_back(WiimoteDatos(wiimote));

    datos_thread.eventos.boton_derecho_abajo = sigc::mem_fun(*this, &VentanaCalibracion::calibrado_boton_derecho_abajo);
    datos_thread.eventos.raton_movido = sigc::mem_fun(*this, &VentanaCalibracion::calibrado_raton_movido);
    datos_thread.eventos.raton_arriba = sigc::mem_fun(*this, &VentanaCalibracion::calibrado_raton_abajo);
    datos_thread.eventos.raton_abajo = sigc::mem_fun(*this, &VentanaCalibracion::calibrado_raton_arriba);
    datos_thread.eventos.empezar_click_arrastre = sigc::mem_fun(*this, &VentanaCalibracion::calibrado_empieza_click_y_arrastre);

    MENSAJE_DEBUG(2, "Ventana de calibrado: eventos puestos");

    MENSAJE_DEBUG(2, "Ventana de calibrado: terminada inicializacion");
}

/*
 * obtiene los puntos de calibrado y devuelve si ha funcionado
 */
bool VentanaCalibracion::obtiene_puntos_calibrado(PuntosCalibradosWiimote& p_wii)
{
    MENSAJE_DEBUG(1, "Empezando calibracion");

    MENSAJE_DEBUG(2, "Ventana de calibrado: empezando ventana gtk");
    Gtk::Main gtk_kit(0, 0);

    MENSAJE_DEBUG(2, "Ventana de calibrado: cursor hilo wii");
    empezar_thread_wiicursor(datos_thread);
    sigc::connection redibujar_conexion = Glib::signal_timeout().connect(sigc::mem_fun(*this, &VentanaCalibracion::redibujar_area_calibrado), 100);

    MENSAJE_DEBUG(2, "Ventana de calibrado: ventana de calibracion");
    gtk_kit.run(*gtkmm_ventana);

    MENSAJE_DEBUG(2, "Ventana de calibrado: calibrado acabado");
    poner_estado_led(datos_thread.wiimotes.front().wiimote, WIIMOTE_LED_CONNECTED);
    redibujar_conexion.disconnect();

    bool const funciona = (datos_calibrado.punto_activo == WIIMOTE_NUM_PUNTOS_CALIBRADOS);
    if (funciona)
    {
        MENSAJE_DEBUG(1, "Calibrado funcionó, devolviendo los valores");
        p_wii = datos_calibrado.p_wii;
    }

    return funciona;
}
