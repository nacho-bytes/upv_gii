/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#ifndef  __CALIBRADO_H__
#define  __CALIBRADO_H__


#include <gtkmm.h>
#include <gdkmm.h>
#include <libglademm.h>
#include <cairomm/context.h>

#include "configurador.h"
#include "funciones.h"
#include "wiicursor.h"
#include "wiicontrol.h"
#include "comun.h"


/* Dibuja los puntos de calibracion
 * los cuadrados parpadeantes y los estáticos
 */
void dibuja_puntos_calibracion(Cairo::RefPtr<Cairo::Context>& cr,point_t const puntos[WIIMOTE_NUM_PUNTOS_CALIBRADOS],unsigned int activo, bool luz_activa);

// Escribe el texto en la ventana
void dibuja_texto( Cairo::RefPtr<Cairo::Context>& cr, std::string const& text, double size,	Punto<double> const& traducciones, Punto<double> const& justificar, Punto<double> const& alinear);
void dibuja_texto( Cairo::RefPtr<Cairo::Context>& cr, std::string const& text, double size,	Punto<double> const& traducciones, Punto<double> const& justificar, Punto<double> const& alinear, double const colores[3]);

class VentanaCalibracion
{
public:

    VentanaCalibracion(cwiid_wiimote_t* wiimote, char const* mensaje_usuario);

    bool obtiene_puntos_calibrado(PuntosCalibradosWiimote& p_wii);

    void quit();

private:
    /* Manejadores de los eventos para
     * la ventana de calibrado
     */
    bool area_calibracion_tecla_apretada(GdkEventKey* evento);
    bool area_calibracion_expuesta(GdkEventExpose* evento);
    bool redibujar_area_calibrado();
    bool wiimote_led_parpadea();

    void calibrado_boton_derecho_abajo(WiiDatosEvento const& datos);
    void calibrado_raton_movido(WiiDatosEvento const& datos);
    void calibrado_raton_abajo(WiiDatosEvento const& datos);
    void calibrado_raton_arriba(WiiDatosEvento const& datos);
    void calibrado_empieza_click_y_arrastre(WiiDatosEvento const& datos);

    point_t wii_ir_pos_to_screen_pos(point_t const& centro_pantalla, unsigned int area_radio_wii, point_t const& ir_pos) const
    {
        point_t const MAX_WII(1020, 760);

        return point_t((centro_pantalla.x-area_radio_wii) + static_cast<int>(((float) ir_pos.x / (float) MAX_WII.x)*(area_radio_wii*2)),(centro_pantalla.y+area_radio_wii) - static_cast<int>(((float) ir_pos.y / (float) MAX_WII.y)*(area_radio_wii*2)) );
    }

    // GUI
    Gtk::Window* gtkmm_ventana;
    Gtk::DrawingArea* gtkmm_area_calibrado;

    unsigned int wiimote_led_parpadeante;
    int wiimote_led_parpadeante_direccion;

    //Datos
    char const* mensaje_usuario;
    std::vector<WiimoteDatos> vec_datos_wiimote;
    WiiThreadFuncionesDatos datos_thread;

    //Datos de calibrado
    struct DatosCalibrado
    {
        PuntosCalibradosWiimote p_wii;
        unsigned int punto_activo; // Punto que está siendo calibrado
        bool luz_activa; // HAce parpadear al punto que se está calibrando


        point_t ir_pos; // Puntero IR actual
        point_t ir_raton_abajo; // Puntero IR
        delta_t_t esperado; // Para dibujar un circulo
        unsigned int tolerancia_mov;
        bool borde_cruzado; // Será = true si se mueve fuera del ciruclo el puntero

        DatosCalibrado() :
            punto_activo(0),
            luz_activa(true),
            ir_pos(POSICION_IR_INVALIDA, 0),
            ir_raton_abajo(POSICION_IR_INVALIDA, 0),
            esperado(0),
            tolerancia_mov(1),
            borde_cruzado(false)
        { }
    } datos_calibrado;
};


#endif /* __CALIBRADO_H__ */
