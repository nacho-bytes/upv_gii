/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#ifndef  __COMUN_H__
#define  __COMUN_H__


#include <assert.h>
#include <cwiid.h>
#include <string>



#define ASSERT(exp, msg) { \
    int const p = exp; \
    if (!p) \
    { \
	printf ("\nAssert '%s' FALLADO en linea '%d' de la funcion '%s' en el archivo '%s': '%s'.\n", #exp, __LINE__, __FUNCTION__, __FILE__, msg); \
	assert (1); \
    } \
}

/* Hay 7 niveles de mensajes de desarrollo:
 * 1: Mensaje de algo funcionando (principalmente GUI)
 * 2: Valores internos especialmente de los wiimote
 * 3: Mensajes saliendo y entrando de las funciones
 * 4:
 * 5:
 * 6:
 * 7: Funcionando!
*/

void MENSAJE_DEBUG(unsigned int nivel, char const* mensaje, ...);


// Para diferentes tipos con la misma lógica de control
template<typename T>
struct Punto {
    Punto() :
	x(T()),
	y(T())
    {
    }

    Punto(T x, T y) :
	x(x),
	y(y)
    {
    }
    T x, y;
};
typedef Punto<int> point_t; // Por defecto


enum BotonesRatonID {
    BOTON_IZQ = 1,
    BOTON_DER = 3,
};

enum ValoresEventoInvalidos {
    POSICION_IR_INVALIDA = 1, // no existe IR evento
    BOTON_MSG_ID_INVALIDO = 1337,
};

enum DimensionesMatrizTransformada {
    MATRIZ_TRANSFORMADA_FILAS = 3,
    MATRIZ_TRANSFORMADA_COLS = 3,
};

enum EstadosWiimoteLed {
    WIIMOTE_LED_CONNECTED = CWIID_LED1_ON,
};

#define WIIMOTE_NUM_PUNTOS_CALIBRADOS static_cast<unsigned int>(4)
struct PuntosCalibradosWiimote {
    point_t p[WIIMOTE_NUM_PUNTOS_CALIBRADOS];
};


#endif   /* __COMUN_H__ */
