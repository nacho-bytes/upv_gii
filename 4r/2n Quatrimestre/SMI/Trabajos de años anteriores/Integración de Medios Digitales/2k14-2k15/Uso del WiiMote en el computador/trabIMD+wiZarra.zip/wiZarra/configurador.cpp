/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#include "configurador.h"


/*
 * Configura la ruta de los archivos
 */
std::string config_ruta_archivos()
{
    // Advertencia: deberia usarse g_build_filename() y g_get_home_dir()
    std::string const ruta(std::string(getenv("HOME")) + ".wiizarra-config" );

    return ruta;
}

/*
 * Da acceso al configurador
 */
Configurador& get_configurador()
{
    static Configurador config;

    return config;
}


/*
 * Inicializa el archivo
 */
void Configurador::inicializa(Glib::RefPtr<Gnome::Glade::Xml>& refXml)
{
    MENSAJE_DEBUG(1, "Inicializando Configurador...");

    refXml->get_widget("spin-click-derecho", gtkmm_click_derecho_tiempo);
    click_derecho_tiempo_cambio();
    gtkmm_click_derecho_tiempo->signal_value_changed().connect(sigc::mem_fun(*this, &Configurador::click_derecho_tiempo_cambio));

    MENSAJE_DEBUG(1, "Configurador Inicializado\n");
}

/*
 * Cargar archivo de configuración
 */
bool Configurador::cargar_otra_config()
{
    bool devolver = true;

    try
    {
        MENSAJE_DEBUG(1, "Abriendo archivo %s", config_ruta_archivos().c_str());
        ConfigFileParser config( config_ruta_archivos() );

        // CONFIG_CLICK_DERECHO_TIEMPO
        try
        {
            MENSAJE_DEBUG(1, "Leyendo click-derecho-tiempo\n");
            gtkmm_click_derecho_tiempo->set_value(config.getValue<int>(CONFIG_CLICK_DERECHO_TIEMPO));
            MENSAJE_DEBUG(1, "Poniendo click-derecho-tiempo a %d\n", config.getValue<int>(CONFIG_CLICK_DERECHO_TIEMPO) );
        } catch(ConfigFileParser::KeyNotFound)
        {
            MENSAJE_DEBUG(1, "Configuracion '%s' no encontrada", CONFIG_CLICK_DERECHO_TIEMPO);
            devolver = false;
        }
    }
    catch(ConfigFileParser::FileNotFound)
    {
        MENSAJE_DEBUG(1, "Archivo de configuracion no encontrado");
        devolver = false;
    }

    return devolver;
}

/*
 * Cargar la matriz de transformadas
 */
bool Configurador::cargar_config_wiimotes()
{
    bool devolver = true;

    try
    {
        MENSAJE_DEBUG(1, "Abriendo archivo de configuracion %s", config_ruta_archivos().c_str());
        ConfigFileParser config(config_ruta_archivos());

        // CONFIG_MATRIZ
        try
        {
            std::vector<WiimoteDatos>& wiis = datos_configuracion.wiimotes;
            for (unsigned int i = 0; i != wiis.size(); ++i)
            {
                MENSAJE_DEBUG(1, "Tomando matriz #%d...\n", i);
                wiis[i].transformada = construir_matrix_valor_key(config.getValue<std::string>(construir_matriz_nombre(i)));
                MENSAJE_DEBUG(1, "Matriz cogido!");
            }
        }
        catch(ConfigFileParser::KeyNotFound)
        {
            MENSAJE_DEBUG(1, "Matriz de transformacion no cargada");
            devolver = false;
        }
    }
    catch(ConfigFileParser::FileNotFound)
    {
        MENSAJE_DEBUG(1, "Archivo de configuración no encontrado");
        devolver = false;
    }

    return devolver;
}

/*
 * Guardar configuracion
 */
bool Configurador::guardar_configuracion()
{
    // Aviso: Faltan los try / catch

    MENSAJE_DEBUG(1, "Guardando archivo de configuracion");

    ConfigFileParser configuracion;

    // CONFIG_CLICK_DERECHO_TIEMPO
    MENSAJE_DEBUG(1, "Tiempo de click derecho: %d", datos_configuracion.tolerancia_espera);
    configuracion.add<unsigned int>(CONFIG_CLICK_DERECHO_TIEMPO, datos_configuracion.tolerancia_espera);
    // CONFIG_MATRIZ
    std::vector<WiimoteDatos> const& wiis = datos_configuracion.wiimotes;
    for (unsigned int i = 0; i != wiis.size(); ++i)
    {
        std::string const nueva_matriz( construir_matriz_nombre(i) );
        std::string const nueva_matriz_transformada( construir_matriz_valor(wiis[i].transformada) );

        MENSAJE_DEBUG(1, "%s es %s\n", nueva_matriz.c_str(), nueva_matriz_transformada.c_str());
        configuracion.add<std::string>(nueva_matriz, nueva_matriz_transformada);
    }

    MENSAJE_DEBUG(1, "Archivo de configuracion guardado");

    // Aviso: Siempre devuelve true, faltan try catch
    return true;
}
