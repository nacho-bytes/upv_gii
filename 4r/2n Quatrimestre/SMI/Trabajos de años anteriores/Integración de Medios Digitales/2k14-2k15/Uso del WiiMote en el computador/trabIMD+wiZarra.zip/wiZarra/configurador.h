/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#ifndef  __CONFIGURADOR_H__
#define  __CONFIGURADOR_H__


#include <gtkmm.h>
#include <libglademm.h>
#include <string>
#include <cstdlib>
#include <cwiid.h>

#include "funciones.h"
#include "matrizop.h"
#include "ArchivoConfigSet.h"
#include "comun.h"


std::string config_ruta_archivos();

struct WiimoteDatos
{
    WiimoteDatos(cwiid_wiimote_t* wiimote) :
	wiimote(wiimote),
	transformada(MATRIZ_TRANSFORMADA_FILAS, MATRIZ_TRANSFORMADA_COLS)
    {

    }

    WiimoteDatos(cwiid_wiimote_t* wiimote, matriz_t const& transformada) :
	wiimote(wiimote),
	transformada(transformada)
    {

    }
    cwiid_wiimote_t* wiimote;
    matriz_t transformada;
};

typedef std::vector<WiimoteDatos>::iterator WiimoteDatosIterador;


#define CONFIG_CLICK_DERECHO_TIEMPO "clic_tiempo_derecho"
#define CONFIG_MATRIZ "matriz"


class Configurador
{
public:
    Configurador() :
	gtkmm_click_derecho_tiempo(0)
    { }


    void inicializa(Glib::RefPtr<Gnome::Glade::Xml>& refXml);


    delta_t_t const& tolerancia_espera() const
    {
        return datos_configuracion.tolerancia_espera;
    }

    std::vector<WiimoteDatos> const& wiimotes() const
    {
        return datos_configuracion.wiimotes;
    }

    std::vector<WiimoteDatos>& wiimotes()
    {
        return datos_configuracion.wiimotes;
    }
    bool const& muestra_instrucciones() const
    {
        return datos_configuracion.muestra_instrucciones;
    }


    bool cargar_otra_config();
    bool cargar_config_wiimotes();
    bool guardar_configuracion();

private:

    void click_derecho_tiempo_cambio()
    {
        datos_configuracion.tolerancia_espera = gtkmm_click_derecho_tiempo->get_value_as_int();
        MENSAJE_DEBUG(2, "Tiempo click cambiado a %d\n", datos_configuracion.tolerancia_espera);
    }

    std::string construir_matriz_nombre(unsigned int indice) const
    {
        std::ostringstream devolver;
        devolver << CONFIG_MATRIZ << indice;
        return devolver.str();
    }

    std::string construir_matriz_valor(matriz_t const& transformada) const
    {
        std::ostringstream devolver;
        devolver << '\"' << transformada << '\"';
        return devolver.str();
    }

    matriz_t construir_matrix_valor_key(std::string const& key) const
    {
        matriz_t devolver(MATRIZ_TRANSFORMADA_FILAS, MATRIZ_TRANSFORMADA_COLS);
        std::istringstream stream(key);
        stream >> devolver;
        return devolver;
    }


    Gtk::SpinButton* gtkmm_click_derecho_tiempo;

    struct DatosConfiguracion
    {
        delta_t_t tolerancia_espera;
        std::vector<WiimoteDatos> wiimotes;
        bool muestra_instrucciones;
    } datos_configuracion;
};


Configurador& get_configurador();


#endif /* __CONFIGURADOR_H__ */

