/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#include "eventos.h"

/*
 * Genera un movimiento de ratón falso, para posicionar el ratón en cualquier lado de la pantalal cuando detecta el IR
 */
void movimiento_raton_falso(int x, int y)
{
    Display* pantalla = XOpenDisplay(0);
    XTestFakeMotionEvent(pantalla, -1, x, y, 0);
    XCloseDisplay(pantalla);

    MENSAJE_DEBUG(4, "Raton movido: %dx%d\n", x, y);
}

/*
 * Genera un botón apretado del ratón, cuando está quieto el IR segú el tiempo de click
 */
void click_boton_falso(int boton, bool apretado)
{
    Display* pantalla = XOpenDisplay(0);
    XTestFakeButtonEvent(pantalla, boton, apretado, 0);
    XCloseDisplay(pantalla);

    MENSAJE_DEBUG(4, "Boton de raton #%d' cambiado a %d\n", boton, apretado);
}
