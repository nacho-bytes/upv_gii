/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#include "filtroir.h"

/*
 *
 */
bool FiltroIr::procesar_tolerancia(point_t const& pos_nueva)
{
    bool devolver = false;

    delta_t_t const delta_t = obtener_delta_t(m_ultima_vez);
    if (pos_nueva.x == POSICION_IR_INVALIDA)
    {
        m_desaparecido += delta_t;
        if (m_desaparecido < TOLERANCIA_DESAPARICION)
            devolver = true;
    }

    return devolver;
}

/*
 * Con todas las poisciones posibles, calcula la media para devolver el punto donde se encuentra
 */
point_t FiltroIr::procesar_ir_posicion_media()
{
    point_t devolver;
    for (std::list<point_t>::const_iterator iteracion = m_posiciones_anteriores.begin(); iteracion != m_posiciones_anteriores.end(); ++iteracion)
    {
        devolver.x += iteracion->x;
        devolver.y += iteracion->y;
    }
    devolver.x /= m_posiciones_anteriores.size();
    devolver.y /= m_posiciones_anteriores.size();

    return devolver;
}

/*
 * Porcesa la nueva posicion del IR obtenida y devuelve la media, si es invalida devuelve la posicion dada
 */
point_t FiltroIr::procesar_ir(point_t const& pos_nueva)
{
    bool const pos_valida = (m_pos_actual.x != POSICION_IR_INVALIDA) && (pos_nueva.x != POSICION_IR_INVALIDA);
    if (pos_valida) //Si la posicion no es invalida
    {
        m_posiciones_anteriores.push_back(pos_nueva);
        if (m_posiciones_anteriores.size() > MAX_NUMERO_POSICIONES)
            m_posiciones_anteriores.pop_front();
        m_tolerancia_mov = MAX_NUMERO_POSICIONES / m_posiciones_anteriores.size() + 1;

        return procesar_ir_posicion_media();
    }
    else
    {
        resetear();
        return pos_nueva; // No hay ningún punto calculad
    }
}

/*
 * Si la nueva posicion entra dentro del nivel de tolerancia y no se deshecha procesa la nueva, sino solo las actuales
 */
point_t FiltroIr::procesar(point_t const& pos_nueva)
{

    point_t devolver;

    if (procesar_tolerancia(pos_nueva))
        devolver = procesar_ir(m_pos_actual);
    else
        devolver = procesar_ir(pos_nueva);

    return devolver;
}
