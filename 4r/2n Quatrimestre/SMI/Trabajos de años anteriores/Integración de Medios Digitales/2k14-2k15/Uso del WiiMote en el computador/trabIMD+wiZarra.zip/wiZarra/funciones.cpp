/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#include "funciones.h"

/*
 *  Nos devuelve el tamaño de la pantalla
 */
point_t tamanyo_pantalla()
{
    Display* display = XOpenDisplay(0);
    int const pantalla = DefaultScreen(display);
    point_t const tamanyo_pantalla(DisplayWidth(display, pantalla), DisplayHeight(display, pantalla));
    XCloseDisplay(display);
    MENSAJE_DEBUG(5, "Tamaño pantalla: %dx%d\n", tamanyo_pantalla.x, tamanyo_pantalla.y);
    return tamanyo_pantalla;
}

/*
 *  actualiza las esquinas de la pantalla
 */
void esquinas_pantalla(point_t p_pantalla[4])
{
    point_t const tam_pantalla = tamanyo_pantalla();
    int const PADING = 50;

    p_pantalla[0] = point_t(PADING, PADING);
    p_pantalla[1] = point_t(tam_pantalla.x - PADING, PADING);
    p_pantalla[3] = point_t(PADING, tam_pantalla.y - PADING);
    p_pantalla[2] = point_t(tam_pantalla.x - PADING, tam_pantalla.y - PADING);
}

/*
 * Calcula la matriz de transformacion
 */
matriz_t calcular_matriz_transformacion(PuntosCalibradosWiimote const& p_wii)
{
    MENSAJE_DEBUG(1, "Calculando coeficientes");

    point_t p_pantalla[4];
    esquinas_pantalla(p_pantalla);
    matriz_t m(8, 8), n(1, 8);

    for (int i = 0; i != 4; ++i)
    {
        n[0][i*2] = p_pantalla[i].x;
        n[0][i*2+1] = p_pantalla[i].y;
    }

    for (int i = 0; i != 4; ++i)
    {
        m[0][i*2] = p_wii.p[i].x;
        m[1][i*2] = p_wii.p[i].y;
        m[2][i*2] = 1;
        for (int j = 3; j != 6; ++j)
            m[j][i*2] = 0;
        m[6][i*2] = -p_pantalla[i].x * p_wii.p[i].x;
        m[7][i*2] = -p_pantalla[i].x * p_wii.p[i].y;

        for (int j = 0; j != 3; ++j)
            m[j][i*2+1] = 0;
        m[3][i*2+1] = p_wii.p[i].x;
        m[4][i*2+1] = p_wii.p[i].y;
        m[5][i*2+1] = 1;
        m[6][i*2+1] = -p_pantalla[i].y * p_wii.p[i].x;
        m[7][i*2+1] = -p_pantalla[i].y * p_wii.p[i].y;
    }

    matriz_t salida(MATRIZ_TRANSFORMADA_FILAS, MATRIZ_TRANSFORMADA_COLS);
    matriz_t const r = m.invert() * n;
    memcpy(salida.elementos(), r.elementos(), 8*sizeof(matriz_elem_t)); // NOTE: Do *something* about it!. memcpy, ugh...

    std::ostringstream os;
    os << salida;
    MENSAJE_DEBUG(2, "Matriz de transformacion %s", os.str().c_str());

    return salida;
}


/*
 *
 */
delta_t_t obtener_delta_t(delta_t_t& ultima_vez)
{
    timeval actual={0, 0};
    gettimeofday(&actual, 0);
    delta_t_t const tiempo_actual =
	static_cast<delta_t_t>(static_cast<double>(actual.tv_sec)*1000.0 + static_cast<double>(actual.tv_usec)/1000.0 );

    MENSAJE_DEBUG(5, "Tiempo: Actual %lld; Ultimo %lld\n", tiempo_actual, ultima_vez);

    ASSERT (tiempo_actual >= ultima_vez, "¿¿¿¿EL TIEMPO VA AL REVES????");

    delta_t_t const devolver = tiempo_actual - ultima_vez;
    ultima_vez = tiempo_actual;

    return devolver;
}

/*
 *  conversion a coordenadas con la matriz de transformacion
 */
point_t datos_infrarrojos(point_t const& ir_pos, matriz_t const& transformada)
{
    point_t cursor_pos;

    //matriz_t const& t = transformada;
    cursor_pos.x = static_cast<int> (
	    (transformada[0][0]*ir_pos.x + transformada[0][1]*ir_pos.y + transformada[0][2]) /
	    (transformada[2][0]*ir_pos.x + transformada[2][1]*ir_pos.y + 1.0) );
    cursor_pos.y = static_cast<int> (
	    (transformada[1][0]*ir_pos.x + transformada[1][1]*ir_pos.y + transformada[1][2]) /
	    (transformada[2][0]*ir_pos.x + transformada[2][1]*ir_pos.y + 1.0) );

    point_t const tam_pantalla = tamanyo_pantalla();
    if (cursor_pos.x<0)
        cursor_pos.x = 0;
    if (cursor_pos.x>=tam_pantalla.x)
        cursor_pos.x = tam_pantalla.x-1;
    if (cursor_pos.y<0)
        cursor_pos.y = 0;
    if (cursor_pos.y>=tam_pantalla.y)
        cursor_pos.y = tam_pantalla.y-1;

    MENSAJE_DEBUG(4, "Posicion cursor: %dx%d\n", cursor_pos.x, cursor_pos.y);

    return cursor_pos;
}


/*
 *  cuadrado del numero
 */
unsigned int cuadrado(int n) {
    return static_cast<unsigned int>(n*n);
}

/*
 *  distancia euclidea entre dos puntos
 */
unsigned int distancia_euclidea(point_t const& punto1, point_t const& punto2) {
    return cuadrado(punto1.x - punto2.x) + cuadrado(punto1.y - punto2.y);
}
