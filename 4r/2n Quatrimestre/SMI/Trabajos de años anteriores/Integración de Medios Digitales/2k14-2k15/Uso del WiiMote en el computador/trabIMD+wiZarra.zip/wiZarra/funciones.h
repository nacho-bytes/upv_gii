/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#ifndef  __AUXILIAR_H__
#define  __AUXILIAR_H__


#include <sys/time.h>
#include <iostream>
#include <unistd.h>
#include <sstream>
#include <X11/extensions/XTest.h>

#include "matrizop.h"
#include "comun.h" // ASSERT


struct EstadosOpciones
{
    char direccion_mac[18];
    bool calibrado_futuro;
    bool mostrar_ayuda;

    EstadosOpciones() :
	calibrado_futuro(false)
    {
    }
};

point_t tamanyo_pantalla();
void esquinas_pantalla(point_t p_pantalla[4]);

matriz_t calcular_matriz_transformacion(PuntosCalibradosWiimote const& p_wii);

/* Devuelve cuanto tiempo ha pasado desde el ultimo evento en ms
 */
typedef unsigned long long delta_t_t;
delta_t_t obtener_delta_t(delta_t_t& ultima_vez);

/* Transforma las coordenadas del infrarrojo a
 * coordenadas de la pantalla usando la matriz
 * transformada anterior
 */
point_t datos_infrarrojos(point_t const& ir_pos, matriz_t const& transformada);

unsigned int cuadrado(int n);
unsigned int distancia_euclidea(point_t const& punto1, point_t const& punto2);


#endif /* __AUXILIAR_H__ */
