/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#include "gtkGlade.h"


void wii_izquierda_clicked(WiiDatosEvento const& datos) {
    click_boton_falso(BOTON_IZQ, true);
    click_boton_falso(BOTON_IZQ, false);

    MENSAJE_DEBUG(2, "Click Izquierdo");
}
void wii_boton_derecha_abajo(WiiDatosEvento const& datos) {
    click_boton_falso(BOTON_DER, true);

    MENSAJE_DEBUG(2, "Boton derecha abajo");
}
void wii_boton_derecha_arriba(WiiDatosEvento const& datos) {
    click_boton_falso(BOTON_DER, false);

    MENSAJE_DEBUG(2, "Boton derecha arriba");
}
void wii_empezar_click_y_mover(WiiDatosEvento const& datos) {
    click_boton_falso(BOTON_IZQ, true);

    MENSAJE_DEBUG(2, "Empezar Click y Mover");
}
void wii_fin_click_y_mover(WiiDatosEvento const& datos) {
    click_boton_falso(BOTON_IZQ, false);

    MENSAJE_DEBUG(2, "Finalizar Click y Mover");
}
void wii_raton_movido(WiiDatosEvento const& datos) {
    movimiento_raton_falso(datos.cursor_pos.x, datos.cursor_pos.y);
}


VentanaPrincipal::VentanaPrincipal(int argc,char *argv[]) :
    gtkmm_principal(argc, argv),
    gtkmm_ventana_principal(0),
    gtkmm_salida_scroll(0),
    gtkmm_salida_texto(0),
    glib_buffer_salida( Gtk::TextBuffer::create() ),
    gtkmm_boton_conectar(0),
    gtkmm_boton_activar(0),
    gtkmm_boton_calibrar(0),
    gtkmm_icono_estado( Gtk::StatusIcon::create("icono-wiizarra") ),
    gtkmm_icono_estado_menu(0),
    gtkmm_eim_conectar(0),
    gtkmm_eim_desconectar(0),
    gtkmm_eim_activar(0),
    gtkmm_eim_desactivar(0),
    gtkmm_eim_calibrar(0),
    gtkmm_eim_cerrar(0),
    gtkmm_menu_salir(0),
    gtkmm_menu_sobre(0),
    gtkmm_menu_instrucciones(0),
    gtkmm_dialogo_sobre(0),
    gtkmm_ventana_conexion(0),
    gtkmm_etiqueta_numero_wiimote(0),
    gtkmm_conexion_barraprogreso(0),
    gtkmm_ventana_instrucciones(0),
    gtkmm_boton_instrucciones_cerrar(0),
    m_configurador(get_configurador()),
    m_wii_cursorgestor(eventos_conexion)
{
    MENSAJE_DEBUG(1, "Inicializando la GUI principal...");

    Glib::RefPtr<Gnome::Glade::Xml> refXml = Gnome::Glade::Xml::create("ventana-principal.glade");
    MENSAJE_DEBUG(2, "Archivo glade cargado");

    refXml->get_widget("ventana-principal", gtkmm_ventana_principal);
    refXml->get_widget("salida-scroll", gtkmm_salida_scroll);
    refXml->get_widget("salida-texto", gtkmm_salida_texto);
    refXml->get_widget("boton-wiimote", gtkmm_boton_conectar);
    refXml->get_widget("boton-activar", gtkmm_boton_activar);
    refXml->get_widget("boton-calibrar", gtkmm_boton_calibrar);
    refXml->get_widget("icono-estado-menu", gtkmm_icono_estado_menu);
    refXml->get_widget("eim-conectar", gtkmm_eim_conectar);
    refXml->get_widget("eim-desconectar", gtkmm_eim_desconectar);
    refXml->get_widget("eim-activar", gtkmm_eim_activar);
    refXml->get_widget("eim-desactivar", gtkmm_eim_desactivar);
    refXml->get_widget("eim-calibrar", gtkmm_eim_calibrar);
    refXml->get_widget("eim-cerrar", gtkmm_eim_cerrar);
    refXml->get_widget("menuitem-cerrar", gtkmm_menu_cerrar);
    refXml->get_widget("menuitem-salir", gtkmm_menu_salir);
    refXml->get_widget("menuitem-sobre", gtkmm_menu_sobre);
    refXml->get_widget("menuitem-instrucciones", gtkmm_menu_instrucciones);
    refXml->get_widget("dialogo-sobre", gtkmm_dialogo_sobre);
    refXml->get_widget("ventana-conexion", gtkmm_ventana_conexion);
    refXml->get_widget("ventana-conexion-numero-wiimote", gtkmm_etiqueta_numero_wiimote);
    refXml->get_widget("ventana-conexion-barrarprogreso-conexion", gtkmm_conexion_barraprogreso);
    refXml->get_widget("ventana-instrucciones", gtkmm_ventana_instrucciones);
    refXml->get_widget("ventana-instrucciones-boton-cerrar", gtkmm_boton_instrucciones_cerrar);
    MENSAJE_DEBUG(2, "GUI cargada, todos los get_widget funcionando");

    gtkmm_boton_conectar->signal_clicked().connect(sigc::mem_fun(*this, &VentanaPrincipal::boton_wiimote_con_des));
    gtkmm_boton_activar->signal_clicked().connect(sigc::mem_fun(*this, &VentanaPrincipal::boton_wiimote_activar));
    gtkmm_boton_calibrar->signal_clicked().connect(sigc::mem_fun(*this, &VentanaPrincipal::boton_wiimote_calibrar));
    gtkmm_icono_estado->signal_activate().connect(sigc::mem_fun(*this, &VentanaPrincipal::icono_estado_click));
    gtkmm_icono_estado->signal_popup_menu().connect(sigc::mem_fun(*this, &VentanaPrincipal::icono_estado_menu));


    gtkmm_eim_conectar->signal_activate().connect(sigc::mem_fun(*this, &VentanaPrincipal::boton_wiimote_con_des));
    gtkmm_eim_desconectar->signal_activate().connect(sigc::mem_fun(*this, &VentanaPrincipal::boton_wiimote_con_des));
    gtkmm_eim_activar->signal_activate().connect(sigc::mem_fun(*this, &VentanaPrincipal::boton_wiimote_activar));
    gtkmm_eim_desactivar->signal_activate().connect(sigc::mem_fun(*this, &VentanaPrincipal::boton_wiimote_activar));
    gtkmm_eim_calibrar->signal_activate().connect(sigc::mem_fun(*this, &VentanaPrincipal::boton_wiimote_calibrar));
    gtkmm_eim_cerrar->signal_activate().connect(sigc::mem_fun(*this, &VentanaPrincipal::menu_salir_click));
    gtkmm_menu_cerrar->signal_activate().connect(sigc::mem_fun(*this, &VentanaPrincipal::menu_cerrar_click));
    gtkmm_menu_salir->signal_activate().connect(sigc::mem_fun(*this, &VentanaPrincipal::menu_salir_click));
    gtkmm_menu_sobre->signal_activate().connect(sigc::mem_fun(*this, &VentanaPrincipal::menu_sobre_click));
    gtkmm_menu_instrucciones->signal_activate().connect(sigc::mem_fun(*gtkmm_ventana_instrucciones, &Gtk::Window::show));
    gtkmm_dialogo_sobre->signal_response().connect(sigc::mem_fun(*this, &VentanaPrincipal::dialogo_sobre_respuesta));
    gtkmm_boton_instrucciones_cerrar->signal_clicked().connect(sigc::mem_fun(*gtkmm_ventana_instrucciones, &Gtk::Window::hide));
    MENSAJE_DEBUG(2, "Todas las señales conectadas");


    gtkmm_salida_texto->set_buffer(glib_buffer_salida);
//  glib_texto_tiempo->property_font() = "bold"; //Pone la hora en negrita pero no funciona!!!

    //Ponemos el icono en todas las ventanas
    std::string const ARCHIVO_ICONO_EIM("iconos/icono-wiiz.png");
    gtkmm_ventana_principal->set_icon_from_file(ARCHIVO_ICONO_EIM);
    gtkmm_icono_estado->set_from_file(ARCHIVO_ICONO_EIM);
    gtkmm_dialogo_sobre->set_icon_from_file(ARCHIVO_ICONO_EIM);
    gtkmm_ventana_conexion->set_icon_from_file(ARCHIVO_ICONO_EIM);
    gtkmm_ventana_instrucciones->set_icon_from_file(ARCHIVO_ICONO_EIM);
    gtkmm_ventana_principal->signal_key_press_event().connect( sigc::mem_fun(*this, &VentanaPrincipal::tecla_apretada) );

    sincroniza_estado_wiimote(false); // Desconectado por default


    m_configurador.inicializa(refXml);


    eventos_conexion.empezar_conexion.connect(sigc::mem_fun(*this, &VentanaPrincipal::wiicursorgestor_empezar_conexion));
    eventos_conexion.acabar_conexion.connect(sigc::mem_fun(*this, &VentanaPrincipal::wiicursorgestor_acabar_conexion));
    eventos_conexion.conexion_terminada.connect(sigc::mem_fun(*this, &VentanaPrincipal::wiicursorgestor_done_conexion));


    m_wii_cursorgestor.eventos().click_izq = sigc::ptr_fun(&wii_izquierda_clicked);
    m_wii_cursorgestor.eventos().boton_derecho_abajo = sigc::ptr_fun(&wii_boton_derecha_abajo);
    m_wii_cursorgestor.eventos().boton_derecho_arriba = sigc::ptr_fun(&wii_boton_derecha_arriba);
    m_wii_cursorgestor.eventos().empezar_click_arrastre = sigc::ptr_fun(&wii_empezar_click_y_mover);
    m_wii_cursorgestor.eventos().fin_click_arrastre = sigc::ptr_fun(&wii_fin_click_y_mover);
    m_wii_cursorgestor.eventos().raton_movido = sigc::ptr_fun(&wii_raton_movido);


    gtkmm_ventana_principal->show();

    MENSAJE_DEBUG(2, "Eventos del ratón conectados");

    MENSAJE_DEBUG(1, "GUI Inicializada correctamente");
}

/*
 *  Funciona para empezar el GUI
 */
int VentanaPrincipal::start()
{
    MENSAJE_DEBUG(1, "Antes de empezar el run");
    gtkmm_principal.run();
    MENSAJE_DEBUG(1, "Despues de empezar el run");


    return 0;
}

/*
 * Conecta/desconecta los wiimote y pone los botones sincronizados
 *
 */
void VentanaPrincipal::boton_wiimote_con_des()
{
    MENSAJE_DEBUG(1, "Boton conectar/desconectar clicado");

    if (!m_wii_cursorgestor.conectado())
    {
        MENSAJE_DEBUG(1, "Wiimotes no conectados. Conectando");

        imprime_salida("Preparandose para conectar\n");

        sincroniza_estado_wiimote_conexion(true);

        MENSAJE_DEBUG(1, "Empezando a conectar a los wiimotes");

        m_wii_cursorgestor.conectar();

    }
    else
    {
        MENSAJE_DEBUG(1, "Wiimotes conectados. Desconectando");

        if ( m_wii_cursorgestor.activado() )
        {
            MENSAJE_DEBUG(1, "Wiimotes activados. Desactivando");
            boton_wiimote_activar();
        }

        MENSAJE_DEBUG(1, "Guardando archivo de configuracion...");

        m_configurador.guardar_configuracion();

        if ( m_wii_cursorgestor.desconectar() )
            imprime_salida("Desconectado de los wiimotes");
        else
            imprime_salida("Error desconectado los wiimotes");

        sincroniza_estado_wiimote(false);
    }
}

/*
 * Activa los wiimotes para empezar a funcionar
 *
 */
void VentanaPrincipal::boton_wiimote_activar()
{
    MENSAJE_DEBUG(1, "Boton activar wiimote clicado");

    if ( !m_wii_cursorgestor.activado() )
    {
        MENSAJE_DEBUG(1, "Activando todos los wiimotes");
        sincroniza_estado_activo(true);
        m_wii_cursorgestor.activar();
    }
    else
    {
        MENSAJE_DEBUG(1, "Desactivando todos los wiimotes");
        m_wii_cursorgestor.desactivar();
        sincroniza_estado_activo(false);
    }
}

/*
 * Calibra el wiimote, llamando a la ventana de calibración
 */
void VentanaPrincipal::boton_wiimote_calibrar()
{
    MENSAJE_DEBUG(1, "Botón calibrar clicado");

    if ( m_wii_cursorgestor.calibrado() )
        imprime_salida("Calibración satisfactoria");
    else
        imprime_salida("[ESC] Apretado durante el calibrado o error inesperado");
}

/*
 * Un click en el icono de la barra de estados
 *
 */
void VentanaPrincipal::icono_estado_click()
{
    MENSAJE_DEBUG(1, "Icono estado clicado");

    gtkmm_ventana_principal->property_visible() = !gtkmm_ventana_principal->property_visible();
}

/*
 * Manejador del menu del icono de la bara de estado
 *
 */
void VentanaPrincipal::icono_estado_menu(guint boton, guint32 tiempo_activacion)
{
    MENSAJE_DEBUG(1, "Icono estado menu clicado");

    gtkmm_icono_estado->popup_menu_at_position(*gtkmm_icono_estado_menu, boton, tiempo_activacion);
}

/*
 * Salir de la aplicacion
 */
void VentanaPrincipal::menu_salir_click()
{
    MENSAJE_DEBUG(1, "Menu salir clicado");

    if ( m_wii_cursorgestor.conectado() )
    {
        MENSAJE_DEBUG(1, "Wiimotes conectado. Desconectando...");
        boton_wiimote_con_des();
    }

    MENSAJE_DEBUG(1, "Saliendo GUI principal");
    gtkmm_principal.quit();
}

/*
 * Cerrar la aplicacion principal y mandarla al icono de estado
 */
void VentanaPrincipal::menu_cerrar_click()
{
    MENSAJE_DEBUG(1, "GUI Principal cerrada");

    gtkmm_ventana_principal->hide();
}

/*
 * Dialogo about
 */
void VentanaPrincipal::menu_sobre_click()
{
    MENSAJE_DEBUG(1, "Dialogo sobre abriendo");

    gtkmm_dialogo_sobre->show();
}

/*
 * respuesta dialogo about, para que se cierre, lo oculta
 */
void VentanaPrincipal::dialogo_sobre_respuesta(int id_respuesta)
{
    MENSAJE_DEBUG(1, "Dialogo sobre respondiendo");

    switch (id_respuesta)
    {
        case Gtk::RESPONSE_CANCEL:
            gtkmm_dialogo_sobre->hide();
            break;
        default:
            break;
    }
}

/*
 * empieza a buscar la conexión del wiimote
 */
void VentanaPrincipal::wiicursorgestor_empezar_conexion()
{
    unsigned int const indice = m_wii_cursorgestor.conectado() + 1;

    // Advertencia: C function. I'd have used std::ostringstream if not for l10n.
    char salida[1024];
    sprintf(salida, "Conectando al wiimote #%d... ", indice);
    imprime_salida(salida);
    gtkmm_etiqueta_numero_wiimote->set_text(salida);
    gtkmm_ventana_conexion->show();
    MENSAJE_DEBUG(1, "Ventana de conexion abierta por el wiimote #%d...\n");

    sigc_tick_barraprogreso_conexion = Glib::signal_timeout().connect(sigc::mem_fun(*this, &VentanaPrincipal::ventana_conexion_barraprogreso_tick), 50 );

}

/*
 * Termina la conexion con el wiimote
 */
void VentanaPrincipal::wiicursorgestor_acabar_conexion()
{
    bool const conectado = m_wii_cursorgestor.ultima_conexion_satisfactoria();

    imprime_salida(conectado ? ("Funciona!") : ("Error!"), false);

    sigc_tick_barraprogreso_conexion.disconnect();
    MENSAJE_DEBUG(1, "Barra de progreso desactivada");

    gtkmm_ventana_conexion->hide();
    MENSAJE_DEBUG(1, "Ventana de conexion cerrada");
}

/*
 * termina la conexion con el wiimote
 */
void VentanaPrincipal::wiicursorgestor_done_conexion()
{
    MENSAJE_DEBUG(1, "Conectado a todos los wiimote");

    unsigned int const numero_de_conectados = m_wii_cursorgestor.conectado();

    sincroniza_estado_wiimote_conexion(false);
    // WARNING: C function. I'd have used std::ostringstream if not for l10n.
    if (numero_de_conectados)
    {
        char salida[1024];
        sprintf(salida, ("Conectado a los %d wiimotes, cargando configuraciones"), numero_de_conectados);
        imprime_salida(salida);

        if ( m_configurador.cargar_config_wiimotes() )
            imprime_salida("Hecho!. Click 'activar' para usar el boli infrarrojos");
        else
            imprime_salida("Error");

        sincroniza_estado_wiimote(true);
    }
    else
        imprime_salida("Imposible conectar a ningun wiimote");
}

/*
 * genera un 'pulso' en la barra de progreso para moverla
 */
bool VentanaPrincipal::ventana_conexion_barraprogreso_tick()
{
    gtkmm_conexion_barraprogreso->pulse();

    return true;
}

/*
 * Si se apreta la tecla 'ESC' se minimiza el programa
 */
bool VentanaPrincipal::tecla_apretada(GdkEventKey* event)
{
    MENSAJE_DEBUG(1, "Tecla apretada en la ventana principal");

    bool const voy_a_cerrar = (event->keyval == GDK_Escape);

    if (voy_a_cerrar)
        menu_cerrar_click();

    return true;
}

/*
 * imprime la salida del texto por el textbox que hay en la ventana principal
 */
void VentanaPrincipal::imprime_salida(char const* texto)
{
    imprime_salida(texto, true);
}

void VentanaPrincipal::imprime_salida(char const* texto, bool anyadir_marca_tiempo)
{
    MENSAJE_DEBUG(3, "Imprimir mensajes a la aplicación principal");

    if (anyadir_marca_tiempo)
    {

        time_t const tiempo_actual = time(0);
        tm const* const _tm = localtime(&tiempo_actual);



        char tiempo_actual_texto[12];
        sprintf(tiempo_actual_texto, "(%.2d:%.2d:%.2d) ", _tm->tm_hour, _tm->tm_min, _tm->tm_sec);


        glib_buffer_salida->insert(glib_buffer_salida->end(), tiempo_actual_texto);
        MENSAJE_DEBUG(4, "Tiempo añadido");
        Gtk::TextBuffer::iterator texto_tiempo_inicio = glib_buffer_salida->end();
        texto_tiempo_inicio.backward_chars( sizeof(tiempo_actual_texto) );
        glib_buffer_salida->apply_tag( glib_texto_tiempo, texto_tiempo_inicio, glib_buffer_salida->end() );
        MENSAJE_DEBUG(4, "TAG añadido");
    }

    glib_buffer_salida->insert(glib_buffer_salida->end(), texto);
    MENSAJE_DEBUG(4, "Añadido el mensaje");


    Gtk::Adjustment *const vadj = gtkmm_salida_scroll->get_vadjustment();
    vadj->set_value( vadj->get_upper() );

    MENSAJE_DEBUG(4, "Ajustada la barra de scroll");

    //MENSAJE_DEBUG(3, "mensaje imprimido");
}

/*
 * cambia los estados de los botones según el estado
 */
void VentanaPrincipal::sincroniza_estado_activo(bool activado)
{
    MENSAJE_DEBUG(1, "Estado: '%s'. sincronizando botones\n", activado ? "activado" : "desactivado");

    gtkmm_boton_activar->set_label(activado ? ("Desactivar") : ("Activar"));
    gtkmm_boton_calibrar->set_sensitive(!activado);
    gtkmm_eim_activar->set_sensitive(!activado);
    gtkmm_eim_desactivar->set_sensitive(activado);
    gtkmm_eim_calibrar->set_sensitive(!activado);
}

/*
 * cambia las etiquetas de los botones según el estado
 */
void VentanaPrincipal::sincroniza_estado_wiimote(bool conectado)
{
    MENSAJE_DEBUG(1, "Estado conexión wiimote '%s'. sincronizando botones\n", conectado ? "conectado" : "desconectado");

    gtkmm_boton_conectar->set_label(conectado ? "Desconectar" : "Conectar");
    gtkmm_boton_activar->set_sensitive(conectado);
    gtkmm_boton_calibrar->set_sensitive(conectado);

    gtkmm_eim_conectar->set_sensitive(!conectado);
    gtkmm_eim_desconectar->set_sensitive(conectado);
    gtkmm_eim_activar->set_sensitive(conectado);
    gtkmm_eim_desactivar->set_sensitive(false);
    gtkmm_eim_calibrar->set_sensitive(conectado);
}

/*
 *
 */
void VentanaPrincipal::sincroniza_estado_wiimote_conexion(bool empezando)
{
    MENSAJE_DEBUG(1, "Estado wiimote conexion: '%s'. sincronizando botones\n", empezando ? "empezando" : "acabado");

    gtkmm_boton_conectar->set_sensitive(!empezando);
    gtkmm_eim_conectar->set_sensitive(!empezando);
}
