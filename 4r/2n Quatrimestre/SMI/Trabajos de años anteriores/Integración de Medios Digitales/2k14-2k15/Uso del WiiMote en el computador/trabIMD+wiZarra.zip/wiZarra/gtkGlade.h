/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#ifndef  __GTKGLADE_H__
#define  __GTKGLADE_H__


#include <gtkmm.h>
#include <libglademm.h>
#include <string>
#include <cstdio>
#include <glib.h>

#include "wiicursorgestor.h"
#include "configurador.h"
#include "comun.h"



void wii_izquierda_clicked(WiiDatosEvento const& data);
void wii_boton_derecha_abajo(WiiDatosEvento const& data);
void wii_boton_derecha_arriba(WiiDatosEvento const& data);
void wii_empezar_click_y_mover(WiiDatosEvento const& data);
void wii_fin_click_y_mover(WiiDatosEvento const& data);
void wii_raton_movido(WiiDatosEvento const& data);


class VentanaPrincipal {
public:
    VentanaPrincipal(int argc,char *argv[]);


    int start();
private:

    void boton_wiimote_con_des();
    void boton_wiimote_activar();
    void boton_wiimote_calibrar();
    void icono_estado_click();
    void icono_estado_menu(guint boton, guint32 tiempo_activacion);
    void menu_cerrar_click();
    void menu_sobre_click();
    void menu_salir_click();
    void dialogo_sobre_respuesta(int id_respuesta);
    void wiicursorgestor_empezar_conexion();
    void wiicursorgestor_acabar_conexion();
    void wiicursorgestor_done_conexion();
    bool ventana_conexion_barraprogreso_tick();
    bool tecla_apretada(GdkEventKey* event);

    void imprime_salida(char const* texto);
    void imprime_salida(char const* texto, bool anyadir_marca_tiempo);


    void sincroniza_estado_activo(bool activacion);
    void sincroniza_estado_wiimote(bool wiimote_is_connected);
    void sincroniza_estado_wiimote_conexion(bool starting);


    Gtk::Main gtkmm_principal;
    Gtk::Window* gtkmm_ventana_principal;
    Gtk::ScrolledWindow* gtkmm_salida_scroll;
    Gtk::TextView* gtkmm_salida_texto;
    Glib::RefPtr<Gtk::TextBuffer> glib_buffer_salida;
    Gtk::Button* gtkmm_boton_conectar;
    Gtk::Button* gtkmm_boton_activar;
    Gtk::Button* gtkmm_boton_calibrar;

    Glib::RefPtr<Gtk::StatusIcon> gtkmm_icono_estado;
    Gtk::Menu* gtkmm_icono_estado_menu;
    Gtk::MenuItem* gtkmm_eim_conectar;
    Gtk::MenuItem* gtkmm_eim_desconectar;
    Gtk::MenuItem* gtkmm_eim_activar;
    Gtk::MenuItem* gtkmm_eim_desactivar;
    Gtk::MenuItem* gtkmm_eim_calibrar;
    Gtk::MenuItem* gtkmm_eim_cerrar;

    Gtk::MenuItem* gtkmm_menu_cerrar;
    Gtk::MenuItem* gtkmm_menu_salir;
    Gtk::MenuItem* gtkmm_menu_sobre;
    Gtk::MenuItem* gtkmm_menu_instrucciones;

    Gtk::AboutDialog* gtkmm_dialogo_sobre;

    Gtk::Window* gtkmm_ventana_conexion;
    Gtk::Label* gtkmm_etiqueta_numero_wiimote;
    Gtk::ProgressBar* gtkmm_conexion_barraprogreso;
    sigc::connection sigc_tick_barraprogreso_conexion;

    Gtk::Window* gtkmm_ventana_instrucciones;
    Gtk::Button* gtkmm_boton_instrucciones_cerrar;

    Glib::RefPtr<Gtk::TextTag> glib_texto_tiempo;


    Configurador& m_configurador;
    WiiCursorGestorEventosConexion eventos_conexion;
    WiiCursorGestor m_wii_cursorgestor;
};


#endif /* __GTKGLADE_H__ */
