/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#include "configurador.h"
#include "gtkGlade.h"
#include "comun.h"


/*
 * Programa principal, punto de entrada
 */
int main(int argc,char *argv[])
{
    MENSAJE_DEBUG(1, "Arranca el programa");

    //Se inicializa los threads de las librerias GDK y Glib
    g_thread_init(0);
    gdk_threads_init();
    MENSAJE_DEBUG(1, "Threads de Glib y GDK inicializadas");

    //get_configurador();
    MENSAJE_DEBUG(1, "Configuracion inicializada");

    VentanaPrincipal ventana_principal(argc, argv);
    //Se crea la ventana principal y se arranca (start muestra la ventana)
    return ventana_principal.start();
}
