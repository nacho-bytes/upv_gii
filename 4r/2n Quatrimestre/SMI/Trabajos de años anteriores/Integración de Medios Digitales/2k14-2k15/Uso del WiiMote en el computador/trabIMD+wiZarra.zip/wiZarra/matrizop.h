/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#ifndef __MATRIZOP_H__
#define __MATRIZOP_H__


#include <vector>
#include <iostream>

#include "comun.h" // ASSERT


// Operaciones con matriz 2D de dos tipos
template<typename T>
struct Matrix
{
    public:
        Matrix(unsigned int filas, unsigned int columnas);
        Matrix(Matrix<T> const& m);

        T* operator[](unsigned int filas);
        T const* operator[](unsigned int filas) const;
        T* elementos();
        T const* elementos() const;

        Matrix<T>& invert(); // Invertir
        Matrix<T>& transpose(); // Transponer

        unsigned int filas() const;
        unsigned int columnas() const;
    private:
        unsigned int m_filas;
        unsigned int m_columnas;

        std::vector<T> m_e;
};


//Operaciones artiméticas
template<typename T>
Matrix<T> operator*(Matrix<T> const m1, Matrix<T> const m2);


//Para otras funciones
typedef double matriz_elem_t;
typedef Matrix<matriz_elem_t> matriz_t;


// IMPLEMENTACION
template<typename T>
Matrix<T>::Matrix(unsigned int filas, unsigned int columnas) :
    m_filas(filas),
    m_columnas(columnas),
    m_e( filas*columnas )
{
    ASSERT( (filas != 0) && (columnas != 0), "Numero de columnas/filas invalido" );
}

template<typename T>
Matrix<T>::Matrix(Matrix<T> const& m)
{
    m_filas = m.filas();
    m_columnas = m.columnas();
    m_e.assign( m.elementos(), m.elementos() + m.filas()*m.columnas() );
}


template<typename T>
T* Matrix<T>::operator[](unsigned int filas)
{
    return &m_e.at(m_columnas*filas);
}
template<typename T>
T const* Matrix<T>::operator[](unsigned int filas) const
{
    return &m_e.at(m_columnas*filas);
}
template<typename T>
T* Matrix<T>::elementos()
{
    return &m_e[0];
}
template<typename T>
T const* Matrix<T>::elementos() const
{
    return &m_e[0];
}


template<typename T>
Matrix<T>& Matrix<T>::invert()
{
    T const det = matrizDeterminante(*this);
    Matrix const temp = matrixCofactor(*this).transpose();
    T const* temp_elementos = temp.elementos();

    unsigned int const n_elementos = m_filas*m_columnas;
    for(unsigned int i = 0; i != n_elementos; ++i)
        m_e[i] = temp_elementos[i] / det;

    return *this;
}
template<typename T>
Matrix<T>& Matrix<T>::transpose()
{
    Matrix<T> const c = *this;

    for (unsigned int i = 0; i != m_filas; ++i)
        for(unsigned int j = 0; j != m_columnas; ++j)
            (*this)[j][i] = c[i][j];

    return *this;
}


template<typename T>
unsigned int Matrix<T>::filas() const
{
    return m_filas;
}
template<typename T>
unsigned int Matrix<T>::columnas() const
{
    return m_columnas;
}


template<typename T>
Matrix<T> operator*(Matrix<T> const m1, Matrix<T> const m2)
{
    return matrixMul(m1, m2);
}

template<typename T>
std::ostream& operator<<(std::ostream& out, Matrix<T> const& m)
{
    unsigned int const n_elementos = m.filas()*m.columnas();
    T const*const elementos = m.elementos();
    for (unsigned int i = 0; i != n_elementos; ++i)
	out << elementos[i] << " ";

    return out;
}
template<typename T>
std::istream& operator>>(std::istream& isn, Matrix<T>& m)
{
    T* elementos = m.elementos();
    while (isn >> *elementos)
        ++elementos;

    return isn;
}

/*
template<typename T>
void matrixPrint(Matrix<T> const& m)
{
    unsigned int const n_elementos = m.filas()*m.columnas();
    T const*const elementos = m.elementos();
    for (unsigned int i = 0; i != n_elementos; ++i)
    {
	printf("%03.2f ", elementos[i]);
	if (!(i / m.columnas()))
	    printf ("\n");
    }
}
*/

template<typename T>
Matrix<T> matrizCoef(Matrix<T> const& m, unsigned int x, unsigned int y)
{
    Matrix<T> c = Matrix<T>( m.filas()-1, m.columnas()-1 );

    unsigned int xx = 0;
    for (unsigned int i = 0; i != m.filas(); ++i)
	if (i != x)
	{
	    unsigned int yy = 0;
	    for (unsigned int j = 0; j != m.columnas(); ++j)
            if (j != y)
            {
                c[xx][yy] = m[i][j];
                ++yy;
            }
        ++xx;
	}

    return c;
}

template<typename T>
T matrizDeterminante(Matrix<T> const& m)
{
    T devolver = 0.0;

    if ((m.filas() == 2) && (m.columnas() == 2))
    {
        devolver = m[0][0]*m[1][1] - m[0][1]*m[1][0];
    }
    else
    {
        for (unsigned int i = 0; i != m.filas(); ++i)
        {
            Matrix<T> const cofactor = matrizCoef(m, i, 0);
            T const p = (i % 2) ? -1.0 : 1.0;
            devolver += m[i][0]*p*matrizDeterminante(cofactor);
        }
    }

    return devolver;
}

template<typename T>
Matrix<T> matrixCofactor(Matrix<T> const& m)
{
    Matrix<T> devolver = Matrix<T>(m.filas(), m.columnas());

    for (unsigned int i = 0; i != m.filas(); ++i)
        for (unsigned int j = 0; j != m.columnas(); ++j)
        {
            T const p = ((i+j) % 2) ? -1.0 : 1.0;

            Matrix<T> const cc = matrizCoef(m, i, j);
            T const f = p*matrizDeterminante(cc);

            devolver[i][j] = f;
        }

    return devolver;
}


template<typename T>
Matrix<T> matrixMul(Matrix<T> const& m, Matrix<T> const& n)
{
    Matrix<T> devolver = Matrix<T>(n.filas(), m.columnas());

    for (unsigned int j = 0; j != devolver.columnas(); ++j)
        for (unsigned int k = 0; k != n.filas(); ++k)
        {
            T total = 0.0;
            for (unsigned int i = 0; i != m.filas(); ++i)
                total += m[i][j] * n[k][i];
            devolver[k][j] = total;
        }

    return devolver;
}


#endif /* __MATRIZOP_H__ */
