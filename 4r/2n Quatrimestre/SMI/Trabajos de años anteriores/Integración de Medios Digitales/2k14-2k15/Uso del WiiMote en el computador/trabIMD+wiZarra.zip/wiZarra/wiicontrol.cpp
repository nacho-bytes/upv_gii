/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#include <cwiid.h>
#include "wiicontrol.h"


/*
 *  Cambiar el estado de los led del wiimote
 */
void poner_estado_led(cwiid_wiimote_t *wiimote, unsigned char estado_led)
{
    if (cwiid_command(wiimote, CWIID_CMD_LED, estado_led))
    {
        MENSAJE_DEBUG(4, "Error poniendo los LED");
    }
}

/*
 *  Cambiar el estado de modo informe del wiimote, para obtener resultados
 */
void set_rpt_mode(cwiid_wiimote_t *wiimote, unsigned char rpt_mode)
{
    if (cwiid_command(wiimote, CWIID_CMD_RPT_MODE, rpt_mode))
    {
        MENSAJE_DEBUG(4, "Error poniendo el modo informe del wiimote");
    }
}

/*
 *  Conectar con el wiimote
 */
cwiid_wiimote_t* conectar_wiimote(char *direccion_mac)
{

    bdaddr_t bdaVar;
    if (!direccion_mac)
        bdaVar = *BDADDR_ANY;
    else
        str2ba(direccion_mac, &bdaVar);

    /* Conectar al wiimote */
    cwiid_wiimote_t* wiimote = 0;
    if ((wiimote = cwiid_open(&bdaVar, 0)))
    {
        MENSAJE_DEBUG(1, "Conectado al wiimote");

        poner_estado_led(wiimote, WIIMOTE_LED_CONNECTED);
        set_rpt_mode(wiimote, CWIID_RPT_IR | CWIID_RPT_BTN);

        return wiimote;
    }
    else
        MENSAJE_DEBUG(1, "Imposible conectar al wiimote");

    return 0;
}

/*
 *  Desconecta el wiimote
 */
int desconectar_wiimote(cwiid_wiimote_t* wiimote)
{
    /* poner_estado_led(wiimote,0); */
    return cwiid_disconnect(wiimote);
}


/* Envia los movimientos y botones a procesar()
 * Devuelve -1 si hay error
 * ir_pos.x = POSICION_IR_INVALIDA cuando no hay un evento IR valido
 */
int procesar_mensaje(cwiid_mesg const& mensaje, point_t* ir_pos, uint16_t* botones)
{
    int devolver = 0;

    switch (mensaje.type)
    {
        case CWIID_MESG_BTN:
            if (botones)
            {
                MENSAJE_DEBUG(4, "Informe de botones: %.4X", mensaje.btn_mesg.buttons);
                *botones = mensaje.btn_mesg.buttons;
            }
	    break;
	case CWIID_MESG_IR:
	    /* Aviso: Solo se utiliza el primer punto
	     */
	    if (ir_pos)
	    {
            std::vector<point_t> ir_s;
            for (unsigned int i = 0; i != CWIID_IR_SRC_COUNT; ++i)
            {
                cwiid_ir_src const& actual = mensaje.ir_mesg.src[i];
                if (actual.valid)
                    ir_s.push_back(point_t(actual.pos[CWIID_X], actual.pos[CWIID_Y]));
            }
            // Encuentra el nuevo IR
            point_t const ir_ant = *ir_pos;
            ir_pos->x = POSICION_IR_INVALIDA; // Posicion IR no valida
            unsigned int distancia_cercana = static_cast<unsigned int>(-1);
            for (unsigned int i = 0; i != ir_s.size(); ++i)
            {
                unsigned int const distancia = distancia_euclidea(ir_s[i], ir_ant);
                if ( distancia_cercana > distancia )
                {
                    distancia_cercana = distancia;
                    *ir_pos = ir_s[i];
                }
            }
	    }
	    break;
	case CWIID_MESG_ERROR:
	    devolver = -1;
	    break;
	default:
	    break;
    }

    return devolver;
}
