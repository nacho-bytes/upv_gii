/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#include "wiicursor.h"


/*
 *  Funcion del thread de wiicrusor
 */
void* wiicursor_thread_funcion(void* puntero)
{
    MENSAJE_DEBUG(3, "Entrando wiicursor_thread_funcion");

    ASSERT(puntero != 0, "Sin datos pasados");
    WiiThreadFuncionesDatos& datos = *static_cast<WiiThreadFuncionesDatos*>(puntero);
    ASSERT(datos.este_hilo != 0, "El thread todavia vive");

    WiiCursor wc;
    wc.eventos() = datos.eventos;
    wc.procesar(datos.wiimotes, datos.hilo_ejecutado); // Loop principal

    for (std::vector<WiimoteDatos>::iterator iteracion = datos.wiimotes.begin(); iteracion != datos.wiimotes.end(); ++iteracion)
    {
        MENSAJE_DEBUG(1, "Desactivando el informe de eventos Wiimote #%d...\n", iteracion-datos.wiimotes.begin());
        cwiid_disable(iteracion->wiimote, CWIID_FLAG_MESG_IFC);
    }

    MENSAJE_DEBUG(3, "Saliendo wiicursor_thread_funcion");


    return 0;
}

/*
 *  Crea el thread para el wiicursor
 */
void empezar_thread_wiicursor(WiiThreadFuncionesDatos& datos)
{
    MENSAJE_DEBUG(1, "Empezando el hilo para wiicursor");

    if (!datos.hilo_ejecutado)
    {
        datos.hilo_ejecutado = true;
        pthread_create(&datos.este_hilo, 0, &wiicursor_thread_funcion, &datos);
    }
}

/*
 *  Termina el thread para el wiicursor
 */
void acabar_wiicursor_thread(WiiThreadFuncionesDatos& datos)
{
    MENSAJE_DEBUG(1, "Acabando el hilo para wiicursor");

    if (datos.hilo_ejecutado)
    {
        datos.hilo_ejecutado = false;
        pthread_join(datos.este_hilo, 0);
    }
}

/*
 *
 */
void WiiCursor::funcion_thread_click_der()
{
    // Pone el timer
    delta_t_t ultima_vez = 0;
    obtener_delta_t(ultima_vez);
    //
    datos_thread.movido = 0;
    datos_thread.esperado = 0;

    while (datos_thread.all_ejecutando())
    {
        if (datos_thread.click_derecho())
        {
            datos_thread.eventos.boton_derecho_abajo(datos_thread.datos_evento);
            break;
        }
        else
            datos_thread.esperado += obtener_delta_t(ultima_vez);

        if (datos_thread.click_y_arrastre())
        {
            datos_thread.eventos.empezar_click_arrastre(datos_thread.datos_evento);
            break;
        }
        else
        {
            if (datos_thread.ir.x != POSICION_IR_INVALIDA)
                datos_thread.movido = distancia_euclidea(datos_thread.ir, datos_thread.ir_raton_abajo);
        }
    }
}

/*
 *
 */
void WiiCursor::hilo_click_derecho_empieza()
{
    if (!datos_thread.hilo_ejecutado)
    {
        datos_thread.hilo_ejecutado = true;
        datos_thread.este_hilo = Glib::Thread::create(sigc::mem_fun(*this, &WiiCursor::funcion_thread_click_der), true);
    }
}

/*
 *
 */
void WiiCursor::hilo_click_derecho_acaba()
{
    if (datos_thread.hilo_ejecutado)
    {
        datos_thread.hilo_ejecutado = false;
        datos_thread.este_hilo->join();
    }
}


/*
 *
 */
void WiiCursor::procesar(std::vector<WiimoteDatos>& wiimotes, bool const& ejecutando)
{
    for (std::vector<WiimoteDatos>::iterator iteracion = wiimotes.begin(); iteracion != wiimotes.end(); ++iteracion)
    {
        MENSAJE_DEBUG(1, "Activando informe de eventos y señal nonblock Wiimote #%d...\n", iteracion-wiimotes.begin());
        cwiid_enable(iteracion->wiimote, CWIID_FLAG_MESG_IFC);
        cwiid_disable(iteracion->wiimote, CWIID_FLAG_NONBLOCK);
    }

    datos_thread.ejecutando = &ejecutando;

    //Mientras el thread se ejecute se obtienen los eventos y se procesan
    while (ejecutando)
    {
        std::vector<WiiEvento> eventos;
        get_datos_eventos_wiis(wiimotes, datos_thread.ir, eventos);
        for (std::vector<WiiEvento>::const_iterator iteracion = eventos.begin(); iteracion != eventos.end(); ++iteracion)
        {
            switch (iteracion->tipo)
            {
            case WII_EVENTO_TIPO_BOTON:
                //ejecutando = false;
                break;
            case WII_EVENTO_TIPO_IR:
                procesar_ir_events(iteracion->ir, iteracion->transformada);
                break;
            case WII_EVENTO_TIPO_SIN_EVENTO:
            default:
                break;
	    }
	}
    }
}

/*
 *  Recoge los eventos del wiimote y los procesa
 */
void get_datos_eventos_recoge_todos_eventos(std::vector<WiimoteDatos>& wiimotes, point_t const& ir_ant, std::vector< std::vector<WiiEvento> >& vector_eventos, unsigned int& max_eventos)
{
    for (unsigned int i = 0; i != wiimotes.size(); ++i)
    {
        int msj_cont = 0;
        cwiid_mesg* mensaje = 0;
        // Aviso: API cambiado en GUTSY
        #ifdef COMPATIBILITY_GUTSY
            cwiid_get_mesg(wiimotes[i].wiimote, &msj_cont, &mensaje);
        #else
            timespec tspec;
            cwiid_get_mesg(wiimotes[i].wiimote, &msj_cont, &mensaje, &tspec);
        #endif // COMPATIBILITY_GUTSY

        vector_eventos[i].resize(msj_cont);
        for (int i = 0; i != msj_cont; ++i)
        {
            WiiEvento& evento_actual = vector_eventos[i][i];
            evento_actual.ir = ir_ant;
            evento_actual.boton = BOTON_MSG_ID_INVALIDO;
            procesar_mensaje(mensaje[i], &evento_actual.ir, &evento_actual.boton);

            evento_actual.tipo = (evento_actual.boton != BOTON_MSG_ID_INVALIDO) ? WII_EVENTO_TIPO_BOTON : WII_EVENTO_TIPO_IR;
        }

        if (max_eventos < static_cast<unsigned int>(msj_cont))
            max_eventos = static_cast<unsigned int>(msj_cont);
    }
}

/*
 *  Implementado para más de un wiimote, rebalancea el numero de eventos
 */
void get_wiis_event_data_rebalance_events(unsigned int max_eventos, std::vector<std::vector<WiiEvento> >& vector_eventos)
{
    for (std::vector< std::vector<WiiEvento> >::iterator iter = vector_eventos.begin(); iter != vector_eventos.end(); ++iter)
	iter->insert( iter->end(), max_eventos-iter->size(), WiiEvento() );
}

/*
 *
 */
void wii_evento_datos_procesa_eventos(
    std::vector< std::vector<WiiEvento> > const& vector_eventos,
    unsigned int indice_evento_actual,
    std::vector<WiimoteDatos> const& wiimotes,
    point_t const& ir_ant,
    std::vector<point_t>& irs,
    std::vector<matriz_t const*>& transformadas,
    std::vector<WiiEvento>& eventos)
{
    for (unsigned int i = 0; i != vector_eventos.size(); ++i)
    {
        switch (vector_eventos[i][indice_evento_actual].tipo)
        {
        case WII_EVENTO_TIPO_BOTON:
            eventos.push_back(WiiEvento(vector_eventos[i][indice_evento_actual].boton));
            break;
	    case WII_EVENTO_TIPO_IR:
            irs.push_back(vector_eventos[i][indice_evento_actual].ir);
            transformadas.push_back(&wiimotes[i].transformada);
            break;
	    case WII_EVENTO_TIPO_SIN_EVENTO:
	    default:
            break;
        }
    }

    int indice_ir_cercano = -1;
    unsigned int distancia_cercana = static_cast<unsigned int>(-1);
    ASSERT(irs.size() == transformadas.size(), "Matriz de transformacion erronea");
    for (std::vector<point_t>::const_iterator iteracion = irs.begin(); iteracion != irs.end(); ++iteracion)
        if (iteracion->x != POSICION_IR_INVALIDA)
        {
            unsigned int const distancia = distancia_euclidea(*iteracion, ir_ant);
            if ( distancia_cercana > distancia )
            {
                distancia_cercana = distancia;
                indice_ir_cercano = iteracion - irs.begin();
                break;
            }
        }
    if (indice_ir_cercano != -1)
        eventos.push_back(WiiEvento(irs[indice_ir_cercano], transformadas[indice_ir_cercano]));
    else
        eventos.push_back(WiiEvento(point_t(POSICION_IR_INVALIDA, 0), 0));
}

/*
 *
 */
void get_datos_eventos_wiis(std::vector<WiimoteDatos>& wiimotes, point_t const& ir_ant, std::vector<WiiEvento>& eventos)
{
    // Busca los eventos que se esperan y los introduce en datos_evento
    // luego los procesa

    std::vector< std::vector<WiiEvento> > vector_eventos(wiimotes.size());

    unsigned int max_eventos = 0;
    get_datos_eventos_recoge_todos_eventos(wiimotes, ir_ant, vector_eventos, max_eventos);
    get_wiis_event_data_rebalance_events(max_eventos, vector_eventos);

    for (unsigned int i = 0; i != max_eventos; ++i)
    {
        std::vector<point_t> irs;
        std::vector<matriz_t const*> transformadas;
        wii_evento_datos_procesa_eventos(vector_eventos, i, wiimotes, ir_ant, irs, transformadas, eventos);
    }
}

/*
 *  procesar los eventos IR
 */
void WiiCursor::procesar_ir_events(point_t ir_nuevo, matriz_t const* transformada)
{
    point_t const ir_ant = datos_thread.ir;

    ir_nuevo = filtro_ir.procesar(ir_nuevo);
    datos_thread.ir = ir_nuevo;

    if (ir_nuevo.x != POSICION_IR_INVALIDA) // Movimiento del raton solo si los datos son validos
    {
        if (transformada)
            datos_thread.datos_evento.cursor_pos = datos_infrarrojos(ir_nuevo, *transformada);

	    //Se usa el evento aunque el cursor no se mueva
        datos_thread.eventos.raton_movido(datos_thread.datos_evento);
    }

    if ( (ir_nuevo.x != POSICION_IR_INVALIDA) && (ir_ant.x == POSICION_IR_INVALIDA))
    {
        datos_thread.ir_raton_abajo = ir_nuevo;
        hilo_click_derecho_empieza();
        datos_thread.eventos.raton_arriba(datos_thread.datos_evento);
    }

    if ( (ir_nuevo.x == POSICION_IR_INVALIDA) && (ir_ant.x != POSICION_IR_INVALIDA))
    {
        datos_thread.eventos.raton_abajo(datos_thread.datos_evento);

        if ( datos_thread.click_y_arrastre())
        {
            datos_thread.eventos.fin_click_arrastre(datos_thread.datos_evento);
        }
        else
        {
            if (!datos_thread.click_derecho())
            {
                datos_thread.eventos.click_izq(datos_thread.datos_evento);
            }
            else
                datos_thread.eventos.boton_derecho_arriba(datos_thread.datos_evento);
        }
        hilo_click_derecho_acaba();
    }
}
