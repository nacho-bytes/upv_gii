/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#ifndef  __WIICURSOR_H__
#define  __WIICURSOR_H__


#include <cwiid.h>
#include <pthread.h>
#include <sigc++/sigc++.h>
#include <vector>
#include <glibmm.h>

#include "configurador.h"
#include "funciones.h"
#include "comun.h"
#include "eventos.h"
#include "wiicontrol.h"
#include "filtroir.h"



struct WiiDatosEvento
{
    WiiDatosEvento(point_t const& ir_pos, point_t const& ir_raton_abajo, delta_t_t const& esperado, unsigned int const& tolerancia_mov) :
        ir_pos(ir_pos),
        ir_raton_abajo(ir_raton_abajo),
        esperado(esperado),
	tolerancia_mov(tolerancia_mov)
    {
    }

    point_t const& ir_pos;
    point_t const& ir_raton_abajo;
    point_t cursor_pos;
    delta_t_t const& esperado;
    unsigned int const& tolerancia_mov;
};

struct WiiEventos
{
    typedef sigc::slot<void, WiiDatosEvento const&> WiiEventoSlotTipo;

    WiiEventoSlotTipo    click_izq, boton_derecho_abajo, boton_derecho_arriba,
                        empezar_click_arrastre, fin_click_arrastre,
                        raton_arriba, raton_abajo, raton_movido;
};



struct WiiThreadFuncionesDatos
{
    WiiThreadFuncionesDatos(std::vector<WiimoteDatos>& wiimotes) :
	wiimotes(wiimotes),
	este_hilo(0),
	hilo_ejecutado(false)
    {

    }

    std::vector<WiimoteDatos>& wiimotes;
    WiiEventos eventos;

    pthread_t este_hilo;
    bool hilo_ejecutado;
};


enum WiiEventoTipo {
    WII_EVENTO_TIPO_BOTON,
    WII_EVENTO_TIPO_IR,
    WII_EVENTO_TIPO_SIN_EVENTO,
};

void* wiicursor_thread_funcion(void* ptr);
void empezar_thread_wiicursor(WiiThreadFuncionesDatos& datos);
void acabar_wiicursor_thread(WiiThreadFuncionesDatos& datos);

struct WiiEvento
{
    WiiEvento():tipo(WII_EVENTO_TIPO_SIN_EVENTO)
    {
    }

    WiiEvento(uint16_t boton) :
	tipo(WII_EVENTO_TIPO_BOTON),
	boton(boton)
    {
    }

    WiiEvento(point_t ir, matriz_t const* transformada) :
	tipo(WII_EVENTO_TIPO_IR),
	ir(ir),
	transformada(transformada)
    { }
    WiiEventoTipo tipo;
    uint16_t boton;
    point_t ir;
    matriz_t const* transformada;
};

void get_datos_eventos_wiis(std::vector<WiimoteDatos>& wiimotes, point_t const& ir_ant, std::vector<WiiEvento>& eventos);

void get_datos_eventos_recoge_todos_eventos(std::vector<WiimoteDatos>& wiimotes, point_t const& ir_ant, std::vector< std::vector<WiiEvento> >& vector_eventos, unsigned int& max_eventos);

void get_wiis_event_data_rebalance_events(unsigned int max_eventos, std::vector< std::vector<WiiEvento> >& vector_eventos);

void wii_evento_datos_procesa_eventos(std::vector< std::vector<WiiEvento> > const& vector_eventos,
    unsigned int indice_evento_actual,
    std::vector<WiimoteDatos> const& wiimotes,
    point_t const& ir_ant,
    std::vector<point_t>& irs,
    std::vector<matriz_t const*>& transformadas,
    std::vector<WiiEvento>& eventos);


class WiiCursor
{
public:
    WiiCursor() :
	filtro_ir(datos_thread.ir, datos_thread.tolerancia_mov)
    {
        }

    void procesar(std::vector<WiimoteDatos>& wiimotes, bool const& ejecutando);

    WiiEventos& eventos()
    {
        return datos_thread.eventos;
    }
private:
    void procesar_ir_events(point_t ir_nuevo, matriz_t const* transformada);

    struct WiiCursorDatosHilo
    {
	WiiCursorDatosHilo() :
	    ir(POSICION_IR_INVALIDA, 0),
	    ir_raton_abajo(POSICION_IR_INVALIDA, 0),
	    esperado(0),
	    movido(0),
	    hilo_ejecutado(false),
	    este_hilo(0),
	    tolerancia_mov(0),
	    tolerancia_espera( get_configurador().tolerancia_espera() ),
	    ejecutando(0),
	    datos_evento(ir, ir_raton_abajo, esperado, tolerancia_mov)
	{ }

	bool click_y_arrastre() const { return movido > cuadrado(tolerancia_mov); }
	bool click_derecho() const { return esperado > tolerancia_espera; }
	bool all_ejecutando() const { return *ejecutando && hilo_ejecutado; }


	point_t ir;
	point_t ir_raton_abajo;
	delta_t_t esperado;
	unsigned int movido;
	bool hilo_ejecutado;
	Glib::Thread* este_hilo;

	unsigned int tolerancia_mov;
	delta_t_t const& tolerancia_espera;
	bool const* ejecutando;

	WiiEventos eventos;
	WiiDatosEvento datos_evento;
    } datos_thread;


    void funcion_thread_click_der();
    void hilo_click_derecho_empieza();
    void hilo_click_derecho_acaba();


    FiltroIr filtro_ir;
};


#endif /* __WIICURSOR_H__ */
