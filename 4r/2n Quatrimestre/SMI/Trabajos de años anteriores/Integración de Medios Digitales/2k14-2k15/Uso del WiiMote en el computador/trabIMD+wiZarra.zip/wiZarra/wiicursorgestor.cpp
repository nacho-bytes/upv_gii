/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#include "wiicursorgestor.h"

/*
 *  Thread de conexion del wiimote
 */
void WiiCursorGestor::wiicursorgestor_conexion_threads()
{
    MENSAJE_DEBUG(3, "Entrando WiiCursorGestor::wiicursorgestor_conexion_threads");


    cwiid_wiimote_t* wiimote_nuevo = 0;
    //do {  //PARA MULTIPLES WIIMOTES
        eventos_conexion.empezar_conexion();
        if ((wiimote_nuevo = conectar_wiimote(0)))
            vector_wiimotes.push_back(WiimoteDatos(wiimote_nuevo));
            ultima_conexion_saisfactoria = (wiimote_nuevo != 0) ? true : false;
            eventos_conexion.acabar_conexion();
    //}
    //while (wiimote_nuevo);

    eventos_conexion.conexion_terminada();

    MENSAJE_DEBUG(3, "Saliendo WiiCursorGestor::wiicursorgestor_conexion_threads");
}

/*
 *  Crea un thread para la conexion y no bloquear la gui
 */
void WiiCursorGestor::conectar()
{
    Glib::Thread::create(sigc::mem_fun(*this, &WiiCursorGestor::wiicursorgestor_conexion_threads), false);
}

/*
 *  Desconecta el wiimote
 */
bool WiiCursorGestor::desconectar()
{
    if (gtkmm_ventana_calibracion)
    {
        MENSAJE_DEBUG(1, "Ventana de calibracion viva (ESC apretado), saliendo..\n");
        gtkmm_ventana_calibracion->quit();
    }

    MENSAJE_DEBUG(1, "Desactivando los cursores");
    desactivar();
    MENSAJE_DEBUG(1, "Desconectando los wiimotes");

    for (WiimoteDatosIterador iteracion = vector_wiimotes.begin(); iteracion != vector_wiimotes.end(); ++iteracion)
        desconectar_wiimote(iteracion->wiimote);
    vector_wiimotes.clear();

    //AVISO: Siempre devuelve true
    return true;
}

/*
 *  Calibra el wiimote
 */
bool WiiCursorGestor::calibrado()
{
    bool devolver = true;

    for (WiimoteDatosIterador iteracion = vector_wiimotes.begin(); iteracion != vector_wiimotes.end(); ++iteracion)
    {
        // WARNING: C function. I'd have used std::ostringstream if not for l10n.
        unsigned int const indice_wiimote = iteracion - vector_wiimotes.begin() + 1;
        char salida[1024];
        sprintf(salida, ("Calibrando Wiimote #%d"), indice_wiimote);

        MENSAJE_DEBUG(1, "Inicializando ventana de calibración #%d...\n", indice_wiimote);
        VentanaCalibracion ventana_calibracion(iteracion->wiimote, salida);
        gtkmm_ventana_calibracion = &ventana_calibracion;
        PuntosCalibradosWiimote p_wii;
        if ( !ventana_calibracion.obtiene_puntos_calibrado(p_wii) ) {
            MENSAJE_DEBUG(1, "Fallo en la calibracion");
            devolver = false;
            break;
        }
        else
        {
            MENSAJE_DEBUG(1, "Calibración completa");
            iteracion->transformada = calcular_matriz_transformacion(p_wii);
        }
    }
    gtkmm_ventana_calibracion = 0;
    MENSAJE_DEBUG(1, "gtkmm_ventana_calibracion puesta a 0");

    return devolver;
}

/*
 *  Activa el thread para hacer funcionar el cursor
 */
bool WiiCursorGestor::activar()
{
    empezar_thread_wiicursor(datos_thread);

    //AVISO: Siempre devuelve true
    return true;
}

/*
 *  Desactiva el thread para hacer funcionar el cursor
 */
bool WiiCursorGestor::desactivar()
{
    acabar_wiicursor_thread(datos_thread);

    //AVISO: Siempre devuelve true
    return true;
}
