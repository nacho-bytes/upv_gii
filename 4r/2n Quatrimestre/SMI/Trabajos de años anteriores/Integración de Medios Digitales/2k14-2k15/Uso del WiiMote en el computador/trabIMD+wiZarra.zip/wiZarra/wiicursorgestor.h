/*
    wiiZarra
    Copyright (C) <2009>  <Javier Martí Monforte>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    Programa basado en linux-whiteboard http://code.google.com/p/linux-whiteboard/
    que está licenciado bajo licencia GPL.

    Copyright (C) 2008 Pere Negre
*/

#ifndef  __WIICURSORGESTOR_H__
#define  __WIICURSORGESTOR_H__


#include <vector>

#include "calibrado.h"
#include "matrizop.h"
#include "wiicursor.h"
#include "wiicontrol.h"
#include "configurador.h"
#include "comun.h"


struct WiiCursorGestorEventosConexion
{
    Glib::Dispatcher empezar_conexion;
    Glib::Dispatcher acabar_conexion;
    Glib::Dispatcher conexion_terminada;
};

class WiiCursorGestor
{
public:

    WiiCursorGestor(WiiCursorGestorEventosConexion& eventos) :
        datos_thread( get_configurador().wiimotes() ),
        vector_wiimotes(datos_thread.wiimotes),
        gtkmm_ventana_calibracion(0),
        ultima_conexion_saisfactoria(false),
        eventos_conexion(eventos)
    {
    }

    void conectar();
    bool desconectar();
    bool calibrado();
    bool activar();
    bool desactivar();

    WiiEventos& eventos()
    {
        return datos_thread.eventos;
    }

    unsigned int conectado() const
    {
        return vector_wiimotes.size();
    }

    bool activado() const
    {
        return conectado() && datos_thread.hilo_ejecutado;
    }

    bool ultima_conexion_satisfactoria() const
    {
        return ultima_conexion_saisfactoria;
    }

private:

    WiiThreadFuncionesDatos datos_thread;
    std::vector<WiimoteDatos>& vector_wiimotes;
    VentanaCalibracion* gtkmm_ventana_calibracion;

    bool ultima_conexion_saisfactoria;
    WiiCursorGestorEventosConexion& eventos_conexion;
    void wiicursorgestor_conexion_threads();
};


#endif /* __WIICURSORGESTOR_H__ */
