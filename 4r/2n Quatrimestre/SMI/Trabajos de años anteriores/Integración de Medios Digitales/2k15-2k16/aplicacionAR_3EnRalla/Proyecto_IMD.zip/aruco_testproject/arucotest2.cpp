
#include <iostream>

#include <fstream>
#include <sstream>
#include <GL/gl.h>
#include <GL/glut.h>
#include <aruco/aruco.h>
using namespace cv;
using namespace aruco;

string TheInputVideo;
string TheIntrinsicFile;
bool The3DInfoAvailable=false;
float TheMarkerSize=-1;
MarkerDetector PPDetector;
VideoCapture TheVideoCapturer;
vector<Marker> TheMarkers;
Mat TheInputImage, TheInputImageCopy, TheUndInputImage,TheResizedImage;
CameraParameters TheCameraParams;

Size TheGlWindowSize;
bool TheCaptureFlag=true;
bool readIntrinsicFile(string TheIntrinsicFile,Mat & TheIntriscCameraMatrix,Mat &TheDistorsionCameraParams,Size size);

void vDrawScene();
void vIdle();
void vResize( GLsizei iWidth, GLsizei iHeight );
void vMouse(int b,int s,int x,int y);


/************************************
 *
 *
 *
 *
 ************************************/

bool readArguments ( int argc,char **argv )
{
    if (argc!=4) {
        cerr<<"Invalid number of arguments"<<endl;
        cerr<<"Usage: (in.avi|live)  intrinsics.yml   size "<<endl;
        return false;
    }
    TheInputVideo=argv[1];
    TheIntrinsicFile=argv[2];
    TheMarkerSize=atof(argv[3]);
    return true;
}


/************************************
 *
 *
 *
 *
 ************************************/

int main(int argc,char **argv)
{
    try
    {//parse arguments
        if (readArguments (argc,argv)==false) return 0;
        //read from camera
        if (TheInputVideo=="live") TheVideoCapturer.open(0);
        else TheVideoCapturer.open(TheInputVideo);
        if (!TheVideoCapturer.isOpened())
        {
            cerr<<"Could not open video"<<endl;
            return -1;

        }

        //read first image
        TheVideoCapturer>>TheInputImage;
        //read camera paramters if passed
        TheCameraParams.readFromXMLFile(TheIntrinsicFile);
        TheCameraParams.resize(TheInputImage.size());

        glutInit(&argc, argv);
        glutInitWindowPosition( 0, 0);
        glutInitWindowSize(TheInputImage.size().width,TheInputImage.size().height);
        glutInitDisplayMode( GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE );
        glutCreateWindow( "AruCo" );
        glutDisplayFunc( vDrawScene );
        glutIdleFunc( vIdle );
        glutReshapeFunc( vResize );
        glutMouseFunc(vMouse);
        glClearColor( 0.0, 0.0, 0.0, 1.0 );
        glClearDepth( 1.0 );
        TheGlWindowSize=TheInputImage.size();
        vResize(TheGlWindowSize.width,TheGlWindowSize.height);
        glutMainLoop();
	
	glPushMatrix() ;
	glColor3f(1.0,0.0,0.0) ;
	glutWireCube(0.5) ;
	glPopMatrix() ;

    } catch (std::exception &ex)

    {
        cout<<"Exception :"<<ex.what()<<endl;
    }

}
/************************************
 *
 *
 *
 *
 ************************************/

void vMouse(int b,int s,int x,int y)
{
    if (b==GLUT_LEFT_BUTTON && s==GLUT_DOWN) {
        TheCaptureFlag=!TheCaptureFlag;
    }

}

/************************************
 *
 *
 *
 *
 ************************************/
void axis(float size)
{
    glColor3f (1,0,0 );
    glBegin(GL_LINES);
    glVertex3f(0.0f, 0.0f, 0.0f); // origin of the line
    glVertex3f(size,0.0f, 0.0f); // ending point of the line
    glEnd( );

    glColor3f ( 0,1,0 );
    glBegin(GL_LINES);
    glVertex3f(0.0f, 0.0f, 0.0f); // origin of the line
    glVertex3f( 0.0f,size, 0.0f); // ending point of the line
    glEnd( );


    glColor3f (0,0,1 );
    glBegin(GL_LINES);
    glVertex3f(0.0f, 0.0f, 0.0f); // origin of the line
    glVertex3f(0.0f, 0.0f, size); // ending point of the line
    glEnd( );


}
/************************************
 *
 *
 *
 *
 ************************************/

void drawCubeModel(int ficha)
{
	static const GLfloat LightAmbient[] = { 0.25f, 0.25f, 0.25f, 1.0f };  // Ambient Light Values
	static const GLfloat LightDiffuse[] = { 0.1f, 0.1f, 0.1f, 1.0f };     // Diffuse Light Values
	static const GLfloat LightPosition[] = { 0.0f, 0.0f, 2.0f, 1.0f };    // Light Position

	glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT1);
	glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbient);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);
	glLightfv(GL_LIGHT1, GL_POSITION, LightPosition);
	glEnable(GL_COLOR_MATERIAL);

	glScalef(0.02f, 0.02f, 0.02f);
	glTranslatef(0, 0, 1);

	glEnableClientState(GL_NORMAL_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);

	const static GLfloat vertices[] = {
			 1.0f, -1.0f, -1.0f,
			 1.0f, -1.0f,  1.0f,
			-1.0f, -1.0f,  1.0f,
			-1.0f, -1.0f, -1.0f,
			 1.0f,  1.0f, -1.0f,
			 1.0f,  1.0f,  1.0f,
			-1.0f,  1.0f,  1.0f,
			-1.0f,  1.0f, -1.0f
	};

	const static GLfloat normals[] = {
		  0.0f, -1.0f, -0.0f,
		  0.0f,  1.0f,  0.0f,
		  1.0f,  0.0f,  0.0f,
		 -0.0f,  0.0f,  1.0f,
		 -1.0f ,-0.0f, -0.0f,
		  0.0f,  0.0f, -1.0f
	};

	const static GLubyte indices[] = {
		1 - 1, 2 - 1, 3 - 1, 4 - 1,
		5 - 1, 8 - 1, 7 - 1, 6 - 1,
		1 - 1, 5 - 1, 6 - 1, 2 - 1,
		2 - 1, 6 - 1, 7 - 1, 3 - 1,
		3 - 1, 7 - 1, 8 - 1, 4 - 1,
		5 - 1, 1 - 1, 4 - 1, 8 - 1
	};

	GLfloat normales[24];
	size_t index = 0;

	for (size_t i = 0; i < 24; i += 4)
	{
		normales[i + 0] = normals[index];
		normales[i + 1] = normals[index];
		normales[i + 2] = normals[index];
		normales[i + 3] = normals[index];

		index = index >= 18 ? 0 : index++;
	}

	glNormalPointer(GL_FLOAT, 0, normales);
	glVertexPointer(3, GL_FLOAT, 0, vertices);

	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	if (ficha == 0){
	glColor4f(0.0f, 0.0f, 1.0f, 0.75f);
	} else if (ficha == 1){
	glColor4f(1.0f, 0.0f, 0.0f, 0.75f);
	}
	glDrawElements(GL_QUADS, 24, GL_UNSIGNED_BYTE, indices);

	glLineWidth(2.0f);

	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	if (ficha == 0){
	glColor4f(0.0f, 0.4f, 1.0f, 0.75f);
	} else if (ficha == 1){
	glColor4f(1.0f, 0.4f, 0.0f, 0.75f);
	}
	glDrawElements(GL_QUADS, 24, GL_UNSIGNED_BYTE, indices);

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
}


void vDrawScene()
{
    if (TheResizedImage.rows==0) //prevent from going on until the image is initialized
        return;
    
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, TheGlWindowSize.width, 0, TheGlWindowSize.height, -1.0, 1.0);
    glViewport(0, 0, TheGlWindowSize.width , TheGlWindowSize.height);
    glDisable(GL_TEXTURE_2D);
    glPixelZoom( 1, -1);
    glRasterPos3f( 0, TheGlWindowSize.height  - 0.5, -1.0 );
    glDrawPixels ( TheGlWindowSize.width , TheGlWindowSize.height , GL_RGB , GL_UNSIGNED_BYTE , TheResizedImage.ptr(0) );
    glMatrixMode(GL_PROJECTION);
    double proj_matrix[16];
    double modelview_matrix[16];
    TheCameraParams.glGetProjectionMatrix(TheInputImage.size(),TheGlWindowSize,proj_matrix,0.05,10);
    glLoadIdentity();
    glLoadMatrixd(proj_matrix);

    
    for (unsigned int m=0;m<TheMarkers.size();m++)
    {
        TheMarkers[m].glGetModelViewMatrix(modelview_matrix);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glLoadMatrixd(modelview_matrix);
	
	if (TheMarkers[m].id%2 == 0){
		drawCubeModel(0);
	} else {
		drawCubeModel(1);
	}
	
	//cout<<TheMarkers[m]<<endl;              
	//TheMarkers[m].draw(TheInputImageCopy,Scalar(0,0,255),1);

	//drawCubeModel();

	//TheMarkers[m].calculateExtrinsics(TheMarkerSize, TheCameraParams, false);
	//			cout << "Marker id:" << TheMarkers[m].id << "  Rvec: " << TheMarkers[m].Rvec << "  Tvec: " << TheMarkers[m].Tvec << endl;
			
	//			TheMarkers[m].draw(TheInputImage, Scalar(0,0,255), 1);	
	//			aruco::CvDrawingUtils::draw3dCube(TheInputImage, TheMarkers[m], TheCameraParams);

        //axis(TheMarkerSize);

        //glColor3f(1,0.4,0.4);
        //glTranslatef(0, TheMarkerSize/2,0);
        //glPushMatrix();
        //glutWireCube( TheMarkerSize );

        //glPopMatrix();
    }

    glutSwapBuffers();

}


/************************************
 *
 *
 *
 *
 ************************************/
void vIdle()
{
    if (TheCaptureFlag) {
        //capture image
        TheVideoCapturer.grab();
        TheVideoCapturer.retrieve( TheInputImage);
        TheUndInputImage.create(TheInputImage.size(),CV_8UC3);
        //transform color that by default is BGR to RGB because windows systems do not allow reading BGR images with opengl properly
        cv::cvtColor(TheInputImage,TheInputImage,CV_BGR2RGB);
        //remove distorion in image
        cv::undistort(TheInputImage,TheUndInputImage, TheCameraParams.CameraMatrix, TheCameraParams.Distorsion);
        //detect markers
        PPDetector.detect(TheUndInputImage,TheMarkers, TheCameraParams.CameraMatrix,Mat(),TheMarkerSize);
        //resize the image to the size of the GL window
        cv::resize(TheUndInputImage,TheResizedImage,TheGlWindowSize);
    }
    glutPostRedisplay();
}


/************************************
 *
 *
 *
 *
 ************************************/
void vResize( GLsizei iWidth, GLsizei iHeight )
{
    TheGlWindowSize=Size(iWidth,iHeight);
    //not all sizes are allowed. OpenCv images have padding at the end of each line in these that are not aligned to 4 bytes
    if (iWidth*3%4!=0) {
        iWidth+=iWidth*3%4;//resize to avoid padding
        vResize(iWidth,TheGlWindowSize.height);
    }
    else {
        //resize the image to the size of the GL window
        if (TheUndInputImage.rows!=0)
            cv::resize(TheUndInputImage,TheResizedImage,TheGlWindowSize);
    }
}

