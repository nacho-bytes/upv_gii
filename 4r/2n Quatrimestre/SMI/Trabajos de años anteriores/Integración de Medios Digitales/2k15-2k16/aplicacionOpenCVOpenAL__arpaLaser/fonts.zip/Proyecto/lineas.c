#include <cv.h>
#include <cxcore.h>
#include <highgui.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> // clock
#include <AL/alut.h>
//#include <math.h> // round --> cvRound

//include "comun.h"

   IplImage *imagen; 
   IplImage *imagen2; 
  int  line_type = CV_AA;
  int shift = 0;
  ALuint Buffer[6],Source[6];

void my_mouse_callback( int event, int x, int y, int flags, void* param )
{
  CvScalar  elColor;
 // printf(" HOLA\n");
  // Cuando hagamos el evento de refrescar  la imagen como el paso de apretar boton y levantarlo es de milesimas de segudos puede que no se note, en todo caso refrescaremos la imagen y dibujaremos
  switch( event ) {
  case CV_EVENT_LBUTTONUP: 
     elColor = cvGet2D(imagen2, y, x);
     for(int i=0;i<6;i++){
       if((int)elColor.val[0]!=255){	 
	cvLine(imagen, cvPoint(300,800), cvPoint(i*100,0), cvScalar(0,255,0, 1),5, line_type, shift );
       }
     }
//for para saber que linea toca
    break;
    
  case CV_EVENT_LBUTTONDOWN: 
  elColor = cvGet2D(imagen2, y, x);
  int antigua =0;
  for(int i=0;i<6;i++){
    if((int)elColor.val[0]==i*10+10){ 
      antigua=i;
      cvLine(imagen, cvPoint(300,800), cvPoint(i*100,0), cvScalar(0,0,0, 1),5, line_type, shift );
      cvLine(imagen, cvPoint(300,800), cvPoint(x,y), cvScalar(0,255,0, 1),5, line_type, shift );
      //sonido que tiene que reproducir
       alSourceStop(Source[antigua]); //REVISAR NO PARA
       alSourcei (Source[i], AL_BUFFER, Buffer[i]);
       alSourcePlay(Source[i]);
    }

  }
    break;

 // case CV_EVENT_RBUTTONUP: 
  //  if( cvScalar(0,255,0, 1))
   // {
     //hacer sonido
   //   printf(" todo correcto");
   // }
   // cvShowImage( fORG, image );
      

   // break;

  } // fi del switch
  cvShowImage("Drawing", imagen); 
}// fi de "void my_mouse_callback
       

int main(int argc, char* argv[])
{
       int anchura = 600;
       int altura = 800;
       int rec = 150; 
       int thickness = 1;
        alutInit(0, NULL);
        ALint sourceState;
	
/*
 *	{
  ALuint helloBuffer, helloSource;
  alutInit (&argc, argv);

  helloBuffer = alutCreateBufferFromFile( "horse.wav" );
  alGenSources (1, &helloSource);
  alSourcei (helloSource, AL_BUFFER, helloBuffer);
  alSourcePlay (helloSource);
  alSourcePlay (helloSource);


  alutSleep (1);
  alutExit ();
  return EXIT_SUCCESS;
}
*/

       alGenBuffers(6,Buffer); 
       Buffer[0]= alutCreateBufferFromFile( "arpa.wav" );
       Buffer[1]= alutCreateBufferFromFile( "arpa2.wav" );
       Buffer[2]= alutCreateBufferFromFile( "arpa3.wav" );
       Buffer[3]= alutCreateBufferFromFile( "arpa.wav" );
       Buffer[4]= alutCreateBufferFromFile( "arpa2.wav" );
       Buffer[5]= alutCreateBufferFromFile( "arpa3.wav" );
       alGenSources(6,Source);
       
//posible bucle for para asignar las diferentes notas 
       
       imagen = cvCreateImage(cvSize(altura,anchura),IPL_DEPTH_8U, 3);
       imagen2 = cvCreateImage(cvSize(altura,anchura),IPL_DEPTH_8U, 3);
 
        
       
       
    //Dibuja las lineas  Hacer los FOR
       for(int i=0;i<6;i++){
	 cvLine(imagen, cvPoint(300,800), cvPoint(i*100,0), cvScalar(0,255,0, 1),5, line_type, shift );
	 cvLine(imagen2, cvPoint(300,800), cvPoint(i*100,0), cvScalar(10+i*10,10+i*10,10+i*10, 1),5, line_type, shift );
	 
       }   
	
  
      cvShowImage("Drawing", imagen);
      //Mostar imagen interna
    //  cvShowImage("Drawing", imagen2);
      cvSetMouseCallback( "Drawing", my_mouse_callback,NULL);     
      cvWaitKey(0);
     // cvReleaseCapture(&camara);
      //el click del evento 
}


