#include <cv.h>
#include <cxcore.h>
#include <highgui.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> // clock
#include <AL/alut.h>
//#include <math.h> // round --> cvRound

//include "comun.h"

   IplImage *imagen; 
   IplImage *imagen2; 
   IplImage *imagenCam; 
   IplImage *imagenDif;
   IplImage *imagenCamAnt;
   
  int  line_type = CV_AA;
  int shift = 0;
  ALuint Buffer[6],Source[6];

void my_mouse_callback( int event, int x, int y, int flags, void* param )
{
  CvScalar  elColor;
 // printf(" HOLA\n");
  // Cuando hagamos el evento de refrescar  la imagen como el paso de apretar boton y levantarlo es de milesimas de segudos puede que no se note, en todo caso refrescaremos la imagen y dibujaremos
  switch( event ) {
  case CV_EVENT_LBUTTONUP: 
     elColor = cvGet2D(imagen2, y, x);
     for(int i=0;i<6;i++){
       if((int)elColor.val[0]!=255){	 
	cvLine(imagen, cvPoint(300,800), cvPoint(i*100,0), cvScalar(0,255,0, 1),5, line_type, shift );
       }
     }
    break;
    
  case CV_EVENT_LBUTTONDOWN: 
  elColor = cvGet2D(imagen2, y, x);
  int antigua =0;
  for(int i=0;i<6;i++){
    if((int)elColor.val[0]==i*10+10){ 
      antigua=i;
      cvLine(imagen, cvPoint(300,800), cvPoint(i*100,0), cvScalar(0,0,0, 1),5, line_type, shift );
      cvLine(imagen, cvPoint(300,800), cvPoint(x,y), cvScalar(0,255,0, 1),5, line_type, shift );
      //sonido que tiene que reproducir
       alSourceStop(Source[antigua]); //REVISAR NO PARA
       alSourcei (Source[i], AL_BUFFER, Buffer[i]);
       alSourcePlay(Source[i]);
    }

  }
    break;

  } // fi del switch
  cvShowImage("Drawing", imagen); 
}// fi de "void my_mouse_callback
       
int contarPuntos(IplImage *img){
  int contador=0;
  
  for (int x = 0; x < img->width; x++ )
   for (int y = 0; y < img->height; y++ )
   {
     if(cvPoint(x,y)!=0){
	contador++;
     }   
   }  
   return contador
}  
       
int main(int argc, char* argv[])
{
       int anchura = 600;
       int altura = 800;
       int rec = 150; 
       int thickness = 1;
       int key;
        alutInit(0, NULL);
        ALint sourceState;

// Inicializamos ventanas y cam y los sonidos
  CvCapture* camara=cvCreateCameraCapture(0) ;
 // imagenCam=cvQueryFrame(camara);
 // cvNameWIndow("Drawing",CV_WINDOW_AUTOSIZE);  
 // cvMoveWindow("Drawing",0,0);

       alGenBuffers(6,Buffer); 
       Buffer[0]= alutCreateBufferFromFile( "arpa.wav" );
       Buffer[1]= alutCreateBufferFromFile( "arpa2.wav" );
       Buffer[2]= alutCreateBufferFromFile( "arpa3.wav" );
       Buffer[3]= alutCreateBufferFromFile( "arpa2.wav" );
       Buffer[4]= alutCreateBufferFromFile( "arpa.wav" );
       Buffer[5]= alutCreateBufferFromFile( "arpa3.wav" );
       alGenSources(6,Source);
       
//Inicializamos las imagenes
       
       imagen = cvCreateImage(cvSize(altura,anchura),IPL_DEPTH_8U, 3);
       imagen2 = cvCreateImage(cvSize(altura,anchura),IPL_DEPTH_8U, 3);
        
    //Dibuja las lineas de la imagen interna
       for(int i=0;i<6;i++){
	 cvLine(imagen2, cvPoint(300,800), cvPoint(i*100,0), cvScalar(10+i*10,10+i*10,10+i*10, 1),5, line_type, shift );
	 
       }   
	//Bucle principal
	key = cvWaitKey( 25 ) & 255; 
	while(key!=ESC){
	  imagenCam=cvQueryFrame(camara);nCamAn	   
	  cvAbsDiff(imagenCam,imagenCamAnt,imagenDif);
	int puntosCambiados=contarPuntos(imagenDif);
	  if(puntoCambiados>50){	    
	    imagenCamAnt=cvCloneImage(imagenDif);
	    //CENTRO DE GRAVEDAD con eso obtenemos unas coordenadas
		
	          //Dibuja las lineas y pintas la linea donde hay evento
	    for(int i=0;i<6;i++){
	      
	      cvLine(imagen, cvPoint(300,800), cvPoint(i*100,0), cvScalar(0,255,0, 1),5, line_type, shift );   
	      //x y de las coordenadas sacadas
	      cvLine(imagen, cvPoint(300,800), cvPoint(x,y), cvScalar(0,255,0, 1),5, line_type, shift );
      //sonido que tiene que reproducir
       alSourceStop(Source[antigua]); //REVISAR NO PARA
       alSourcei (Source[i], AL_BUFFER, Buffer[i]);
       alSourcePlay(Source[i]);
	      	      cvReleaseCapture(imagenCam);
	  }//fin del for
	   else{
	      imagenCamAnt=cvCloneImage(imagenDif);
	      cvLine(imagen, cvPoint(300,800), cvPoint(i*100,0), cvScalar(0,255,0, 1),5, line_type, shift );  
	      cvReleaseCapture(imagenCam);
	   }
	cvShowImage("Drawing", imagen);
      //Mostar imagen interna
    //  cvShowImage("Drawing", imagen2);
      cvSetMouseCallback( "Drawing", my_mouse_callback,NULL);     
      cvWaitKey(0);
      cvReleaseCapture(&camara);
      //el click del evento 
      imagenCamAnt=imagenCam;	  
	  
	}//fin del while
	
}


