// ***************************************************************** 
// ***************** Detector de caras para la pecera imd **********
// ***************************************************************** 
//
// Codigo basado en el ejemplo: https://github.com/adamb/opencv-samples
//
// Este codigo "facedetect.h" y ha sido adaptado para la pecera imd v4.
//
// codigo original "facedetect.c"
// copilar: g++ facedetect.c -o facedetect -lalut -lopenal -lfreeimage -g `pkg-config --cflags openal opencv glu gl` -lglut `pkg-config --libs openal opencv glu gl`
// ejecutar: ./facedetect --cascade="haarcascade_frontalface_alt.xml" lena.jpg
// ref: https://github.com/adamb/opencv-samples

#include <cv.h>
#include <highgui.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <time.h>
#include <ctype.h>

#ifdef _EiC
#define WIN32
#endif

#define True 	1
#define False 	0

// *** define la ventana  ***
#define VentanaCV "Pecera WebCam."

static CvMemStorage* storage = 0;
static CvHaarClassifierCascade* cascade = 0;

// *** Declaracion de funciones ***
void detect_and_draw( IplImage* image );
void webCamDetCara();
void webCamOff();
int webCamOn();

// *** Constantes con los archivos de la foto y caraFrontal ***
const char* cascade_name = "haarcascade_frontalface_alt.xml"; // "haarcascade_profileface.xml";
const char* input_name = "lena.jpg";

CvCapture* capture;		// WebCam
IplImage*  image;		// Foto

float caraX = -1;
float caraY = -1;

// *** programa principal ***
int mainNoEs( int argc, char** argv )
{
	// *** inicia foto ***
	IplImage *image = 0;
	
    // *** pone los archivos a leer (foto y caraFrontal) ***
    int optlen = strlen("--cascade=");
    const char* input_name;
    if( argc > 1 && strncmp( argv[1], "--cascade=", optlen ) == 0 )
    {
        cascade_name = argv[1] + optlen;
        input_name = argc > 2 ? argv[2] : 0;
    }
    else
    {
        cascade_name = "/opt/local/var/macports/software/opencv/1.0.0_0/opt/local/share/opencv/haarcascades/haarcascade_frontalface_alt.xml";
        input_name = argc > 1 ? argv[1] : 0;
    }

    // *** carga la caraFrontal **
    cascade = (CvHaarClassifierCascade*)cvLoad( cascade_name, 0, 0, 0 );    
    if( !cascade )
    {
        fprintf( stderr, "ERROR: Could not load classifier cascade\n" );
        fprintf( stderr,
        "Usage: facedetect --cascade=\"<cascade_path>\" [filename]\n" );
        return -1;
    }
    
    // *** Reserva memoria ***
    storage = cvCreateMemStorage(0);
    
    // *** No hay foto a leer ***
    if( !input_name )
    {
        fprintf( stderr, "ERROR: Need a valid filename\n" );
        fprintf( stderr,
        "Usage: facedetect --cascade=\"<cascade_path>\" [filename]\n" );
        return -1;
    }

    // *** Carga la foto ***
    image = cvLoadImage( input_name , 1); 
	if (!image) {
		printf("Could not load image file: %s\n", input_name);
		exit(0);
	}
	
    // *** Crea una ventana OpenCV ***
    cvNamedWindow( "result", 1 );

	// *** Detecta cara en foto ***
	detect_and_draw( image );

	// *** Espera una tecla para salir ***
	cvWaitKey( 0 );

    // *** Libera foto ***
    cvReleaseImage( &image );
    
    // *** Cierra ventana ***
    cvDestroyWindow("result");

    return 0;
}

void detect_and_draw( IplImage* img )
{
	//caraX = -1; caraY = -1;
	
	int fotoAncho = img->width;
	int fotoAlto = img->height;
	// ref: http://www.cs.iit.edu/~agam/cs512/lect-notes/opencv-intro/opencv-intro.html

    static CvScalar colors[] = 
    {
        {{0,0,255}},
        {{0,128,255}},
        {{0,255,255}},
        {{0,255,0}},
        {{255,128,0}},
        {{255,255,0}},
        {{255,0,0}},
        {{255,0,255}}
    };

    double scale = 1.3;
    IplImage* gray = cvCreateImage( cvSize(img->width,img->height), 8, 1 );
    IplImage* small_img = cvCreateImage( cvSize( cvRound (img->width/scale),
                         cvRound (img->height/scale)),
                     8, 1 );
    int i;

    cvCvtColor( img, gray, CV_BGR2GRAY );
    cvResize( gray, small_img, CV_INTER_LINEAR );
    cvEqualizeHist( small_img, small_img );
    cvClearMemStorage( storage );

    if( cascade )
    {
        double t = (double)cvGetTickCount();
        CvSeq* faces = cvHaarDetectObjects( small_img, cascade, storage,
                                            1.1, 2, 0/*CV_HAAR_DO_CANNY_PRUNING*/,
                                            cvSize(30, 30) );
        
        for( i = 0; i < (faces ? faces->total : 0); i++ )
        {
            CvRect* r = (CvRect*)cvGetSeqElem( faces, i );
            CvPoint center;
            int radius;
            center.x = cvRound((r->x + r->width*0.5)*scale);
            center.y = cvRound((r->y + r->height*0.5)*scale);
            radius = cvRound((r->width + r->height)*0.25*scale);
            cvCircle( img, center, radius, colors[i%8], 3, 8, 0 );
            
            center.x= cvRound( center.x * 100.0 / fotoAncho );
			center.y= cvRound( center.y * 100.0 / fotoAlto );

            if (i==0)
            {
				caraX = 1-( ((r->x + r->width*0.5)*scale) / fotoAncho );
				caraY = ((r->y + r->height*0.5)*scale) / fotoAlto;
			}
            
        }
    }

    // *** muestra la foto ***
    cvShowImage( VentanaCV, img );    
    cvWaitKey(25);	// permite que se atiendan los eventos pendientes.
    
    cvReleaseImage( &gray );
    cvReleaseImage( &small_img );
}


// *** Activa la webCam ***
int webCamOn()
{
    // *** carga la caraFrontal **
    cascade = (CvHaarClassifierCascade*)cvLoad( cascade_name, 0, 0, 0 );    
    if( !cascade )
    {
        fprintf( stderr, "ERROR: Could not load classifier cascade\n" );        
        return False;
    }
    
    // *** Reserva memoria ***
    storage = cvCreateMemStorage(0);
    
    // *** Crea una ventana OpenCV ***    
    cvNamedWindow( VentanaCV, CV_WINDOW_AUTOSIZE );
    cvMoveWindow( VentanaCV, 600, 0);

    // *** Abre la webcam ***
    capture = cvCaptureFromCAM(0);
    if (!capture) 
    {
        fprintf(stderr, "Error: No se puede abrir la webcam.\n");
        return False;
	}
    cvSetCaptureProperty(capture, CV_CAP_PROP_FRAME_WIDTH, 320);
	cvSetCaptureProperty(capture, CV_CAP_PROP_FRAME_HEIGHT, 240);
    
    
    printf("WebCam abierta.\n");
    
    return True;
}

// *** Desactiva la webCam ***
void webCamOff()
{
    // *** Cierra ventana ***
    cvDestroyWindow(VentanaCV);
    cvWaitKey(25);   

	// *** cierra la camara ***
	cvReleaseCapture( &capture );
	 
	printf("WebCam cerrada.\n");	

}

// *** Desactiva la webCam ***
void webCamDetCara()
{

    // *** Carga la foto ***
    //image = cvLoadImage( input_name , 1); // Saca foto desde archivo
    image = cvQueryFrame(capture);	// Saca foto desde webCam
	if (!image) fprintf(stderr, "Error: no se carga la foto %s\n", input_name);

	// *** Detecta cara en foto ***
	detect_and_draw( image );

}
