// ***************************************************************** 
// ************************* Pecera Imd v4 *************************
// ***************************************************************** 
//
//  pecera.c
//  pecera IMD v4.
//
//  Creado el 16-04-2016.
//
//
// Librerías necesarias:
// g++:			sudo apt-get install build-essential
// OpenGL:		sudo apt-get install mesa-common-dev freeglut3-dev
// OpenCV:		sudo apt-get install libopencv-dev python-opencv opencv-doc
// OpenAL:		sudo apt-get install libopenal-dev libalut-dev
// FreeImage:	sudo apt-get install libfreeimage-dev
//
// compilar: make
// compilar: g++ pecera.c -o pecera -lalut -lopenal -lfreeimage -g `pkg-config --cflags openal opencv glu gl` -lglut `pkg-config --libs openal opencv glu gl`

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GL/glut.h>
#include <GL/gl.h>
#include <AL/alut.h>
#include <AL/al.h>
#include <FreeImage.h>
#include "facedetect.h"


#define True 	1
#define False 	0

#define ActMseg		65	// Cada cuandos mseg de mueven los peces (15 fps).

#define FotosAdor	3	// Donde empiezan los adornos.
#define FotosBru 	10	// Donde empiezan las burbujas.
#define FotosPez 	13	// Donde empiezan los peces.
#define FotosComida	29	// Donde empiezan las comidas.
#define FotosMax 	33	// Numero de foto y texturas

#define PapelesMax	200	// Numero de papeles para comer.

ALuint buffer, fuente;		// Bufer y altavoz del sonido
ALfloat	volumen = 1.0;		// Volumen del sonido

int numPeces = 3;			// Numero de peces a mostrar.
int pezAsustado = False;	// Indica si los peces estan asustados.
int webCamActiva = False;	// Indica si la webCam esta abierta.
int estanComiendo = False;	// Indica si los peces estan comiendo.

struct tipoFoto
{
	char	archivo[1024];			// nombre de la foto
    GLuint  textura;				// textura de la foto
    float   x, y, z;				// posicion de la foto
    float 	velox, veloy, veloz;	// velocidad
    float 	veloActx, veloActy, veloActz;	// velocidad actual
    float 	zoomx, zoomy;			// zoom
    float	rotax, rotay, rotaz;	// rotacion
    float	rotaActx, rotaActy, rotaActz;	// rotacion actual
    int 	invDir;					// invierte su direcion al azar
} foto[FotosMax];

struct tipoComida
{
    float   x, y, z;				// posicion de la foto
    float 	velox, veloy, veloz;	// velocidad
    float 	zoomx, zoomy;			// zoom
    int 	sePinta;				// se pinta
} comida[PapelesMax];



// *** Carga fotos ***
void loadImageFile(char* nombre){
    // Deteccion del formato, lectura y conversion a BGRA
    FREE_IMAGE_FORMAT formato = FreeImage_GetFileType(nombre,0);
    FIBITMAP* imagen = FreeImage_Load(formato, nombre,0);
    if(imagen==NULL) printf("Error al cargar la imagen\n");
    FIBITMAP* imagen32b = FreeImage_ConvertTo32Bits(imagen);
    
    // Lectura de dimensiones y colores
    int w = FreeImage_GetWidth(imagen32b);
    int h = FreeImage_GetHeight(imagen32b);
    GLubyte* texeles = FreeImage_GetBits(imagen32b);
    
    // Carga como textura actual
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_BGRA_EXT, GL_UNSIGNED_BYTE, texeles);
    
    // Liberar recursos
    FreeImage_Unload(imagen);
    FreeImage_Unload(imagen32b);
}


// *** Inicia las fotos y texturas ***
void IniciaFotos(){
	int x;

	// *** Inicia los peces en estado normal ***
	pezAsustado = False;	// peces no asustados.
	estanComiendo = False;	// peces no comen.

	// *** Inicia los datos ***
	for (int i=0; i < FotosMax; i++)
	{
		foto[i].x=0; foto[i].y=0; foto[i].z=0;	// posicion de la foto
		foto[i].velox=0; foto[i].veloy=0; foto[i].veloz=0;	// velocidad
		foto[i].veloActx=0; foto[i].veloActy=0; foto[i].veloActz=0;	// velocidad actual
		foto[i].zoomx=1; foto[i].zoomy=1;			// zoom
		foto[i].rotax=0; foto[i].rotay=0; foto[i].rotaz=0;;	// rotacion
		foto[i].rotaActx=0; foto[i].rotaActy=0; foto[i].rotaActz=0;	// rotacion actual
		foto[i].invDir = False;					// invierte su direcion al azar
	}

	// *** Nombre de las fotos ***
    // ref: http://www.tutorialspoint.com/cplusplus/cpp_data_structures.htm
    // ref: dibu vect http://es.fordesigner.com/maps/12575-0.htm
	strcpy(foto[0].archivo, "foto/fondo.jpeg");
	strcpy(foto[1].archivo, "foto/coral.png");
	strcpy(foto[2].archivo, "foto/Sirena.png");
	
	strcpy(foto[3].archivo, "foto/Adornos-Caja2.png");
	strcpy(foto[4].archivo, "foto/Adornos-Caja4.png");
	strcpy(foto[5].archivo, "foto/Adornos-Castillo1.png");
	strcpy(foto[6].archivo, "foto/Adornos-Castillo2.png");
	strcpy(foto[7].archivo, "foto/Adornos-Monolito.png");
	strcpy(foto[8].archivo, "foto/Adornos-Estrella Mar.png");
	
	strcpy(foto[9].archivo, "foto/cofre.png");
	
	strcpy(foto[10].archivo, "foto/burbuja.png");	
	strcpy(foto[11].archivo, "foto/burbuja.png");
	strcpy(foto[12].archivo, "foto/burbuja.png");	
	
	strcpy(foto[13].archivo, "foto/pezOscuro.png");	// fish1
	strcpy(foto[14].archivo, "foto/pezAzul.png");	// fish2
	strcpy(foto[15].archivo, "foto/pezGlobo.png");	// fish3
	strcpy(foto[16].archivo, "foto/Pez-Glogo2.png");
	strcpy(foto[17].archivo, "foto/Pez-Ojitos.png");
	strcpy(foto[18].archivo, "foto/Pez-Pasota.png");
	strcpy(foto[19].archivo, "foto/Pez-Sonrriente.png");	
	strcpy(foto[20].archivo, "foto/Pez-Hoo.png");
	
	strcpy(foto[21].archivo, "foto/Pez-Payaso1.png");
	strcpy(foto[22].archivo, "foto/Pez-Payaso2.png");
	strcpy(foto[23].archivo, "foto/Pez-Payaso3.png");
	strcpy(foto[24].archivo, "foto/Pez-Reina.png");	
	strcpy(foto[25].archivo, "foto/pezClaro.png");	
	strcpy(foto[26].archivo, "foto/Pez-Payaso1.png");
	strcpy(foto[27].archivo, "foto/Pez-Payaso2.png");
	strcpy(foto[28].archivo, "foto/Pez-Payaso3.png");
	
	strcpy(foto[29].archivo, "foto/Comida-Amarilla.png");
	strcpy(foto[30].archivo, "foto/Comida-Azul.png");
	strcpy(foto[31].archivo, "foto/Comida-Roja.png");
	strcpy(foto[32].archivo, "foto/Comida-Verde.png");

	
	// *** Pone coordenadas del fondo ***
	x=0;
	foto[x].x = -1; foto[x].y = -1; foto[x].z = 0;
	foto[x].zoomx = 1;foto[x].zoomy = 1;
    
	// *** Pone coordenadas del coral ***
	x=1;
	foto[x].x = -20; foto[x].y = -20; foto[x].z = -0.5;
	foto[x].zoomx = 0.4; foto[x].zoomy = 0.4;

	// *** Pone coordenadas del sirena ***
	x=2;
	foto[x].x = 120; foto[x].y = 10; foto[x].z = 0;
	foto[x].veloActx=foto[x].x; foto[x].veloActy=foto[x].y; foto[x].veloActz=foto[x].z;
	foto[x].zoomx = 1.8; foto[x].zoomy = 0.8;
	foto[x].velox= -0.8; foto[x].veloy= -0.4; foto[x].veloz= -0.0;
	foto[x].rotay = 180; foto[x].invDir = False;

	
	// ################ Adornos ##########################
	
	// *** Pone coordenadas del caja2 ***
	x=3;
	foto[x].x = 33; foto[x].y = -20; foto[x].z = 0;
	foto[x].zoomx = 0.8; foto[x].zoomy = 0.5;

	// *** Pone coordenadas del caja 4 ***
	x=4;
	foto[x].x = 4; foto[x].y = -20; foto[x].z = 0;
	foto[x].zoomx = 0.8; foto[x].zoomy = 0.5;

	// *** Pone coordenadas del castillo 1  ***
	x=5;
	foto[x].x = -25; foto[x].y = -20; foto[x].z = -10;
	foto[x].zoomx = 1.5; foto[x].zoomy = 1.0;

	// *** Pone coordenadas del castillo 2 ***
	x=6;
	foto[x].x = 25; foto[x].y = -20; foto[x].z = -10;
	foto[x].zoomx = 1.5; foto[x].zoomy = 1.0;

	// *** Pone coordenadas del monolito ***
	x=7;
	foto[x].x = -0; foto[x].y = -20; foto[x].z = -18;
	foto[x].zoomx = 1.0; foto[x].zoomy = 1.5;

	// *** Pone coordenadas del estrella mar ***
	x=8;
	foto[x].x = -40; foto[x].y = -20; foto[x].z = 0;
	foto[x].zoomx = 0.6; foto[x].zoomy = 0.5;


	// *** Pone coordenadas del cofre ***
	x=9;
	foto[x].x = -20; foto[x].y = -20; foto[x].z = 0;
	foto[x].zoomx = 0.6; foto[x].zoomy = 0.5;

	// *** Pone coordenadas de burbuja1 ***
	x=10;
	foto[x].x = -20; foto[x].y = -20; foto[x].z = -1;
	foto[x].zoomx = 0.15; foto[x].zoomy = 0.15;
	foto[x].velox= 0.0; foto[x].veloy= 0.6; foto[x].veloz= 0.0;
            
	// *** Pone coordenadas de burbuja2 ***
	x=11;
	foto[x].x = -21; foto[x].y = -20; foto[x].z = -2.5;
	foto[x].zoomx = 0.4; foto[x].zoomy = 0.4;
	foto[x].velox= 0.0; foto[x].veloy= 0.2; foto[x].veloz= 0.0;
	
	// *** Pone coordenadas de burbuja3 ***
	x=12;
	foto[x].x = -18; foto[x].y = -20; foto[x].z = -1;
	foto[x].zoomx = 0.25; foto[x].zoomy = 0.25;
	foto[x].velox= 0.0; foto[x].veloy= 0.4; foto[x].veloz= 0.0;

	
	// ################ Peces ##########################
	
	// *** Pone coordenadas de peces oscuro ***
	x=13;
	foto[x].x = -6; foto[x].y = -2; foto[x].z = -5;
	foto[x].zoomx = 0.5; foto[x].zoomy = 0.5;
	foto[x].velox= -0.4; foto[x].veloy= 0.25; foto[x].veloz= -0.25;
	foto[x].rotay = 180; foto[x].invDir = True;

	// *** Pone coordenadas de peces azul ***
	x=14;
	foto[x].x = -1; foto[x].y = 5; foto[x].z = -5;
	foto[x].zoomx = 0.5; foto[x].zoomy = 0.5;
	foto[x].velox= -1.0; foto[x].veloy= 0.6; foto[x].veloz= -0.8;
	foto[x].rotay = 180; foto[x].invDir = False;

	// *** Pone coordenadas de peces globo 1 ***
	x=15;
	foto[x].x = 0;  foto[x].y = -12; foto[x].z = -2;
	foto[x].zoomx = 1.0; foto[x].zoomy = 0.8;
	foto[x].velox= -0.2; foto[x].veloy= 0.1; foto[x].veloz= 0.0;
	foto[x].rotay = 180; foto[x].invDir = False;

	// *** Pone coordenadas de peces globo 2 ***
	x=16;
	foto[x].x = 20;  foto[x].y = -12; foto[x].z = -5;
	foto[x].zoomx = 1.0; foto[x].zoomy = 0.8;
	foto[x].velox= 0.0; foto[x].veloy= 0.1; foto[x].veloz= -0.6;
	foto[x].rotay = 180; foto[x].invDir = False;

	// *** Pone coordenadas de peces ojitos ***
	x=17;
	foto[x].x = -25;  foto[x].y = 12; foto[x].z = -3;
	foto[x].zoomx = 0.6; foto[x].zoomy = 0.6;
	foto[x].velox= -0.4; foto[x].veloy= 0.0; foto[x].veloz= -0.0;
	foto[x].rotay = 180; foto[x].invDir = False;

	// *** Pone coordenadas de peces pasota ***
	x=18;
	foto[x].x = 35;  foto[x].y = -5; foto[x].z = -4;
	foto[x].zoomx = 0.6; foto[x].zoomy = 0.4;
	foto[x].velox= -0.0; foto[x].veloy= 0.3; foto[x].veloz= -0.0;
	foto[x].rotay = 180; foto[x].invDir = False;

	// *** Pone coordenadas de peces sonrriente ***
	x=19;
	foto[x].x = -28;  foto[x].y = -10; foto[x].z = -5;
	foto[x].zoomx = 1.0; foto[x].zoomy = 0.8;
	foto[x].velox= -1.2; foto[x].veloy= 0.6; foto[x].veloz= -0.2;
	foto[x].rotay = 180; foto[x].invDir = True;


	// *** Pone coordenadas de peces hoo ***
	x=20;
	foto[x].x = -17;  foto[x].y = -2; foto[x].z = -5;
	foto[x].zoomx = 0.4; foto[x].zoomy = 0.4;
	foto[x].velox= -0.6; foto[x].veloy= 0.3; foto[x].veloz= -0.4;
	foto[x].rotay = 180; foto[x].invDir = True;

	// *** Pone coordenadas de peces payaso 1 ***
	x=21;
	foto[x].x = -39;  foto[x].y = 8; foto[x].z = -5;
	foto[x].zoomx = 0.6; foto[x].zoomy = 0.4;
	foto[x].velox= -0.8; foto[x].veloy= 0.4; foto[x].veloz= -0.2;
	foto[x].rotay = 180; foto[x].invDir = True;

	// *** Pone coordenadas de peces payaso 2 ***
	x=22;
	foto[x].x = 18;  foto[x].y = 9; foto[x].z = -5;
	foto[x].zoomx = 0.6; foto[x].zoomy = 0.4;
	foto[x].velox= -0.8; foto[x].veloy= 0.4; foto[x].veloz= -0.4;
	foto[x].rotay = 180; foto[x].invDir = True;

	// *** Pone coordenadas de peces payaso 3 ***
	x=23;
	foto[x].x = 22;  foto[x].y = 0; foto[x].z = -5;
	foto[x].zoomx = 0.6; foto[x].zoomy = 0.4;
	foto[x].velox= -1.2; foto[x].veloy= 0.4; foto[x].veloz= -0.6;
	foto[x].rotay = 180; foto[x].invDir = True;

	// *** Pone coordenadas de peces reina ***
	x=24;
	foto[x].x = -30;  foto[x].y = 6; foto[x].z = -5;
	foto[x].zoomx = 0.6; foto[x].zoomy = 0.6;
	foto[x].velox= -0.4; foto[x].veloy= 0.1; foto[x].veloz= -0.2;
	foto[x].rotay = 180; foto[x].invDir = True;

	// *** Pone coordenadas de peces claro ***
	x=25;
	foto[x].x = 30;  foto[x].y = 10; foto[x].z = -5;
	foto[x].zoomx = 0.6; foto[x].zoomy = 0.4;
	foto[x].velox= -0.6; foto[x].veloy= 0.4; foto[x].veloz= -0.4;
	foto[x].rotay = 180; foto[x].invDir = True;

	// *** Pone coordenadas de peces payaso 1 ***
	x=26;
	foto[x].x = 0;  foto[x].y = 16; foto[x].z = -6;
	foto[x].zoomx = 0.6; foto[x].zoomy = 0.4;
	foto[x].velox= -0.6; foto[x].veloy= 0.4; foto[x].veloz= -0.0;
	foto[x].rotay = 180; foto[x].invDir = False;


	// *** Pone coordenadas de peces payaso 2 ***
	x=27;
	foto[x].x = 10;  foto[x].y = 18; foto[x].z = -6;
	foto[x].zoomx = 0.6; foto[x].zoomy = 0.4;
	foto[x].velox= -0.6; foto[x].veloy= 0.4; foto[x].veloz= -0.0;
	foto[x].rotay = 180; foto[x].invDir = False;

	// *** Pone coordenadas de peces payaso 3 ***
	x=28;
	foto[x].x = 20;  foto[x].y = 14; foto[x].z = -6;
	foto[x].zoomx = 0.6; foto[x].zoomy = 0.4;
	foto[x].velox= -0.6; foto[x].veloy= 0.4; foto[x].veloz= -0.0;
	foto[x].rotay = 180; foto[x].invDir = False;
	
	printf("Peces iniciados.\n");
}

// *** Inicia la comida de los peces ***
void IniComida()
{
	estanComiendo = True;
	
	// ref: http://www.chuidiang.com/clinux/funciones/rand.php
	srand48(time(NULL));
	
	for (int i=0; i < PapelesMax; i++)
	{
		comida[i].x = (drand48() * 80) - 40;
		comida[i].y = (drand48() * 15) + 21;
		comida[i].z = -1.5;
		comida[i].velox = -0.05 + (drand48() / 10); // da + y -
		comida[i].veloy = -0.10 - (drand48() / 10); // da - solo
		comida[i].veloz = 0;
		comida[i].zoomx = 0.2;
		comida[i].zoomy = 0.2;
		comida[i].sePinta = True;		
	}
	
	printf("Damos de comer a los peces.\n");	
	
}

// *** Inicia el pintado de pantalla ***
void Init(){    
    // Color de borrado
    glClearColor(0.0, 4.0, 7.0, 1.0);
    // Habilitar la visibilidad (z-buffer)
    glEnable(GL_DEPTH_TEST);
    
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    
    
    // *** Inicia las fotos (pone coordenadas, velocidad, ...) ***
    IniciaFotos();
    
	// *** Carga todas las texturas y fotos ***
	for (int i=0; i < FotosMax; i++)
	{		
	    glGenTextures(1, &foto[i].textura);
	    glBindTexture(GL_TEXTURE_2D, foto[i].textura);	    
	    loadImageFile( foto[i].archivo ); 
	    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	    if (i != 0) glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	}
	printf("Cargadas %i texturas.\n", FotosMax);

    
    // *** Activa las texturas ***
    glEnable(GL_TEXTURE_2D);
    
}

// *** Pinta la foto que indiques ***
void pintaFoto( int x ){
    glBindTexture(GL_TEXTURE_2D, foto[x].textura);
    glPushMatrix();
    glPushAttrib(GL_COLOR_BUFFER_BIT); 
    
    glTranslatef(foto[x].x, foto[x].y, foto[x].z);	// desplaza foto.
    glScalef(foto[x].zoomx, foto[x].zoomy, 1); 		// zoom de foto.
    glRotatef( foto[x].rotaActx, 1.0f, 0.0f, 0.0f );	// rota la foto.    
    glRotatef( foto[x].rotaActy, 0.0f, 1.0f, 0.0f );	// rota la foto.    
    glRotatef( foto[x].rotaActz, 0.0f, 0.0f, 1.0f );	// rota la foto.
    glBegin(GL_QUADS);
        glTexCoord2d(0,0); glVertex3f(0, 0, 0);
        glTexCoord2d(0,1); glVertex3f(0, 10, 0);
        glTexCoord2d(1,1); glVertex3f(10, 10, 0);
        glTexCoord2d(1,0); glVertex3f(10, 0, 0);
    glEnd();
    
    glPopAttrib();
    glPopMatrix();
}

// *** Pinta papeles (comida) ***
void pintaPapel(int x){
    // Dibujar papelitos comida peces + movimiento
    glPushMatrix();
        glColor3f(1.0, 1.0, 1.0);
        glBegin(GL_TRIANGLES);
            glVertex3f(0, 0, 0);
            glVertex3f(0, 10, 0);
            glVertex3f(5, -5, 0);
        glEnd();
    glPopMatrix();
    printf("pinto trianguo.\n");
}


// *** Pinta la pantalla ***
void display(){

    // *** Borra pantalla ****
    glClearColor (0.5,0.5,0.5,0.5); // Color del borrado.
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Seleccionar la matrix del modelo
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    
    // Situo y oriento la camara
    gluLookAt(	0, 0, 20 /* ojo */,
              0.0, 0.0, 0.0 /* punto al que miro */,
              0.0, 1.0, 0.0 /* vertical subjetiva */);

  
    // *** Pinta fodo ***
	glBindTexture(GL_TEXTURE_2D, foto[0].textura);
	glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT | GL_TEXTURE_BIT);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
    glDisable(GL_TEXTURE_GEN_S);
    glDisable(GL_TEXTURE_GEN_T);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);		//Texel menor que pixel
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);		//Texel mayor que pixel
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);			//La textura se repite en abcisas
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);			//La textura se repite en ordenadas
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);				//Asigna solo el color de la textura al fragmento

    
    // --- Cargar el fondo con la textura corriente ---
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glOrtho(-1,1,-1,1,-10,10);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    
    glBegin(GL_POLYGON);
    glTexCoord2f(0,0); glVertex3f(-1,-1,0);
    glTexCoord2f(1,0); glVertex3f(1,-1,0);
    glTexCoord2f(1,1); glVertex3f(1,1,0);
    glTexCoord2f(0,1); glVertex3f(-1,1,0);
    glEnd();
    
    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    
    glPopAttrib();


    // *** pinta coral ***
	for(foto[1].x = -40; foto[1].x < 40; foto[1].x = foto[1].x + 5)
        pintaFoto(1);

    // *** Pinta adornos ***
    for (int i = FotosAdor; i < FotosBru; i++)
		pintaFoto(i);

    // *** Pinta burbujas ***
    for (int i = FotosBru; i < FotosPez; i++)
		pintaFoto(i);
    
    // *** Pinta los peces *** 
    for (int i = FotosPez; i < FotosComida; i++) 
		if ( i < FotosPez + numPeces ) pintaFoto (i);

	// *** Pinta la sirena ***
	if (foto[2].invDir == True) pintaFoto (2);
		
	// *** Pinta la comida ***
	if (estanComiendo == True) 
	{
		int contaComida = 0;
		int a;
		
		for (int i=0; i < PapelesMax; i++)
		{
			if ( comida[i].sePinta == True)
			{
				a = FotosComida + contaComida;
				
			    foto[a].x = comida[i].x;
			    foto[a].y = comida[i].y;
			    foto[a].z = comida[i].z;
				    
			    foto[a].zoomx = comida[i].zoomx;
			    foto[a].zoomy = comida[i].zoomy;
				    
			    foto[a].rotaActx = 0;
			    foto[a].rotaActy = 0;
			    foto[a].rotaActz = 0;
					 
				pintaFoto (a);
			}
			contaComida = (contaComida + 1) % 4;
		}
	}

    // *** Intercambia los buferes ***
    glutSwapBuffers();
}

// *** Sale ***
void cerrarPrograma(){
  
	// *** Cierra freeimage ***
    FreeImage_DeInitialise();  
  
	// *** Cierra OpenAl (Sonido) ***
	alSourceStop(fuente);
	alDeleteSources( 1, &fuente );
	alDeleteBuffers( 1, &buffer );
	alutExit();
  
	// *** Libera las texturas (openGL) ***
	for (int i=0; i < FotosMax; i++)
		glDeleteTextures( 1, &foto[i].textura);
  
	// *** Libera imagen (openCV) ***
	cvReleaseImage( &image );

    // *** Cierra el video (openCV) ***
	cvReleaseCapture( &capture );    
	
	// *** mensaje final ***
	printf("Fin del programa.\n");

}

// *** Ventana cambia de tamaño ***
void reshape(int w, int h){
    // Definir el marco
    glViewport(0, 0, w, h);
    
    // Configurar la c·mara
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    
    // Mantener la isotopria
    float razon = (float)w/h;
    
    // Camara Perspectiva
    gluPerspective(90, razon, 0.1, 1000);
    
}


// *** Imprime la ayuda ***
void ayuda()
{
	printf("***** Información de Ayuda *******\n");	
	printf("cursor arriba  - Añade un pez.\n");
	printf("cursor abajo   - Disminuye un pez.\n");
	printf("cursor derecha - Disminuye el volumen.\n");
	printf("cursor izquierda-Aumenta el volumen.\n\n");

	
	printf("r - Reinicia pecera.\n");
	printf("a - Asusta los peces.\n");
	printf("s - Finaliza el susto.\n");
	printf("v - Activa la webcam.\n");
	printf("b - Desactiva la webcam.\n");
	printf("c - Da de comer a los peces.\n");
	printf("h - Muestra esta ayuda.\n");
	printf("q - Salir.\n\n");
	
	printf("Click en la parte superior de la pantalla - Da de comer a los peces.\n");
	printf("Click en la parte inferior de la pantalla - Llama a ser mitológico.\n\n");	
	
}

// *** Gestion de teclas pulsadas ***
void onKey(unsigned char key, int x, int y){
    switch (key) {

        // *** Salir ***
        case 27:           /* Esc, q, Q will quit */
        case 'q':
        case 'Q':            
            exit(0);
            //cerrarPrograma();
            break;

		// *** Reinicia pecera ***
		case 'R':
		case 'r':
			IniciaFotos();
			break;

		// *** Pez asustado ***
        case 'A':
        case 'a':
			pezAsustado = True;
			printf("Peces asustados.\n");
			break;

		// *** Pez normal ***
        case 'S':
        case 's':
			pezAsustado = False;
			printf("Fin del susto, manual.\n");
			break;
			
		// *** Activa Webcam (y seguimiento de sirena) ***
		case 'V':
		case 'v':			
			if (webCamActiva == False) 
				webCamActiva = webCamOn();
			else 
				printf("La WebCam ya esta activa.\n");
			
			break;

		// *** Desactiva WebCam ***
		case 'B':
		case 'b':
			if (webCamActiva == True) 
			{
				webCamOff();
				webCamActiva = False;
				foto[2].rotax = -1; // esconde sirena
				foto[2].rotay = -1;
			} else 				
				printf("La WebCam ya esta cerrada.\n");				
			break;	
			
		// *** Damos de comer a los peces ***
		case 'C':
		case 'c':
			if (estanComiendo == False) 
				IniComida();
			else
				printf("Aun estan comiendo.\n");
			break;
			
		// *** Muestra la ayuda ***
		case 'H':
		case 'h':
			ayuda();
			break;
			
    }
}

// *** Menu emergente ***
void onMenu(int value){
    switch (value){
        
        // *** Asusta los peces ***
        case 1:
			pezAsustado = True;
			printf("Peces asustados.\n");
            break;
        
        // *** Da de comer a los peces ***
        case 2:
			if (estanComiendo == False) 
				IniComida();
			else
				printf("Aun estan comiendo.\n");
			break;
			
        // *** Activa o desactiva la webcam ***
        case 3:
			if (webCamActiva == False) 
				webCamActiva = webCamOn();
			else {
				webCamOff();
				webCamActiva = False;
				foto[2].rotax = -1; // esconde sirena
				foto[2].rotay = -1;
			}
			break;	

        
        // *** Reinicia los peces ***
        case 4:
            IniciaFotos();
            break;
        
        // *** Muestra la ayuda ***
        case 5:
            ayuda();
            break;
        
        // *** Salir ***
        case 6:
            exit(0);
            break;
    }
}

// *** Control del raton ***
void mouse(int button, int state, int x, int y){
    
    // *** tamaño ventana ***
    double ventAncho = glutGet(GLUT_WINDOW_WIDTH);
    double ventAlto = glutGet(GLUT_WINDOW_HEIGHT);
    
    // *** tantos por uno de x, y ***
    double porX = x / ventAncho;
    double porY = y / ventAlto;

    // *** la sirena se va ***
    if(button == GLUT_MIDDLE_BUTTON && state == GLUT_DOWN) 
	{
		foto[2].rotax = -1;
		foto[2].rotay = -1;
		foto[2].rotaz = 0;
		foto[2].invDir = True;
		printf("La Sirena se esconde.\n");
	}

    // *** la sirena te busca ***
    if(button == GLUT_LEFT_BUTTON && porY > 0.30 && state == GLUT_DOWN)
    {
		foto[2].rotax = porX * 80;
		foto[2].rotay = 40 - (porY * 40);
		foto[2].rotaz = 0;
		foto[2].invDir = True;
		printf("La Sirena te busca.\n");
	}
    
    // *** Damos de comer a los peces ***
    if (button == GLUT_LEFT_BUTTON && porY < 0.30 && state == GLUT_DOWN && estanComiendo == False) 
		IniComida();
}

// *** Teclas del cursor ***
void onSpecialUp(int tecla, int x, int y){
    
	switch (tecla) 
	{
		// *** Cursor arriba - Aumenta el nº de peces ***
		case GLUT_KEY_UP:		
	        if (numPeces < FotosComida - FotosPez)
	        {
				numPeces++;			
				printf("Numero de peces mostrados: %i \n", numPeces);
				glutPostRedisplay();
			}
			break;

		// *** Cursor abajo - Disminuye el nº de peces ***
		case GLUT_KEY_DOWN:
	        if (numPeces > 0)
	        {
				numPeces--;			
				printf("Numero de peces mostrados: %i \n", numPeces);
				glutPostRedisplay();
			}
			break;

		// *** Cursor izq - Sube el volumen ****
		case GLUT_KEY_RIGHT:
			if (volumen < 1.0)
			{	
				volumen += 0.05;
				alSourcef(fuente,AL_GAIN,volumen);	// pone volumen(ganancia) 
				printf("Sube el volumen a %f.\n", volumen);
			}
			break;

		// *** Cursor izq - Disminuye el volumen ****
		case GLUT_KEY_LEFT:		
			if (volumen > 0.0)
			{	
				volumen -= 0.05;
				alSourcef(fuente,AL_GAIN,volumen);	// pone volumen(ganancia) 
				printf("Baja el volumen a %f.\n", volumen);
			}
			break;
	}    
}

// *** mueve los peces ***
void muevePeces(int valorSinUso){

	static int pezAsustadoContador;
	static int webCamContador;
	static int comerContador;

	int x;
	
    // *** inicia el generador de numeros aleatorios ***
    srand((unsigned int) time(NULL));
    
    // *****************************************************
    // *** Desactiva el susto de peces, después unos seg ***
    // *****************************************************
    if (pezAsustado == False)
		pezAsustadoContador = 40;
	else
	{
		pezAsustadoContador--;
		if (pezAsustadoContador <= 0) 
			{
				// *** Fin del susto ***
				pezAsustado = False;
				
				// *** Peces que mueren del suste ***
				for (int i = FotosPez; i < FotosMax; i++)				
					if (rand() % 100 < 80) foto[i].rotaActz = 180;				
				printf("Fin del susto, automático (algunos peces se han muerto).\n");
			}
	}
		
	
    // *****************************************************
	// ********** Detecta Caras (con webCam activa) ********
    // *****************************************************
	if ( webCamActiva == True ) 
	{
		// tiempo en milisegundos.
		webCamContador = (webCamContador + 1) % 4;
		if (webCamContador == 0) 
		{
			webCamDetCara();
			foto[2].rotax = 80 - (caraX * 80); // en la webcam x esta invertida
			foto[2].rotay = 40 - (caraY * 40);
			foto[2].invDir = True;	// activa el pintado
		}	
	}

    // *****************************************************
    // ************* Mueve las burbujas ********************
    // *****************************************************
    for (int i = FotosBru; i < FotosPez; i++)
    {
		// *** llega al limite superior ***
		if (foto[i].y > 20 ) 
			foto[i].y = -20;
		else 		
			// *** Actualiza movimiento ***
			foto[i].y = foto[i].y + foto[i].veloy;
	}
    
    // *****************************************************
	// ***************** Mueve la comida *******************
    // *****************************************************
	if (estanComiendo == False)
		comerContador = 300;	// tiempo de espera para comer.		
	else 	
		if (comerContador <= 0)
		{
			// *** Fin de la comida ***
			estanComiendo = False;
			printf("Fin de la comida.\n");
			
		} else {
			
			// *** Están comiendo ***
			comerContador--;
		
			for (int i=0; i < PapelesMax; i++)					
				if ( comida[i].sePinta == True)
				{
				    comida[i].x += comida[i].velox;
				    comida[i].y += comida[i].veloy;
				    comida[i].z += comida[i].veloz;
				    
				    if (comida[i].y < -15 || drand48() < ( (comerContador > 100) ? 0.01 : 0.03 )  ) 
						comida[i].sePinta = False;
				}		
		}
		

    // *****************************************************
    // ***************** Mueve la sirena *******************
    // *****************************************************
    x=2;
    if ( foto[x].invDir == True)
    {
		// Posición real en pantalla:	x, y, z (positivas o negativas);
		// Posición a la que quiere ir:	rotax, rotay, rotaz (positivas siempre);
		// Posición actual: 			veloActx, veloActy, veloActz (positivas siempre);
		// Velocidad:					velox, veloy, veloz;
		// Se pinta:					invDir;
		// Ratación:					rotaActx, rotaActy, rotaActz
		
		double distancia;
		
		// ############### control x ####################
		
		// *** La sinera se esconde (1º se va y despues se esconde) ***
		if (foto[x].rotax == -1.0 && foto[x].rotay == -1.0)
		{
			foto[x].rotax = 140;
			foto[x].rotay = 10;
			if (foto[x].velox < 0) foto[x].rotax *= -1;	
		}
		if (fabs(foto[x].veloActx) > 120 ) foto[x].invDir = False;
		
		// *** Busca la posición (ajusta la dir de la velo) ***
		if (foto[x].veloActx > foto[x].rotax && foto[x].velox > 0) 
			foto[x].velox = foto[x].velox * -1;
		
		if (foto[x].veloActx < foto[x].rotax && foto[x].velox < 0) 
			foto[x].velox = foto[x].velox * -1;
		
		// *** Controla la rotación según su dirección ***
		if (foto[x].velox > 0) { foto[x].rotaActx=0; foto[x].rotaActy=180; }
		if (foto[x].velox <= 0) { foto[x].rotaActx=0; foto[x].rotaActy=0; }

		// *** Suaviza el avance ***
		distancia = (fabs(foto[x].veloActx - foto[x].rotax) / 80) * 100;
		if (distancia > 20 ) 
			foto[x].veloActx = foto[x].veloActx + foto[x].velox;
		else if (distancia > 10 ) 
			foto[x].veloActx = foto[x].veloActx + foto[x].velox / 1.5;
		else if (distancia > 6 ) 
			foto[x].veloActx = foto[x].veloActx + foto[x].velox / 2;
		else if (distancia > 4 ) 
			foto[x].veloActx = foto[x].veloActx + foto[x].velox / 4;
	
		// *** Actualiza la posi real **
		// x va de -40 a 40 y tiene una anchura de 80.
		foto[x].x=foto[x].veloActx - 40;
		
		
		
		// ############### control y ####################
		
		// *** Busca la posición (ajusta la dir de la velo) ***
		if (foto[x].veloActy > foto[x].rotay && foto[x].veloy > 0) 
			foto[x].veloy = foto[x].veloy * -1;
		
		if (foto[x].veloActy < foto[x].rotay && foto[x].veloy < 0) 
			foto[x].veloy = foto[x].veloy * -1;
		
		// *** Suaviza el avance ***
		distancia = (fabs(foto[x].veloActy - foto[x].rotay) / 40) * 100;
		if (distancia > 20 ) 
			foto[x].veloActy = foto[x].veloActy + foto[x].veloy;
		else if (distancia > 10 ) 
			foto[x].veloActy = foto[x].veloActy + foto[x].veloy / 1.5;
		else if (distancia > 6 ) 
			foto[x].veloActy = foto[x].veloActy + foto[x].veloy / 2;
		else if (distancia > 4 ) 
			foto[x].veloActy = foto[x].veloActy + foto[x].veloy / 4;
	
		// *** Actualiza la posi real **
		// y va de -20 a 20 y tiene una anchura de 40.
		foto[x].y=foto[x].veloActy - 20;
		
		
	}
    
    
    // *****************************************************
    // ****************** Mueve los peces ******************
    // *****************************************************
    for (int i = FotosPez; i < FotosComida; i++)
    {
		// *** Sale si el pez no se pinta ***
		if ( i >= FotosPez + numPeces ) break;
		
		// ############### control x ####################
		
		// *** llega al limite derecho ***
		if (foto[i].x > 40 -1 && foto[i].velox > 0 && pezAsustado == False)
			foto[i].velox = foto[i].velox * -1;
			
		// *** llega al limite izquierdo ***
		if (foto[i].x < -40 && foto[i].velox < 0 && pezAsustado == False)
			foto[i].velox = foto[i].velox * -1;	
		
		// *** Cambio de sentido al azar (evita cambios continuados) ***
		if 
		(	rand() % 100 < 0.2 && foto[i].invDir == True && pezAsustado == False &&
			(foto[i].velox > 0 && foto[i].veloActx > foto[i].velox * 0.8 ||
			foto[i].velox < 0 && foto[i].veloActx < foto[i].velox * 0.8)			
		) 		
			foto[i].velox = foto[i].velox * -1;

		// *** Cambia la direción con suavidad ***
		// ref: http://www.cplusplus.com/reference/cmath/abs/
		if ( foto[i].veloActx  > foto[i].velox )
			foto[i].veloActx = foto[i].veloActx - fabs(foto[i].velox/40);

		if ( foto[i].veloActx  < foto[i].velox )
			foto[i].veloActx = foto[i].veloActx + fabs(foto[i].velox/40);
			

		// *** Controla la rotación según su dirección ***
		if (foto[i].veloActx > 0) { foto[i].rotax=0; foto[i].rotay=180; }
		if (foto[i].veloActx <= 0) { foto[i].rotax=0; foto[i].rotay=0; }

		
		// *** Cambia la rotación con suavidad ***
		if ( foto[i].rotaActy > foto[i].rotay )
			foto[i].rotaActy = foto[i].rotaActy - 45;

		if ( foto[i].rotaActy < foto[i].rotay )				
			foto[i].rotaActy = foto[i].rotaActy + 45;
		
	
		// *** Actualiza movimiento de der a izq ***
		if (pezAsustado == False )
			if ( foto[i].rotaActz != 180 || fabs(foto[i].x) > 80)
				// *** pez normal ***
				foto[i].x = foto[i].x + foto[i].veloActx;
			else
				// *** pez muerto ***
				foto[i].x = foto[i].x + (foto[i].veloActx / 4.0f);
		else
			// *** pez asustado ***
			if ( fabs(foto[i].x) < 100 ) 
				foto[i].x = foto[i].x + foto[i].veloActx*40;
			

		// ############### control y ####################

		// *** Llega al limite superior ***
		if (foto[i].y > 15 && foto[i].veloy > 0 && pezAsustado == False)
			foto[i].veloy = foto[i].veloy * -1;
		
		// *** Llega al limite inferior ***
		
		if (foto[i].y < ( (estanComiendo == False) ? -15 : 5) && foto[i].veloy < 0 && pezAsustado == False)
			foto[i].veloy = foto[i].veloy * -1;

		// *** Cambio de sentido al azar (evita cambios continuados) ***
		if 
		(	rand() % 100 < 0.6 && foto[i].invDir == True && 
			pezAsustado == False && estanComiendo == False &&
			(foto[i].veloy > 0 && foto[i].veloActy > foto[i].veloy * 0.8 ||
			foto[i].veloy < 0 && foto[i].veloActy < foto[i].veloy * 0.8)			
		) 		
			foto[i].veloy = foto[i].veloy * -1;

		// *** Cambia la direción con suavidad ***
		if ( foto[i].veloActy  > foto[i].veloy )
			foto[i].veloActy = foto[i].veloActy - fabs(foto[i].veloy/20);

		if ( foto[i].veloActy  < foto[i].veloy )
			foto[i].veloActy = foto[i].veloActy + fabs(foto[i].veloy/20);
			

		// *** Actualiza movimiento superior e inferior ***
		if (pezAsustado == False )
			if ( foto[i].rotaActz != 180 || fabs(foto[i].y) > 40)
				// *** pez normal ***
				foto[i].y = foto[i].y + foto[i].veloActy;
			else
				// *** pez muerto ***
				foto[i].y = foto[i].y + (foto[i].veloActy / 4.0f);
		else
			// *** pez asustado ***
			if ( fabs(foto[i].y) < 50 ) 
				foto[i].y = foto[i].y + foto[i].veloActy*40;
			

		// ############### control z ####################

		// *** Llega al limite superior ***
		// No pongas valores positivos o los peces atravesaran el cristal.
		if (foto[i].z > -4 && foto[i].veloz > 0 && pezAsustado == False)
			foto[i].veloz = foto[i].veloz * -1;
		
		// *** Llega al limite inferior ***
		if (foto[i].z < -20 && foto[i].veloz < 0 && pezAsustado == False)
			foto[i].veloz = foto[i].veloz * -1;

		// *** Cambio de sentido al azar (evita cambios continuados) ***
		if 
		(	rand() % 100 < 0.6 && foto[i].invDir == True && pezAsustado == False &&
			(foto[i].veloz > 0 && foto[i].veloActz > foto[i].veloz * 0.8 ||
			foto[i].veloz < 0 && foto[i].veloActz < foto[i].veloz * 0.8)			
		) 		
			foto[i].veloz = foto[i].veloz * -1;

		// *** Cambia la direción con suavidad ***
		if ( foto[i].veloActz  > foto[i].veloz )
			foto[i].veloActz = foto[i].veloActz - fabs(foto[i].veloz/20);

		if ( foto[i].veloActz  < foto[i].veloz )
			foto[i].veloActz = foto[i].veloActz + fabs(foto[i].veloz/20);
			

		// *** Actualiza movimiento hacia adelante o hacia el fondo ***
		if (pezAsustado == False )
			if ( foto[i].rotaActz != 180 || fabs(foto[i].z) > 75)
				// *** pez normal ***
				foto[i].z = foto[i].z + foto[i].veloActz;
			else
				// *** pez muerto ***
				foto[i].z = foto[i].z + (foto[i].veloActz / 4.0f);
		else
			// *** pez asustado ***
			if ( fabs(foto[i].z) < 100 ) 
				foto[i].z = foto[i].z - fabs(foto[i].veloActz * 80);
	
	} // Fin del for para todos los peces.
	
	
    // *** Pide el repintado de pantalla ***
    glutPostRedisplay();
    
    // *** Prepara la siguiente actualizacion ***
    glutTimerFunc(ActMseg, muevePeces, 0);
}

// *** Carga el audio ***
void InitAlut(){
    // Inicializar alut
    //alutInit(0, NULL);
    
    // *** Crea y carga un bufer de sonido ***
    alGenBuffers(1, &buffer);
    buffer = alutCreateBufferFromFile("bubbles.wav");
    
    // *** Crea y pone propiedades a un altavoz ***
    alGenSources (1, &fuente);
    alSourcei(fuente, AL_BUFFER, buffer);
    alSourcei(fuente, AL_LOOPING, AL_TRUE);
    
    // *** Inicia la reproducion ***
    alSourcePlay (fuente);  
    
}

// *** Programa principal ***
int main(int argc, char **argv){

    // *** Inicia freeimage ***
    FreeImage_Initialise(0);
    
    // *** Inicia el sistema de video (openCV) ***
    cvInitSystem( argc, argv ); 
    
	// *** Inicia el sistema de sonido (OpenAL)  **
	alutInit (&argc, argv);

    // *** Inicia el sistema grafico (OpenGL) ***
    glutInit(&argc, argv);
    
    // Frame buffer doble y z-buffer
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    
    // Construir la ventana
    glutCreateWindow("Pecera");
    glutInitWindowSize(600, 600);
    glutPositionWindow(20,20);
   
    // *** Inicia los callbacks necesarios ***
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutSpecialFunc(onSpecialUp);
    glutKeyboardFunc(onKey);
    glutMouseFunc(mouse);
    glutTimerFunc(ActMseg, muevePeces, 0);
    
    // *** Carga el audio ***
    InitAlut();
    
    // *** Imprime las versiones ***
    printf("\n********** Pecera *********\n\n");
    
    printf("OpenGL, versión %s.\n", glGetString(GL_VERSION) );
    printf("OpenCV, versión %s.\n", CV_VERSION );
    printf("OpenAL, versión %i.%i.\n", alutGetMajorVersion(), alutGetMinorVersion() );
    printf("FreeImage, versión %s.\n\n", FreeImage_GetVersion() );
    // ref: http://freeimage.sourceforge.net/documentation.html
    
   	printf("Numero de peces mostrados: %d.\n\n", numPeces);    
    
    // *** Inicia la pantalla ***
    Init();    
    
    // *** Crear menu ***
    glutCreateMenu(onMenu);
    glutAddMenuEntry("* Asusta a los peces.", 1);
    glutAddMenuEntry("* Da de comer a los peces.", 2);
    glutAddMenuEntry("* Activa o desactiva la webcam.", 3);
    glutAddMenuEntry("* Reinicia los peces.", 4);
    glutAddMenuEntry("* Muestra ayuda.", 5);
    glutAddMenuEntry("* Salir.", 6);
    glutAttachMenu(GLUT_RIGHT_BUTTON);    
    
    
    // *** Prepara el cierre de programa ***
    // permite ejecutar la func cerrarPrograma antes de salir con exit(nº)
    // ref: http://www.zator.com/Cpp/E1_5_1.htm
    atexit(cerrarPrograma); 
    
    // *** Cede el control de eventos ha OpenGL (es un bucle infinito) ***
    glutMainLoop();
    
    // *** Sale (la liberacion se hace en la func cerrarPrograma) *** 
    return 0;
}
