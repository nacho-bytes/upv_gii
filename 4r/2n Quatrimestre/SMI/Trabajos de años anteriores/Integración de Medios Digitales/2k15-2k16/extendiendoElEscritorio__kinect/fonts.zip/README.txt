Para el funcionamiento de la aplicación se deberá seguir la instalación de las librerías necesarias
propuesta en la memoria del trabajo "MemoriaKinectFranciscoGonzalo.pdf" entregada anteriormente.

ATENCIÓN!!

Por problemas que desconocemos ¿con OpenGL? la ventana de la derecha no se actualiza
al inicio del programa, para que se vea deberemos detectar ambas manos (saludando al kinect 
y viendo que se dibuja un punto rojo sobre ellas en la ventana de OpenCV) y desplazar una de las
manos (generalmente la derecha) a la esquina superior derecha de la ventana, donde pulsará el
botón de dibujado y se mostrará la diapositiva correctamente.
