#!/usr/bin/python
# -*- coding: utf-8 -*-

###
# INTEGRACION DE MEDIOS DIGITALES, UPV
# Esta aplicacion permite dibuja un punto por cada mano detectada en la escena. Servira
# de guia para posteriores implementaciones.
#
# @author: Gonzalo Ortega Castillo (gonorcas@inf.upv.es)
# @author: Francisco Vazquez Palacios (fravzpa7@etsid.upv.es)
#
# @date Abril, 2016

from openni import *
import cv2.cv as cv
from OpenGL.GLUT import *
from OpenGL.GLU import *
from OpenGL.GL import *
from os import listdir
import math, Image, sys
import numpy  as np 


# Variables globales OpenNI
hands = {}

buttons =  {    
    'clearbutton': (0, 0, 640*0.2, 480*0.25),
    'drawbutton': (640*0.8, 0, 640*0.2, 480*0.25),
    'previousbutton': (640*0.3, 0, 640*0.2, 480*0.25),
    'nextbutton': (640*0.5, 0, 640*0.2, 480*0.25),
}

# Variables globales OpenGL
canClear, canMove = True, True
pdfpages = []
currPage = 0

# -------------------------------------------------------------------------------------
# FUNCIONES AUXILIARES
# -------------------------------------------------------------------------------------
def appendToCache(cache, val):
    cache.append(val)
    del cache[0]
    return (np.mean([x[0] for x in cache]), np.mean([y[1] for y in cache]))

def openNItoOpenCVCoords(openNIPoint):
  openCVPoint = depth.to_projective([openNIPoint])[0]
  return (int(openCVPoint[0]), int(openCVPoint[1]))

def openCVtoOpenGLCoords(openCVPoint, wwidth=640, wheight=480):
  x = (openCVPoint[0] - wwidth/2.0) / (wwidth/2.0)
  y = (wheight/2.0 - openCVPoint[1]) / (wheight/2.0)
  print openCVPoint, x, y
  return (x, y)

def texFromImage(filename):
    img = Image.open(filename)
    img_data = np.array(list(img.getdata()), np.uint8)
    texture = glGenTextures(1)
    glPixelStorei(GL_UNPACK_ALIGNMENT,1)
    glBindTexture(GL_TEXTURE_2D, texture)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, img.size[0], img.size[1], 0, GL_RGB, GL_UNSIGNED_BYTE, img_data)
    return texture

def overlap(rect, circ):
    rleft, rtop, width, height = rect[0], rect[1], rect[2], rect[3]
    center_x, center_y, radius = circ[0], circ[1], circ[2]
    rright, rbottom = rleft + width, rtop + height
    cleft, ctop = center_x-radius, center_y-radius
    cright, cbottom = center_x+radius, center_y+radius
    if rright < cleft or rleft > cright or rbottom < ctop or rtop > cbottom:
        return False
    for x in (rleft, rleft+width):
        for y in (rtop, rtop+height):
            if math.hypot(x-center_x, y-center_y) <= radius:
                return True
    if rleft <= center_x <= rright and rtop <= center_y <= rbottom:
        return True
    return False

def allowClearing(time):
    global canClear
    canClear = True

def allowMoving(time):
    global canMove
    canMove = True

# -------------------------------------------------------------------------------------
# OPENCV
# -------------------------------------------------------------------------------------
def initOpenCV():
    global videoImage
    # Creamos las ventanas e imagenes necesarias con OpenCV
    cv.NamedWindow('Video', cv.CV_WINDOW_AUTOSIZE)
    cv.MoveWindow('Video', 0,0)
    videoImage = cv.CreateImage((640,480), cv.IPL_DEPTH_8U, 3)

def displayOpenCV(image, window_name):
    cv.SetData(videoImage, image)
    # Dibuja la informacion recibida por la camara del kinect y la posicion de la mano
    if hands:
        for handID in hands:
            hand = hands[handID]
            center = (int(hand['currentPos'][0]), int(hand['currentPos'][1]))
            color = (0.0, 255.0, 255.0) if hand['drawing'] else (0.0, 0.0, 255.0)
            cv.Circle(videoImage, center, 30, color, cv.CV_FILLED )
    cv.ShowImage(window_name, videoImage)

# -------------------------------------------------------------------------------------
# OPENNI
# -------------------------------------------------------------------------------------

def initOpenNI():
    global context, video, depth, handsGenerator, gestureGenerator
    try:
        # Inicializamos OpenNI
        context = Context()
        context.init()
        context.init_from_xml_file('OpenniConfig.xml')    
        video = context.find_existing_node(NODE_TYPE_IMAGE) # RGB
        depth = context.find_existing_node(NODE_TYPE_DEPTH) # DEPTH
        # Manos
        handsGenerator = HandsGenerator()
        handsGenerator.create(context)
        # Gestos
        gestureGenerator = GestureGenerator()
        gestureGenerator.create(context)
        gestureGenerator.add_gesture('Wave')
        gestureGenerator.add_gesture('Click')    
        context.start_generating_all()
        # Anyadimos las callbacks pertinentes para las manos
        gestureGenerator.register_gesture_cb(gesture_detected, gesture_progress)
        handsGenerator.register_hand_cb(create, update, destroy)
    except OpenNIError, err:
        print "OpenNI error:", err

def gesture_detected(src, gesture, id, end_point):
    # Comienza a seguir una mano a partir del punto donde fue detectado el gesto
    handsGenerator.start_tracking(end_point)

def gesture_progress(src, gesture, point, progress): pass

def create(src, id, pos, time):
    # Guarda informacion sobre la nueva mano detectada:
    #   currentPos: posicion donde fue detectada
    #   cache: pequeña cache que elimina ruido
    pos = openNItoOpenCVCoords(pos)
    hands[id] = {'currentPos':pos, 
                 'cache': [pos]*10,
                 'drawing': False,
                 'clearing': False}
    print 'Detectada mano en', pos

def update(src, id, pos, time):
    # Guarda informacion acerca de la nueva posicion y actualiza la cache
    pos = openNItoOpenCVCoords(pos)
    pos = appendToCache(hands[id]['cache'], pos)
    hands[id]['currentPos'] = pos

def destroy(src, id, pos):
    # Elimina la informacion de la mano
    del hands[id]

# -------------------------------------------------------------------------------------
# OPENGL
# -------------------------------------------------------------------------------------
def initOpenGL():
    global drawicontex, clearicontex, nexticontex, previousicontex, \
        pdfpages 
    # Inicializaciones
    glutInit(sys.argv)
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH)
    glutInitWindowSize(640,480)
    glutInitWindowPosition(640, 0)
    glutCreateWindow('Canvas')
    # Callbacks
    glutDisplayFunc(display)
    glutIdleFunc(idle)
    glutReshapeFunc(reshape)
    glutKeyboardFunc(keyboard)
    # Texturas (iconos)
    glEnable(GL_TEXTURE_2D)
    clearicontex = texFromImage('icons/clear-freehand-icon.jpg')
    drawicontex = texFromImage('icons/draw-freehand-icon.jpg')
    nexticontex = texFromImage('icons/next-freehand-icon.jpg')
    previousicontex = texFromImage('icons/previous-freehand-icon.jpg')
    # Texturas (páginas del pfg)
    pdfpages = [texFromImage('pdf/'+pdf) for pdf in listdir('pdf')]
    clearWindow()
    glutMainLoop()

def keyboard(key, x, y):
   if key == chr(27):
      sys.exit(0)

def reshape(w, h): 
    pass

def idle():
    global canClear, canMove, currPage
    context.wait_any_update_all()
    image = video.get_raw_image_map_bgr()
    displayOpenCV(image, 'Video')
    for handid in hands:
        handarea = (hands[handid]['currentPos'][0],hands[handid]['currentPos'][1],30)
        # Case: estamos apretando el botón de limpiar
        if overlap(buttons['clearbutton'], handarea) and canClear:
            canClear = False
            clearWindow()
            glutTimerFunc(3000, allowClearing, 0);
            continue
        # Case: estamos aprentando el botón siguiente
        if currPage < len(pdfpages)-1 and \
            overlap(buttons['nextbutton'], handarea) and canMove:
            canMove = False; currPage += 1
            clearWindow()
            glutTimerFunc(3000, allowMoving, 0);
            continue
                # Case: estamos aprentando el botón siguiente
        if currPage > 0 and \
            overlap(buttons['previousbutton'], handarea) and canMove:
            canMove = False; currPage -= 1
            clearWindow()
            glutTimerFunc(3000, allowMoving, 0);
            continue
        # Case: estamos apretando el botón de dibujar
        candraw = overlap(buttons['drawbutton'], handarea)
        for x in [x for x in hands.keys() if x != handid]:
            hands[x]['drawing'] = candraw
    key = cv.WaitKey(1)
    if key > 0:
        sys.exit()
    glutPostRedisplay()

def clearWindow():
    glClearColor(1.0, 1.0, 1.0, 1.0)
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity();
    glEnable(GL_TEXTURE_2D)
    glColor(1.0,1.0,1.0)
    glBindTexture(GL_TEXTURE_2D, pdfpages[currPage])
    # Dibujamos el pdf de fondo
    glBegin(GL_QUADS)
    glTexCoord2d(0.0,0.0); glVertex2d(-1.0,  1.0)
    glTexCoord2d(1.0,0.0); glVertex2d( 1.0,  1.0)
    glTexCoord2d(1.0,1.0); glVertex2d( 1.0, -1.0)
    glTexCoord2d(0.0,1.0); glVertex2d(-1.0, -1.0)
    glEnd()
    # Dibujamos el icono de borrado
    glBindTexture(GL_TEXTURE_2D, clearicontex)
    glBegin(GL_QUADS)
    glTexCoord2d(0.0,0.0); glVertex2d(-1.0, 1.0)
    glTexCoord2d(1.0,0.0); glVertex2d(-0.8, 1.0)
    glTexCoord2d(1.0,1.0); glVertex2d(-0.8, 0.75)
    glTexCoord2d(0.0,1.0); glVertex2d(-1.0, 0.75)
    glEnd()
    # Dibujamos el icono de dibujo
    glBindTexture(GL_TEXTURE_2D, drawicontex)
    glBegin(GL_QUADS)
    glTexCoord2d(0.0,0.0); glVertex2d(1.0, 1.0)
    glTexCoord2d(1.0,0.0); glVertex2d(0.8, 1.0)
    glTexCoord2d(1.0,1.0); glVertex2d(0.8, 0.75)
    glTexCoord2d(0.0,1.0); glVertex2d(1.0, 0.75)
    glEnd()
    # Dibujamos la flecha "siguiente" si hay una diapo siguiente
    if currPage < len(pdfpages)-1:
        glBindTexture(GL_TEXTURE_2D, nexticontex)
        glBegin(GL_QUADS)
        glTexCoord2d(0.0,0.0); glVertex2d(0.0, 1.0)
        glTexCoord2d(1.0,0.0); glVertex2d(0.2, 1.0)
        glTexCoord2d(1.0,1.0); glVertex2d(0.2, 0.75)
        glTexCoord2d(0.0,1.0); glVertex2d(0.0, 0.75)
        glEnd()
    # Dibujamos la flecha "anterior" si hay una diapo anterior
    if currPage > 0:
        glBindTexture(GL_TEXTURE_2D, previousicontex)
        glBegin(GL_QUADS)
        glTexCoord2d(0.0,0.0); glVertex2d(-0.2, 1.0)
        glTexCoord2d(1.0,0.0); glVertex2d( 0.0, 1.0)
        glTexCoord2d(1.0,1.0); glVertex2d( 0.0, 0.75)
        glTexCoord2d(0.0,1.0); glVertex2d(-0.2, 0.75)
        glEnd()
    glutSwapBuffers()

def display():
    for handid in [handid for handid in hands.keys() if hands[handid]['drawing']]:
        vertex, vertey = openCVtoOpenGLCoords(hands[handid]['currentPos'])
        glEnable(GL_POINT_SMOOTH)
        glPointSize(10.0)
        glColor(0.0,0.0,1.0)
        glBegin(GL_POINTS);
        glVertex2d(vertex, vertey)
        glEnd();
        glutSwapBuffers();

# -------------------------------------------------------------------------------------
# MAIN
# -------------------------------------------------------------------------------------

if __name__ == "__main__":

    initOpenCV();
    initOpenNI();
    initOpenGL();
