//

#include <stdio.h>
/*
#include <opencv/cv.h>
#include <opencv/cxcore.h>
#include <opencv/highgui.h>
*/
#include <opencv2/opencv.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>




#define Stream "OpenCV camara"
#define StreamGris "OpenCV Umbral"
#define PintaPantalla "OpenCV Snake Alvaro"


struct list {
  int x;
  int y;
  struct list *next;
};

struct puntoObjetivo {
  int x;
  int y;
  int reaparece;
};

 struct list *raiz;
 struct list *rec;
 

struct list* crearLista(int x ,int y){
	struct list *ptr = (struct list*)malloc(sizeof(struct list));
    
    ptr->x = x;
    ptr->y = y;
    ptr->next = NULL;

    raiz = rec = ptr;
    return ptr;
	}

struct list* asignarALista(int x, int y,IplImage* image,int refresco,int valorRefresco){
	if(NULL == raiz){
        return (crearLista(x,y));
    }
    int thickness = -1,line_type = CV_AA,shift = 0;

    struct list *ptr = (struct list*)malloc(sizeof(struct list));
  
    ptr->x = x;
    ptr->y = y;
    ptr->next = NULL;
    if(refresco==valorRefresco){
    //eliminamos el primero
	cvCircle(image, cvPoint(raiz->x,raiz->y), 12, cvScalar(255,255,255, 1), thickness, line_type, shift );
	
    raiz = raiz->next;
	}
    //añadimos al final  
    rec->next = ptr;
    rec = ptr;
    
    return ptr;
}

struct list* recorreSerpeinte(IplImage* image){
    struct list *ptr = raiz;
	int thickness = -1,line_type = CV_AA,shift = 0;

    while(ptr != NULL){
        cvCircle(image, cvPoint(ptr->x,ptr->y), 10, cvScalar(0,0,0, 1), thickness, line_type, shift );
		ptr = ptr->next;
        
        }
    }

int centroGravedad(IplImage *imagen, CvPoint *posCDG, int grisObjeto) {

int suma_x, suma_y, n, i, j;
CvScalar s;

suma_x = 0; suma_y = 0; n = 0;

for(i=0; i<imagen->height; i++)
	for(j=0; j<imagen->width; j++) {
		s=cvGet2D(imagen,i,j);
	if(s.val[0] == grisObjeto) { 
		suma_x += j;
		suma_y += i;
		n++; 
		} 
	} 
	if( n != 0 ) {
			posCDG->x = suma_x / n; posCDG->y = suma_y / n; 
	}else{ 		posCDG->x = 0;		 posCDG->y = 0;
		}
return( 0 );
} // Fin de "int cdg( ...

void  pintaCruz( IplImage* image, int fila, int columna, int ancho ){
  int thickness = 1,
      line_type = CV_AA,
      shift = 0;

  cvLine(image, cvPoint(columna-ancho,fila), cvPoint(columna+ancho, fila), cvScalar(0,255,0, 1), thickness, line_type, shift );
  cvLine(image, cvPoint(columna, fila-ancho), cvPoint(columna, fila+ancho), cvScalar(0,255,0, 1), thickness, line_type, shift );

}// Fi de "void  pintaCruz( ..."

void generaPuntoObjetivo(puntoObjetivo *punto,int fila, int columna){
int i;
for(i=0;i<10;i++){	
	if(punto[i].x==0 & punto[i].y==0){
		punto[i].x=fila;
		punto[i].y=columna;
		punto[i].reaparece=100+10*i;
		break;
	}
}
}

void ponPuntoObjetivo(IplImage* image,puntoObjetivo *punto){
	int thickness = -1, i=0,line_type = CV_AA,shift = 0;
	for(i=0;i<10;i++){
		if(punto[i].x==0)break;
		punto[i].reaparece--;
		printf("%d (%d, %d)\n",i,punto[i].x,punto[i].y);
		
	if(punto[i].reaparece>0) cvCircle(image, cvPoint(punto[i].x,punto[i].y), 10, cvScalar(100,255,255, 1), thickness, line_type, shift );
	if(-50>punto[i].reaparece){
		cvCircle(image, cvPoint(punto[i].x,punto[i].y), 12, cvScalar(255,255,255, 1), thickness, line_type, shift );
		punto[i].reaparece=300+10*i;}
	}
	}

int objetivoPintado(IplImage* image,puntoObjetivo *objetivo,CvPoint *punto){
	int thickness = -1, i=0,line_type = CV_AA,shift = 0;
	int distanciaO=20;
	float distanciaS;
	
	for(i=0;i<10;i++){
		if(punto[i].x==0 )break;
	
		distanciaS=sqrt(((objetivo[i].x-punto->x)*(objetivo[i].x-punto->x))+((objetivo[i].y-punto->y)*(objetivo[i].y-punto->y)));
		if(distanciaO>distanciaS & objetivo[i].reaparece>0){
			objetivo[i].reaparece=0;
		    cvCircle(image, cvPoint(objetivo[i].x,objetivo[i].y), 12, cvScalar(255,255,255, 1), thickness, line_type, shift );
		    return 1;}
		}
	return 0;
	}

void pintameeeTexto( IplImage* image,  int puntuacion ){
  double hScale = 0.5, 
         vScale = 0.5, 
         lineWidth = 1.0, 
         italicScale = 1.0;
  int tipoLletra = CV_FONT_HERSHEY_SIMPLEX,columna = 50,fila = 50;
  int thickness = -1, i=0,line_type = CV_AA,shift = 0;
	
  CvFont font;
  char msj[1024];
  
  cvInitFont(&font,CV_FONT_HERSHEY_SIMPLEX, hScale,vScale, italicScale, lineWidth, 8);
  cvRectangle(image, cvPoint(columna,fila-15),cvPoint(columna+120,fila+5), cvScalar(230,255,255, 1), thickness, line_type, shift );
	
  sprintf(msj,"Puntuacion: %d",puntuacion);
	cvPutText (image,msj, cvPoint(columna, fila ), &font, CV_RGB(0,0,0));


}

int main(int argc, char* argv[]) {
 int tecla, i, j,puntuacion,valorUmbral,salir,tasaRefresco,valorRefresco,aux;
 IplImage *imgOrg,*imgGris,*imgUmbral,*imgNegro,*imgFlip;
 long int nCuadro;
 puntoObjetivo arrayObjetivo[10];
 
 CvSize imgSize; // size of visualisation image
 CvCapture* videoOrg;
 CvPoint posCDG,p1,p2;
 CvFont font;
 double fps, tiempoEntreCuadros;
 	
 valorUmbral= 225;
 nCuadro = 0;
 puntuacion=0;
 tasaRefresco=0;
 valorRefresco=4;
 aux=0;
 for(i=0;i<10;i++){arrayObjetivo[i].x=0;
 arrayObjetivo[i].y=0;
}



  printf("%s [OpenCV version %s]\n", argv[0], CV_VERSION );
  printf("init system\n");
  cvInitSystem( argc, argv );
  videoOrg = cvCaptureFromCAM(0);
  
  imgOrg = cvQueryFrame( videoOrg );
  
 imgGris= cvCreateImage(cvSize(imgOrg->width, imgOrg->height),IPL_DEPTH_8U, 1);
 imgUmbral= cvCreateImage(cvSize(imgOrg->width, imgOrg->height),IPL_DEPTH_8U, 1);
 imgNegro= cvCreateImage(cvSize(imgOrg->width, imgOrg->height),IPL_DEPTH_8U, 1);
 imgFlip= cvCreateImage(cvSize(imgOrg->width, imgOrg->height),IPL_DEPTH_8U, 1);
 
 
 cvAddS(imgNegro,cvScalar(255,255,255, 0),imgNegro,NULL);

 generaPuntoObjetivo(arrayObjetivo,400,320);
 generaPuntoObjetivo(arrayObjetivo,350,270);
 generaPuntoObjetivo(arrayObjetivo,150,450);
 
  cvCvtColor(imgOrg,imgGris,CV_BGR2GRAY);
   
  
  cvNamedWindow( Stream, CV_WINDOW_AUTOSIZE );
  cvNamedWindow( StreamGris, CV_WINDOW_AUTOSIZE );
  cvNamedWindow( PintaPantalla, CV_WINDOW_AUTOSIZE );
  
  cvMoveWindow( Stream, 0, 0 );
  cvMoveWindow( StreamGris, imgGris->width+30, 0 );
  cvMoveWindow( PintaPantalla, imgNegro->height+30, 0 );
  
  cvShowImage( Stream, imgOrg );  
  cvShowImage( StreamGris, imgGris );
  cvShowImage( PintaPantalla, imgNegro );
  
  //cvDestroyWindow(Stream);
  //cvDestroyWindow( StreamGris);
  cvDestroyWindow( PintaPantalla);
 
  tiempoEntreCuadros = 1000.0 / 100.0;
  

  salir=0;
  printf("Mostrando contenido de la camara\n q, Q - Salir.\n" );  

  while ( salir==0 )
  { 
	imgOrg=cvQueryFrame(videoOrg);
	cvCvtColor(imgOrg,imgGris,CV_BGR2GRAY);
	cvFlip(imgGris,imgFlip,1);
	
	cvThreshold (imgFlip,imgUmbral, valorUmbral, 255, CV_THRESH_BINARY);
	centroGravedad(imgUmbral,&posCDG,255);
    pintaCruz(imgUmbral,posCDG.y, posCDG.x, 12);
    if(objetivoPintado(imgNegro,arrayObjetivo,&posCDG)){
	puntuacion++;
    valorRefresco++;
    }
    asignarALista(posCDG.x,posCDG.y,imgNegro,tasaRefresco,valorRefresco);
    ponPuntoObjetivo(imgNegro,arrayObjetivo);
    
	tasaRefresco++;
	//con este if controlamos el numero de puntos que borra
	if(tasaRefresco>4)tasaRefresco =valorRefresco;
	recorreSerpeinte(imgNegro);
    pintameeeTexto(imgNegro,puntuacion);
    
    cvShowImage( StreamGris, imgUmbral );
    cvShowImage( Stream, imgOrg );
    cvShowImage( PintaPantalla, imgNegro );
	
	
   tecla = cvWaitKey( tiempoEntreCuadros ) & 255; 
   
   switch ( tecla ){
	case 'u':
	valorUmbral--; 
	break;
	case 'U': 
	valorUmbral++; 
	break;
	case 'R': 
	valorRefresco++; 
	break;
	case 'r': 
	valorRefresco--; 
	break;
    case 'q':
    case 'Q':    
    printf("saliendo texto\n");
     salir = 1;
     break;
  default: ;  
  }     
 // Fin de "switch ( tecla )"
	
  }  
printf("Valor umbral:%d\n",valorUmbral);
 cvReleaseCapture( &videoOrg );
 cvDestroyAllWindows( );
 // No cal lliberar esta imgOrg, ja que és una copia interna
 // cvReleaseImage( &imgOrg );


 return 0;
}// Fin de "main"



//
// Fi de fitxer "opencv_player"
//

