#!/bin/bash

gcc -o game main.c -lalut -lopenal -lm -lglut -lGLU -lGL `pkg-config opencv --cflags --libs`

