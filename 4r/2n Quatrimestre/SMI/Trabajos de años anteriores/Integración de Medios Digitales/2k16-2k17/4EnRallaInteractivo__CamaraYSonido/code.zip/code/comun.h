#ifndef COMUN_H
#define COMUN_H



// Valores l�gicos
#define OR ||
#define AND &&
#define TRUE 1
#define FALSE 0
#define BOOL int

// Para mantener la compatibilidad con el c�digo de Learning OpenCV
#define true TRUE
#define false FALSE
#define CIERTO TRUE
#define FALSO FALSE
#define bool BOOL

#define NUM_BUFFERS 4
#define NUM_SOURCES 4
#define NUM_ENVIRONMENTS 1
#define fOriginal "webcam"
struct color { // rojo verde azul
	int iLowH;
	int iHighH;
	int iLowS;
	int iHighS;
	int iLowV;
	int iHighV;
};

#define PI 3.14159265f

#define ESTADO_MENU_PRINCIPAL 1
#define ESTADO_JUEGO_4 2
#define ESTADO_EXIT 3
#define ESTADO_JUEGO_4_PARCIAL 4




#endif
