/*
 * GL07BouncingBall.cpp: A ball bouncing inside the window
 */

#ifdef _WIN32
	 #include <windows.h>  // for MS Windows
#endif

#include <stdio.h>

#include <cv.h>
#include <cxcore.h>
#include <highgui.h>
#include "comun.h"
#include <AL/alut.h>

#include <GL/glut.h>  // GLUT, includes glu.h and gl.h
#include <math.h>     // Needed for sin, cos
#include <string.h>

//sonido

ALuint  buffer[NUM_BUFFERS];
ALuint  source[NUM_SOURCES];
ALuint  environment[NUM_ENVIRONMENTS];
int     GLwin;

ALsizei size,freq;
ALenum  format;
ALvoid  *data;
int     ch;


char VentanaControl[10] = "Jugador: ";


int calibracionModo = 0;

CvCapture* videoOrg;
IplImage *imgOrg, *imgDst, *imageCamara;
IplImage * imgHSV ;
IplImage *imgThresholded ;
CvMoments *oMoments   ;
IplConvKernel* kernel ;


int ample_real,
alt_real;
float fAreaMax;

float punteroX = 0.0f ;
float punteroY = 0.0f ;
float lastpunteroX = 0.0f;
float lastpunteroY = 0.0f;

float alphaSeleccion = 0.0f;
float last_columna = -2.0f;
float current_columna = -1.0f;

int contadorPuntero = 0;

int fullscreen=1;

char mensajePresentacionl1[100] = "Jugar al 4 en Raya, pulsa 1.";
char mensajePresentacionl2[100] = "Pulsa c para calibrar en cualquier momento.";
char mensajePresentacionl3[100] = "";

char mensajeCredito1[100] = "4 en RAYA 2016-2017";
char mensajeCredito2[100] = "REALIZADO POR: MOLE";
float creditosScroll =1.0f;



int marcador[2] = {0}; 


struct color colores[3];
struct color *colorActual;



int SumaArray (int *array, int n);

int cargarCuadroDeCamara();

void presentacion();
void dibujaTablero(float xp1, float yp1, float xp2, float yp2, int rows, int cols) ;
void reshape(GLsizei width, GLsizei height) ;
void Timer(int value) ;
void createPopup();
void freeMatrix(int **A, int n);
void destroy();
void ponficha(int columna);
void keyboardJuego4(unsigned char key,int yi,int xi);
void printTablero(int **matrix, int filas, int columnas);
void InitializeCounter(int *array, int n, int vi);
void keyboardMenuPrincipal(unsigned char key,int yi,int xi);
void configuracionEstado(int cambioE);
void initGL() ;
void dibujarpresentacion();
void calibracion();
void dibujaCirculo(float radio,float cx, float cy, float red, float green, float blue) ;
void dibuja4raya();
void display();
void iniciarOpengl(int argc, char** argv);
float getsizeCelda(float xp1, float yp1, float xp2, float yp2, int rows, int cols);
void dibujarmarcador4 ();

int **A; //matriz
int row; // filas
int col; //columnas
int jugadores = 2 ;
int *contador;
int turno=1;
int ganador;

int ESTADO_ACTUAL;

// mis globales
char estado[40]="menujuego";

// Global variables
char title[] = "Tablero";  // Windowed mode's title
int windowWidth  = 640;     // Windowed mode's width
int windowHeight = 480;     // Windowed mode's height
int windowPosX   = 50;      // Windowed mode's top-left corner x
int windowPosY   = 50;      // Windowed mode's top-left corner y
int refreshMillis = 30;      // Refresh period in milliseconds

// Projection clipping area
GLdouble clipAreaXLeft, clipAreaXRight, clipAreaYBottom, clipAreaYTop;


void detectaColor(int jugador){
//filasxcol
	switch (jugador) {
		case 1:
		colorActual = &colores[1];
		break;
		case 2:
		colorActual = &colores[2];
		break;
		case 3:
		colorActual = &colores[0];
		break;
//  default:

 // break;
	}
}

void calibracionON(){
	calibracionModo = 1;
	calibracion();
	strcpy(mensajePresentacionl3,"Pulsa C para salir de calibrar.");

	strcpy(mensajePresentacionl3,"Pulsa P para cambiar de jugador.");

	glutReshapeWindow(640, 480);
	glutPositionWindow(0,0);
//	cvMoveWindow(fOriginal,100,480);
	cvMoveWindow(VentanaControl,0,480);
	fullscreen=0;
}

void calibracionOFF(){
	strcpy(mensajePresentacionl3,"");

	calibracionModo = 0;
	glutFullScreen();
	cvDestroyWindow(VentanaControl);

	cvDestroyWindow(fOriginal);

	glutFullScreen();
	fullscreen=1;
}

void bitmap_output(float x, float y, char *string, void *font)
{
	int len, i;

	glRasterPos2f(x, y);
	len = (int) strlen(string);
	for (i = 0; i < len; i++) {
		glutBitmapCharacter(font, string[i]);
	}
}

float getsizeCelda(float xp1, float yp1, float xp2, float yp2, int rows, int cols) {
	float sizeceldax = (xp2 - xp1)/(float)cols;
	float sizecelday = (yp2 - yp1)/(float)rows;
	float sizecelda = (sizeceldax < sizecelday)? sizeceldax : sizecelday;
	return sizecelda;
}

void dibujaTablero(float xp1, float yp1, float xp2, float yp2, int rows, int cols) {

	float sizecelda = getsizeCelda(xp1, yp1, xp2, yp2, rows, cols);
	float origenz = 0.0f;

	for (float y = 0 ; y < rows; y++) {
		for (float x = 0; x < cols; x++) {
			glBegin(GL_TRIANGLES);

			glColor3f(1.0f, 0.5f, 0.0f);


			float x1 = xp1 + (sizecelda * x);
			float x2 = xp1 + (sizecelda * (x + 1.0f));
			float y1 = yp1 + (sizecelda * y);
			float y2 = yp1 + (sizecelda * (y + 1.0f));


			glVertex3f(x1, y1, origenz);
			glVertex3f(x2, y2, origenz);
			glVertex3f(x1, y2, origenz);
			glVertex3f(x1, y1, origenz);
			glVertex3f(x2, y1, origenz);
			glVertex3f(x2, y2, origenz);
			glEnd();

			float radio = ((x2 - x1)/2.0f) * 0.9f;
			float desp = 0.0f;

			switch (A[rows-1-(int)y][(int)x]) {
				case 1:
				dibujaCirculo(radio, (x2 + x1) / 2.0f,(y2 + y1) / 2.0f, 0.0f,0.7f,0.0f);
				break;

				case 2:
				dibujaCirculo(radio, (x2 + x1) / 2.0f,(y2 + y1) / 2.0f, 0.0f,0.0f,0.7f);
				break;

				default:
				dibujaCirculo(radio, (x2 + x1) / 2.0f,(y2 + y1) / 2.0f, 0.0f,0.0f,0.0f);
				break;
			}
		}
	}

	bool dentro = false;
	for(float x = 0 ; x<cols ; x++){

		if ((punteroX > (xp1 + (sizecelda * x))) && (punteroX < (xp1 + (sizecelda * (x + 1.0f))) )) {

			if ((punteroY > (yp2 - (sizecelda * 2.0f))) && ( punteroY < yp2)){

				dentro = true;
				if(x == last_columna)
				{
					alphaSeleccion = alphaSeleccion + 0.03f;
					if (alphaSeleccion > 1.0f){
						ponficha(x);
						current_columna = last_columna = -1.0;
						alphaSeleccion = 0.5;
					}
					//fprintf(stderr, "columna %1.0f %f \n", x ,alphaSeleccion );

				}else{
					alphaSeleccion = 0.5f;
					current_columna =  x ;
					last_columna = current_columna ;
				}
			}
		}

	}

	if (!dentro){
		current_columna = last_columna = -1.0;
		alphaSeleccion = 0.5;
	}

  // Zona de eleccion de columna


	for(float x = 0 ; x<cols ; x++){

		if (current_columna == x){
			//fprintf(stderr, " %1.0f columna %1.0f alphaSeleccion %1.2f\n", current_columna ,x,alphaSeleccion );
			glColor4f(1.0f, 0.5f, 1.0f, alphaSeleccion);
		} else{
			glColor4f(1.0f, 0.5f, 1.0f, 0);
		}

		
		float x1 = xp1 + (sizecelda * x);
		float x2 = xp1 + (sizecelda * (x + 1.0f));
		float y1 = yp2 - (sizecelda * 2.0f);
		float y2 = yp2;

		glBegin(GL_TRIANGLES);

		glVertex3f(x1, y1, origenz);
		glVertex3f(x2, y2, origenz);
		glVertex3f(x1, y2, origenz);
		glVertex3f(x1, y1, origenz);
		glVertex3f(x2, y1, origenz);
		glVertex3f(x2, y2, origenz);
		glEnd();

	}

  // Dibujar ficha camara
	switch (turno) {
		default:
		case 1:
		dibujaCirculo(0.1f,punteroX,punteroY, 0.0f,0.7f,0.0f);
		break;
		case 2:
		dibujaCirculo(0.1f,punteroX,punteroY, 0.0f,0.0f,0.7f);
		break;
	}

}

/* Call back when the windows is re-sized */
void reshape(GLsizei width, GLsizei height) {
	 // Compute aspect ratio of the new window
	if (height == 0) height = 1;                // To prevent divide by 0

	GLfloat aspect = (GLfloat)width / (GLfloat)height;

	 // Set the viewport to cover the new window
	glViewport(0, 0, width, height);

	// Set the aspect ratio of the clipping area to match the viewport
	glMatrixMode(GL_PROJECTION);  // To operate on the Projection matrix
	glLoadIdentity();             // Reset the projection matrix
	if (width >= height) {
		clipAreaXLeft   = -1.0 * aspect;
		clipAreaXRight  = 1.0 * aspect;
		clipAreaYBottom = -1.0;
		clipAreaYTop    = 1.0;
	} else {
		clipAreaXLeft   = -1.0;
		clipAreaXRight  = 1.0;
		clipAreaYBottom = -1.0 / aspect;
		clipAreaYTop    = 1.0 / aspect;
	}

	gluOrtho2D(clipAreaXLeft, clipAreaXRight, clipAreaYBottom, clipAreaYTop);
}

/* Called back when the timer expired */
void Timer(int value) {
	glutPostRedisplay();    // Post a paint request to activate display()
	glutTimerFunc(refreshMillis, Timer, 0); // subsequent timer call at milliseconds
}

void handle_main_menu(int item){
	ALenum state;
	switch(item) {
		case 1:
		printf("Reset \n");
		keyboardMenuPrincipal('1',0,0);
		marcador[0] = 0;
		marcador[1] = 0;
		turno = 1;
		break;
		case 2:
		if (calibracionModo == 0){
			calibracionON();
		}else{
			calibracionModo = 0;
			calibracionOFF();
		}
		break;
		case 3:

		
		alGetSourcei(source[0], AL_SOURCE_STATE, &state);

		if (state == AL_PLAYING){
			alSourceStop(source[0]);
		} else{
			alSourcePlay(source[0]);
		}
		break;
		case 4: 
		keyboardMenuPrincipal('f',0,0);
		break;
		case 5:
		keyboardMenuPrincipal('q',0,0);
		break;

	}
}



void createPopup(){
	glutCreateMenu(handle_main_menu);
	glutAddMenuEntry("Reiniciar 4 en Raya", 1);
	glutAddMenuEntry("Calibrar webcam", 2);
	glutAddMenuEntry("-----------------", -1);
	glutAddMenuEntry("Musica ON/OFF", 3);
	glutAddMenuEntry("Fullsceen ON/OFF", 4);
	glutAddMenuEntry("Salir del juego", 5);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
}

void freeMatrix(int **A, int n)
{
	int i;
	for(i=0; i<n; i++)
		free(A[i]);
	free(A);
}

void destroy(){


	alutExit();
	freeMatrix(A, row);
	exit(0);
}

int checkFilas(int **A, int rows, int cols) {
	for (int y = rows - 1; y >= 0; y--) {
		int lastgamer = 0;
		int cont = 0;

		for (int x = 0; x < cols; x++) {
			int gamer = A[y][x];
			if (gamer != lastgamer) {
				lastgamer = gamer;
				cont = 1;
			} else
			cont++;

			if ((cont >= 4) && (lastgamer != 0))
				return lastgamer;
		}
	}

	return 0;
}

int checkColumnas(int **A, int rows, int cols) {
	for (int x = 0; x < cols; x++) {
		int lastgamer = 0;
		int cont = 0;

		for (int y = rows - 1; y >= 0; y--) {
			int gamer = A[y][x];
			if (gamer != lastgamer) {
				lastgamer = gamer;
				cont = 1;
			} else
			cont++;

			if ((cont >= 4) && (lastgamer != 0))
				return lastgamer;
		}
	}

	return 0;
}

int checkDiagSimple(int **A, int row, int col, int rows, int cols, int dir) {
	int lastgamer = 0;
	int cont = 0;
	while (row < rows) {
		if ((col >= 0) && (col < cols)) {

			int gamer = A[row][col];
			if (gamer != lastgamer) {
				lastgamer = gamer;
				cont = 1;
			} else
			cont++;

			if ((cont >= 4) && (lastgamer != 0))
				return lastgamer;
		}

		col += dir;
		row++;
	}

	return 0;
}

int checkDiags(int **A, int rows, int cols) {
	for (int i = 0; i <= cols * 2; i++) {
		int gamer = checkDiagSimple(A, 0, i, rows, cols, -1);
		if (gamer != 0)
			return gamer;
	}

	for (int i = -cols; i <= cols; i++) {
		int gamer = checkDiagSimple(A, 0, i, rows, cols, +1);
		if (gamer != 0)
			return gamer;
	}

	return 0;
}


int CompFilas (int **A, int fila, int columnas, int turno) {
	int i, i2, tmp, res=0;
	for (i=0; i< columnas-4; i++){
		tmp=0;
		for (i2=i; i2<i+4; i2++) {
			if (A[fila][i2]==turno)
				tmp++;
		}

		if (tmp==4)
			res=turno;
	}

	return (res);
}

int CompCols (int **A, int filas, int columna, int turno)
{
	int i, i2, tmp, res=0;
	for (i=filas-1; i>3; i--) {
		tmp=0;
		for (i2=i; i2>i-4; i2--) {
			if (A[i2][columna]==turno)
				tmp++;
		}

		if (tmp==4)
			res=turno;
	}
	return (res);
}

//la comprobacion de las diagonales no esta optimizada, pero las operaciones las hace el ordenador, no yo jeje
int CompDiagPrim(int **A, int filas, int columnas, int turno)
{
	int i, j, n, tmp, res=0;
	for(i=filas-1; i>2; i--)
	{
		for(j=3; j<columnas; j++)
		{
			tmp=0;
			for(n=0; n<4; n++) {
				if(A[i-n][j-n]==turno)
					tmp++;
			}

			if (tmp==4)
				res=turno;

		}
	}
	return(res);
}

int CompDiagSec(int **A, int filas, int columnas, int turno)
{
	int i, j, n, tmp, res=0;
	for(i=filas-1; i>2; i--)
	{
		for(j=0; j<columnas-3; j++)
		{
			tmp=0;
			for(n=0; n<4; n++) {
				if(A[i-n][j+n]==turno)
					tmp++;
			}

			if (tmp==4)
				res=turno;

		}
	}
	return(res);
}

void cambiaTurno(){
	if(calibracionModo == 1){
		cvDestroyWindow(VentanaControl);
	}
	turno++;
	if (turno > jugadores)
		turno = 1;

	detectaColor(turno);
}

void ponficha(int columna) {
	if (A[0][columna] == 0){


		for (int i =row-1; i >= 0; i--){
			if (A[i][columna]==0){
				A[i][columna]=turno;
				alSourcePlay(source[1]);
				break;
			}
		}

		ganador=checkFilas(A,row,col);

		if (ganador==0)
			ganador=checkColumnas(A,row,col);

		if (ganador==0)
			ganador=checkDiags(A, row, col);

		int empate=1;
		for(int i = 0; i < col;i++) {
			if (A[0][i]==0){
				empate=0;
			}
		}

		if (empate){
			printf("EMPATE\n");
			glColor3f(1.0, 1.0, 1.0);

			alSourcePlay(source[3]);
			configuracionEstado(ESTADO_JUEGO_4_PARCIAL);

			strcpy(mensajePresentacionl1,"EMPATE");
			strcpy(mensajePresentacionl2,"");
			strcpy(mensajePresentacionl3,"");
			
		}

		if (ganador){
			printf("Gana el jugador: %d\n", turno);

			marcador[ganador-1]++;
			glColor3f(1.0, 1.0, 1.0);
			char mensaje[255] = "Gana el jugador: \0";
			char str[5];

			sprintf(str, "%d", turno);
			strcat( mensaje, str);
			strcpy(mensajePresentacionl1,mensaje);
			strcpy(mensajePresentacionl2,"");
			strcpy(mensajePresentacionl3,"");
			alSourcePlay(source[2]);

			configuracionEstado(ESTADO_JUEGO_4_PARCIAL);

		}

		cambiaTurno();
		punteroX = -100;
		punteroY = -100;
		
	} else {
		printf("Columna %d llena\n", columna );
	}
}

void keyboardJuego4(unsigned char key,int yi,int xi)///funcion teclado
{
 //  printf("%c \n", key);
	switch(key){
		case '1' :
		ponficha(0);
		break;
		case '2' :
		ponficha(1);
		break;
		case '3' :
		ponficha(2);
		break;
		case '4' :
		ponficha(3);
		break;
		case '5' :
		ponficha(4);
		break;
		case '6' :
		ponficha(5);
		break;
		case '7' :
		ponficha(6);
		break;

		default:
		keyboardMenuPrincipal((char)key,yi,xi);
		break;
	}
}



void printTablero(int **matrix, int filas, int columnas)
{
	int i, j;
	int sumacont=SumaArray(contador, col);


	for (i=0; i<columnas; i++)
		printf("%4d", i+1);
	printf("\n ");

	for (i=0; i< filas; i++)
	{
		printf("|");
		for (j=0; j<columnas; j++)
		{
			switch (matrix[i][j])
			{
				case 1:
				printf(" X ");
				break;
				case 2:
				printf(" O ");
				break;
				default:
				printf("   ");
				break;
			}
			printf("|");
		}
		printf("\n ");
	}

}

int **getTablero( int filas, int columnas)
{
	int **var;
	int i;

	var=(int**) calloc (filas, sizeof(int*));
	for( i=0; i<filas; i++)
		var[i]=(int*) calloc (columnas, sizeof(int));
	return(var);
}

int *getArray(int n)
{
	return ((int*) calloc (n, sizeof(int)));
}

void InitializeCounter(int *array, int n, int vi)
{
	int i;
	for (i=0; i<n; i++)
		array[i]=vi;

}

int SumaArray (int *array, int n)
{
	int i, suma=0;
	for (i=0; i<n; i++)
		suma=suma+array[i];
	return(suma);
}

void printTexto( IplImage* image, char *ventana,  char *mensaje )
{
	double hScale = 1.0,
	vScale = 1.0,
	lineWidth = 1.0,
	italicScale = 1.0;
	int tipoLletra = CV_FONT_HERSHEY_SIMPLEX,
	columna = 35,
	fila = 135;
	CvFont font;

	cvInitFont(&font,CV_FONT_HERSHEY_SIMPLEX, hScale,vScale, italicScale, lineWidth, 8);
	cvPutText (image,mensaje, cvPoint(columna, fila ), &font, CV_RGB(255,0,255));
	//printf("Texto en (col, fila) %dx%d\n", columna, fila );
	cvShowImage(ventana, image);
}

void keyboardMenuPrincipal(unsigned char key,int yi,int xi)///funcion teclado
{
	 //printf("%c \n", key);
	switch(key){
		case '1' :

		row = 6;
		col = 7;
		//turno = 1;
		jugadores = 2;
		ganador = 0;

		
		
					//reservamos matriz
		A=getTablero(row, col);
		contador=getArray(col); //con esto llevaremos la cuenta de donde hay que ponerlo
		InitializeCounter(contador, col, row-1);
		//printTablero(A, row, col); Funcion de debug

		printf("Seleccionado Juego de 4 en Raya \n");
		configuracionEstado(ESTADO_JUEGO_4);
			//juego(A, contador, filas, columnas, jug);
		break;
		case 'f' :
		case 'F' :
		if (fullscreen){
			glutReshapeWindow(640, 480);
			glutPositionWindow(0,0);
			fullscreen=0;
		}else{
			glutFullScreen();
			fullscreen=1;
		}
		break;
		case 'c' :
		case 'C' :
		if (calibracionModo == 0){
			calibracionON();
		}else{
			calibracionOFF();
		}
		break;
		case 'p' :
		case 'P' :
		
		cambiaTurno();

		break;
		case 'm' :
		case 'M' :
		handle_main_menu(3);
		break;
		case 'Q' :
		case 'q' :
		//destroy();
		configuracionEstado(ESTADO_EXIT);

		break;
	}

}


void configuracionEstado(int cambioE){

	if (cambioE == ESTADO_JUEGO_4){
		glClearColor(0.0, 0.0, 0.0, 1.0); // Set background (clear) color to black
		ESTADO_ACTUAL = ESTADO_JUEGO_4;
		glutKeyboardFunc(keyboardJuego4);
	}

	if (cambioE == ESTADO_MENU_PRINCIPAL){
		glClearColor(0.0, 0.0, 0.0, 1.0); // Set background (clear) color to black
		ESTADO_ACTUAL = ESTADO_MENU_PRINCIPAL;
		glutKeyboardFunc(keyboardMenuPrincipal);
	}

	if (cambioE == ESTADO_EXIT){
		glClearColor(1.0, 0.0, 0.0, 1.0); // Set background (clear) color to black
		creditosScroll=1.0f;
		ESTADO_ACTUAL = ESTADO_EXIT;
		glutKeyboardFunc(NULL);
	}

	if (cambioE == ESTADO_JUEGO_4_PARCIAL){
		glClearColor(0.0, 0.0, 0.0, 1.0); // Set background (clear) color to black
		creditosScroll=1.0f;
		ESTADO_ACTUAL = ESTADO_JUEGO_4_PARCIAL;
		glutKeyboardFunc(NULL);
	}
	
}

void initGL() {
	glClearColor(0.0, 0.0, 0.0, 1.0); // Set background (clear) color to black
}

void dibujarpresentacion(){
	glClearColor(1.0, 0.0, 0.0, 1.0); // Set background (clear) color to black
	bitmap_output(-0.8f, 0.0f, mensajePresentacionl1, GLUT_BITMAP_TIMES_ROMAN_24 );
	bitmap_output(-0.8f, -0.1f, mensajePresentacionl2, GLUT_BITMAP_TIMES_ROMAN_24 );
	bitmap_output(-0.8f, -0.2f, mensajePresentacionl3, GLUT_BITMAP_TIMES_ROMAN_24 );

}

void dibujar4rayaParcial(){
	glColor3f(1.0, 1.0, 1.0);
	glClearColor(1.0, 0.0, 0.0, 1.0); 
	bitmap_output(-0.8f, 0.0f, mensajePresentacionl1, GLUT_BITMAP_TIMES_ROMAN_24 );
	bitmap_output(-0.8f, -0.1f, mensajePresentacionl2, GLUT_BITMAP_TIMES_ROMAN_24 );
	bitmap_output(-0.8f, -0.2f, mensajePresentacionl3, GLUT_BITMAP_TIMES_ROMAN_24 );
	creditosScroll = creditosScroll - 0.04f;
	if(creditosScroll < -1){

		A=getTablero(row, col);
		contador=getArray(col); //con esto llevaremos la cuenta de donde hay que ponerlo
		InitializeCounter(contador, col, row-1);
		//printTablero(A, row, col); Funcion de debug
		configuracionEstado(ESTADO_JUEGO_4);

		creditosScroll =1.0f;
	}
	dibujarmarcador4();
}


void dibujarCreditos(){

	glColor3f(1.0, 1.0, 1.0);
	glClearColor(0.0, 0.0, 0.0, 1.0); // Set background (clear) color to black
	
	bitmap_output(-0.8f, creditosScroll, mensajeCredito1, GLUT_BITMAP_TIMES_ROMAN_24 );
	bitmap_output(-0.8f, creditosScroll -0.08f, mensajeCredito2, GLUT_BITMAP_TIMES_ROMAN_24 );
	creditosScroll = creditosScroll - 0.01f;

	if (creditosScroll < -1.2f){
		destroy();
		
	}

}


void dibujarmarcador4 (){
	char mensaje[255] = "";
	char str[5];

	sprintf(str, "%d", marcador[0]);
	strcat( mensaje, str);
	strcpy(mensaje,str);
	
	dibujaCirculo(0.06f,-1.06f, 0.86f , 0.0f,0.7f,0.0f);
	bitmap_output(-0.98f, 0.83f,mensaje, GLUT_BITMAP_TIMES_ROMAN_24 );
	
	sprintf(str, "%d", marcador[1]);
	strcat( mensaje, str);
	strcpy(mensaje,str);
	
	dibujaCirculo(0.06f, 1.0f , 0.86f, 0.0f,0.0f,0.7f);
	bitmap_output(1.1f, 0.83f, mensaje, GLUT_BITMAP_TIMES_ROMAN_24 );

}

void dibujaCirculo(float radio,float cx, float cy, float red, float green, float blue)
{
	//   glClear(GL_COLOR_BUFFER_BIT);  // Clear the color buffer
	// glMatrixMode(GL_MODELVIEW);    // To operate on the model-view matrix
	// glLoadIdentity();              // Reset model-view matrix
//  radio =0.03f;

	//fprintf(stderr," x: %f y: %f\n", cx,cy);

	glTranslatef(cx, cy, 0.0f);  // Translate to (xPos, yPos)
	// Use triangular segments to form a circle
	glBegin(GL_TRIANGLE_FAN);
	glColor3f(red ,green, blue);  // Blue
	glVertex2f(0.0f, 0.0f);       // Center of circle
	int numSegments = 100;
	GLfloat angle;
	for (int i = 0; i <= numSegments; i++) { // Last vertex same as first vertex
		angle = i * 2.0f * PI / numSegments;  // 360 deg for all segments
		glVertex2f(cos(angle) * radio, sin(angle) * radio);
	}
	glEnd();
	glTranslatef(-cx, -cy, 0.0f);  // Translate to (xPos, yPos)
}


void dibuja4raya(){
	dibujaTablero(-0.95f, -0.95f, 0.95f, 0.95f, 6, 7);
	dibujarmarcador4();
}

/* Callback handler for window re-paint event */
void display() {
	glClear(GL_COLOR_BUFFER_BIT);  // Clear the color buffer
	glMatrixMode(GL_MODELVIEW);    // To operate on the model-view matrix
	glLoadIdentity();              // Reset model-view matrix

	cargarCuadroDeCamara();

	switch(ESTADO_ACTUAL) {
		case ESTADO_MENU_PRINCIPAL:
		dibujarpresentacion();
			//printf("estado ESTADO_MENU_PRINCIPAL \n" );
		break;
		case ESTADO_JUEGO_4:
			//printf("estado ESTADO_JUEGO_4 \n" );
		dibuja4raya();
		break;
		case ESTADO_EXIT:
		dibujarCreditos();
			//printf("estado ESTADO_MENU_PRINCIPAL \n" );
		break;
		case ESTADO_JUEGO_4_PARCIAL:
		dibujar4rayaParcial();
		break;

	}

	glutSwapBuffers();  // Swap front and back buffers (of double buffered mode)
}

void iniciarOpengl(int argc, char** argv){
	glutInit(&argc, argv);            // Initialize GLUT
	glutInitDisplayMode(GLUT_DOUBLE); // Enable double buffered mode
	glutInitWindowSize(windowWidth, windowHeight);  // Initial window width and height
	glutInitWindowPosition(windowPosX, windowPosY); // Initial window top-left corner (x, y)
	glutCreateWindow(title);      // Create window with given title

	configuracionEstado(ESTADO_MENU_PRINCIPAL);

	glutDisplayFunc(display);     // Register callback handler for window re-paint
	glutReshapeFunc(reshape);     // Register callback handler for window re-shape
	glutTimerFunc(0, Timer, 0);   // First timer call immediately
	initGL();                     // Our own OpenGL initialization
	glutFullScreen();
	glEnable (GL_BLEND);
	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	createPopup();

	glutMainLoop();               // Enter event-processing loop
}

int cargarCuadroDeCamara() {
	imageCamara = cvQueryFrame( videoOrg );
	imgDst = cvCreateImage( cvSize(imageCamara->width, imageCamara->height), imageCamara->depth, imageCamara->nChannels );

	if (imageCamara == NULL) {
		fprintf(stderr, "Problemas obteniendo imÃ¡genes de la cÃ¡mara\n");
		return( 3 );
	}

// invertimos la imagen
	cvFlip( imageCamara, imgDst, 1 );

// cambiamos el espacio de color
	imgHSV = cvCreateImage( cvGetSize(imgDst), 8, 3 );
	imgThresholded = cvCreateImage( cvGetSize(imgDst), 8, 1 );


	cvCvtColor(imgDst, imgHSV, CV_BGR2HSV  );

	cvInRangeS(imgHSV, cvScalar(colorActual->iLowH, colorActual->iLowS, colorActual->iLowV,0), cvScalar(colorActual->iHighH, colorActual->iHighS, colorActual->iHighV,0), imgThresholded); //Threshold the image


 //morphologicalimgHSV opening (removes small objects from the foreground)
	cvErode(imgThresholded, imgThresholded, kernel,1 );
	cvDilate( imgThresholded, imgThresholded, kernel,1 );

	//morphological closing (removes small holes from the foreground)

	cvDilate( imgThresholded, imgThresholded, kernel,1 );
	cvErode(imgThresholded, imgThresholded, kernel,1 );

	//Calculate the moments of the thresholded image


	cvMoments(imgThresholded,oMoments,1);

//cvGetHuMoments(&Moments, &HuMoments)
//cvMoments(const CvArr* arr, CvMoments* moments, int binary=0 )
	double dM01 = cvGetSpatialMoment(oMoments, 0, 1);
	double dM10 = cvGetSpatialMoment(oMoments, 1, 0);
	double dArea = cvGetCentralMoment(oMoments, 0, 0);


	// if the area <= 1000, I consider that the there are no object in the image and it's because of the noise, the area is not zero
	if (dArea > 1000) {
	 //calculate the position of the ball
		int posX = dM10 / dArea;
		int posY = dM01 / dArea;

		if ( posX >= 0 && posY >= 0) {
			float calcX  = (((2.0f*(float)posX)/(float)imageCamara->width)-1.0f) * 1.3f;
			float calcY = -(((2.0f*(float)posY)/(float)imageCamara->height)-1.0f) * 1.4f;

			// suavizamos los temblores de las fichas.
			punteroX = (calcX + lastpunteroX) / 2.0f;
			punteroY = (calcY + lastpunteroY) / 2.0f;
			// guardamos las ultimas posiciones para el suavizado.
			lastpunteroX = calcX;
			lastpunteroY = calcY;


		}
	}

	if (calibracionModo == 1){

		cvShowImage( fOriginal, imgThresholded);
		//printTexto(imgThresholded, fOriginal, "Pulsa ESC per acabar" );
		calibracion();
	}

	cvWaitKey( 20 ); //Milliseconds

	cvReleaseImage(&imgDst);
	cvReleaseImage(&imgHSV);
	cvReleaseImage(&imgThresholded);

	return( 0 );
}

void calibracion() {

	strcpy(VentanaControl, "Jugador: ");
	char str[5];
	sprintf(str, "%d", turno);
	strcat( VentanaControl, str);
	
	cvNamedWindow(VentanaControl, 0); //create a window called "Control"
	cvCreateTrackbar("LowH", VentanaControl, &colorActual->iLowH, 179,NULL); //Hue (0 - 179)
	cvCreateTrackbar("HighH", VentanaControl, &colorActual->iHighH, 179,NULL);

	cvCreateTrackbar("LowS", VentanaControl, &colorActual->iLowS, 255,NULL); //Saturation (0 - 255)
	cvCreateTrackbar("HighS", VentanaControl, &colorActual->iHighS, 255,NULL);

	cvCreateTrackbar("LowV", VentanaControl, &colorActual->iLowV, 255,NULL);//Value (0 - 255)
	cvCreateTrackbar("HighV", VentanaControl, &colorActual->iHighV, 255,NULL);
}

void cargaSonido() {
	ALfloat listenerPos[]={0.0,0.0,4.0};
	ALfloat listenerVel[]={0.0,0.0,0.0};
	ALfloat	listenerOri[]={0.0,0.0,1.0, 0.0,1.0,0.0};

	ALfloat sourcePos[]={ 0.0, 0.0, 0.0};
	ALfloat sourceVel[]={ 0.0, 0.0, 0.0};

	buffer[0] = alutCreateBufferFromFile( "source/banda.wav" );
	buffer[1] = alutCreateBufferFromFile( "source/ficha1.wav" );
	buffer[2] = alutCreateBufferFromFile( "source/winner.wav" );
	buffer[3] = alutCreateBufferFromFile( "source/empate.wav" );

		alGetError(); /* clear error */
	alGenSources(NUM_SOURCES, source);

	if(alGetError() != AL_NO_ERROR)
	{
		printf("- Error creating sources !!\n");
		exit(2);
	}
	alSourcef(source[0],AL_PITCH,1.0f);
	alSourcef(source[0],AL_GAIN,0.1f);
	alSourcefv(source[0],AL_POSITION,sourcePos);
	alSourcefv(source[0],AL_VELOCITY,sourceVel);
	alSourcei(source[0],AL_BUFFER,buffer[0]);
	alSourcei(source[0],AL_LOOPING,AL_TRUE);

	alSourcef(source[1],AL_PITCH,1.0f);
	alSourcef(source[1],AL_GAIN,1.0f);
	alSourcefv(source[1],AL_POSITION,sourcePos);
	alSourcefv(source[1],AL_VELOCITY,sourceVel);
	alSourcei(source[1],AL_BUFFER,buffer[1]);
	alSourcei(source[1],AL_LOOPING,AL_FALSE);

	alSourcef(source[2],AL_PITCH,1.0f);
	alSourcef(source[2],AL_GAIN,1.0f);
	alSourcefv(source[2],AL_POSITION,sourcePos);
	alSourcefv(source[2],AL_VELOCITY,sourceVel);
	alSourcei(source[2],AL_BUFFER,buffer[2]);
	alSourcei(source[2],AL_LOOPING,AL_FALSE);

	alSourcef(source[3],AL_PITCH,1.0f);
	alSourcef(source[3],AL_GAIN,1.0f);
	alSourcefv(source[3],AL_POSITION,sourcePos);
	alSourcefv(source[3],AL_VELOCITY,sourceVel);
	alSourcei(source[3],AL_BUFFER,buffer[3]);
	alSourcei(source[3],AL_LOOPING,AL_FALSE);

}

/* Main function: GLUT runs as a console application starting at main() */
int main(int argc, char** argv) {
 // valores de color por defecto
	colores[0] = (struct color) { .iLowH = 170, .iHighH = 179, .iLowS = 150, .iHighS = 255, .iLowV = 0, .iHighV = 255}; // rojo
	colores[1] = (struct color) { .iLowH = 58,  .iHighH = 91,  .iLowS = 53,  .iHighS = 164, .iLowV = 0, .iHighV = 255}; // verde
	colores[2] = (struct color) { .iLowH = 110, .iHighH = 120, .iLowS = 150, .iHighS = 255, .iLowV = 0, .iHighV = 255}; // azul
	
	int majorOpenGL, minorOpenGL;

	cvInitSystem( argc, argv ); // Initializes HighGUI
	videoOrg = cvCreateCameraCapture( (argc > 1? atoi(argv[1]) : CV_CAP_ANY)  );

	if (videoOrg == NULL)
	{
		fprintf(stderr, "Problemas abriendo la conexiÃ³n con la cÃ¡mara %d.\n",
			(argc > 0? atoi(argv[1]) : CV_CAP_ANY) );
		return( 2 );
	}

	detectaColor(1);

	oMoments   =(CvMoments*)malloc(sizeof(CvMoments));
	kernel = cvCreateStructuringElementEx(5, 5, 2, 2, CV_SHAPE_ELLIPSE,NULL);

	//inicializa sonido
	alutInit(&argc, argv);
	cargaSonido();

	alSourcePlay(source[0]);
	cargarCuadroDeCamara();

	iniciarOpengl(argc, argv);

	return 0;
}
