
# import the necessary packages
from collections import deque
from imutils.video import VideoStream
from imutils import face_utils
import argparse
import cv2
import imutils
import time
import dlib
import numpy as np


# construct the argument parse and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-m", "--mirror",
				help="Mirror behaviour or not",
				action="store_true")
ap.add_argument("-l", "--line",
				help="Show direction line or not",
				action="store_true")
ap.add_argument("-p", "--points",
				help="Show facial landmarks points or not",
				action="store_true")
ap.add_argument("-w", "--write",
				help="Save points to an external file. ONLY WORKS IF -p IS ENABLED.",
				action="store_true")
args = ap.parse_args()

#Starts the webcam
vs = VideoStream(src=0).start()

# initialize dlib's face detector (HOG-based) and then create
# the facial landmark predictor
p = "shape_predictor_68_face_landmarks.dat"
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor(p)

#Create model array of points for a virtual face
model_points = np.array([
							(0.0, 0.0, 0.0),			#Nose tip
							(0.0, -330.0, -65.0),		#Chin
							(-225.0, 170.0, -135.0),	#Left eye left corner
							(225.0, 170.0, -135.0),		#Right eye right corner
							(-150.0, -150.0, -125.0),	#Left mouth corner
							(150.0, -150.0, -125.0),	#Right mouth corner
						])

image_points = np.array([
							(0,0),
							(0,0),
							(0,0),
							(0,0),
							(0,0),
							(0,0)
						], dtype = "double")

# allow the camera or video file to warm up
time.sleep(1.0)
frame = vs.read()

#Camera internals
focal_length = frame.shape[1]
center = (frame.shape[0]/2, frame.shape[1]/2)
#print(center)
camera_matrix = np.array(
							[[focal_length, 0, center[0]],
							[0, focal_length, center[1]],
							[0, 0, 1]], dtype = "double"
						)

#print("Camera Matrix:\n {0}".format(camera_matrix))

dist_coeffs = np.zeros((4,1)) #We assume no lens distorion




# Main Loop
while True:
    # grab the current frame
	frame = vs.read()

	if args.mirror:
		frame = cv2.flip(frame, 1)

	# load the input frame and convert it to grayscale
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

	# detect faces in the grayscale frame
	rects = detector(gray, 0)

	# loop over the face detections
	for (i, rect) in enumerate(rects):
		# determine the facial landmarks for the face region, then
		# convert the facial landmark (x, y)-coordinates to a NumPy
		# array
		shape = predictor(gray, rect)
		shape = face_utils.shape_to_np(shape)

		# loop over the (x, y)-coordinates for the facial landmarks
		# and draw them on the frame
		k = 0
		for j in (30, 8, 36, 45, 48, 54):
			image_points[k] = (int(shape[j][0]), int(shape[j][1]))
			k+=1
			if args.points:
				cv2.circle(frame, (shape[j][0], shape[j][1]), 2, (0, 255, 255), -1)

	# Get rotation and translation vectors
	(success, rotation_vector, translation_vector) = cv2.solvePnP(model_points, image_points, camera_matrix, dist_coeffs, flags=cv2.SOLVEPNP_ITERATIVE)
	

	if args.line:
		(nose_end_point2D , jacobian) = cv2.projectPoints(np.array([(0.0, 0.0, 1000.0)]), rotation_vector, translation_vector, camera_matrix, dist_coeffs)
		p1 = ( int(image_points[0][0]), int(image_points[0][1]))
		p2 = (int(nose_end_point2D[0][0][0]), int(nose_end_point2D[0][0][1]))
		cv2.line(frame, p1, p2, (255, 0, 0), 2)
		p3 = (p2[0]-p1[0], p2[1]-p1[1])
	
	if args.write:
		#Writing files snippet
		file = open("data.txt", "w")
		file.write(str(p3[0]))
		file.write(" ")
		file.write(str(p3[1]))
		file.close()
	
	


	# show the output frame with the face detections + facial landmarks
	cv2.imshow("Output", frame)

	# if we are viewing a video and we did not grab a frame,
	# then we have reached the end of the video
	if frame is None:
		break

	# show the frame to our screen
	key = cv2.waitKey(1) & 0xFF

	# if the 'q' key is pressed, stop the loop
	if key == ord("q"):
		break



#End video streaming

vs.stop()

cv2.destroyAllWindows()