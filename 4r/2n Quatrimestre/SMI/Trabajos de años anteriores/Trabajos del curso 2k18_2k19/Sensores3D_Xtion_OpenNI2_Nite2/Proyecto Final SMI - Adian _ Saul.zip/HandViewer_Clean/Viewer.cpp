
/*******************************************************************************
*                                                                              *
*   PrimeSense NiTE 2.0 - Hand Viewer Sample                                   *
*   Copyright (C) 2012 PrimeSense Ltd.                                         *
*                                                                              *
*******************************************************************************/

#include <map>
#include "Viewer.h"
#include <Windows.h>
#include <ctime>

#if (ONI_PLATFORM == ONI_PLATFORM_MACOSX)
        #include <GLUT/glut.h>
#else
        #include <GL/glut.h>
#endif

#include "HistoryBuffer.h"
#include <NiteSampleUtilities.h>

#define GL_WIN_SIZE_X	700
#define GL_WIN_SIZE_Y	700
#define TEXTURE_SIZE	512

#define DEFAULT_DISPLAY_MODE	DISPLAY_MODE_DEPTH

#define MIN_NUM_CHUNKS(data_size, chunk_size)	((((data_size)-1) / (chunk_size) + 1))
#define MIN_CHUNKS_SIZE(data_size, chunk_size)	(MIN_NUM_CHUNKS(data_size, chunk_size) * (chunk_size))

#define FRAMES_TWO_HAND_GESTURE 10
#define FRAMES_STOP_ZOOMING 3 // N�mero de veces que cogemos la media de las posiciones de la mano 2
#define DISTANCIA_MANOS 10

enum ApplicationRunning {
	GOOGLE_EARTH,
	POWER_POINT
};

ApplicationRunning appRunning = GOOGLE_EARTH;

SampleViewer* SampleViewer::ms_self = NULL;

std::map<int, HistoryBuffer<20> *> g_histories;

bool g_drawDepth = true;
bool g_smoothing = false;
bool g_drawFrameId = false;

//meter array de X e Y, de posici�n del rat�n para la media y un contador.
#define N 5

int manos[5] = {};

float sumaX = 0;					//suma del valor en X
float sumaY = 0;					//suma del valor en Y
int contador = 0;					//llevar la cuenta del n�mero de valores que leemos y estamos sumando en X e Y 
int contadorManos = 0;
float ultimaReferenciax = 0;
float ultimaReferenciay = 0;

float sumaXM2 = 0;
float sumaYM2 = 0;
int contadorMano2 = 0;
float valorAnteriorxM2 = 50.0;
float valorAnterioryM2 = 50.0;
float ultimaReferenciaxM2 = 0;
float ultimaReferenciayM2 = 0;

int g_nXRes = 0, g_nYRes = 0;


// Google Earth Variables

bool clickPressed = false;
bool scrollPressed = false;
bool haciendoZoom = false;
float ultimaDistanciaEntreManos = 0.0f;

int framesTwoHandsGesture = FRAMES_TWO_HAND_GESTURE;
int framesStopZooming = FRAMES_STOP_ZOOMING;
int acumulatedGestures = 0;
NiteGestureType acumulatedGestureType = NITE_GESTURE_CLICK;
nite::Point3f& posicion = nite::Point3f(0.0f, 0.0f, 0.0f);

INPUT _buffer[1]; // Save the key we want to press

void SampleViewer::glutIdle()
{
	glutPostRedisplay();
}
void SampleViewer::glutDisplay()
{
	SampleViewer::ms_self->Display();
}
void SampleViewer::glutKeyboard(unsigned char key, int x, int y)
{
	SampleViewer::ms_self->OnKey(key, x, y);
}

SampleViewer::SampleViewer(const char* strSampleName)
{
	ms_self = this;
	strncpy(m_strSampleName, strSampleName, ONI_MAX_STR);
	m_pHandTracker = new nite::HandTracker;
}
SampleViewer::~SampleViewer()
{
	Finalize();

	delete[] m_pTexMap;

	ms_self = NULL;
}

void SampleViewer::Finalize()
{
	delete m_pHandTracker;
	nite::NiTE::shutdown();
	openni::OpenNI::shutdown();
}

openni::Status SampleViewer::Init(int argc, char **argv)
{
	m_pTexMap = NULL;

	openni::OpenNI::initialize();


	const char* deviceUri = openni::ANY_DEVICE;
	for (int i = 1; i < argc-1; ++i)
	{
		if (strcmp(argv[i], "-device") == 0)
		{
			deviceUri = argv[i+1];
			break;
		}
	}

	openni::Status rc = m_device.open(deviceUri);
	if (rc != openni::STATUS_OK)
	{
		printf("Open Device failed:\n%s\n", openni::OpenNI::getExtendedError());
		return rc;
	}

	nite::NiTE::initialize();

	if (m_pHandTracker->create(&m_device) != nite::STATUS_OK)
	{
		return openni::STATUS_ERROR;
	}

	m_pHandTracker->startGestureDetection(nite::GESTURE_WAVE);
	m_pHandTracker->startGestureDetection(nite::GESTURE_CLICK);

	return InitOpenGL(argc, argv);

}
openni::Status SampleViewer::Run()	//Does not return
{
	glutMainLoop();

	return openni::STATUS_OK;
}

float Colors[][3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {1, 1, 1}};
int colorCount = 3;

void DrawHistory(nite::HandTracker* pHandTracker, int id, HistoryBuffer<20>* pHistory)
{
	glColor3f(Colors[id % colorCount][0], Colors[id % colorCount][1], Colors[id % colorCount][2]);
	float coordinates[60] = {0};
	float factorX = GL_WIN_SIZE_X / (float)g_nXRes;
	float factorY = GL_WIN_SIZE_Y / (float)g_nYRes;

	for (int i = 0; i < pHistory->GetSize(); ++i)
	{
		const nite::Point3f& position = pHistory->operator[](i);
		
		pHandTracker->convertHandCoordinatesToDepth(position.x, position.y, position.z, &coordinates[i*3], &coordinates[i*3+1]);

		coordinates[i*3]   *= factorX;
		coordinates[i*3+1] *= factorY;
	}

	glPointSize(8);
	glVertexPointer(3, GL_FLOAT, 0, coordinates);
	glDrawArrays(GL_LINE_STRIP, 0, pHistory->GetSize());

	glPointSize(12);
	glVertexPointer(3, GL_FLOAT, 0, coordinates);
	glDrawArrays(GL_POINTS, 0, 1);

}

#ifndef USE_GLES
void glPrintString(void *font, const char *str)
{
	int i,l = (int)strlen(str);

	for(i=0; i<l; i++)
	{   
		glutBitmapCharacter(font,*str++);
	}   
}
#endif
void DrawFrameId(int frameId)
{
	char buffer[80] = "";
	sprintf(buffer, "%d", frameId);
	glColor3f(1.0f, 0.0f, 0.0f);
	glRasterPos2i(20, 20);
	glPrintString(GLUT_BITMAP_HELVETICA_18, buffer);
}

// Reseteo de todas las variables utilizadas para llevar el estado de la ejecuci�n
void resetVariables() {
	clickPressed = false;
	scrollPressed = false;
	haciendoZoom = false;
	ultimaDistanciaEntreManos = 0.0f;
	acumulatedGestures = 0;
	framesTwoHandsGesture = FRAMES_TWO_HAND_GESTURE;
	framesStopZooming = FRAMES_STOP_ZOOMING;
}

// C�digo a ejecutar cuando estas en modo Google Earth
void exeGoogleEarth(const nite::Array<nite::GestureData>& gestures, const nite::Array<nite::HandData>& hands,
	nite::HandTracker* m_pHandTracker) {

	// Cuando se detecta un gesto se decrementa el contador y hasta que no llegue a 0 no se ejecutar� 
	// el gesto detectado, dando margen a hacer un posible segundo gesto y contarlo como que se han
	// hecho a la vez
	if (acumulatedGestures > 0) {
		framesTwoHandsGesture--;
	}

	/*
				1 GESTO CUANDO TENEMOS 2 MANOS 
	*/
	// Si han pasado mas de FRAMES_TWO_HAND_GESTURE frames despues de un gesto con dos manos en pantalla sin que haya otro,
	// se contara como un gesto y se realizara la accion pertinente
	if (framesTwoHandsGesture <= 0) {
		acumulatedGestures = 0;
		framesTwoHandsGesture = FRAMES_TWO_HAND_GESTURE;
		switch (acumulatedGestureType) {
		case NITE_GESTURE_CLICK:
			if (!clickPressed) {
				mouse_event(MOUSEEVENTF_LEFTDOWN, (int)ultimaReferenciax * 4, (int)ultimaReferenciay * (-5), 0, 0);
				clickPressed = true;
			}
			else {
				mouse_event(MOUSEEVENTF_LEFTUP, (int)ultimaReferenciax * 4, (int)ultimaReferenciay * (-5), 0, 0);
				clickPressed = false;
			}
			break;
		case NITE_GESTURE_WAVE:
			if (!scrollPressed) {
				mouse_event(MOUSEEVENTF_MIDDLEDOWN, (int)ultimaReferenciax * 4, (int)ultimaReferenciay * (-5), 0, 0);
				scrollPressed = true;
			}
			else {
				mouse_event(MOUSEEVENTF_MIDDLEUP, (int)ultimaReferenciax * 4, (int)ultimaReferenciay * (-5), 0, 0);
				scrollPressed = false;
			}
			break;
		}
	}

	// Para cada gesto encontrado en el frame actual..
	for (int i = 0; i < gestures.getSize(); ++i)
	{
		if (gestures[i].isComplete())
		{
			const nite::Point3f& position = gestures[i].getCurrentPosition();
			nite::GestureType gestureType = gestures[i].getType();

			/* 
					1 GESTO CUANDO TENEMOS 1 MANO
			*/
			if (hands.getSize() == 1) {
				switch (gestureType)
				{
				case NITE_GESTURE_CLICK:
					break;
				case NITE_GESTURE_WAVE:
					break;
				}
			}
			else if (hands.getSize() > 1 && gestures.getSize() == 1 && acumulatedGestures <= 0) {
				
				acumulatedGestures++;
				framesTwoHandsGesture = FRAMES_TWO_HAND_GESTURE;
				
				switch (gestureType)
				{
				case NITE_GESTURE_CLICK:
					acumulatedGestureType = NITE_GESTURE_CLICK;
					break;
				case NITE_GESTURE_WAVE:
					acumulatedGestureType = NITE_GESTURE_WAVE;
					break;
				}

			}
			else if (gestures.getSize() >= 1 && hands.getSize() > 1) {
				/*
						2 GESTOS CUANDO TENEMOS 2 MANOS
				*/
				if (gestures.getSize() > 1) { // Si se encuentran 2 gestos en el mismo frame, diremos que son del mismo tipo y no miraremos el segundo.
					switch (gestureType)
					{
						case NITE_GESTURE_CLICK:
							haciendoZoom = true;
							ultimaDistanciaEntreManos = abs(ultimaReferenciax - ultimaReferenciaxM2);
							framesTwoHandsGesture = FRAMES_TWO_HAND_GESTURE;
							framesStopZooming = FRAMES_STOP_ZOOMING;
							break;
						case NITE_GESTURE_WAVE:
							framesTwoHandsGesture = FRAMES_TWO_HAND_GESTURE;
							break;
					}
					break;
				} else if (acumulatedGestures >= 1) { // Los 2 gestos se encuentran en frames distintos
					switch (gestureType)
					{
						case NITE_GESTURE_CLICK:
							if (acumulatedGestureType == NITE_GESTURE_CLICK) { // Coinciden los 2 gestos
								haciendoZoom = true;
								ultimaDistanciaEntreManos = abs(ultimaReferenciax - ultimaReferenciaxM2);
								framesTwoHandsGesture = FRAMES_TWO_HAND_GESTURE;
								framesStopZooming = FRAMES_STOP_ZOOMING;
							}
							break;
						case NITE_GESTURE_WAVE:
							if (acumulatedGestureType == NITE_GESTURE_WAVE) { // Coinciden los 2 gestos
								framesTwoHandsGesture = FRAMES_TWO_HAND_GESTURE;
							}
							break;
					}
				}
				acumulatedGestures = 0;
			}
		}
		nite::HandId newId;
		m_pHandTracker->startHandTracking(gestures[i].getCurrentPosition(), &newId);
	}


	// Cuando estamos haciendo zoom, si las manos se separan lo suficiente, se producir� un evento de la ruleta del rat�n
	// Si despu�s de unos cuantos frames no se detecta distancia entre las manos, dejaremos de hacer zoom.
	if (contadorMano2 == 0) {
		if (haciendoZoom && abs(ultimaReferenciax - ultimaReferenciaxM2) > ultimaDistanciaEntreManos + DISTANCIA_MANOS) {
			ultimaDistanciaEntreManos = abs(ultimaReferenciax - ultimaReferenciaxM2);
			mouse_event(MOUSEEVENTF_WHEEL, (int)ultimaReferenciax * 4, (int)ultimaReferenciay * (-5), WHEEL_DELTA * 5, 0);
			framesStopZooming = FRAMES_STOP_ZOOMING;
		}
		else if (haciendoZoom && abs(ultimaReferenciax - ultimaReferenciaxM2) < ultimaDistanciaEntreManos - DISTANCIA_MANOS) {
			ultimaDistanciaEntreManos = abs(ultimaReferenciax - ultimaReferenciaxM2);
			mouse_event(MOUSEEVENTF_WHEEL, (int)ultimaReferenciax * 4, (int)ultimaReferenciay * (-5), -WHEEL_DELTA * 5, 0);
			framesStopZooming = FRAMES_STOP_ZOOMING;
		}
		else {
			if (haciendoZoom) {
				if (framesStopZooming <= 0) {
					haciendoZoom = false;
				}
				else {
					framesStopZooming--;
				}
			}
		}
	}
}

// C�digo a ejecutar cuando estas en modo Power Point
void exePowerPoint(const nite::Array<nite::GestureData>& gestures, const nite::Array<nite::HandData>& hands,
	nite::HandTracker* m_pHandTracker) {

	// Cuando se detecta un gesto se decrementa el contador y hasta que no llegue a 0 no se ejecutar� 
	// el gesto detectado, dando margen a hacer un posible segundo gesto y contarlo como que se han
	// hecho a la vez
	if (acumulatedGestures > 0) {
		framesTwoHandsGesture--;
	}

	/*
				1 GESTO CUANDO TENEMOS 2 MANOS
	*/
	// Si han pasado mas de FRAMES_TWO_HAND_GESTURE frames despues de un gesto con dos manos en pantalla sin que haya otro,
	// se contara como un gesto y se realizara la accion pertinente
	if (framesTwoHandsGesture <= 0) {
		acumulatedGestures = 0;
		framesTwoHandsGesture = FRAMES_TWO_HAND_GESTURE;
		switch (acumulatedGestureType) {
		case NITE_GESTURE_CLICK:
			keybd_event(VK_F5, 0, 0, 0);
			break;
		case NITE_GESTURE_WAVE:
			keybd_event(VK_ESCAPE, 0, 0, 0);
			break;
		}
	}

	// Para cada gesto encontrado en el frame actual..
	for (int i = 0; i < gestures.getSize(); ++i)
	{
		if (gestures[i].isComplete())
		{
			const nite::Point3f& position = gestures[i].getCurrentPosition();
			nite::GestureType gestureType = gestures[i].getType();

			/*
					1 GESTO CUANDO TENEMOS 1 MANO
			*/
			if (hands.getSize() == 1) {
				switch (gestureType)
				{
				case NITE_GESTURE_CLICK:
					keybd_event(VK_RIGHT, 0, 0, 0);
					break;
				case NITE_GESTURE_WAVE:
					keybd_event(VK_LEFT, 0, 0, 0);
					break;
				}
			}
			else if (hands.getSize() > 1 && gestures.getSize() == 1 && acumulatedGestures <= 0) {

				acumulatedGestures++;
				framesTwoHandsGesture = FRAMES_TWO_HAND_GESTURE;

				switch (gestureType)
				{
				case NITE_GESTURE_CLICK:
					acumulatedGestureType = NITE_GESTURE_CLICK;
					break;
				case NITE_GESTURE_WAVE:
					acumulatedGestureType = NITE_GESTURE_WAVE;
					break;
				}

			}
			else if (gestures.getSize() >= 1 && hands.getSize() > 1) {
				/*
						2 GESTOS CUANDO TENEMOS 2 MANOS
				*/
				if (gestures.getSize() > 1) { // Si se encuentran 2 gestos en el mismo frame, diremos que son del mismo tipo y no miraremos el segundo.
					switch (gestureType)
					{
					case NITE_GESTURE_CLICK:
						framesStopZooming = FRAMES_STOP_ZOOMING;
						break;
					case NITE_GESTURE_WAVE:
						framesTwoHandsGesture = FRAMES_TWO_HAND_GESTURE;
						break;
					}
					break;
				} else if (acumulatedGestures >= 1) { // Los 2 gestos se encuentran en frames distintos
					switch (gestureType)
					{
					case NITE_GESTURE_CLICK:
						if (acumulatedGestureType == NITE_GESTURE_CLICK) { // Coinciden los 2 gestos
							framesStopZooming = FRAMES_STOP_ZOOMING;
						}
						break;
					case NITE_GESTURE_WAVE:
						if (acumulatedGestureType == NITE_GESTURE_WAVE) { // Coinciden los 2 gestos
							framesTwoHandsGesture = FRAMES_TWO_HAND_GESTURE;
						}
						break;
					}
				}
				acumulatedGestures = 0;
			}
		}
		nite::HandId newId;
		m_pHandTracker->startHandTracking(gestures[i].getCurrentPosition(), &newId);
	}
}

void SampleViewer::Display()
{
	nite::HandTrackerFrameRef handFrame;
	openni::VideoFrameRef depthFrame;
	nite::Status rc = m_pHandTracker->readFrame(&handFrame);

	const nite::Array<nite::GestureData>& gestures = handFrame.getGestures();
	const nite::Array<nite::HandData>& hands = handFrame.getHands();

	if (rc != nite::STATUS_OK)
	{
		printf("GetNextData failed\n");
		return;
	}

	depthFrame = handFrame.getDepthFrame();

	if (m_pTexMap == NULL)
	{
		// Texture map init
		m_nTexMapX = MIN_CHUNKS_SIZE(depthFrame.getVideoMode().getResolutionX(), TEXTURE_SIZE);
		m_nTexMapY = MIN_CHUNKS_SIZE(depthFrame.getVideoMode().getResolutionY(), TEXTURE_SIZE);
		m_pTexMap = new openni::RGB888Pixel[m_nTexMapX * m_nTexMapY];
	}


	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0, GL_WIN_SIZE_X, GL_WIN_SIZE_Y, 0, -1.0, 1.0);

	if (depthFrame.isValid())
	{
		calculateHistogram(m_pDepthHist, MAX_DEPTH, depthFrame);
	}

	memset(m_pTexMap, 0, m_nTexMapX*m_nTexMapY*sizeof(openni::RGB888Pixel));

	float factor[3] = {1, 1, 1};
	// check if we need to draw depth frame to texture
	if (depthFrame.isValid() && g_drawDepth)
	{
		const openni::DepthPixel* pDepthRow = (const openni::DepthPixel*)depthFrame.getData();
		openni::RGB888Pixel* pTexRow = m_pTexMap + depthFrame.getCropOriginY() * m_nTexMapX;
		int rowSize = depthFrame.getStrideInBytes() / sizeof(openni::DepthPixel);

		for (int y = 0; y < depthFrame.getHeight(); ++y)
		{
			const openni::DepthPixel* pDepth = pDepthRow;
			openni::RGB888Pixel* pTex = pTexRow + depthFrame.getCropOriginX();

			for (int x = 0; x < depthFrame.getWidth(); ++x, ++pDepth, ++pTex)
			{
				if (*pDepth != 0)
				{
					factor[0] = Colors[colorCount][0];
					factor[1] = Colors[colorCount][1];
					factor[2] = Colors[colorCount][2];

					int nHistValue = m_pDepthHist[*pDepth];
					pTex->r = nHistValue*factor[0];
					pTex->g = nHistValue*factor[1];
					pTex->b = nHistValue*factor[2];

					factor[0] = factor[1] = factor[2] = 1;
				}
			}

			pDepthRow += rowSize;
			pTexRow += m_nTexMapX;
		}
	}

	glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP_SGIS, GL_TRUE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, m_nTexMapX, m_nTexMapY, 0, GL_RGB, GL_UNSIGNED_BYTE, m_pTexMap);

	// Display the OpenGL texture map
	glColor4f(1,1,1,1);

	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);

	g_nXRes = depthFrame.getVideoMode().getResolutionX();
	g_nYRes = depthFrame.getVideoMode().getResolutionY();

	// upper left
	glTexCoord2f(0, 0);
	glVertex2f(0, 0);
	// upper right
	glTexCoord2f((float)g_nXRes/(float)m_nTexMapX, 0);
	glVertex2f(GL_WIN_SIZE_X, 0);
	// bottom right
	glTexCoord2f((float)g_nXRes/(float)m_nTexMapX, (float)g_nYRes/(float)m_nTexMapY);
	glVertex2f(GL_WIN_SIZE_X, GL_WIN_SIZE_Y);
	// bottom left
	glTexCoord2f(0, (float)g_nYRes/(float)m_nTexMapY);
	glVertex2f(0, GL_WIN_SIZE_Y);

	glEnd();
	glDisable(GL_TEXTURE_2D);

	// Movimiento del cursor por la pantalla
	for (int i = 0; i < hands.getSize(); ++i)
	{
		const nite::HandData& user = hands[i];

		if (!user.isTracking())
		{
			printf("Lost hand %d\n", user.getId());

			// reseteamos estado de la ejecuci�n para evitar comportamientos inesperados
			resetVariables();
			
			//si la mano se ha perdido, vamos a borrarla del array que la identifica
			for (int i = 0; i < sizeof(manos); i++) {
				
				if (manos[i] == user.getId()) {
					manos[i] = NULL;
					break;
				}
			}
			nite::HandId id = user.getId();
			HistoryBuffer<20>* pHistory = g_histories[id];
			g_histories.erase(g_histories.find(id));
			delete pHistory;
		}
		else
		{
			if (user.isNew())
			{
				printf("Found hand %d\n", user.getId());

				//si encontramos una mano, la a�adimos al espacio en nulo que hay
				for (int i = 0; i < sizeof(manos); i++) {
					if(manos[i]==NULL){
						manos[i] = user.getId();
						break;
					}
				}
				g_histories[user.getId()] = new HistoryBuffer<20>;
			}
			// Add to history
			HistoryBuffer<20>* pHistory = g_histories[user.getId()];

			//si hay una mano encontrada en la posici�n zero (por lo general la primera encontrada)
			if (manos[0]==user.getId()) {
				
				//le a�andimos un puntero
				pHistory->AddPoint(user.getPosition());

				//sumamos los valores de posici�n en el eje X e Y
				sumaX += user.getPosition().x;
				sumaY += user.getPosition().y;
				contador++;

				//si hemos sumado ya N veces la posici�n de la mano
				if (contador == N) {

					//reseteamos el contador y calculamos la media
					contador = 0;
					sumaX = sumaX / N;
					sumaY = sumaY / N;

					//guardamos la ultima referencia
					ultimaReferenciax = sumaX;
					ultimaReferenciay = sumaY;

					//hacemos que el cursor se mueva al valor medio calculado (multiplicados para poder moverse por toda la pantalla)
					SetCursorPos((int)sumaX * 4, (int)sumaY*(-5));

					//reseteamos suma
					sumaX = 0;
					sumaY = 0;
				}
			}
			
			//si hay una mano en la posici�n 1 de manos(por lo general la segunda mano)
			if (manos[1] == user.getId()) {

				//Obtengo los datos de la mano y le asigno un puntero
				HistoryBuffer<20>* pHistory = g_histories[user.getId()];
				pHistory->AddPoint(user.getPosition());

				//sumamos los valores de posici�n en el eje X e Y de la segunda mano
				sumaXM2 += user.getPosition().x;
				sumaYM2 += user.getPosition().y;
				contadorMano2++;

				//si hemos sumado ya 5 valores de X e Y
				if (contadorMano2 == N) {

					//reseteamos el contador y calculamos la media
					contadorMano2 = 0;
					sumaXM2 = sumaXM2 / N;
					sumaYM2 = sumaYM2 / N;

					//acumulamos la media y guardamos la ultima referencia
					ultimaReferenciaxM2 = sumaXM2;
					ultimaReferenciayM2 = sumaYM2;

					//reeteamos valores
					ultimaReferenciaxM2 = 0;
					ultimaReferenciayM2 = 0;

					//reseteamos suma
					sumaXM2 = 0;
					sumaYM2 = 0;
				}
			}

			// Draw history
			DrawHistory(m_pHandTracker, user.getId(), pHistory);
		}
	}


	/*
		EJECUTAR LAS ACCIONES RELACIONADAS CON LA APLICACI�N EN CURSO
	*/
	switch (appRunning) {
		case GOOGLE_EARTH:
			exeGoogleEarth(gestures, hands, m_pHandTracker);
			break;
		case POWER_POINT:
			exePowerPoint(gestures, hands, m_pHandTracker);
			break;
	}

	if (g_drawFrameId)
	{
		DrawFrameId(handFrame.getFrameIndex());
	}

	// Swap the OpenGL display buffers
	glutSwapBuffers();

}

void SampleViewer::OnKey(unsigned char key, int /*x*/, int /*y*/)
{
	switch (key)
	{
	case 27:
		Finalize();
		exit (1);
	case 'd':
		g_drawDepth = !g_drawDepth;
		break;
	case 's':
		if (g_smoothing)
		{
			// Turn off smoothing
			m_pHandTracker->setSmoothingFactor(0);
			g_smoothing = FALSE;
		}
		else
		{
			m_pHandTracker->setSmoothingFactor(0.1);
			g_smoothing = TRUE;
		}
		break;
	case 'f':
		// Draw frame ID
		g_drawFrameId = !g_drawFrameId;
		break;

	case 'g':
		resetVariables();
		appRunning = GOOGLE_EARTH;
		printf("Estas en modo GOOGLE_EARTH\n");
		break;

	case 'p':
		resetVariables();
		appRunning = POWER_POINT;
		printf("Estas en modo POWER_POINT\n");
		break;
	}

}

openni::Status SampleViewer::InitOpenGL(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(GL_WIN_SIZE_X, GL_WIN_SIZE_Y);
	glutCreateWindow (m_strSampleName);
	// 	glutFullScreen();
	glutSetCursor(GLUT_CURSOR_NONE);

	InitOpenGLHooks();

	glDisable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);

	glEnableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);

	return openni::STATUS_OK;

}
void SampleViewer::InitOpenGLHooks()
{
	glutKeyboardFunc(glutKeyboard);
	glutDisplayFunc(glutDisplay);
	glutIdleFunc(glutIdle);
}
