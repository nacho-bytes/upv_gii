You can check our Project on HEROKU !! !
We also Use Speach Recognition to provide Voice feedback. 
But to get it working on your browser You have to do some work.

1: You need to use Chrome.

2: Go to chrome://flags/

3: Enable Autoplay policy 

4: Enter https://no-hablo-espaniol.herokuapp.com/ 

5: Allow website to use Your microphone 

Here is the list of few commands that are provided by our app for testing purposes:
0: "hello"
1: "email *something*"
2: "password *something*"
3: "repeat password *something*"
4: "show password"
5: "hide password"
6: "tell me a joke"
7: "go to function"
8: "go to list"
9: "go to presentation"
10: "go to homepage"
11: "scroll down"
12: "scroll up"
13: "start scrolling down"
14: "start scrolling up"
15: "stop scrolling"