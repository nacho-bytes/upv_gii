if (annyang) {
    // Let's define our first command. First the text we expect, and then the function it should call


    var up,down;

      var commands = {
        'hello': function() {
          console.log("elo")
          hello();
        },
        'email *cos': function(cos) {
          console.log("email")
          document.getElementById('email').value = cos;
        },
        'password *cos': function(cos) {
          console.log("psw")
          document.getElementById('psw').value = cos;
        },
        'repeat password *cos': function(cos) {
          console.log("psw-repeat")
          document.getElementById('psw-repeat').value = cos;
        },
        'show password': function() {
          console.log("pass show")
          document.getElementById('psw-repeat').type = "text";
          document.getElementById('psw').type = "text";
        },
        'hide password': function() {
          console.log("pass hide")
          document.getElementById('psw-repeat').type = "password";
          document.getElementById('psw').type = "password";
        },
        'tell me a joke': function() {
          console.log("joke")
          getJoke();
        },
        'go to function': function() {
          window.location.href = '/features.html';
        },
        'go to list': function() {
          window.location.href = '/list_of_libs.html';
        },
        'go to presentation': function() {
          window.location.href = '/presentation.html';
        },
        'go to homepage': function() {
          window.location.href = '/index.php';
        },
        'scroll down': function() {
          console.log("scroll down")
          window.scroll(0,window.scrollY + 250);
        },
        'scroll up': function() {
          console.log("scroll up")
          window.scroll(0,window.scrollY - 250);
        },
        'start scrolling down': function() {
          console.log("scrolling down")
          clearInterval(up);
          down = setInterval(()=>{window.scroll(0,window.scrollY + 250);},500);
          console.log(down);
          
        },
        'start scrolling up': function() {
          console.log("scrolling up")
          clearInterval(down);
          up = setInterval(()=>{window.scroll(0,window.scrollY - 250);},500);
          console.log(up);
          
        },
        'stop scrolling': function() {
          console.log("scrolling stopped")
          clearInterval(up);
          clearInterval(down);
        },
        'find *cos': function(cos) {
          console.log("find " + encodeURIComponent(cos));
          window.location.href = "https://www.google.com/search?q=" + encodeURIComponent(cos);
          
        },
        'calculator *cos': function(cos) {
          console.log("Calculator" + cos)
        },
      };

      let helpBox = Object.keys(commands);
      console.log(helpBox);
    
      // Add our commands to annyang
      annyang.addCommands(commands);
    
      // Start listening. You can call this here, or attach this call to an event, button, etc.
      annyang.start({ autoRestart: true, continuous: false });
    
    let body = document.getElementsByTagName('body')[0];
    let helpBar = document.createElement('div');
    helpBar.setAttribute('id','helpBar');
    helpBar.style.backgroundColor = "yellow";
    helpBox.forEach(element => {
    helpBar.innerHTML += `<div>${element}</div>`;
  });


  body.insertBefore(helpBar,body.firstChild);
}  
  else {
    alert('No annyang found')
  }
  function getJoke() { 
    axios.get('https://api.icndb.com/jokes/random')
      .then(function (response) {
        console.log(response.data.value.joke);
        var msg = new SpeechSynthesisUtterance(response.data.value.joke);
        window.speechSynthesis.speak(msg);
        document.getElementById('volume').style.visibility = 'visible';
        setTimeout(()=>{
          document.getElementById('volume').style.visibility ='hidden';
        },6000)
      })
      .catch(function (error) {
        console.log(error);
      })

  }

  function hello (){
    document.getElementById("dupa").style.visibility="hidden";
    document.getElementById("dupa2").style.visibility="hidden";
    document.getElementById("title").innerHTML = "HOLA !!";
    var msg = new SpeechSynthesisUtterance("Hola !!!");
    window.speechSynthesis.speak(msg);
    setTimeout(()=>{
      document.getElementById("dupa").style.visibility="visible";
      document.getElementById("title").innerHTML = "";
      document.getElementById("dupa2").style.visibility="visible";
    },2000);
  }