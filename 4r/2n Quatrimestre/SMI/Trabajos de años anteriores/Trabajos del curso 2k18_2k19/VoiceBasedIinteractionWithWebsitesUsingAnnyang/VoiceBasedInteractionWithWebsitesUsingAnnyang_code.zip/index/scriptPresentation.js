class PartOfPresentation {
    currentPart;
    baseUrl;

    constructor() {
        this.currentPart = 1;
        this.baseUrl = "https://no-hablo-espaniol.herokuapp.com/presentation.html#part";
    }

    inc() {
        if (this.currentPart<4)
            return    ++this.currentPart;
        else
            return this.currentPart;
    }

    dec() {
        if (this.currentPart>1)
            return    --this.currentPart;
        else
            return this.currentPart;
    }
}



if (annyang) {
    
    let partCounter = new PartOfPresentation();

    var commands = {
      'hello': function() {
        console.log("elo")
        hello();
      },
      'go to function': function() {
        window.location.href = '/features.html';
      },
      'go to list': function() {
        window.location.href = '/list_of_libs.html';
      },
      'go to homepage': function() {
        window.location.href = '/index.php';
      },
      'scroll down': function() {
        console.log("scroll down")
        window.scroll(0,window.scrollY + 250);
      },
      'scroll up': function() {
        console.log("scroll up")
        window.scroll(0,window.scrollY - 250);
      },
      'next slide please': function() {
        console.log("scrolling down")
        window.location.href = partCounter.baseUrl + partCounter.inc();
        var msg = new SpeechSynthesisUtterance("OK Kamil, showing next slide");
        window.speechSynthesis.speak(msg);
        
      },
      'next slide': function() {
        console.log("scrolling up")
        window.location.href = partCounter.baseUrl + partCounter.inc();
        var msg = new SpeechSynthesisUtterance("OK, obi wan kenobi");
        window.speechSynthesis.speak(msg);
        
      },
      'go back': function() {
        console.log("scrolling down")
        window.location.href = partCounter.baseUrl + partCounter.dec();
        
      },
    };

    let helpBox = Object.keys(commands);
    console.log(helpBox);
  
    // Add our commands to annyang
    annyang.addCommands(commands);
  
    // Start listening. You can call this here, or attach this call to an event, button, etc.
    annyang.start({ autoRestart: true, continuous: false });
    
    let body = document.getElementsByTagName('body')[0];
    let helpBar = document.createElement('div');
    helpBar.setAttribute('id','helpBar');
    helpBar.style.backgroundColor = "yellow";
    helpBox.forEach(element => {
    helpBar.innerHTML += `<div>${element}</div>`;
  });


  body.insertBefore(helpBar,body.firstChild);
}  
  else {
    alert('No annyang found')
  }
  function getJoke() { 
    axios.get('https://api.icndb.com/jokes/random')
      .then(function (response) {
        console.log(response.data.value.joke);
        var msg = new SpeechSynthesisUtterance(response.data.value.joke);
        window.speechSynthesis.speak(msg);
        document.getElementById('volume').style.visibility = 'visible';
        setTimeout(()=>{
          document.getElementById('volume').style.visibility ='hidden';
        },6000)
      })
      .catch(function (error) {
        console.log(error);
      })

  }

  function hello (){
    document.getElementById("dupa").style.visibility="hidden";
    document.getElementById("dupa2").style.visibility="hidden";
    document.getElementById("title").innerHTML = "HOLA !!";
    var msg = new SpeechSynthesisUtterance("Hola !!!");
    window.speechSynthesis.speak(msg);
    setTimeout(()=>{
      document.getElementById("dupa").style.visibility="visible";
      document.getElementById("title").innerHTML = "";
      document.getElementById("dupa2").style.visibility="visible";
    },2000);
  }