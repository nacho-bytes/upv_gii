class Miembros:
    xManoDerecha = 0
    yManoDerecha = 0
    xManoIzquierda = 0
    yManoIzquierda = 0
    xHombroIzquierdo = 0
    yHombroIzquierdo = 0
    xHombroDerecho = 0
    yHombroDerecho = 0
    yCabeza = 0
    xCabeza = 0


    def esCruz(self):
        if(self.yHombroIzquierdo == 0 or self.yHombroDerecho ==0 or self.yManoDerecha == 0 or self.yManoIzquierda == 0):
            return False
        if(self.yManoIzquierda-5 < self.yManoDerecha and self.yManoDerecha < self.yManoIzquierda+5 and self.yHombroDerecho - 3 < self.yHombroIzquierdo and self.yHombroIzquierdo<self.yHombroDerecho +3):
            return True
        else: 
            return False
            

