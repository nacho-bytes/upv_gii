import random
from datetime import datetime, timedelta



f = open("Figuras\Cruz.txt", "r")
cruz = f.read()
f = open("Figuras\ManosArriba.txt", "r")
manosArriba = f.read()
f = open("Figuras\IzquierdaAbajo.txt", "r")
izquierdaAbajo = f.read()
f = open("Figuras\DerechaAbajo.txt", "r")
derechaAbajo = f.read()

figuras = [cruz,manosArriba,derechaAbajo,izquierdaAbajo]
figuraElegida = ""
step = None
delta = None

def eligeFigura():
    x = random.randint(0,3)
    figuraElegida = figuras[x]
    return figuraElegida

while(True):
    if step == None:
        step = datetime.now()
        delta = step + timedelta(seconds = 5)
        figuraElegida = eligeFigura()
        print(figuraElegida)
    else: 
        if step > delta:
            step = datetime.now()
            delta = step + timedelta(seconds = 5)
            figuraElegida = eligeFigura()
            print(figuraElegida)
    step = datetime.now()






    




 