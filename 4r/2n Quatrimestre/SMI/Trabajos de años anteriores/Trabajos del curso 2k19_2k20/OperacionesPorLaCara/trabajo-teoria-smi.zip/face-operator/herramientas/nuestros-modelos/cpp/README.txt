La red recibe como entrada un objeto `matrix<rgb_pixel>`.
Si el archivo está en disco, se puede cargar con estos comandos:

load_png( destino_en_memoria, nombre_fichero );

Tened en cuenta que la variable <destino-en-memoria> tiene que ser
un `array2d<rgb_pixel>`. Para convertir a `matrix<rgb_pixel>`:

matrix<rgb_pixel> foo = mat( destino_en_memoria );
// destino_en_memoria es el resultado de llamar a load_png()

TODO: ver cómo se utiliza la red para clasificar

La red clasifica en dos clases:
   - Clase 0: fotos con personas felices
   - Clase 1: fotos con personas neutrales


DOCKER
sudo docker build -f nvidia.Dockerfile -t probandocuda . --build-arg CUDAARCH=6.1
sudo docker run --rm -v /home/rodhuega/Escritorio/grupos/smi/herramientas/our-face-recog-models/split-fer:/trainingData --gpus all probandocuda
