/*
    Este código se basa en el entrenamiento oficial de DLib de la base de datos de dígitos MNIST:
    http://dlib.net/dnn_introduction_ex.cpp.html

    Es muy similar a ese código, prácticamente el entrenamiento se ha adaptado:
    de cargar las típicas matrices del MNIST pasamos a leer imágenes pertenecientes a emociones desde el disco.

    Este programa se llama de la siguiente manera: $ ./face-recog-train <carpeta>
    En <carpeta> deben haber dos subcarpetas: <carpeta>/train y <carpeta>/test, que corresponden a los datos
    de entrenamiento y de pruebas, respectivamente.

    El modelo consta de dos clases: feliz (0) y neutral (1). Como es entrenamiento supervisado, los nombres
    de las imágenes tienen "happy" o "neutral". Para preparar el vector de entrenamiento sencillamente
    se lee si el nombre de la imagen contiene "happy" o "neutral" y se mete en el vector de clases
    0 o 1 respectivamente.

    Nota: verdaderamente el hecho de que el nombre contenga "neutral" no es relevante ya que si el nombre
    no tiene "happy" se clasifica automáticamente como "neutral". Vamos, que está en un bloque else.
    La función load_dataset() explica esto bastante mejor.
*/

#include <dlib/dnn.h>
#include <iostream>
#include <experimental/filesystem>
#include <dlib/data_io.h>
#include <dlib/array2d.h>
#include <dlib/pixel.h>
#include <dlib/gui_widgets.h>
#include <dlib/image_io.h>
#include <dlib/image_transforms.h>
#include <fstream>

using namespace std;
using namespace dlib;
// Necesario para cargar las imágenes de disco
namespace fs = std::experimental::filesystem;

/*
    Nota: sabemos que hay redundancia de código y que el código se podría simplificar si quitáramos
    variables que significan prácticamente lo mismo (por ejemplo, fusionar `img_happy' y `img_nothappy'
    en una variable, y solo comprobar el nombre del archivo al añadir el valor en el vector de clases).
    
    Sin embargo, esperamos que esto ayude a seguir mejor el código puesto que los nombres
    son más relevantes que si combináramos las dos partes del código.
 */
void load_dataset(
    const std::string dir_name,
    std::vector<matrix<unsigned char>> *train_images,
    std::vector<unsigned long> *train_labels,
    std::vector<matrix<unsigned char>> *test_images,
    std::vector<unsigned long> *test_labels )
{
    array2d<rgb_pixel> img_happy, img_nothappy;
    array2d<unsigned char> img_happy_grey, img_nothappy_grey;
    matrix<unsigned char> mat_happy, mat_nothappy;
    
    for( const auto &pic : fs::directory_iterator( dir_name + "/train" ) ) {
        // Mirar si el nombre de la imagen contiene "happy"
        if( string( pic.path() ).find( "happy", 0 ) != string::npos ) {
            // Clase "feliz" (0)
            // Cargar la imagen
            load_png( img_happy_grey, pic.path() );
            // Convertir a matriz (es lo que DLib necesita como input)
            mat_happy = mat( img_happy_grey );
            train_images->push_back( mat_happy );
            train_labels->push_back( 0 );
        }
        else {
            // Clase "neutral" (1)
            // Cargar la imagen
            load_png( img_nothappy_grey, pic.path() );
            // Convertir a matriz (es lo que DLib necesita como input)
            mat_nothappy = mat( img_nothappy_grey );
            train_images->push_back( mat_nothappy );
            train_labels->push_back( 1 );
        }
    }

    for( const auto &pic : fs::directory_iterator( dir_name + "/test" ) ) {
        // Mirar si el nombre de la imagen contiene "happy"
        if( string( pic.path() ).find( "happy", 0 ) != string::npos ) {
            // Clase "feliz"
            // Cargar la imagen
            load_png( img_happy_grey, pic.path() );
            // Convertir a matriz (es lo que DLib necesita como input)
            mat_happy = mat( img_happy_grey );
            test_images->push_back( mat_happy );
            test_labels->push_back( 0 );
        }
        else {
            // Clase "neutral"
            // Cargar la imagen
            load_png( img_nothappy, pic.path() );
            // Convertir a matriz (es lo que DLib necesita como input)
            mat_nothappy = mat( img_nothappy_grey );
            test_images->push_back( mat_nothappy );
            test_labels->push_back( 1 );
        }
    }
}

int main(int argc, char** argv) try
{
    if (argc != 2)
    {
        cout << "Uso: ./face-recog-train <carpeta-con-subcarpetas-train-y-test>" << endl << endl;
        cout << "Este ejemplo necesita la carpeta con las subcarpetas train y test como primer argumento." << endl;
        
        return 1;
    }
    
    std::vector<matrix<unsigned char>> training_images;
    std::vector<unsigned long>         training_labels;
    std::vector<matrix<unsigned char>> testing_images;
    std::vector<unsigned long>         testing_labels;
    load_dataset(argv[1], &training_images, &training_labels, &testing_images, &testing_labels);

    // La siguiente línea define la estructura de la red neuronal.
    // Recomendamos leer el código original para obtener más información.
    //
    // Esencialmente, el cambio ha sido fc<10, ...> => fc<2, ...>
    // puesto que solo tenemos dos emociones (clases) que reconocer, al contrario
    // que el problema de MNIST que tiene 10 dígitos a reconocer.
    using net_type = loss_multiclass_log<
                                fc<2,        
                                relu<fc<84,   
                                relu<fc<120,  
                                max_pool<2,2,2,2,relu<con<16,5,5,1,1,
                                max_pool<2,2,2,2,relu<con<6,5,5,1,1,
                                input<matrix<unsigned char>> 
                                >>>>>>>>>>>>;
    
    // Instancia de la red
    net_type net;
    
    // Entrenamiento y parámetros de la red
    dnn_trainer<net_type> trainer(net);
    trainer.set_learning_rate(0.01);
    trainer.set_min_learning_rate(0.0001);
    trainer.set_mini_batch_size(128);
    trainer.be_verbose();
    
    // Se pide al entrenador que guarde el progreso cada 20 segundos en un archivo auxiliar
    trainer.set_synchronization_file("sync", std::chrono::seconds(20));

    // Esta línea empieza el entrenamiento
    trainer.train(training_images, training_labels);
    
    // Guardar el modelo en disco y limpiar datos irrelevantes
    net.clean();
    serialize("network.dat") << net;
    // Para sacar de disco la red usaremos:
    // deserialize("network.dat") >> net;
    // Esto se usa en el código del servidor que está en svOatCpp/src/App.cpp
    
    // Correr el modelo entrenado por las imágenes de ENTRENAMIENTO
    std::vector<unsigned long> predicted_labels = net(training_images);
    int num_right = 0;
    int num_wrong = 0;
    // Ver si las imágenes han sido clasificadas correctamente
    for (size_t i = 0; i < training_images.size(); ++i)
    {
        if (predicted_labels[i] == training_labels[i])
            ++num_right;
        else
            ++num_wrong;
        
    }
    cout << "training num_right: " << num_right << endl;
    cout << "training num_wrong: " << num_wrong << endl;
    cout << "training accuracy:  " << num_right/(double)(num_right+num_wrong) << endl;

    // Correr el modelo entrenado por las imágenes de PRUEBAS y
    // ver si las imágenes han sido clasificadas correctamente
    predicted_labels = net(testing_images);
    num_right = 0;
    num_wrong = 0;
    for (size_t i = 0; i < testing_images.size(); ++i)
    {
        if (predicted_labels[i] == testing_labels[i])
            ++num_right;
        else
            ++num_wrong;
        
    }
    cout << "testing num_right: " << num_right << endl;
    cout << "testing num_wrong: " << num_wrong << endl;
    cout << "testing accuracy:  " << num_right/(double)(num_right+num_wrong) << endl;
    
    // Guardar los parámetros de la red a XML, por si acaso
    net_to_xml(net, "face-recog-net.xml");
    std::ifstream  srcNetwork("network.dat", std::ios::binary);
    std::ofstream  dstNetwork(string(argv[1])+"/network.dat",   std::ios::binary);
    std::ifstream  srcXml("face-recog-net.dat", std::ios::binary);
    std::ofstream  dstXml(string(argv[1])+"/face-recog-net.dat",   std::ios::binary);
    dstNetwork << srcNetwork.rdbuf();
    dstXml << srcXml.rdbuf();
}
catch(std::exception& e)
{
    cout << e.what() << endl;
}
