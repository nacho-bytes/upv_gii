import csv
import os
import cv2
import numpy as np

ANGRY    = 0
DISGUST  = 1
FEAR     = 2
HAPPY    = 3
SAD      = 4
SURPRISE = 5
NEUTRAL  = 6

if not os.path.exists( "train" ):
    os.mkdir( "train" )
if not os.path.exists( "test" ):
    os.mkdir( "test" )
happ = 0
neut = 0

with open( "fer2013.csv", "r" ) as csv_file:
    read_csv = csv.reader( csv_file )
    first = True
    for emotion, img_matrix, usage in read_csv:
        if first:
            first = False
            continue  # This is the first line which has no content at all
        
        emotion = int( emotion )
        if emotion == HAPPY:
            img_name = "happy" + str( happ ) + ".png"
            happ += 1
        elif emotion == NEUTRAL:
            img_name = "neutral" + str( neut ) + ".png"
            neut += 1
        else:
            continue
        
        img_data = img_matrix.split()
        python_array = []
        ## We are sure that the image is 48x48
        for i in range( 48 ):
            aux_list = []
            for j in range( 48 ):
                aux_list.append( int( img_data[ 48 * i + j ] ) )
            python_array.append( aux_list )
        numpy_mat = np.asmatrix( python_array, dtype = np.uint8 )
        opencv_img = cv2.resize( numpy_mat, ( 48, 48 ) )
        
        if usage == "Training":
            cv2.imwrite( "train/" + img_name, opencv_img )
        else:
            cv2.imwrite( "test/" + img_name, opencv_img )
        
