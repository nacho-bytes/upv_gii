//NOTA IMPORTANTE; CREO QUE EL PRIMER RESULTADO QUE SE MANDA ES UNA IMAGEN EN NEGRO NO VALIDA; ESO CREO QUE VIENE DADO DE LA LOGICA INICIAL DEL SETINTERVAL
let imageCapture;
let serverAddress = "http://127.0.0.1"
let serverPort = "5001"
let serverEndpoint = "recibeImagen"
let sendAddress = serverAddress + ":" + serverPort + "/" + serverEndpoint

//Tipos de respuesta
const resCaraNoDetectada = -1;
const resFeliz = 0;
const resInfeliz = 1;

let tiempoActual=5;

async function comprobarRespuestaUsuario(resultadoReal,resultadoMostradoAlUsuario,numeroPregunta) {
    //Convertir imagen a base64
    canvasSend.width = video.videoWidth
    canvasSend.height = video.videoHeight
    imageCapture.grabFrame()
        .then(imageBitmap => {
            canvasSend.getContext("2d").drawImage(imageBitmap, 0, 0, video.videoWidth, video.videoHeight)
            let imgBase64WithFormat = canvasSend.toDataURL()
            let imgBase64 = imgBase64WithFormat.substring(imgBase64WithFormat.indexOf(",") + 1)
            //Enviar la imagen
            let t0=performance.now()
            $.ajax({
                url: sendAddress,
                headers: {
                    'Content-Type': 'application/json'
                },
                type: "POST",
                dataType: "json",
                data: JSON.stringify({
                    "Imagen": imgBase64
                }),
                success: function (result) {
                    let t1=performance.now()
                    //AQUI LLEGA EL RESULTADO DEL SERVER
                    if(result.respuesta==resCaraNoDetectada)
                    { //Error cara no detectada
                        divRespuestaCaraNoDetectada.classList.remove('d-none')
                        divRespuestaCaraNoDetectada.classList.add('d-block')
                    }
                    else if(result.respuesta == 0.5) {
                        puntuacion -= 1
                        divNoConsenso.classList.remove('d-none')
                        divNoConsenso.classList.add('d-block')
                    }
                    else if((result.respuesta < 0.5 && resultadoCorrecto[numeroPregunta]) || (result.respuesta > 0.5 && !resultadoCorrecto[numeroPregunta]))
                    {//Respuesta correcta
                        puntuacion+=5
                        divRespuestaCorrecta.classList.remove('d-none') 
                        divRespuestaCorrecta.classList.add('d-block')
                    } else 
                    {//Respuesta incorrecta
                        puntuacion-=1;
                        divRespuestaIncorrecta.classList.remove('d-none')
                        divRespuestaIncorrecta.classList.add('d-block')
                    }
                    lblPuntuacion.innerHTML = puntuacion.toString();

                    console.log("Expresion cara: ", result, " tiempo empleado: ", t1-t0, " ms")
                    siguiente(numeroPregunta)
                },
                error: function () {//Error en el servidor
                    divRespuestaErrorServidor.classList.remove('d-none')
                    divRespuestaErrorServidor.classList.add('d-block')
                    siguiente(numeroPregunta)
                }
            });
            

        })

}

function siguiente(numeroPregunta)
{
    numeroPregunta++;
    tiempoActual=5;
    nuevaPregunta(numeroPregunta)
}

const canvasSend    = document.querySelector("#canvasSend")
const cameraOptions = document.querySelector(".video-options>select");
const video         = document.querySelector("video");
const divOptions    = document.getElementById("divOptions")
const divJuego      = document.getElementById("divJuego")
const lblPuntuacion = document.getElementById("lblPuntuacion")
const lblTiempo     = document.getElementById("lblTiempo")
const btnPlay       = document.getElementById("btnPlay")

const lblOperand1  = document.getElementById("pMathOperand1")
const lblOperand2  = document.getElementById("pMathOperand2")
const lblOperation = document.getElementById("pMathOperation")
const lblEquals    = document.getElementById("pMathEquals")
const lblResult    = document.getElementById("pMathResult")

const divRespuestaCaraNoDetectada = document.getElementById("divRespuestaCaraNoDetectada")
const divRespuestaCorrecta        = document.getElementById("divRespuestaCorrecta")
const divRespuestaIncorrecta      = document.getElementById("divRespuestaIncorrecta")
const divNoConsenso               = document.getElementById("divNoConsenso")
const divRespuestaErrorServidor   = document.getElementById("divRespuestaErrorServidor")

// Mapeo de números de operación a símbolos para facilitar
// la salida por pantalla del símbolo en cuestión
const op2symbol = ["+", "-", "x", "/"]

// Probabilidad de que al usuario se le ponga en pantalla
// el resultado correcto de la operación
const probabilityRightAnswer = 0.5

// Máximo valor que aparece en las operaciones
const operationMaxVal = 10;

let streamStarted = false;
let puntuacion = 0;
let op1 = 0;
let op2 = 0;
let operation = "+";
let resReal = []
let resUser = []
let resultadoCorrecto = []
let numeroPregunta=0

function computeResult(op1, op2, operation) {
    let res;
    if (operation == "+") {
        res = op1 + op2;
    }
    else if (operation == "-") {
        res = op1 - op2;
    }
    else if (operation == "x") {
        res = op1 * op2;
    }
    else if (operation == "/") {
        res = op1 / op2;
    }

    return res;
}

const getCameraSelection = async () => {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const videoDevices = devices.filter(device => device.kind === 'videoinput');
    i = 1;
    const options = videoDevices.map(videoDevice => {
        return `<option value="${videoDevice.deviceId}">${"Cámara " + i++}</option>`;
    });
    cameraOptions.innerHTML = options.join('');
};

btnPlay.onclick = () => {
    if (streamStarted) {
        video.play();
        return;
    }
    if ('mediaDevices' in navigator && navigator.mediaDevices.getUserMedia) {
        const updatedConstraints = {
            video: {
                deviceId: { exact: cameraOptions.value },
                width: {
                    min: 1280,
                    ideal: 1920,
                    max: 2560,
                },
                height: {
                    min: 720,
                    ideal: 1080,
                    max: 1440
                }
            }
        }
        startStream(updatedConstraints);
    }
};

const startStream = async (constraints) => {
    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    handleStream(stream);
};

const handleStream = (stream) => {
    const track = stream.getVideoTracks()[0];
    imageCapture = new ImageCapture(track);
    video.srcObject = stream;
    divOptions.classList.add('d-none');
    divJuego.classList.remove('d-none')
    streamStarted = true;
    nuevaPregunta(numeroPregunta)
};

function nuevaPregunta(numeroPregunta) {
    op1 = Math.floor(Math.random() * operationMaxVal);
    op2 = Math.floor(Math.random() * operationMaxVal);
    let numValidOps = Object.keys(op2symbol).length;
    operation = op2symbol[Math.floor(Math.random() * numValidOps)];
    if (operation == "/") {
        if (op2 == 0) {
            op2 = 1;
        }
        // Hacer el resultado de la división un entero
        while (op1 % op2 != 0) {
            op1++;
        }
    }
    resReal.push(computeResult(op1, op2, operation));
    // Ponerle al usuario una respuesta correcta dada una probabilidad
    if (Math.random() < probabilityRightAnswer) {
        // Se le pone al usuario la respuesta correcta
        resUser.push(resReal[numeroPregunta]);
        resultadoCorrecto.push(true)
    }
    else {
        // Se le pone al usuario una respuesta aleatoria
        // TODO: discutir poner respuestas que tengan sentido
        //       (por ejemplo, 2 + 3 = 1 no tiene sentido)
        resUser.push(Math.floor(Math.random() * operationMaxVal));
        resultadoCorrecto.push(false)
    }
    lblOperand1.innerHTML = op1.toString();
    lblOperand2.innerHTML = op2.toString();
    lblOperation.innerHTML = operation;
    lblResult.innerHTML = resUser[numeroPregunta].toString();

    let contadorActual=setInterval(function(){
        lblTiempo.innerHTML = tiempoActual;
        //Ocular mensajes
        if(tiempoActual<3)
        {
            divRespuestaCaraNoDetectada.classList.remove('d-block')
            divRespuestaCorrecta.classList.remove('d-block')
            divRespuestaIncorrecta.classList.remove('d-block')
            divNoConsenso.classList.remove('d-block')
            divRespuestaErrorServidor.classList.remove('d-block')
            
            divRespuestaCaraNoDetectada.classList.add('d-none');
            divRespuestaCorrecta.classList.add('d-none')
            divRespuestaIncorrecta.classList.add('d-none')
            divNoConsenso.classList.add('d-none')
            divRespuestaErrorServidor.classList.add('d-none')
        }
        if(tiempoActual>0)
        {
            tiempoActual--;
        }else{
            clearInterval(contadorActual)
            comprobarRespuestaUsuario(resReal,resUser,numeroPregunta)
        }
    },1000);
}

getCameraSelection();
