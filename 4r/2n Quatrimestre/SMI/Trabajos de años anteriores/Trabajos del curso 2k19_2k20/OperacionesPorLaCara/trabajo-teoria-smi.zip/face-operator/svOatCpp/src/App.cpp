//
//  main.cpp
//  web-starter-project
//
//  Created by Leonid on 2/12/18.
//  Copyright © 2018 oatpp. All rights reserved.
//
#include <vector>
#include <string>
#include <cstdio>
#include <cstdlib>
// #include "./controller/MyController.hpp"
#include "./AppComponent.hpp"
#include "oatpp/network/server/Server.hpp"
#include "dto/DTOs.hpp"
#include "oatpp/web/server/api/ApiController.hpp"
#include "oatpp/core/macro/codegen.hpp"
#include "oatpp/core/macro/component.hpp"
#include <iostream>

//PARTE LOGICA DE CLASIFICACION
#include <opencv2/opencv.hpp>

#include <dlib/opencv.h>
#include <dlib/pixel.h>
#include <dlib/dnn.h>
#include <dlib/data_io.h>

#include <ctime>
#include <inttypes.h>

using namespace cv;
using namespace std;

// Estructura del modelo
using net_type = dlib::loss_multiclass_log<
    dlib::fc<2,
             dlib::relu<dlib::fc<84,
                                 dlib::relu<dlib::fc<120,
                                                     dlib::max_pool<2, 2, 2, 2, dlib::relu<dlib::con<16, 5, 5, 1, 1, dlib::max_pool<2, 2, 2, 2, dlib::relu<dlib::con<6, 5, 5, 1, 1, dlib::input<dlib::matrix<unsigned char>>>>>>>>>>>>>>;

static std::string base64_decode(const std::string &in)
{

    std::string out;

    std::vector<int> T(256, -1);
    for (int i = 0; i < 64; i++)
        T["ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"[i]] = i;

    int val = 0, valb = -8;
    for (uchar c : in) {
        if (T[c] == -1)
            break;
        val = (val << 6) + T[c];
        valb += 6;
        if (valb >= 0) {
            out.push_back(char((val >> valb) & 0xFF));
            valb -= 8;
        }
    }
    return out;
}

/**
 * Recibe la imagen del cliente.
 */
cv::Mat recibeImage(unsigned char *imagenBase64Uchar)
{
    string imagenBase64(reinterpret_cast<char *>(imagenBase64Uchar));
    string decoded_string = base64_decode(imagenBase64);
    vector<uchar> data(decoded_string.begin(), decoded_string.end());
    Mat img = imdecode(data, IMREAD_UNCHANGED);

    return img;
}

/**
 * Procesa la imagen recibida:
 * - Recorta la imagen para que solo aparezca la cara
 * - La convierte a escala de grises (que es lo que la red neuronal reconoce)
 * - La pasa a un formato reconocible por la red neuronal
 * - La escala a 48x48, tamaño con el que ha sido entrenada la red neuronal
 */
std::vector<dlib::matrix<unsigned char>> procesaImage(Mat img, cv::CascadeClassifier faceCascade)
{
    // Pasar a escala de grises
    Mat imgGrey;
    cv::cvtColor(img, imgGrey, cv::COLOR_BGR2GRAY);
    
    // Detectar las caras de la imagen aplicando la herramienta de OpenCV
    std::vector<cv::Rect> detectedFaces;
    faceCascade.detectMultiScale(imgGrey, detectedFaces);
    // Si no se detecta ninguna cara, se pasa una imagen especial de tamaño 1x1
    // Esto se detecta fuera de esta función y se devuelve una respuesta especial al usuario
    if( detectedFaces.size() == 0 ) {
        std::vector<dlib::matrix<unsigned char>> nonDetected;
        dlib::matrix<unsigned char> nd(1,1);
        nonDetected.push_back( nd );
        
        return nonDetected;
    }
    
    // Llenar el vector con las caras recortadas de la imagen
    std::vector<cv::Mat> faceGrey( detectedFaces.size() );
    for( int i = 0; i < detectedFaces.size(); i++ ) {
        faceGrey[ i ] = imgGrey( detectedFaces[ i ] );  // La imagen se "indexa" mediante un cv::Rect (OpenCV lo hace automáticamente)
    }
    
    // Escalar las caras a 48x48
    std::vector<Mat> faceGreyRescaled( faceGrey.size() );
    for( int i = 0; i < faceGrey.size(); i++ ) {
        cv::resize( faceGrey[ i ], faceGreyRescaled[ i ], Size( 48, 48 ) );
    }
    
    // Pasar la imagen a formato reconocible por el modelo de DLib
    dlib::cv_image<unsigned char> dlibRecognizableImage;
    std::vector<dlib::matrix<unsigned char>> dlibRecognizableMatrices( faceGreyRescaled.size() );
    for( int i = 0; i < faceGreyRescaled.size(); i++ ) {
        dlibRecognizableImage = dlib::cv_image<unsigned char>( faceGreyRescaled[ i ] );
        assign_image( dlibRecognizableMatrices[ i ], dlibRecognizableImage );
    }
    
    return dlibRecognizableMatrices;
}

float clasificaImage(std::vector<dlib::matrix<unsigned char>> faces, net_type net)
{
    // Pasar el reconocedor por el vector de caras ya procesado (escala de grises, 48x48)
    std::vector<unsigned long> predictedLabels = net(faces);
    
    // Nos aprovechamos de que HAPPY = 0 y NOT_HAPPY = 1 para
    // devolverle al cliente una media aritmética y que este compare
    // si el valor devuelto está más cerca de HAPPY o de NOT_HAPPY
    int sum = 0;
    for( int i = 0; i < predictedLabels.size(); i++ ) {
        sum += predictedLabels[ i ];
    }
    float res = sum/float( predictedLabels.size() );
    
    return sum/float( predictedLabels.size() );
}

//CONTROLADOR
class MyController : public oatpp::web::server::api::ApiController
{
private:
    net_type net;
    cv::CascadeClassifier faceCascade;
    uint64_t start;
    uint64_t end;
public:
    /**
     * Constructor with object mapper.
     * @param objectMapper - default object mapper used to serialize/deserialize DTOs.
     */
    MyController(OATPP_COMPONENT(std::shared_ptr<ObjectMapper>, objectMapper))
    : oatpp::web::server::api::ApiController(objectMapper)
    {
        /* INICIO DE CARGA DE MODELOS */
        
        // Modelo de reconocimiento de emociones (nuestro)
        dlib::deserialize("../modelo/network.dat") >> net;
        
        // Modelo de reconocimiento de caras (de OpenCV)
        if (!faceCascade.load("../modelo/haarcascade_normal.xml")) {
            cout << "--(!)Error loading face cascade\n";
        }
        
        /* FIN DE CARGA DE MODELOS */
    }

public:
/**
 *  Begin ENDPOINTs generation ('ApiController' codegen)
 */
#include OATPP_CODEGEN_BEGIN(ApiController)
    ADD_CORS(recibeImagen)
    ENDPOINT("POST", "/recibeImagen", recibeImagen, BODY_DTO(RequestDto::ObjectWrapper, requestDto))
    {
        unsigned char *imagenBase64Uchar = requestDto->Imagen->getData();
        auto dto = ResponseDto::createShared();
        
        try {
            // Almacenar la imagen que viene del cliente
            Mat img = recibeImage(imagenBase64Uchar);

            start = std::chrono::duration_cast<std::chrono::milliseconds>( std::chrono::system_clock::now().time_since_epoch() ).count();
            // Sacar de la imagen las caras ya procesadas (en escala de grises, 48x48)
            std::vector<dlib::matrix<unsigned char>> caras = procesaImage(img, faceCascade);
            // Si no se ha detectado ninguna cara, enviar una respuesta especial
            // Esto no se hace automáticamente: ver la función procesaImage()
            if(caras[ 0 ].nr()==1 && caras[ 0 ].nc()==1) {
                cout << "--(!)Cara no detectada\n";
                dto->respuesta = -1;
                return createDtoResponse(Status::CODE_200, dto);
            }
            end = std::chrono::duration_cast<std::chrono::milliseconds>( std::chrono::system_clock::now().time_since_epoch() ).count();
            printf( "Tiempo de procesamiento de la cara: %" PRIu64 "\n", end - start );
            fflush( stdout );

            // Pasar el reconocedor de emociones por las caras extraídas de la imagen
            start = std::chrono::duration_cast<std::chrono::milliseconds>( std::chrono::system_clock::now().time_since_epoch() ).count();
            dto->respuesta = clasificaImage(caras, net);
            end = std::chrono::duration_cast<std::chrono::milliseconds>( std::chrono::system_clock::now().time_since_epoch() ).count();
            printf( "Tiempo de reconocer las emociones de la cara: %" PRIu64 " ms\n", end - start );
            fflush( stdout );
            
            // Devolver la media aritmética de las emociones reconocidas
            // (ver la función clasificaImage() para más información)
            return createDtoResponse(Status::CODE_200, dto);
        }
        catch (exception &ee) {
            dto->respuesta = -1;
            return createDtoResponse(Status::CODE_200, dto);
        }
    }

/**
 *  Finish ENDPOINTs generation ('ApiController' codegen)
 */
#include OATPP_CODEGEN_END(ApiController)
};


void run(int portServer)
{

    /* Register Components in scope of run() method */
    
    AppComponent components;
    
    OATPP_COMPONENT(std::shared_ptr<oatpp::web::server::HttpRouter>, router);
    
    /* Create MyController and add all of its endpoints to router */
    auto myController = std::make_shared<MyController>();
    myController->addEndpointsToRouter(router);
    
    /* Get connection handler component */
    OATPP_COMPONENT(std::shared_ptr<oatpp::network::server::ConnectionHandler>, connectionHandler);
    auto connectionProvider = oatpp::network::server::SimpleTCPConnectionProvider::createShared(portServer);
    /* Get connection provider component */
    // OATPP_COMPONENT(std::shared_ptr<oatpp::network::ServerConnectionProvider>, connectionProvider);
    
    /* Create server which takes provided TCP connections and passes them to HTTP connection handler */
    oatpp::network::server::Server server(connectionProvider, connectionHandler);
    
    /* Print info about server port */
    OATPP_LOGI("Server c++ para procesar la imagen", "Server running on port %s", connectionProvider->getProperty("port").getData());
    
    /* Run server */
    server.run();
}

/**
 *  main
 */
int main(int argc, const char *argv[])
{

    oatpp::base::Environment::init();
    try {
        int port = std::stoi(argv[1]);
        run(port);
        
        /* Print how much objects were created during app running, and what have left-probably leaked */
        /* Disable object counting for release builds using '-D OATPP_DISABLE_ENV_OBJECT_COUNTERS' flag for better performance */
        std::cout << "\nEnvironment:\n";
        std::cout << "objectsCount = " << oatpp::base::Environment::getObjectsCount() << "\n";
        std::cout << "objectsCreated = " << oatpp::base::Environment::getObjectsCreated() << "\n\n";
        
        oatpp::base::Environment::destroy();
    }
    catch (const std::exception &e) {
        std::cerr << e.what() << '\n';
    }
    
    return 0;
}
