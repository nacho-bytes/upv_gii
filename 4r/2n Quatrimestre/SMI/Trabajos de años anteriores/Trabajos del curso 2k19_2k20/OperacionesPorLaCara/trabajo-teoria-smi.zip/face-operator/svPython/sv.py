from flask import Flask, jsonify, request
from flask_cors import CORS,cross_origin
import keras as k
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, AveragePooling2D
from keras.layers import Dense, Activation, Dropout, Flatten
from keras.models import model_from_json
import tensorflow as tf
from tensorflow.python.keras.backend import set_session
from tensorflow.python.keras.models import load_model
from keras.preprocessing import image
from keras.preprocessing.image import ImageDataGenerator
import sys
import numpy as np
import cv2
import base64

from datetime import datetime

faceCascade=None
modeloKeras=None
graph=None
sess=None
session=None

# Recibir la imagen
def decodificarImagen(imgStringEncoded):
    npImgEncoded = np.frombuffer(base64.b64decode(imgStringEncoded.encode('utf-8')), np.uint8)
    imgDecoded = cv2.imdecode(npImgEncoded, cv2.IMREAD_COLOR)
    
    return imgDecoded


def procesaImagen(imgOrig):
    # Pasar a escala de grises
    imgGrey=cv2.cvtColor(imgOrig,cv2.COLOR_BGR2GRAY)

    # Detectar las caras
    detectedFaces=faceCascade.detectMultiScale(imgGrey)
    # Si no se detecta ninguna cara se devuelve un valor especial
    # para luego poder mostrarle al cliente un mensaje diciendo
    # que no se han detectado caras
    if len(detectedFaces) == 0:
        return np.array( [] )
    
    facesGreyReescaledKeras=[]
    for i in range(len(detectedFaces)):
        # Indexar cada una de las caras
        (x,y,w,h)=detectedFaces[i]
        greyFace=imgGrey[y:y+h,x:x+w]
        
        # Reescalar a 48x48 las caras
        greyFaceRescaled=cv2.resize(greyFace,(48,48))
        # Normalizar la imagen a valores entre 0 y 1
        # (tal y como se entrenó)
        kerasImg=greyFaceRescaled.astype(np.float32)/255.0
        
        # Cada imagen tiene que tener una dimensión al final que sea 1
        kerasImg = np.expand_dims( kerasImg, axis = 2 )
        facesGreyReescaledKeras.append(kerasImg)
    
    # La primera dimensión del vector de caras tiene que ser igual
    # al número de caras detectadas; la siguiente línea de código
    # hace esto por nosotros
    facesGreyReescaledKeras = np.array( facesGreyReescaledKeras )

    # Estas salidas por pantalla son útiles para ver la forma que
    # tiene que tener el vector al final y comprobar que la primera
    # dimensión coincide con el número de caras detectadas
    print( facesGreyReescaledKeras.shape )
    print( "Numero de caras detectadas", len( detectedFaces ) )
    
    return facesGreyReescaledKeras

def clasificaImagen(carasParaKeras):
    global modeloKeras, graph, sess, session
    
    with session.graph.as_default():
        k.backend.set_session(session)
        # Predecir las clases de las caras
        prediccion=modeloKeras.predict_classes(carasParaKeras)
    
    print(f"La prediccion es: {prediccion}",flush=True)
    print(f"La prediccion media es: {np.mean(prediccion)}",flush=True)
    
    return float(np.mean(prediccion))

# Lógica del servidor
app = Flask(__name__) 
app.config['CORS_HEADERS'] = 'Content-Type'
cors = CORS(app, resources={r"/recibeImagen": {"origins": "*"}})

@app.route('/recibeImagen', methods = ['POST']) 
@cross_origin(origin='localhost',headers=['Content-Type','Authorization'])
def recibeImagen(): 
    imgReceived=request.get_json(force=True)

    # Recibir y decodificar la imagen
    imagenDecodificada = decodificarImagen(imgReceived['Imagen'])

    # Procesar la imagen y recibir las caras
    t0 = datetime.now()
    carasDetectadas= procesaImagen(imagenDecodificada)
    if not carasDetectadas.any():
        # Si no se ha detectado ninguna cara,
        # devolver valor especial al cliente
        respuesta=-1
    else:
        # Si se ha detectado alguna cara,
        # proceder con la clasificación
        t1 = datetime.now()
        print( "Tiempo de procesamiento de la imagen", str( (t1 - t0).seconds ) + str( (t1 - t0).microseconds/1000 ), flush = True )
        
        t0 = datetime.now()
        respuesta=clasificaImagen(carasDetectadas)
        t1 = datetime.now()
        print( "Tiempo de reconocimiento de las emociones", str( (t1 - t0).seconds ) + str( (t1 - t0).microseconds/1000 ), flush = True )
    response=jsonify({'respuesta': respuesta})
    return response

if __name__ == '__main__':
    # Cargar el modelo de reconocimiento de caras de OpenCV
    faceCascade = cv2.CascadeClassifier('./modelo/haarcascade_normal.xml')
    session = tf.Session(graph=tf.Graph())
    
    with session.graph.as_default():
        k.backend.set_session(session)
        # Cargar nuestro modelo de reconocimiento de emociones
        modeloKeras = k.models.load_model('./modelo/'+sys.argv[2])
    
    serverPort=sys.argv[1]
    app.run(debug = False,host='0.0.0.0',port=serverPort) 
