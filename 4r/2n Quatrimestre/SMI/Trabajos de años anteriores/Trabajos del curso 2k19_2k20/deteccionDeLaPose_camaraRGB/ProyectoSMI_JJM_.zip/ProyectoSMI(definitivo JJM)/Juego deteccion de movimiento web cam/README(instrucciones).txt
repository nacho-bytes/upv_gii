-------------INSTRUCCIONES----------------

Para el funcionamiento de la aplicación web doble click en el archivo index.html.

Para el correcto uso del juego, se recomienda estar a, por lo menos, 1 metro de la camara y que esta 
este captando de cintura hacia arriba,además, es muy recomendable utilizar un sistema operativo Linux,
en el html se especifican las instrucciones del juego y su funcionamiento.



¡Mucha suerte y diviertete!

-------------------------------------------