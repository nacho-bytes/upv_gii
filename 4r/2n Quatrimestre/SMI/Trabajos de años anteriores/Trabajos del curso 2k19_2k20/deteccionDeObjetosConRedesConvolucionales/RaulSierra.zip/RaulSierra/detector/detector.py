import cv2
import argparse
import numpy as np


ap = argparse.ArgumentParser(
    description='Script para cargar modelos de deteccion de objetos')

ap.add_argument('-f', '--folder', required=True,
                help="Ruta de la carpeta de un modelo")
ap.add_argument('-c', '--confidence', type=float, default=0.3,
                help='Probabilidad mínima para filtrar detecciones débiles')
ap.add_argument('-v', '--video', type=str, default='',
                help='Ruta al archivo de video. Si está vacío, se utilizará la transmisión de webcam')
args = vars(ap.parse_args())
folder=args['folder']

# Inicializar las etiquetas de clase
CLASSES = [line.strip() for line in open(folder+'/labels.txt')]
print('Clases detectables:', CLASSES)

# Generar colores aleatorios para cada etiqueta y cuadrado de clase
COLORS = np.random.uniform(0, 255, size=(len(CLASSES), 3))

# Cargar modelo de Tensorflow de la carpeta
tensorflowNet = cv2.dnn.readNetFromTensorflow(folder+'/frozen_inference_graph.pb', folder+'/graph.pbtxt')

print("Empezando el video")
print("Pulsa la tecla Q para salir")

if args['video']:
    cap = cv2.VideoCapture(args['video'])
else:
    cap = cv2.VideoCapture(0)

while cap.isOpened():
    # Capturar frame por frame
    ret, frame = cap.read()
    if not ret:
        break

    (h, w) = frame.shape[:2]

    # Preprocesar la imagen
    tensorflowNet.setInput(cv2.dnn.blobFromImage(frame, size=(300, 300), swapRB=True, crop=False))

    # Computar la inferencia de la red
    detections = tensorflowNet.forward()

    # Bucle de todos los resultados
    for i in range(detections.shape[2]):
        
        confidence = detections[0, 0, i, 2]

        #Filtrar las detecciones debiles de confianza
        if confidence > args["confidence"]:
            
            #Extraer el indice de clase y calcular la bounding box
            class_id = int(detections[0, 0, i, 1])
            box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
            (startX, startY, endX, endY) = box.astype('int')

            # Dibujar la bounding box
            cv2.rectangle(frame, (startX, startY), (endX, endY), COLORS[class_id], 2)

            # Dibujar la etiqueta de clase y la confianza en cada predicción
            label = "{}: {:.2f}%".format(CLASSES[class_id], confidence * 100)
            y = startY - 15 if startY - 15 > 15 else startY + 15
            cv2.putText(frame, label, (startX, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, COLORS[class_id], 2)

    # Mostrar la imagen
    frame = cv2.resize(frame,(int(800),int(600)))
    cv2.imshow('Frame', frame)
    key = cv2.waitKey(1) & 0xFF

    # Pulsa Q para salir
    if key == ord("q"):
        break


cap.release()
cv2.destroyAllWindows()
