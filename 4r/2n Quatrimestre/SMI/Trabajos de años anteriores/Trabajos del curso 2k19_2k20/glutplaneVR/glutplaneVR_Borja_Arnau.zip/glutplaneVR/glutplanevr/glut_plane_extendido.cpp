/***************************************************
   Autor: Nicolas Tortosa Cerezo
   Proyecto: glut_plane_extendido
   Dependencias:
      	libalut-dev
      	libalut0
      	libopenal-data
      	libopenal-dev
      	libopenal1
      	freeglut3
      	freeglut3-dev
      	c++ versión 11.

   Para compilar usar:
        g++ -o proyecto_v.06.cpp source -std=c++11 -lalut -lopenal -L/usr/X11R6/lib -lglut -lGLU -lGL -lXmu -lXt -lSM -lICE -lXext -lX11 -lXi -lXext -lX11 -lm
***************************************************/

#define PROYECTO "Glut Plane Extendido"

#include "glutplanevr.h"
#include <stdio.h>
#include <stdlib.h>
#include <GL/glut.h>
#include <math.h>
#include <string>
#include <vector>
using std::vector;
#include <AL/alut.h>
#include <chrono>
#include <random>
#ifndef WIN32
  #include <unistd.h>
#else
  #define random rand
  #define srandom srand
#endif

#ifndef M_PI
  #define M_PI 3.14159265
#endif

#ifndef M_PI_2
  #define M_PI_2 1.57079632
#endif

//Definicion de teclas
#define ESPACIO_ 32
#define ESC_ 27
#define W_ 87
#define A_ 65
#define S_ 83
#define D_ 68
#define Q_ 81
#define E_ 69
#define P_ 80
#define V_ 86
#define R_ 82
#define L_ 76
#define C_ 67
#define w_ 119
#define a_ 97
#define s_ 115
#define d_ 100
#define q_ 113
#define e_ 101
#define p_ 112
#define v_ 118
#define c_ 99
#define l_ 108
#define r_ 114

#define tasaFPS 60
#define MAX_PLANES 2
#define MAX_AMMO 6
#define VICTORIA 0
#define DERROTA 1
bool teclado[256] = { false }; //Inicializa teclado a falso

GLboolean moving = GL_FALSE;

static float height=0;
static float width=0;

static int ventana=0;

static float posX, posY, posZ;
static float viewX,viewY,viewZ;
static float anguloX,anguloY,anguloZ;
static float anguloAIX,anguloAIY,anguloAIZ;
static float giroCx,giroCy,giroCz;
static float vistaA,stats;
static int colisiones=0;
static int controles=1;

static float velCamara,camaraX,camaraY,camaraZ,camara_anguloY,camara_anguloZ;
static float tiempo_control,tiempo_control_AI,tiempo_segundos,tiempo_minutos,tiempo_horas;
static bool tecla_C,tecla_V,tecla_P,tecla_R;

static bool aiArriba,aiAbajo,aiIzquierda,aiDerecha;
static float posAIX=40,posAIY=-20,posAIZ=0;
static int decision;

static int pausa = 1;
static int camara = 0;
static int caida = 1;
static int caida_AI = 1;

static int final_partida = 0;
static bool musica_final=false;
static bool bool_final_juego=false;
static float tiempo_final_partida=-1;

std::string linea1="";
std::string linea2="";
std::string linea3="";

//VARIABLES NUEVAS MAPA
static int anchura = 200;
static int profundidad = 120;
static int altura = 100;

static int mLimiteSup=profundidad;
static int mLimiteSup2=0;
static int mLimiteInf=0;
static int mlimiteIzqDer=100;
static int sigX=0;

vector<vector<vector<int>>> objetosTerreno;

//VARIABLES FIGURAS
static GLuint arbol,conoM,conoI,tronco,palo,aro,cuerpo,brazoI,brazoD,piernaD,piernaI,cabeza;
//FIN VARIABLES FIGURAS

//VARIABLES SONIDO
#define NUM_BUFFERS 7
#define NUM_SOURCES 6

ALfloat listenerPos[]={0.0,0.0,0.0};
ALfloat listenerVel[]={0.0,0.0,0.0};
ALfloat listenerOri[]={0.0,0.0,1.0, 0.0,1.0,0.0};

ALfloat FondoIzq0Pos[]={ 0.0, 0.0, 0.0};
ALfloat FondoIzq0Vel[]={ 0.0, 0.0, 0.0};

ALfloat FondoDer1Pos[]={ 0.0, 0.0, 0.0};
ALfloat FondoDer1Vel[]={ 0.0, 0.0, 0.0};

ALfloat EfectoPos[]={ 0.0, 0.0, 0.0};
ALfloat EfectoVel[]={ 0.0, 0.0, 0.0};

ALfloat EfectoBalaPos[]={ 0.0, 0.0, 0.0};

ALfloat BalaPos[]={ 0.0, 0.0, 0.0};


ALuint	buffer[NUM_BUFFERS];
ALuint	source[NUM_SOURCES];

std::default_random_engine generator;
std::uniform_int_distribution<int> distribution(1,8);
//FIN VARIABLES SONIDO

//CAMBIAR ANGULO X Y METERLO EN LA ESTRUCTURA
static struct {
        float speed;
        GLfloat red, green, blue;
        float x, y, z, angleX, angleY, angleZ;
} planes[MAX_PLANES];

//VARIABLES MUNICION
static struct {
        float speed,x, y, z, angleX, angleY, angleZ,angulo_transformado_X,angulo_transformado_Y,angulo_transformado_Z,impacto;
} ammo[MAX_AMMO];

int impactos=0;
int municion_activa=-1;
bool recarga=false;
//FIN VARIABLES MUNICION

//Variables VR
CAMERA camera;

double offsetX = 10, offsetY = 2;

//Fin variables VR

//FIN VARIABLES

//SE ENCARGA DE DADOS UNA POSICION X,Y,Z RECORRER EL STRING DADO Y DIBUJARLO EN LA ESCENA
void RenderString(GLdouble x, GLdouble y,GLdouble z, const std::string &string){
    glColor3d(0.0, 0.0, 0.0);
    glRasterPos3d(x, y,z);
    for (int n=0; n<string.size(); ++n) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, string[n]);
    }
}
//TRANSFORMA LOS GRADOS A RADIANES
float radianes(float grados){
    return grados*(M_PI/180);
}

//--------------------------------------------------------------------------------------------------
//Se encarga de rectificar los angulos de los aviones si giran demasiado para evitar el gimbal lock,
//tambien transforma los angulos de las bolas de chicle y los aviones a radianes. Este metodo se llama en el display.
//--------------------------------------------------------------------------------------------------
void corregir_calculos(){

    if( abs(planes[0].angleX) >= 360 ) planes[0].angleX = 0;
    if( planes[0].angleY >= 25 ) planes[0].angleY = 25 ;
	   if( planes[0].angleY <= -25 ) planes[0].angleY = -25 ;
    if( planes[0].angleZ >= 40 )planes[0].angleZ = 40 ;
    if( planes[0].angleZ <= -40 )planes[0].angleZ = -40 ;

    if( planes[1].angleY >= 25 ) planes[1].angleY = 25 ;
	   if( planes[1].angleY <= -25 ) planes[1].angleY = -25 ;
    if( planes[1].angleZ >= 40 )planes[1].angleZ = 40 ;
    if( planes[1].angleZ <= -40 )planes[1].angleZ = -40 ;

    if( giroCz <= -1 ) giroCz = -1;
    if( giroCz >=  1 ) giroCz =  1;
	   if( giroCy <= -1 ) giroCy = -1;
    if( giroCy >=  1 ) giroCy =  1;

    anguloX=radianes(planes[0].angleX);
    anguloY=radianes(planes[0].angleY);
    anguloZ=radianes(planes[0].angleZ);

  	anguloAIX=radianes(planes[1].angleX);
  	anguloAIY=radianes(planes[1].angleY);
  	anguloAIZ=radianes(planes[1].angleZ);

    for(int i=0;i<MAX_AMMO;i++){
      if(ammo[i].speed>0){
        ammo[i].angulo_transformado_X=radianes(ammo[i].angleX);
        ammo[i].angulo_transformado_Y=radianes(ammo[i].angleY);
        ammo[i].angulo_transformado_Z=radianes(ammo[i].angleZ);
      }
    }
}

//--------------------------------------------------------------------------------------------------
//Es el encargado de una vez que se llega a las condiciones de derrota o victoria muestra
//10 segundos el resultado de la partida y cambia la musica segun el mismo.
//--------------------------------------------------------------------------------------------------
void final_juego(int condicion){
    if(tiempo_final_partida==-1)tiempo_final_partida=0;
    controles=0;
    stats=0;
    switch(condicion){
      case VICTORIA:
        if(tiempo_final_partida<10){
          if(!musica_final){
            musica_final=true;
            alSourceStop(source[1]);
            alSourceStop(source[0]);
            alSourcei(source[1],AL_BUFFER,buffer[4]);
            alSourcei(source[0],AL_BUFFER,buffer[4]);
            alSourcePlay (source[0]);
            alSourcePlay (source[1]);
          }

          linea1="ENHORABUENA !! HAS GANADO EN "+std::to_string(tiempo_minutos)+" MINUTOS Y "+std::to_string(tiempo_segundos)+" SEGUNDOS \n ";
          linea2="PULSA ESC SI NO QUIERES ESPERAR 10 SEG\n";


        }else{
          alSourceStop(source[1]);
          alSourceStop(source[0]);
          alutExit();
          glutDestroyWindow(ventana);
          exit(0);
        }
        break;
      case DERROTA:
        if(tiempo_final_partida<10){
          if(!musica_final){
            alSourceStop(source[1]);
            alSourceStop(source[0]);
            musica_final=true;
            alSourcei(source[1],AL_BUFFER,buffer[5]);
            alSourcei(source[0],AL_BUFFER,buffer[5]);
            alSourcePlay (source[0]);
            alSourcePlay (source[1]);
            alSourcePlay (source[3]);
          }

          linea1="HAS PERDIDO EN "+std::to_string(tiempo_minutos)+" MINUTOS Y "+std::to_string(tiempo_segundos)+" SEGUNDOS \n ";
          linea2="PULSA ESC SI NO QUIERES ESPERAR 10 SEG\n";

          }else{
            alSourceStop(source[1]);
            alSourceStop(source[0]);
            alutExit();
            glutDestroyWindow(ventana);
            exit(0);
          }
        break;
    }
}

//------------------------------------------------------------------------------------------------------
//Funcion que se encarga de rellenar las estructuras de los aviones antes de empezar el primer dibujado.
//------------------------------------------------------------------------------------------------------
void add_plane(void) {
    int i;

    for (i = 0; i < MAX_PLANES; i++){
        if (planes[i].speed == 0) {

			if(i==0){
				planes[i].red = 1.0;
				planes[i].green = 1.0;
				planes[i].blue = 0.26;

				planes[i].x = 0;
				planes[i].y = -20;
				planes[i].z = 0;

        planes[i].speed = 8;
			}else{
				planes[i].red = 1.0;
				planes[i].green = 0.0;
				planes[i].blue = 0.0;

				planes[i].x = 20;
				planes[i].y = -20;
				planes[i].z = 0;

        planes[i].speed = 8;
			}

			planes[i].angleX = 0;
			planes[i].angleY = 0;
			planes[i].angleZ = 0;

		}
	}
}

//------------------------------------------------------------------------------------------------------
//Se le llama cuando se dibuja el avion del personaje y sirve para dibujar encima del mismo un pasajero.
//Para dibujarlo se utiliza el metodo expuesto en la memoria de las listas de dibujado.
//-----------------------------------------------------------------------------------------------------
void dibujar_pasajero(){

    cuerpo=glGenLists(1);
    glNewList(cuerpo,GL_COMPILE);
      glPushAttrib(GL_CURRENT_BIT);
        glPushMatrix();
          glColor3f(0.0,0.0,0.0);
          glScalef(1.25, 3, 1.25);
          glutSolidCube(0.25);
        glPopMatrix();
      glPopAttrib();
    glEndList();

    brazoI=glGenLists(1);
    glNewList(brazoI,GL_COMPILE);
      glPushAttrib(GL_CURRENT_BIT);
        glPushMatrix();
              glPushMatrix();
                glCallList(cuerpo);
              glPopMatrix();
          glColor3f(0.0,0.0,0.0);
          glRotatef(45,1,0,0);
          glTranslatef(0,0.25,+0.20);
          glScalef(1, 0.75, 3);
          glutSolidCube(0.25);
        glPopMatrix();
      glPopAttrib();
    glEndList();

    brazoD=glGenLists(1);
    glNewList(brazoD,GL_COMPILE);
      glPushAttrib(GL_CURRENT_BIT);
        glPushMatrix();

          glPushMatrix();
            glCallList(brazoI);
          glPopMatrix();

          glColor3f(0.0,0.0,0.0);
          glRotatef(-45,1,0,0);
          glTranslatef(0,0.25,-0.20);
          glScalef(1, 0.75, 3);
          glutSolidCube(0.25);
        glPopMatrix();
      glPopAttrib();
    glEndList();

    piernaD=glGenLists(1);
    glNewList(piernaD,GL_COMPILE);
      glPushAttrib(GL_CURRENT_BIT);
        glPushMatrix();

          glPushMatrix();
            glCallList(brazoD);
          glPopMatrix();


            glColor3f(0.0,0.0,0.0);
            glRotatef(45,0,1,0);
            glTranslatef(0.25,-0.3,0);
            glScalef(3, 1, 1);
            glutSolidCube(0.25);
        glPopMatrix();
      glPopAttrib();
    glEndList();

    piernaI=glGenLists(1);
    glNewList(piernaI,GL_COMPILE);
      glPushAttrib(GL_CURRENT_BIT);
        glPushMatrix();

          glPushMatrix();
            glCallList(piernaD);
          glPopMatrix();

          glColor3f(0.0,0.0,0.0);
          glRotatef(-45,0,1,0);
          glTranslatef(0.25,-0.3,0);
          glScalef(3, 1, 1);
          glutSolidCube(0.25);
        glPopMatrix();
      glPopAttrib();
    glEndList();

    cabeza=glGenLists(1);
    glNewList(cabeza,GL_COMPILE);
      glPushAttrib(GL_CURRENT_BIT);
        glPushMatrix();

          glPushMatrix();
            glCallList(piernaI);
          glPopMatrix();

          glColor3f(0.0,0.0,0.0);
          glTranslatef(0,0.65,0);
          glutSolidSphere(0.35,8,8);
        glPopMatrix();
      glPopAttrib();
    glEndList();

    glPushMatrix();
      glCallList(cabeza);
    glPopMatrix();
}

//------------------------------------------------------------------------------------------------------
//Dibuja los aviones en cada display. Cabe fijarse que aunque los dos se crean con primitas de TRIANGLE_STRIP,
//tienen distintos modelos y colores.
//------------------------------------------------------------------------------------------------------
void dibujar_avion(void){

  GLfloat red, green, blue;
  int i;

  for (i = 0; i < MAX_PLANES; i++)
          if (planes[i].speed != 0.0) {
				if(i==0){
					glPushMatrix();
            glTranslatef(planes[i].x, planes[i].y, planes[i].z);
            glRotatef(planes[i].angleX, 1.0, 0.0, 0.0);
            glRotatef(planes[i].angleZ, 0.0, 0.0, 1.0);
            glRotatef(planes[i].angleY, 0.0, 1.0, 0.0);
            //!Avion 2 (Sin Pasajero)
            glTranslatef(0,0,-3.5);

            glBegin(GL_TRIANGLE_STRIP);
              /* left wing */
              glColor3f(red = planes[i].red, green = planes[i].green,blue = planes[i].blue);
              glVertex3f(2.5, 0.0, 0.0);                          //0
              glVertex3f(0.0, 0.0, 1.5);                          //1
              glVertex3f(11.5, 0.0, 1.5);                          //2
              glVertex3f(0.0, 0.0, 3.25);                          //3
              glVertex3f(12.0,0.0, 3.25);                          //4
              glVertex3f(0.0, -1.0, 3.5);                          //5
              glVertex3f(12.0, -1.0, 3.5);                          //6
              glVertex3f(0.0, 0.0, 3.75);                          //7
              glVertex3f(12.0, 0.0, 3.75);                          //8
              glVertex3f(0.0, 0.0, 5.5);                          //9
              glVertex3f(11.5, 0.0, 5.5);                          //10
              glVertex3f(2.5, 0.0,7);                          //11
            glEnd();
					glPopMatrix();

          glPushMatrix();
                      glTranslatef(planes[i].x, planes[i].y, planes[i].z);

                      glRotatef(planes[i].angleX, 1.0, 0.0, 0.0);
                      glRotatef(planes[i].angleZ, 0.0, 0.0, 1.0);
                      glRotatef(planes[i].angleY, 0.0, 1.0, 0.0);

                      glScalef(1.25,1.25,1.25);
                      glTranslatef(1.5,0.45,0);

                      dibujar_pasajero();

          glPopMatrix();
				}else{
					glPushMatrix();

					  glTranslatef(planes[i].x, planes[i].y, planes[i].z);
                      glRotatef(planes[i].angleX, 1.0, 0.0, 0.0);
                      glRotatef(planes[i].angleZ, 0.0, 0.0, 1.0);
                      glRotatef(planes[i].angleY, 0.0, 1.0, 0.0);

                      glBegin(GL_TRIANGLE_STRIP);
                          // left wing
                          glColor3f(red = planes[i].red, green = planes[i].green,blue = planes[i].blue);
                          glVertex3f(0.0, 0.0, 5.0);
                          glVertex3f(0.0, 0.0, 0.25);
                          glVertex3f(7.0, 0.0, 0.25);
                          // left side
                          glVertex3f(0.0, -1, 0.0);
                          glVertex3f(7.0, -1, 0.0);
                          // right side
                          glVertex3f(0.0, 0.0, -0.25);
                          glVertex3f(7.0, 0.0, -0.25);
                          // final tip of right wing
                          glVertex3f(0.0, 0.0, -5.0);
                      glEnd();

                glPopMatrix();
				}
          }
}

//FUNCIONES MUNICION
//--------------------------------------------------------------------------------------------------
///Funcion que se encarga de rellenar las estructuras de las bolas de chicle antes de empezar el primer dibujado.
//--------------------------------------------------------------------------------------------------
void inicializar_municion(void) {
    int i;

    for (i = 0; i < MAX_AMMO; i++){
        if (ammo[i].speed == 0) {

      		ammo[i].x = planes[0].x;
      		ammo[i].y = planes[0].y;
      		ammo[i].z = planes[0].z-i;

          ammo[i].speed = 0;

      		ammo[i].angleX = planes[0].angleX;
      		ammo[i].angleY = planes[0].angleY;
      		ammo[i].angleZ = planes[0].angleZ;

		}
	}
}

//------------------------------------------------------------------------------------------------------
//Dibuja las bolas de chicle en cada display.
//------------------------------------------------------------------------------------------------------
void dibujar_municion(void){

  for (int i = 0; i < MAX_AMMO; i++){
      glPushMatrix();
          glColor3f(1,0.34,1);
          glTranslatef(ammo[i].x+3, ammo[i].y-2, ammo[i].z-i);
          //ORDEN IMPORTANTE PARA QUE LA CABEZA NO EXPLOTE
          glRotatef(ammo[i].angleX, 1.0, 0.0, 0.0);
          glRotatef(0, 0.0, 0.0, 1.0);
          glRotatef(-ammo[i].angleY, 0.0, 1.0, 0.0);

          glTranslatef(-3,0.5,0);
          glutSolidSphere(0.5,8,8);
      glPopMatrix();
    }
}
//FIN FUNCIONES MUNICION

//METODOS AI ENEMIGA
//5 ESTADOS --> ARRIBA,ABAJO,IZQUIERDA,DERECHA,CAIDA
//------------------------------------------------------------------------------------------------------
//Metodo que simula la tecla w para la AI enemiga.
//------------------------------------------------------------------------------------------------------
void arribaAI(){
  	planes[1].angleZ += 1;
	planes[1].angleY -= 0;
}

//------------------------------------------------------------------------------------------------------
//Metodo que simula la tecla s para la AI enemiga.
//------------------------------------------------------------------------------------------------------
void abajoAI(){
  	planes[1].angleZ -= 1;
	planes[1].angleY = 0;
}

//-----------------------------------------------------------------------------------------------------
//Metodo que simula la tecla a para la AI enemiga.
//------------------------------------------------------------------------------------------------------
void izquierdaAI(){
	planes[1].angleY -= 1;
	planes[1].angleZ = 0;
}

//------------------------------------------------------------------------------------------------------
//Metodo que simula la tecla d para la AI enemiga.
//------------------------------------------------------------------------------------------------------
void derechaAI(){
	planes[1].angleY += 1;
	planes[1].angleZ = 0;
}

//------------------------------------------------------------------------------------------------------
//Metodo que simula la caida para la AI enemiga.
//------------------------------------------------------------------------------------------------------
void caidaAI(){
      planes[1].angleZ=-90;
      planes[1].angleX=0;
      planes[1].angleY=0;

      planes[1].speed-=(anguloAIZ+(((anguloAIZ+1)/(anguloAIZ+1))*0.05))/(tasaFPS/16);
}

//------------------------------------------------------------------------------------------------------
//Genera un numero aleatorio cada segundo, que se usara para decidir el estado, si no esta cayendo
//------------------------------------------------------------------------------------------------------
void decidir_estado(){
	if(caida_AI==1){
			tiempo_control_AI=0;
      decision = distribution(generator);
	}
}

//------------------------------------------------------------------------------------------------------
//Recibe el numero generado por el metodo anterior y mirando la posicion actual decide si hacerle caso o
//reaccionar a alguna situacion especial del avion, si no esta cayendo. Este metodo se llama en el display.
//------------------------------------------------------------------------------------------------------
void control_estado(int d){

  if(caida_AI==1){
      if(planes[1].y>20) {
        decision=2;
      }

      if(planes[1].y<-40) {
        decision=1;
    	}

    	if(planes[1].z<-50){
        decision=3;
    	}

    	if(planes[1].z>50){
        decision=4;
    	}

    	switch(decision){
    		case 1:
    			arribaAI();
    			break;
    		case 2:
    			abajoAI();
    			break;
    		case 3:
    			izquierdaAI();
    			break;
    		case 4:
    			derechaAI();
    			break;
    		case 0:
    		case 5:
    		case 6:
    		case 7:
    		case 8:
    			break;

    	}
    }else caidaAI();
}

//------------------------------------------------------------------------------------------------------
//Funcion de actualizacion de la posicion y la velocidad del avion enemigo. Se le llama en la funcion de
//update y se le tiene que pasar como parametro el tiempo desde el ultimo frame.
//------------------------------------------------------------------------------------------------------
void actualizar_estado_AI(float tiempo){
  if(planes[1].y>-49){
    	planes[1].x += ((planes[1].speed*6)*tiempo*pausa)*caida_AI;
    	planes[1].y += ((anguloAIZ)*planes[1].speed)*tiempo*pausa;
    	planes[1].z -= ((planes[1].speed*(anguloAIY))*tiempo*pausa)*caida_AI;

    	if(pausa==1 && planes[1].y>0){
    	    if(caida_AI==1){
    		      if(impactos>2)caida_AI=0;
    	    }
    	}
  }else{
      pausa=0;
      planes[1].y=-49;
      final_juego(VICTORIA);
  }

  EfectoBalaPos[0]=planes[1].x;
  EfectoBalaPos[1]=planes[1].y;
  EfectoBalaPos[2]=planes[1].z;

  alSourcefv(source[4],AL_POSITION,EfectoBalaPos);
}
//FIN AI ENEMIGA

//------------------------------------------------------------------------------------------------------
//Funcion de actualizacion de la posicion, la velocidad y el sonido del avion del jugador. Se le llama en la funcion de
//update y se le tiene que pasar como parametro el tiempo desde el ultimo frame.
//------------------------------------------------------------------------------------------------------
void actualizar_estado_jugador(float tiempo){

        planes[0].x += ((camera.vd.x - posX) * (planes[0].speed / 10) * tiempo * pausa) * caida;
        planes[0].y += ( camera.vd.y - posY + 1.5 + vistaA) * (planes[0].speed * 3) * tiempo * pausa;
        planes[0].z += ((camera.vd.z - posZ) * (planes[0].speed * 6) * tiempo * pausa) * caida;

	/*
	planes[0].x += ((camera.vd.x - posX) * (planes[0].speed/3) * tiempo * pausa) * caida;
        planes[0].y += ( camera.vd.y - posY + 1.5 + vistaA) * (planes[0].speed * 3) * tiempo * pausa;
        planes[0].z += ((camera.vd.z - posZ) * (planes[0].speed * 6) * tiempo * pausa) * caida;
	*/

        if(planes[0].y<-48){
            pausa=0;
            planes[0].y=-49;
            final_juego(DERROTA);
        }

      	if(pausa==1){
      	    if(caida==1){

          	  if(planes[0].speed>0){
          		  if(anguloZ<0) planes[0].speed-=(anguloZ+(((anguloZ+1)/(anguloZ+1))*0.05))/tasaFPS;
          		  else planes[0].speed-=((anguloZ+(((anguloZ+1)/(anguloZ+1))*0.05))/tasaFPS)*3;
      	      }else caida=0;

      	    }else{
          		planes[0].angleZ=-100;
          		planes[0].angleX=0;
          		planes[0].angleY=0;

          		planes[0].speed-=(anguloZ+(((anguloZ+1)/(anguloZ+1))*0.05))/(tasaFPS/16);
      	    }
      	}

        if(planes[0].speed>26){
          planes[0].speed=26;
        }

        FondoIzq0Pos[0]=planes[0].x;
        FondoIzq0Pos[1]=planes[0].y;
        FondoIzq0Pos[2]=planes[0].z-50;

        listenerPos[0]=planes[0].x;
        listenerPos[1]=planes[0].y;
        listenerPos[2]=planes[0].z;

        FondoDer1Pos[0]=planes[0].x;
        FondoDer1Pos[1]=planes[0].y;
        FondoDer1Pos[2]=planes[0].z+50;

        alListenerfv(AL_POSITION,listenerPos);
        alSourcefv(source[1],AL_POSITION,FondoDer1Pos);
        alSourcefv(source[0],AL_POSITION,FondoIzq0Pos);


}

//------------------------------------------------------------------------------------------------------
//Funcion de actualizacion de la posicion y la velocidad del avion enemigo. Se le llama en la funcion de
//update y se le tiene que pasar como parametro el tiempo desde el ultimo frame. Tienen distintos comportamientos segun su velocidad.
//------------------------------------------------------------------------------------------------------
void actualizar_estado_municion(float tiempo){
    for (int i = 0; i < MAX_AMMO; i++){
      if(ammo[i].speed==0){
          //ESPERANDO A SER LANZADA
          ammo[i].x=planes[0].x+1;
          ammo[i].y=planes[0].y-0.1;
          ammo[i].z=(planes[0].z+2.5)-i*0.05;

          ammo[i].angleX=planes[0].angleX;
          ammo[i].angleY=planes[0].angleY;
          ammo[i].angleZ=planes[0].angleZ;

      }else if(ammo[i].speed>0){
        //VOLANDO
        ammo[i].x += ((ammo[i].speed*7)*tiempo*pausa)*caida;
        ammo[i].y += ((ammo[i].angulo_transformado_Z)*ammo[i].speed*10)*tiempo*pausa;
        ammo[i].z -= (((ammo[i].speed*10)*(ammo[i].angulo_transformado_Y))*tiempo*pausa)*caida;

        if(ammo[i].x>(planes[0].x+80)) {
          //bala falla y se queda en el suelo
          ammo[i].y = -48;
          ammo[i].speed=-2;
        }

      }else if(ammo[i].speed==-1){
        //PEGADA AL AVION ENEMIGO
        ammo[i].x=planes[1].x+1;
        ammo[i].y=planes[1].y-0.1;
        ammo[i].z=(planes[1].z+2.5)-i*0.05;

        ammo[i].angleX=planes[1].angleX;
        ammo[i].angleY=planes[1].angleY;
        ammo[i].angleZ=planes[1].angleZ;
      }
    }
}

//------------------------------------------------------------------------------------------------------
//Funcion de actualizacion de la posicion y la orientacion de la camara. Se le llama en la funcion de
//update y se le tiene que pasar como parametro el tiempo desde el ultimo frame.
//------------------------------------------------------------------------------------------------------
void actualizar_camara(){

	
      	//viewX
	camera.vd.x = (planes[0].x);
        //viewY
	camera.vd.y = (planes[0].y + anguloZ);
        //viewZ
	camera.vd.z = (planes[0].z - anguloY);

      	posX = (planes[0].x - 20		  ) + camera.vp.x * camara;
        posY = (planes[0].y + 1.5 + vistaA) + camera.vp.y * camara;
        posZ =  planes[0].z		    + camera.vp.z *	camara;

      	camera.vp.x += (camera.vd.x - posX);
      	camera.vp.y += (camera.vd.y - posY);
      	camera.vp.z += (camera.vd.z - posZ);

      	/*
	Pieza de código original
	viewX = (planes[0].x);
        viewY = (planes[0].y+anguloZ);
        viewZ = (planes[0].z-anguloY);

      	posX = (planes[0].x-6)+camaraX*camara;
        posY = (planes[0].y+1.5+vistaA)+camaraY*camara;
        posZ = planes[0].z+camaraZ*camara;

      	camaraX+=(viewX-posX);
      	camaraY+=(viewY-posY);
      	camaraZ+=(viewZ-posZ);
	*/
}

//------------------------------------------------------------------------------------------------------
//Utiliza la funcion RenderString descrita anteriormente para mostrar el texto que se requiera por
//pantalla. Ya sea los controles o las estadisticas si los pide el usuario, la informacion de las
//colisiones o el resultado del juego. Llamada en el display.
//------------------------------------------------------------------------------------------------------
void mostrar_texto_pantalla(){

  if(posY<-40){
    RenderString(posX+2,posY+1,posZ-3,linea1);
    RenderString(posX+2,posY+0.9,posZ-3,linea2);
    RenderString(posX+2,posY+0.8,posZ-3,linea3);
  }else{
    RenderString(posX+2,posY+1.9,posZ-3,linea1);
    RenderString(posX+2,posY+1.8,posZ-3,linea2);
    RenderString(posX+2,posY+1.7,posZ-3,linea3);
  }

  if(stats){
    std::string stats1="AVION 1 POS X: " + std::to_string(planes[0].x)+ " , Y: "+ std::to_string(planes[0].y)+" , Z: "+ std::to_string(planes[0].z)+"VELOCIDAD: "+std::to_string(planes[0].speed)+"\n ";
  	std::string stats2="AVION 2 POS X: " + std::to_string(planes[1].x)+ " , Y: "+ std::to_string(planes[1].y)+" , Z: "+ std::to_string(planes[1].z)+"\n ";
  	std::string stats3="VELOCIDAD 2  :" + std::to_string(planes[1].speed)+" DECISION: "+std::to_string(decision)+"\n";

  	RenderString(posX+2,posY+1,posZ-3,stats1);
  	RenderString(posX+2,posY+0.9,posZ-3,stats2);
  	RenderString(posX+2,posY+0.8,posZ-3,stats3);

    float alturaText=0.6;
    for(int i=0;i<MAX_AMMO;i++){
      if(ammo[i].speed>0){
      	std::string stats5="AMMO "+std::to_string(i)+" X :" + std::to_string(ammo[i].x)+"| AMMO "+std::to_string(i)+" Y :" + std::to_string(ammo[i].y)+"| AMMO "+std::to_string(i)+" Z :" + std::to_string(ammo[i].z)+"\n";
      	std::string stats6="VELOCIDAD AMMO  :" + std::to_string(ammo[i].speed)+"\n";
      	std::string stats7="----------------------------------------------------------------------------------\n";

        RenderString(posX+2,posY+alturaText,posZ-3,stats5);
        alturaText-=0.1;
      	RenderString(posX+2,posY+alturaText,posZ-3,stats6);
        alturaText-=0.1;
      	RenderString(posX+2,posY+alturaText,posZ-3,stats7);
        alturaText-=0.1;
      }
    }
  }
  if(controles ){
    std::string controles1="CONTROLES:\n ";
    std::string controles2="LA NAVE SE MUEVE EN 3 EJES --> EL EJE X CON 'A' Y 'D', EL EJE Y CON 'W' Y 'S' Y EL EJE Z CON 'Q' y 'E'\n ";
    std::string controles3="PARA DISPARAR BOLAS PULSA 'ESPACIO', PARA PAUSAR EL JUEGO PULSA 'P',  \n";
    std::string controles4="PARA VER EL AVION DESDE ARRIBA PULSA 'V', PARA MOSTRAR/OCULTAR ESTADISTICAS PULSA 'R', \n";
    std::string controles5="PARA MOSTRAR/OCULTAR CONTROLES PULSA 'C', PARA SALIR DEL JUEGO PULSA 'ESC'.\n";

    RenderString(posX+2,posY+1.5,posZ-3,controles1);
    RenderString(posX+2,posY+1.4,posZ-3,controles2);
    RenderString(posX+2,posY+1.3,posZ-3,controles3);
    RenderString(posX+2,posY+1.2,posZ-3,controles4);
    RenderString(posX+2,posY+1.1,posZ-3,controles5);
  }
};

//FUNCIONES ESCENARIO//--------------------------------------------------------------------------------------------------
//Se encarga de inicializar la matriz de colisiones a 0 cuando inicia el programa.
//--------------------------------------------------------------------------------------------------
void inicializar_suelo(){
  objetosTerreno.resize(profundidad);
  for (int i = 0; i < profundidad; i++){
    objetosTerreno[i].resize(anchura);
	  for (int j = 0; j < anchura; j++){
		 objetosTerreno[i][j].resize(altura);
		 for(int k = 0; k < altura; k++){
			objetosTerreno[i][j][k]=0;
		 }
    }
  }
}

//--------------------------------------------------------------------------------------------------
//Es llamado en cada display y dibujado de fondo, que es un cilindro formado por quads.
//--------------------------------------------------------------------------------------------------
void dibujarCilindro(float radio, int segmentos){

 for(float i=0;i<=2*M_PI;i=i+(2*M_PI/segmentos)){
	  float j = i+(2*M_PI/segmentos);
	  glPushMatrix();
	  glTranslatef(40,0,0);
      glPolygonMode(GL_FRONT,GL_POLYGON);
      glBegin(GL_QUADS);
        glColor3f(0,0.8,1);
        glVertex3f(posX+sin(i)*radio,-55,posZ+cos(i)*radio);
        glVertex3f(posX+sin(i)*radio,250,posZ+cos(i)*radio);
        glVertex3f(posX+sin(j)*radio,250,posZ+cos(j)*radio);
        glVertex3f(posX+sin(j)*radio,-55,posZ+cos(j)*radio);
      glEnd();
	  glPopMatrix();
 }
}

//------------------------------------------------------------------------------------------------------
//Dibuja el aro usando listas de dibujo. Se le llama cada display.
//------------------------------------------------------------------------------------------------------
void dibujar_aro(float posicionX,float posicionZ){

  palo=glGenLists(1);
  glNewList(palo,GL_COMPILE);
    glPushAttrib(GL_CURRENT_BIT);
      glPushMatrix();
        glColor3f(1.0,1.0,1.0);
        glScalef(0.9, 17, 1);
        glutSolidCube(2);
      glPopMatrix();
    glPopAttrib();
  glEndList();

  aro=glGenLists(1);
  glNewList(aro,GL_COMPILE);
    glPushAttrib(GL_CURRENT_BIT);
      glPushMatrix();

        glPushMatrix();
          glCallList(palo);
        glPopMatrix();

        glColor3f(1,0.8,0.0);
        glRotatef(90,0,1,0);
        glTranslatef(0,25,0);
        glutSolidTorus(1,8,8,8);


      glPopMatrix();
    glPopAttrib();
  glEndList();


  glPushMatrix();
    glTranslatef(posicionX,-50+4,posicionZ);
    glCallList(aro);
  glPopMatrix();
}

//------------------------------------------------------------------------------------------------------
//Dibuja el arbol usando listas de dibujo. Se le llama cada display.
//------------------------------------------------------------------------------------------------------
void dibujar_arbol(float posicionX,float posicionZ,float altura){

  tronco=glGenLists(1);
  glNewList(tronco,GL_COMPILE);
    glPushAttrib(GL_CURRENT_BIT);
      glPushMatrix();
        glColor3f(0.6,0.35,0.1);
        glScalef(0.8, 4, 1);
        glutSolidCube(2);
      glPopMatrix();
    glPopAttrib();
  glEndList();

  conoI=glGenLists(1);
  glNewList(conoI,GL_COMPILE);
    glPushAttrib(GL_CURRENT_BIT);
      glPushMatrix();

        glPushMatrix();
          glCallList(tronco);
        glPopMatrix();

        glColor3f(0.0,0.38,0.0);
        glRotatef(-90,1,0,0);
        glTranslatef(0,0,5);
        glScalef(1, 1, 1);
        glutSolidCone(2,4,4,1);
      glPopMatrix();
    glPopAttrib();
  glEndList();

  conoM=glGenLists(1);
  glNewList(conoM,GL_COMPILE);
    glPushAttrib(GL_CURRENT_BIT);
      glPushMatrix();

        glPushMatrix();
          glCallList(conoI);
        glPopMatrix();

        glColor3f(0.0,0.38,0.0);
        glRotatef(-90,1,0,0);
        glTranslatef(0,0,2.75);
        glScalef(1, 1, 1);
        glutSolidCone(3,4,4,1);
      glPopMatrix();
    glPopAttrib();
  glEndList();

  arbol=glGenLists(1);
  glNewList(arbol,GL_COMPILE);
    glPushAttrib(GL_CURRENT_BIT);
      glPushMatrix();

        glPushMatrix();
          glCallList(conoM);
        glPopMatrix();

        glColor3f(0.0,0.38,0.0);
        glRotatef(-90,1,0,0);
        glTranslatef(0,0,0.5);
        glScalef(1, 1, 1);
        glutSolidCone(4,4,4,1);
      glPopMatrix();
    glPopAttrib();
  glEndList();

  glPushMatrix();
    glTranslatef(posicionX,-50+4,posicionZ);
	  glScalef(1,altura,1);
    glCallList(arbol);
  glPopMatrix();

}

//------------------------------------------------------------------------------------------------------
//Se encarga de llamar a dibujar arbol o aro segun si el parametro de tipoObjeto es 1 o superior a 2.
// El parametro posicionY no tiene efecto en los aros pero para dibujar arboles sirve para multiplicar
// su altura, esto es 15* posicionY. Esta funcion tambien se encarga de insertar los objetos en el mapa
// de colisiones.
//------------------------------------------------------------------------------------------------------
void dibujar_objeto(int posicionX,int posicionZ,int posicionY,int tipoObjeto){

	if(tipoObjeto==2)posicionY=50;

    switch(tipoObjeto){
      case 1:
    		dibujar_arbol(mLimiteSup+posicionX,posicionZ,posicionY);
    		dibujar_arbol(mLimiteInf+posicionX,posicionZ,posicionY);
    		break;
      default:
    		dibujar_aro(mLimiteSup+posicionX,posicionZ);
    		dibujar_aro(mLimiteInf+posicionX,posicionZ);
    		break;
	   }

      if(tipoObjeto==1){
      	for(int i=posicionY*14;i>0;i--){
      	    if(objetosTerreno[posicionX][posicionZ+((int)(anchura/2))][i]==tipoObjeto){
      		break;
      	    }

            objetosTerreno[posicionX][posicionZ+((int)(anchura/2))][i]=tipoObjeto;
          	objetosTerreno[posicionX-3][posicionZ+((int)(anchura/2))][i]=tipoObjeto;
          	objetosTerreno[posicionX+3][posicionZ+((int)(anchura/2))][i]=tipoObjeto;
          	objetosTerreno[posicionX][3+posicionZ+((int)(anchura/2))][i]=tipoObjeto;
          	objetosTerreno[posicionX][-3+posicionZ+((int)(anchura/2))][i]=tipoObjeto;
            }

    }else{
        int j=0;
        int borde=0;


        for(int i=posicionY*37;i>0;i--){
        	if(i>20){
            borde=0;
            for(int k=0;k<j;k++){
            		objetosTerreno[posicionX][k+posicionZ+((int)(anchura/2))][i]=tipoObjeto;
            		objetosTerreno[posicionX][-k+posicionZ+((int)(anchura/2))][i]=tipoObjeto;
                borde++;
            }

            for(int p=borde;p<=borde+2;p++){

                objetosTerreno[posicionX][p+posicionZ+((int)(anchura/2))][i]=2;
                objetosTerreno[posicionX][-p+posicionZ+((int)(anchura/2))][i]=2;

                objetosTerreno[posicionX-3][p+posicionZ+((int)(anchura/2))][i]=2;
                objetosTerreno[posicionX+3][-p+posicionZ+((int)(anchura/2))][i]=2;

                objetosTerreno[posicionX-2][p+posicionZ+((int)(anchura/2))][i]=2;
                objetosTerreno[posicionX+2][-p+posicionZ+((int)(anchura/2))][i]=2;
            }
            if(i>29){
              j++;
            }else{
              j--;
            }

        	}else{
        		objetosTerreno[posicionX][posicionZ+((int)(anchura/2))][i]=2;
        		objetosTerreno[posicionX-3][posicionZ+((int)(anchura/2))][i]=2;
        		objetosTerreno[posicionX+3][posicionZ+((int)(anchura/2))][i]=2;
        		objetosTerreno[posicionX][1+posicionZ+((int)(anchura/2))][i]=2;
        		objetosTerreno[posicionX][-1+posicionZ+((int)(anchura/2))][i]=2;

        	}


      }

      objetosTerreno[posicionX][posicionZ+((int)(anchura/2))][38]=2;
      objetosTerreno[posicionX][posicionZ+((int)(anchura/2))][37]=2;
      objetosTerreno[posicionX][posicionZ+((int)(anchura/2))][36]=2;

      objetosTerreno[posicionX][1+posicionZ+((int)(anchura/2))][38]=2;
      objetosTerreno[posicionX][1+posicionZ+((int)(anchura/2))][37]=2;
      objetosTerreno[posicionX][1+posicionZ+((int)(anchura/2))][36]=2;

      objetosTerreno[posicionX][-1+posicionZ+((int)(anchura/2))][38]=2;
      objetosTerreno[posicionX][-1+posicionZ+((int)(anchura/2))][37]=2;
      objetosTerreno[posicionX][-1+posicionZ+((int)(anchura/2))][36]=2;
    }

}

//------------------------------------------------------------------------------------------------------
//Se encarga de dibujar los objetos. Modificable para añadir mas objetos.
//------------------------------------------------------------------------------------------------------
void actualizar_objetos(){

	glPushMatrix();
		dibujar_objeto(6,0,1,1);
		dibujar_objeto(12,25,3,1);
		dibujar_objeto(30,-40,2,1);
		dibujar_objeto(12,60,2,1);
		dibujar_objeto(12,-10,3,1);
		dibujar_objeto(15,-20,1,1);
		dibujar_objeto(30,-20,1,1);
		dibujar_objeto(40,+28,2,1);
		dibujar_objeto(40,-26,4,1);
		dibujar_objeto(40,-50,2,1);
		dibujar_objeto(40,+75,3,1);
		dibujar_objeto(60,+20,1,1);
		dibujar_objeto(95,+20,2,1);
		dibujar_objeto(50,+50,1,1);
		dibujar_objeto(100,+20,1,1);
		dibujar_objeto(50,+40,1,1);
		dibujar_objeto(60,-20,1,1);
		dibujar_objeto(95,-20,2,1);
		dibujar_objeto(50,-50,1,1);
		dibujar_objeto(100,-20,1,1);
		dibujar_objeto(50,-40,1,1);
		dibujar_objeto(80,-75,1,1);
		dibujar_objeto(25,5,1,4);
	glPopMatrix();
}

//------------------------------------------------------------------------------------------------------
//Se encarga de dibujar el suelo y los objetos sobre el. Se le llama cada display.
//------------------------------------------------------------------------------------------------------
void dibujarSuelo(){

		glPushMatrix();
		  glBegin(GL_QUADS);
			glColor3f(0.0,0.57,0.0);
			glVertex3f(mLimiteSup ,-50 ,posZ-200);
			glVertex3f(mLimiteSup ,-50 ,posZ+200);
			glVertex3f(-mLimiteSup ,-50 ,posZ+200);
			glVertex3f(-mLimiteSup ,-50 ,posZ-200);
		 glEnd();
		glPopMatrix();

		mLimiteSup2=mLimiteSup+profundidad;

		glPushMatrix();
		  glBegin(GL_QUADS);
			glColor3f(0.0,0.57,0.0);
			glVertex3f(mLimiteSup2 ,-50 ,-200);
			glVertex3f(mLimiteSup2 ,-50 ,+200);
			glVertex3f(mLimiteSup ,-50 ,+200);
			glVertex3f(mLimiteSup,-50 ,-200);
		 glEnd();
		glPopMatrix();

		actualizar_objetos();

		if(posX>=mLimiteSup){
			mLimiteInf=mLimiteSup;
			mLimiteSup=mLimiteSup2;
		}

}
//FIN FUNCIONES ESCENARIO

//------------------------------------------------------------------------------------------------------
//Lee las teclas pulsadas del teclado y hacer lo que le digan los casos del switch.
//------------------------------------------------------------------------------------------------------
void actualizar_controles(){
  if(pausa==1 && caida==1){
  	if(teclado[E_] || teclado[e_]) {
		planes[0].angleY -= 1;
		posZ = planes[0].z+giroCz;
  	}
  	if(teclado[Q_] || teclado[q_]) {
		planes[0].angleY += 1;
		posZ = planes[0].z+giroCz;
  	}
	   if(teclado[W_] || teclado[w_]){
		planes[0].angleZ += 1;
  	}
	   if(teclado[S_] || teclado[s_]){
		planes[0].angleZ -= 1;
		giroCy+=0.01;
  	}
  	if(teclado[A_] || teclado[a_]) planes[0].angleX -= 1;
  	if(teclado[D_] || teclado[d_]) planes[0].angleX += 1;

  	if(teclado[ESPACIO_]) {
      if(municion_activa<MAX_AMMO-1 && !recarga){
        recarga=true;
        municion_activa+=1;
        ammo[municion_activa].speed=20;
        ammo[municion_activa].angleX=planes[0].angleX;
        ammo[municion_activa].angleY=planes[0].angleY;
        ammo[municion_activa].angleZ=planes[0].angleZ;
      }
    }
  }
    if(teclado[C_] || teclado[c_]){
      if(!tecla_C){
        tecla_C=true;
        if( controles==0){
          controles=1;
        }else{
          controles=0;
        }
      }
    }
      if(teclado[R_] || teclado[r_]){
        if(!tecla_R){
          tecla_R=true;
          if( stats==0){
            stats=1;
          }else{
            stats=0;
          }
        }
    }
  if(teclado[ESC_]) {

    alSourceStop(source[1]);
    alSourceStop(source[0]);
    alutExit();
    glutDestroyWindow(ventana);
    exit(0);
  }

	if(teclado[P_] || teclado[p_]){
		if(!tecla_P){
			tecla_P=true;
			if( pausa==0){
				pausa=1;
			}else{
				pausa=0;
			}
		}
	}

	if(teclado[V_] || teclado[v_]){
		if(!tecla_V){
			tecla_V=true;
			if( vistaA==0){
			//vista aerea
			vistaA=40;
			}else{
				//vista normal
				vistaA=0;
			}
		}
	}
}

//------------------------------------------------------------------------------------------------------
//Detecta colisiones y reaccionar ante ellas con lo que le digamos.
//------------------------------------------------------------------------------------------------------
void detectar_colisiones(){

  int x=(int)planes[0].x-mLimiteInf;
  int y=(int)planes[0].y+50;
  int z=(int)planes[0].z+(anchura/2);

  if(z<anchura-1 && y < altura-1 && x<profundidad-1 && z>1 && y>1){
    if(objetosTerreno[x][z][y] > 0 && objetosTerreno[x][z][y] < 3){
      std::string aux="";

      if(objetosTerreno[x][z][y]==1){
        aux=" ARBOL";
      }else{
        aux=" ARO";
      }
      linea3="COLISION DETECTADA CON"+aux+". VIDAS RESTANTES: "+std::to_string(8-colisiones)+"\n";
    }

    if(objetosTerreno[x][z][y] == 1 || objetosTerreno[x][z][y] == 2){
        if(colisiones>8){
          pausa=0;
          final_juego(DERROTA);

        }else{
          colisiones++;
        }
    }

    if(objetosTerreno[x][z][y] > 2){

      planes[0].speed += objetosTerreno[x][z][y]*1.25;
      alSourcePlay(source[2]);

    }
  }

  for(int i=0;i<MAX_AMMO;i++){
    if(ammo[i].speed>0){
      float difX=fabs(planes[1].x-ammo[i].x);
      float difY=fabs(planes[1].y-ammo[i].y);
      float difZ=fabs(planes[1].z-ammo[i].z);

      if(difX<7.5 && difZ<7.5 && difY<7.5){
          alSourcei(source[4],AL_GAIN,planes[0].x/planes[1].x);
          alSourcePlay(source[4]);
          impactos+=1;
          ammo[i].impacto=difZ;
          ammo[i].speed=-1;
      }
    }
  }
}

//------------------------------------------------------------------------------------------------------
//Inicializa el sonido antes de que empiece el dibujado.
//------------------------------------------------------------------------------------------------------
void init(){

    alListenerfv(AL_POSITION,listenerPos);
    alListenerfv(AL_VELOCITY,listenerVel);
    alListenerfv(AL_ORIENTATION,listenerOri);

    alGenBuffers(NUM_BUFFERS, buffer);

    buffer[0] = alutCreateBufferFromFile( "viento.wav" );//SONIDO FONDO
    buffer[1] = alutCreateBufferFromFile( "bonus.wav" );//SONIDO ARO
    buffer[2] = alutCreateBufferFromFile( "colision.wav" );//SONIDO COLISION
    buffer[3] = alutCreateBufferFromFile( "hit.wav" );//SONIDO ACIERTO DISPARO
    buffer[4] = alutCreateBufferFromFile( "victoria.wav" );//SONIDO VICTORIA
    buffer[5] = alutCreateBufferFromFile( "derrota.wav" );//SONIDO VICTORIA

    alDistanceModel(AL_LINEAR_DISTANCE);
    alGenSources(NUM_SOURCES, source);

    alSourcef(source[0],AL_PITCH,1.0f);
    alSourcef(source[0],AL_GAIN,1.0f);
    alSourcefv(source[0],AL_POSITION,FondoIzq0Pos);
    alSourcefv(source[0],AL_VELOCITY,FondoIzq0Vel);
    alSourcei(source[0],AL_BUFFER,buffer[0]);
    alSourcei(source[0],AL_LOOPING,AL_TRUE);

    alSourcef(source[1],AL_PITCH,1.0f);
    alSourcef(source[1],AL_GAIN,1.0f);
    alSourcefv(source[1],AL_POSITION,FondoDer1Pos);
    alSourcefv(source[1],AL_VELOCITY,FondoDer1Vel);
    alSourcei(source[1],AL_BUFFER,buffer[0]);
    alSourcei(source[1],AL_LOOPING,AL_TRUE);

    alSourcef(source[2],AL_PITCH,1.0f);
    alSourcef(source[2],AL_GAIN,1.0f);
    alSourcefv(source[2],AL_POSITION,EfectoPos);
    alSourcefv(source[2],AL_VELOCITY,EfectoVel);
    alSourcei(source[2],AL_BUFFER,buffer[1]);
    alSourcei(source[2],AL_LOOPING,0);

    alSourcef(source[3],AL_PITCH,1.0f);
    alSourcef(source[3],AL_GAIN,1.0f);
    alSourcefv(source[3],AL_POSITION,EfectoPos);
    alSourcefv(source[3],AL_VELOCITY,EfectoVel);
    alSourcei(source[3],AL_BUFFER,buffer[2]);
    alSourcei(source[3],AL_LOOPING,0);

    alSourcef(source[4],AL_PITCH,1.0f);
    alSourcef(source[4],AL_GAIN,1.0f);
    alSourcefv(source[4],AL_POSITION,EfectoBalaPos);
    alSourcei(source[4],AL_BUFFER,buffer[3]);
    alSourcei(source[4],AL_LOOPING,0);

    alSourcePlay(source[1]);
    alSourcePlay(source[0]);
}


void control()
{
    control_estado(decision);
    corregir_calculos();
    actualizar_controles();
    detectar_colisiones();
}


void control_1()
{
    mostrar_texto_pantalla();
    dibujar_municion();
    dibujar_avion();
    dibujarCilindro(100,32);
    dibujarSuelo();
}
//------------------------------------------------------------------------------------------------------
//Se encarga de dibujar los objetos de la escena en cada frame, posicionar la camara bien y limpiar la escena
//anterior antes de dibujar la actual. Tambien alberga llamadas a otras funciones auxiliares.
//------------------------------------------------------------------------------------------------------
void display() {

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f );
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    control();
	
    gluLookAt(posX, posY, posZ, camera.vd.x, camera.vd.y, camera.vd.z, 0, 1, 0);
    //gluLookAt(posX, posY, posZ, viewX, viewY, viewZ, 0, 1, 0);

    glPushMatrix();

    control_1();

    glPopMatrix();

    glutSwapBuffers();
}

void Normalise(XYZ *p)
{
   double length;

   length = p->x * p->x + p->y * p->y + p->z * p->z;
   if (length > 0) {
      length = sqrt(length);
      p->x /= length;
      p->y /= length;
      p->z /= length;
   } else {
      p->x = 0;
      p->y = 0;
      p->z = 0;
   }
}

void dummyDisplay()
{
	XYZ r;
   	double ratio,radians,wd2,ndfl;
   	double left,right,top,bottom;

	camera.near = camera.focallength / 10;
	ratio   = camera.screenwidth / (double)camera.screenheight;
	ratio /= 2;

	radians = DTOR * camera.aperture / 2;
	wd2     = camera.near * tan(radians);
	ndfl    = camera.near / camera.focallength;
	top     =   wd2;
	bottom  = - wd2;

	CROSSPROD(camera.vd,camera.vu,r);
	Normalise(&r);
	r.x *= camera.eyesep / 2.0;
	r.y *= camera.eyesep / 2.0;
	r.z *= camera.eyesep / 2.0;

	glDrawBuffer(GL_BACK);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//Primer ojo
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	control();
	
	left  = - ratio * wd2 - 0.5* camera.eyesep * ndfl;
	right =   ratio * wd2 - 0.5 * camera.eyesep * ndfl;
	glFrustum(left,right,bottom,top,camera.near,camera.far);
	glViewport(camera.screenwidth/2,0,camera.screenwidth/2,camera.screenheight);

	glMatrixMode(GL_MODELVIEW);
	glDrawBuffer(GL_BACK_RIGHT);

	glLoadIdentity();
	//posX, posY, posZ,
	/*
	gluLookAt(camera.vp.x + r.x,camera.vp.y + r.y,camera.vp.z + r.z,
		        camera.vp.x + r.x + camera.vd.x,
		        camera.vp.y + r.y + camera.vd.y,
		        camera.vp.z + r.z + camera.vd.z,
		        0, 1, 0);
	*/
	gluLookAt(posX + r.x, posY + r.y, posZ + r.z+2,
		        camera.vp.x + r.x + camera.vd.x,
		        camera.vp.y + r.y + camera.vd.y,
		        camera.vp.z + r.z + camera.vd.z,
		        0, 1, 0);

	control_1();

	//Segundo ojo
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	control();

	left  = - ratio * wd2 + 0.5 * camera.eyesep * ndfl;
	right =   ratio * wd2 + 0.5 * camera.eyesep * ndfl;
	glFrustum(left,right,bottom,top,camera.near,camera.far);

	glViewport(0,0, camera.screenwidth/2,camera.screenheight);

	glMatrixMode(GL_MODELVIEW);
	glDrawBuffer(GL_BACK_LEFT);

	glLoadIdentity();
	/*
	gluLookAt(camera.vp.x - r.x,camera.vp.y - r.y,camera.vp.z - r.z,
		        camera.vp.x - r.x + camera.vd.x,
		        camera.vp.y - r.y + camera.vd.y,
		        camera.vp.z - r.z + camera.vd.z,
		        0, 1, 0);
	*/

	gluLookAt(posX - r.x, posY - r.y, posZ - r.z-2,
		        camera.vp.x + r.x + camera.vd.x,
		        camera.vp.y + r.y + camera.vd.y,
		        camera.vp.z + r.z + camera.vd.z,
		        0, 1, 0);
	control_1();

	glutSwapBuffers();

}

//------------------------------------------------------------------------------------------------------
//Funcion que reacciona al redimensionado de la ventana. Redimensiona la ventana y los objetos segun el
//redimensionado aplicado.
//------------------------------------------------------------------------------------------------------
void reshape(GLint w, GLint h) {

        width=w;
        height=h;

        glEnable(GL_DEPTH_TEST);
		    glDepthFunc(GL_LESS);
        glViewport(0, 0, width, height);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();

        double angulo = 120;
        float razon = (float)width / height;

        gluPerspective(angulo, razon, 0.1, 200);
}

//------------------------------------------------------------------------------------------------------
//Es la funcion encargada de hacer que la aplicacion sea temporalmente coherente. Para ello coge tiempo
// cada segundo y despues de regular los distintos controles que tiene, como el tiempo de la pantalla final
// o el tiempo que evita que se toque 2 veces pausa en un mismo frame, llama a las funciones que actualiza
// la posicion de los objetos.
//------------------------------------------------------------------------------------------------------
void update() {

        static int antes = glutGet(GLUT_ELAPSED_TIME);
        int ahora = glutGet(GLUT_ELAPSED_TIME);
        float tiempo = (ahora - antes) / 1000.0;

    		tiempo_control+=tiempo;

    		if(tiempo_control>1){
    			tiempo_control=0;
          recarga=false;
    			tecla_C=false;
    			tecla_P=false;
    			tecla_V=false;
    			tecla_R=false;

			    tiempo_control_AI+=1;

          if(tiempo_final_partida>=0) tiempo_final_partida+=1;

			    if(tiempo_control_AI>1 && pausa==1) decidir_estado();

          if(tiempo_final_partida<0){
        			tiempo_segundos+=1;

        			if(tiempo_segundos>60){
        				tiempo_segundos=0;
        				tiempo_minutos+=1;
        			}

        			if(tiempo_minutos>60){
        				tiempo_minutos=0;
        				tiempo_horas+=1;
        			}

          }

    		}

    		actualizar_estado_AI(tiempo);
    		actualizar_estado_jugador(tiempo);
        actualizar_estado_municion(tiempo);
    		actualizar_camara();
        antes = ahora;

        glutPostRedisplay();
}

//------------------------------------------------------------------------------------------------------
//Se encarga de poner a true el valor de la tecla pulsada en el array de booleanos de teclado.
//------------------------------------------------------------------------------------------------------
void onKey (unsigned char key, int x, int y) {
        teclado[key] = true;
}

//------------------------------------------------------------------------------------------------------
//Se encarga de poner a false el valor de la tecla pulsada en el array de booleanos de teclado.
//------------------------------------------------------------------------------------------------------
void onKeyRelease (unsigned char key, int x, int y) {
        teclado[key] = false;
}

//------------------------------------------------------------------------------------------------------
//Se encarga de que cada segundo pasen exactamente los fps marcados por tasaFPS
//------------------------------------------------------------------------------------------------------
void onTimer(int tiempo){
	      glutTimerFunc(tiempo, onTimer, tiempo);
	      update();
}

void initialize_camera()
{
	XYZ up = {0.0,0.0,1.0},x = {1.0,0.0,0.0};
	//CameraHome(0);
	camera.aperture = 60;//apertura focal
	camera.focallength = 6;			//default = 6 enfoque fondo
	camera.eyesep = camera.focallength / 25;
	camera.near = camera.focallength /10;
	camera.far = camera.focallength * /*10*/ 30; //50; distancia de enfoque
	camera.vu = up;
   	Normalise(&camera.vd);
   	Normalise(&camera.vu);

	//camera.stereo       = DUALSTEREO; //Resolución
	camera.screenwidth  = 1920;//1024;
	camera.screenheight = 1080;//800;

}

//------------------------------------------------------------------------------------------------------
//Inicia glut, alut y pasa el nombre de las fuciones display, update, etc para que las reconozca glut como
//suyas.
//------------------------------------------------------------------------------------------------------
int main(int argc, char** argv){
        typedef std::chrono::high_resolution_clock myclock;
        myclock::time_point beginning = myclock::now();

        inicializar_suelo();
	initialize_camera();

        myclock::duration d = myclock::now() - beginning;
        unsigned seed = d.count();
        generator.seed(seed);

        glutInit(&argc, argv);
        glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
        glutInitWindowSize(/*1024, 800*/1920, 1080);
        ventana=glutCreateWindow(PROYECTO);

        inicializar_municion();
        add_plane();

	      alutInit(&argc, argv);
	      init();

        //glutDisplayFunc(display);
	glutDisplayFunc(dummyDisplay);
        glutReshapeFunc(reshape);

      	glutKeyboardFunc(onKey);
      	glutKeyboardUpFunc(onKeyRelease);

        glutTimerFunc(1000 / tasaFPS, onTimer, 1000 / tasaFPS);
        glEnable(GL_DEPTH_TEST);
        glutMainLoop();

        return 0;
}
