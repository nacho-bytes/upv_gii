#define NOSTEREO     0
#define ACTIVESTEREO 1
#define DUALSTEREO   2

#define DTOR 0.0174532925

#define TRUE  1
#define FALSE 0

#define CROSSPROD(p1,p2,p3) \
   p3.x = p1.y*p2.z - p1.z*p2.y; \
   p3.y = p1.z*p2.x - p1.x*p2.z; \
   p3.z = p1.x*p2.y - p1.y*p2.x

typedef struct {
	double x,y,z;
} XYZ;

typedef struct {
   XYZ vp;                /* View position           */
   XYZ vd;                /* View direction vector   */
   XYZ vu;                /* View up direction       */
   double focallength;    /* Focal Length along vd   */
   double aperture;       /* Camera aperture         */
   double eyesep;         /* Eye separation          */
   double near,far;       /* Cutting plane distances */
   //int stereo;		  /* Are we in stereo mode   */
   int screenwidth;       /* Screen dimensions       */
   int screenheight;      /*                         */
} CAMERA;

typedef struct {
	int button;
	int shift;
	int mouseh;
	int mousev;
} INTERFACESTATE;

