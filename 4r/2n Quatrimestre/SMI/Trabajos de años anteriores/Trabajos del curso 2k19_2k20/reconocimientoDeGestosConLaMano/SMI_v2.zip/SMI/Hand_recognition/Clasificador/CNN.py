#!/usr/bin/env python3

from keras import layers
from keras import models
from keras.utils import to_categorical
from keras.regularizers import l2
from keras.layers.core import Dropout
import tensorflow as tf
import sys
import os
import random
import numpy as np
import matplotlib.pyplot as plt
import cv2

train_imgs = []
train_labels = []

test_imgs = []
test_labels = []

test_lab = []

class_num = {0:'L', 1:'C', 2:'palm', 3:'fist'}
classes = {'L':0, 'C':1, 'palm': 2, 'fist':3}

def CNN_model():
    model = models.Sequential()

    # 1st layer: 32 filters, 5x5 kernel, 2x2 pooling window
    model.add(layers.Conv2D(32,(3,3), strides=(1, 1), padding='same', activation='relu', use_bias=True, kernel_regularizer=l2(0.0005), input_shape=(200, 200, 1)))
    model.add(layers.MaxPool2D((2,2)))
    model.add(Dropout(0.25))

    # 2nd layer: 64 filters, 5x5 kernel, 2x2 pooling window
    model.add(layers.Conv2D(64,(3,3), strides=(1, 1), padding='same', activation='relu', use_bias=True, kernel_regularizer=l2(0.0005)))
    model.add(layers.MaxPool2D((2,2)))
    model.add(Dropout(0.25))

    # 3nd layer: 128 filters, 5x5 kernel, 2x2 pooling window
    model.add(layers.Conv2D(128,(3,3), strides=(1, 1), padding='same', activation='relu', use_bias=True, kernel_regularizer=l2(0.0005)))
    model.add(layers.MaxPool2D((2,2)))
    model.add(Dropout(0.25))

    # 4th layer: 256 filters, 5x5 kernel, 2x2 pooling window
    #model.add(layers.Conv2D(256,(3,3), strides=(1, 1), padding='same', activation='relu', use_bias=True, kernel_regularizer=l2(0.0005)))
    #model.add(layers.MaxPool2D((2,2)))
    #model.add(Dropout(0.25))

    # 5th layer: 512 filters, 5x5 kernel, 2x2 pooling window
    #model.add(layers.Conv2D(512,(3,3), strides=(1, 1), padding='same', activation='relu', use_bias=True, kernel_regularizer=l2(0.0005)))
    #model.add(layers.MaxPool2D((2,2)))
    #model.add(Dropout(0.25))

    model.add(layers.Flatten())
    model.add(layers.Dense(4, activation='softmax'))

    model.summary()

    return model




def load_data():
    global train_imgs, train_labels, test_imgs, test_labels, test_lab, classes, class_num

    path_imgs = "./data/"

    all_labels = []
    all_imgs = []

    for fil in sorted(os.listdir(path_imgs)):
        class_name = fil.split("_")[0]
        all_labels.append(classes[class_name])
        all_labels.append(classes[class_name])
        all_labels.append(classes[class_name])

        img = cv2.imread(path_imgs+fil)
        img = cv2.resize(img,(200,200))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img = np.expand_dims(img, -1)
        img = img.astype('float32') / 255

        all_imgs.append(img)
        all_imgs.append(img)
        all_imgs.append(img)

    all_imgs = np.asarray(all_imgs)
    all_labels = np.asarray(all_labels)
    indices = np.arange(all_labels.shape[0])
    
    np.random.shuffle(indices)
    np.random.shuffle(indices)
    np.random.shuffle(indices)

    all_imgs = all_imgs[indices]
    all_labels = all_labels[indices]

    num_data = len(all_labels)

    data_training = int(0.8 * num_data)

    train_imgs = all_imgs[:data_training]
    train_labels = all_labels[:data_training]

    test_imgs = all_imgs[data_training:]
    test_labels = all_labels[data_training:]

    #test_lab = test_labels.copy()

    num_c = len(np.unique(all_labels))
    
    # one-hot encoding
    train_labels = to_categorical(train_labels, num_classes=num_c)
    test_labels = to_categorical(test_labels, num_classes=num_c)


def plot_result(history):
    print(history.history.keys())
    
   
    N = 10
    plt.style.use("ggplot")
    plt.figure()
    plt.plot(np.arange(0, N), history.history["loss"], label="train_loss")
    plt.plot(np.arange(0, N), history.history["val_loss"], label="val_loss")
    plt.plot(np.arange(0, N), history.history["accuracy"], label="train_acc") # train_acc
    plt.plot(np.arange(0, N), history.history["val_accuracy"], label="val_acc") # val_acc
    plt.title("Training Loss and Accuracy on Dataset")
    plt.xlabel("Epoch #")
    plt.ylabel("Loss/Accuracy")
    plt.legend(loc="lower left")
    plt.savefig("result.png", dpi=300)

def train(model):

    batch_size = 50
    epochs = 10

    model.compile(loss='categorical_crossentropy', optimizer='sgd', metrics=['accuracy'])

    history = model.fit(train_imgs, train_labels, batch_size=batch_size, validation_split = 0.2, shuffle=True, epochs=epochs, verbose=1)

    test_loss, test_acc = model.evaluate(test_imgs, test_labels)

    model.save("model_SMI.h5")

    
    #y_prob = model.predict(test_imgs) 
    #y_classes = y_prob.argmax(axis=-1)

    #test_output = open(path + "test_labels.txt","w")

    #test_output.write("r.c -- t.c. -- res\n")
    #test_output.write("==================\n")

    #print(y_classes.shape, len(test_lab))
    
    
    #for c in range(len(test_lab)):
    #    real_lab = int(test_lab[c])
    #    pred_lab = int(y_classes[c])
    #    dif = True if real_lab == pred_lab else False
    #    s = " " + str(real_lab) + "    " + str(pred_lab) + "    " + str(dif) + "\n"
    #    test_output.write(s)
    
    #test_output.close()

    print('Test loss:', test_loss)
    print('Test accuracy:', test_acc)

    plot_result(history)

if __name__ == '__main__':

    model = CNN_model()

    load_data()

    train(model)
