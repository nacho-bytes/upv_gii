#!/usr/bin/env python3

import tensorflow as tf
from tensorflow import keras
import sys
import os
import cv2
import numpy as np
import PIL
import subprocess
import time
#from playsound import playsound

from pynput.keyboard import Key, Controller

from screeninfo import get_monitors

monitor_res = str(get_monitors()[0]).split(" ")

mon_width = int(monitor_res[2][6:-1])
mon_height = int(monitor_res[3][7:-1])

keybd = Controller()

height = 600
width = 800
last_key = 0
top, left, right = int(0.5*height), int(0.33*width), int(0.66*width)

class_num = {0:'L', 1:'C', 2:'palm', 3:'fist'}

umbral = 100

predct = False

invertir = True

last_sign = ""

left_sign = np.array([0]*3)
right_sign = np.array([0]*3)

def threshold(x):
    global umbral
    
    umbral = x



def segmentar(hull):
    aux = []
    dis = 30
    
    aux.append(tuple(hull[0][0]))
    ymedia = aux[0][1]
    xmedia = aux[0][0]
    for i in range(1,len(hull)):
        (px,py) = tuple(hull[i][0])
        new = True
        for (x,y) in aux:
            if(abs(x-px)+abs(y-py) < dis):
                new = False
                break
        if new :
            aux.append((px,py))
            ymedia = ymedia + py
            xmedia = xmedia +px
    ymedia =int( ymedia / len(aux))
    xmedia = int(xmedia /len(aux))
    return (aux,xmedia,ymedia)
    

def recognizeR(hull):    
    (hull,xmedia,ymedia) = segmentar(hull)
    aux =[]
    minxPx = 500
    minxPy = 500
    maxxPx = 0
    maxxPy = 0
    for (x,y) in hull:
        if(y <= ymedia+40):
            aux.append((x,y))
            #xmedia += x
            #ymedia += y
            if(x < minxPx):
                minxPx = x
                minxPy = y
            if(x >maxxPx):
                maxxPx = x
                maxxPy = y
    #xmedia /= len(aux)
    #ymedia /= len(aux)
    global senyal
    aux.remove((minxPx,minxPy))
    aux.remove((maxxPx,maxxPy))
    dis = 0
    for (x,y) in aux:
        dis += abs(x-xmedia)+abs(y-ymedia)
    disL = dis +abs(xmedia-maxxPx)+abs(ymedia-maxxPy)
    disL /= len(aux)
    if(abs(xmedia-minxPx)+abs(ymedia-minxPy) > disL*1.2):
        print("l",end ="")
        senyal = (255,0,0)
    disR = dis +abs(xmedia-minxPx)+abs(ymedia-minxPy)
    disR /= len(aux)
    if(abs(xmedia-maxxPx)+abs(ymedia-maxxPy) > disR*1.5):
        print("r",end ="")
        senyal = (0,0,255)
    
    aux.append((int(xmedia),int(ymedia)))
    aux.append((minxPx,minxPy))
    aux.append((maxxPx,maxxPy))
    return aux


def filterFrame(frame):
    global width, height
    frame = cv2.resize(frame, (width,height))
    frame = cv2.flip(frame, 1)   
    
    kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
    frame = cv2.filter2D(frame, -1, kernel)
    frame = cv2.erode(frame,(3,3),7)      

    return frame

def isolate_left(frame):
    global top, height, left
    
    roiL = frame[top:height, 0:left]
    roiL = cv2.cvtColor(roiL, cv2.COLOR_BGR2GRAY)
    hand = roiL.copy()

    #_, thresh = cv2.threshold(roiL, umbral, 255, 1)  
    thresh = cv2.threshold(hand, umbral, 255, cv2.THRESH_BINARY)[1]
    if invertir: 
        thresh = cv2.bitwise_not(thresh)

    #thresh[:40] = 0
    thresh[-30:] = 0

    #kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5))
    #thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    #thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
    #thresh = cv2.GaussianBlur(thresh,(5,5),0)

    hand = cv2.bitwise_and(hand, hand, mask=thresh)   

    #contours, _ = cv2.findContours(hand.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    #cv2.drawContours(hand, contours, -1, (0, 255, 0), 3)
    
    #for c in contours:
    #    (x, y, w, h) = cv2.boundingRect(c)

    #    if cv2.contourArea(c) < 10000:
    #        hand = cv2.rectangle(hand,(x,y),(x+w,y+h),(0,0,0),-1)

    return hand  

def isolate_right(frame):
    global top, height, right, width
    
    roiR = frame[top:height, right:width]      
    roiR = cv2.cvtColor(roiR, cv2.COLOR_BGR2GRAY)
    hand = roiR.copy()

    #_, thresh = cv2.threshold(roiL, umbral, 255, 1)  
    thresh = cv2.threshold(hand, umbral, 255, cv2.THRESH_BINARY)[1]
    if invertir: 
        thresh = cv2.bitwise_not(thresh)

    thresh[-30:] = 0

    #kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5))
    #thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    #thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
    #thresh = cv2.GaussianBlur(thresh,(5,5),0)

    hand = cv2.bitwise_and(hand, hand, mask=thresh)   

    #contours, _ = cv2.findContours(hand.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    #cv2.drawContours(hand, contours, -1, (0, 255, 0), 3)
    
    #for c in contours:
    #    (x, y, w, h) = cv2.boundingRect(c)

    #    if cv2.contourArea(c) < 10000:
    #        hand = cv2.rectangle(hand,(x,y),(x+w,y+h),(0,0,0),-1)

    return hand  

def predict_gesture(hand, model):
    prediction =  cv2.resize(hand,(200,200))      
    prediction = prediction.reshape(1,200,200,1).astype('float32') / 255

    prediction = model.predict(prediction)
    predicted_label = np.argmax(prediction)

    return predicted_label

if __name__ == "__main__":
    model = keras.models.load_model('model_SMI.h5')
    #model.summary()
    cap = cv2.VideoCapture(0)  # initializes capture from webcam 
    #orb = cv2.ORB_create()

    game_path = sys.argv[1]

    if not cap.isOpened():
        print( "ERROR! Unable to open camera\n")	

    ret, frame = cap.read()
    if frame is None:
        exit(0) 
  
    cv2.namedWindow("Display Window")          
    cv2.moveWindow('Display Window', int(mon_width/3),0)
    cv2.createTrackbar('Threshold','Display Window',0,255,threshold)

    cv2.namedWindow('Debug Window Left', cv2.WINDOW_NORMAL)
    cv2.moveWindow('Debug Window Left', 0,0)

    cv2.namedWindow('Debug Window Right', cv2.WINDOW_NORMAL)   
    cv2.moveWindow('Debug Window Right', mon_width,0) 

    num_pic = 100
    num_class = ""

    num_sign = 0
   
    while(True):
        # Capture frame-by-frame
        ret, frame = cap.read()
        frame = filterFrame(frame)      

        left_hand = isolate_left(frame)
        right_hand = isolate_right(frame)

        mean_L = left_hand.mean()
        mean_R = right_hand.mean()
        

        if predct:

            key_time = time.time()

            time_passed = int(round((key_time - last_key)*1000))

            if time_passed > 5:

                predicted_left = predict_gesture(left_hand, model) 
                predicted_right = predict_gesture(cv2.flip(right_hand, 1), model)

                left_sign[num_sign] = predicted_left
                right_sign[num_sign] = predicted_right

                num_sign = (num_sign + 1) % len(left_sign) # array circular
            
                #print(predicted_left)
                l_max = np.bincount(left_sign)
                l_max = np.argmax(l_max)

                r_max = np.bincount(right_sign)
                r_max = np.argmax(r_max)

            
                # permite girar todo lo que se quiera, pero no accelerar/frenar dos veces seguidas
                if mean_L > 15: # and (class_num[l_max] == 'fist' or last_sign != r_max):
                    print(" ", class_num[l_max], " L")
                    
                    #if class_num[l_max] == 'C' and num_sign == 4:
                        #playsound('trompeta.mp4')
                    #    keybd.type(" C ")                        
                    
                    if class_num[l_max] == 'fist': # and num_sign == 4:
                        keybd.press(Key.left)
                        keybd.release(Key.left)
                        #keybd.type(" L ")
                    
                    #elif class_num[l_max] == 'L' and num_sign == 4:
                        #keybd.press("L")                        

                    if class_num[l_max] == 'palm': # and num_sign == 4:
                        keybd.press(Key.right)
                        keybd.release(Key.right)
                        #keybd.type(" R ")
                    
                    #last_sign = l_max

                # permite girar todo lo que se quiera, pero no accelerar/frenar dos veces seguidas            
                if mean_R > 15: # and (class_num[r_max] == 'fist' or last_sign != r_max):
                    print(" ", class_num[r_max], "  R")
                    #if class_num[r_max] == 'C': # and num_sign == 4:
                        #playsound('trompeta.mp4')
                    #    keybd.press(Key.enter)
                    #    keybd.release(Key.enter)
                        #keybd.type("C")
                        
                    
                    if class_num[r_max] == 'fist': # and num_sign == 4:
                        keybd.press(Key.down)
                        keybd.release(Key.down)
                        #keybd.type(" E ")
                        #pass

                    #elif class_num[r_max] == 'L' and num_sign == 4:
                        #keybd.press("L")
                    
                    if class_num[r_max] == 'palm': # and num_sign == 4:
                        keybd.press(Key.up) 
                        keybd.release(Key.up) 
                        #keybd.type(" U ")

                    #last_sign = r_max 
                
                last_key = key_time


        #cv2.rectangle(frame, (leftR, top), (rightR, bottom), (0,255,0), 2)
        #cv2.rectangle(frame, (leftL, top), (rightL, bottom), (0,255,0), 2)  
        cv2.resizeWindow('Display Window', width,height)
        cv2.imshow('Display Window', frame)      

                
        cv2.resizeWindow('Debug Window Left', left,top)        
        cv2.imshow('Debug Window Left', left_hand)
            
        cv2.resizeWindow('Debug Window Right', left, top)#mon_width,mon_height)        
        cv2.imshow('Debug Window Right', right_hand)
       
        
        key = cv2.waitKey(1)
        if key == 27:
            break

        if key == 112: # p -> predict
            predct = True

        if key == 105: # i -> invertir los colores
            invertir = not invertir

        if key == 99: # 'c'
           num_class = "C_"
           cv2.imwrite("./data/" + num_class + str(num_pic) + ".jpg", left_hand) 
           num_pic += 1 
        

        if key == 13: # lanza el juego           
            cv2.moveWindow('Debug Window Left', 0, mon_height)
            cv2.moveWindow('Debug Window Right', mon_width, mon_height)
            cv2.waitKey(1)
            subprocess.Popen(game_path)
            predct = True



    # When everything done, release the capture
    cap.release()
    cv2.destroyAllWindows()
