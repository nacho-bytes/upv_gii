﻿#include <iostream>
#include "Utilidades.h"
#include <math.h>


#define VGIRAR 40
#define VANGULAR 10.0f
#define ACCELERACION 4.0f
#define MAXVELOCIDAD 20.0f
#define GRAVEDAD 6.0f
#define LENGTHCAR 1311
#define PROYECTO "1. Flecha izquierda/derecha: giro del vehículo \n2. Flecha arriba/abajo: aumento/disminución de la velocidad \n3. S/s: Activa/desactiva un modelo simple en alámbrico de la práctica 6 sin luces ni texturas \n4. L/l:  Cambia entre modo diurno/nocturno  \n5. N/n: Cambia el estado de la niebla (on/off) \n6. C/c: Cambia la visibilidad de elementos solidarios a la cámara (on/off)"

/*


*/

using namespace std;

static float nieblaNoche[3] = { 0,0,0.2 };
static int modo = GL_FILL;
static bool niebla = false;
static bool dia = true;
static bool ui = false;
//static float girox = 0, giroy = 0;
static GLubyte objeto[1];
static int xanterior, yanterior;
static int luzCoche = GL_LIGHT0 + 10;

static float velocidadN[3], acceleracionN[3];
static float velocidad[3] = { 0,0,0 };
static float v = 0;
static int N = 0;
static float direccion[3] = { 0,0,1 };
static float acceleracion[3] = { 0,0,ACCELERACION };
static float posCamara[3] = { 0,1,0 };
static float dirCoche[3] = {-1,0,0};
static float posCoche[3] = { 0,0,0 };
static float puntoCoche[4][3] = { {-0.5,0,0},{0.5,0,0},{-0.5,0,-1},{0.5,0,-1} };
static float vectorNormalizado[3] = {0,0,0};
static float deltaTime = 0;
static int vertical = 0, horizontal = 0;
GLfloat puntoLuz[8][4];

static float rad2grad = PI / 180;
//[tramo][posExterior,posInterior][x,y,z]
GLfloat carretera[LENGTHCAR][2][3];
GLfloat fondo[8][2][3];
GLuint texFondo,texCarretera;

void init()
{
	cout <<  PROYECTO << endl;
	glClearColor(0, 0, 0.3, 1);

	//luces
	
	//glLightfv(GL_LIGHT1, GL_DIFFUSE, GRISCLARO);
	//glLightfv(GL_LIGHT1, GL_SPECULAR, BLANCO);


	//niebla
	glFogfv(GL_FOG_COLOR, AMARILLO);
	glFogf(GL_FOG_DENSITY, .2f);


	//configurar el motor de render
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_LIGHTING);
	
	//glEnable(GL_LIGHT1);

	glGenTextures(1, &texFondo);
	glBindTexture(GL_TEXTURE_2D, texFondo);
	loadImageFile((char*)"./desierto.jpg");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &texCarretera);
	glBindTexture(GL_TEXTURE_2D, texCarretera);
	loadImageFile((char*)"./carretera.jpg");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);


	//general carretera 1º tramo
	float intX = -3,extX = 3;
	float zAct;
	for (int i = 0 ;i < 250;i++)
	{
		zAct = i * -0.2;
		carretera[i][0][0] = extX;
		carretera[i][0][2] = zAct;
		carretera[i][1][0] = intX;
		carretera[i][1][2] = zAct;

	}
	//printf("%f, %f\n", carretera[249][0][0], carretera[249][0][2]);



	/*
	2º tramo
	longitud del tramo constante
	perimetro = D*pi
	r = 10
	total distancia = D/2*pi = r*pi = 
	total distancia / 0.2 = 157 tramo
	cada tramo gira 1.1459 grados
	*/
	float vectorAmplitud[2] = { 3,0 };
	float tramo[2] = { 0,-0.2f };
	float actual[2] = { 0,-50 };
	float aux[2];
	carretera[250][0][0] = extX;
	carretera[250][1][0] = intX;
	carretera[250][0][2] = -50;
	carretera[250][1][2] = -50;
	//cos y sin para -1.1459 grados
	float cosG = cos(-1.1459*rad2grad);
	float sinG = sin(-1.1459*rad2grad);
	for (int i = 0; i < 157; i++)
	{
		aux[0] = tramo[0] * cosG - tramo[1] * sinG;
		aux[1] = tramo[0] * sinG + tramo[1] * cosG;
		tramo[0] = aux[0];
		tramo[1] = aux[1];
		aux[0] = vectorAmplitud[0] * cosG - vectorAmplitud[1] * sinG;
		aux[1] = vectorAmplitud[0] * sinG + vectorAmplitud[1] * cosG;
		vectorAmplitud[0] = aux[0];
		vectorAmplitud[1] = aux[1];
		actual[0] += tramo[0];
		actual[1] += tramo[1];
		carretera[i + 251][0][0] = actual[0] + vectorAmplitud[0];
		carretera[i + 251][0][2] = actual[1] + vectorAmplitud[1];
		carretera[i + 251][1][0] = actual[0] - vectorAmplitud[0];
		carretera[i + 251][1][2] = actual[1] - vectorAmplitud[1];
	}
	//printf("%f, %f\n", carretera[250][0][0], carretera[250][0][2]);
	//printf("%f, %f\n", carretera[407][0][0], carretera[407][0][2]);
	


	/*
	3º tramo
	*/
	zAct = carretera[407][0][2];
	extX = -23;
	intX = -17;
	for (int i = 0; i < 99; i++)
	{
		zAct += 0.2f;
		carretera[i + 408][0][0] = extX;
		carretera[i + 408][0][2] = zAct;
		carretera[i + 408][1][0] = intX;
		carretera[i + 408][1][2] = zAct;
	}
	//printf("%f, %f\n", carretera[408][0][0], carretera[408][0][2]);
	//printf("%f, %f\n", carretera[506][0][0], carretera[506][0][2]);

	
	/*
	4º tramo
	40z
	cada 0.1 un tramo
	y = (2.5 * sin(z*pi/40))^3
	*/
	float preCalc = PI / 40;
	zAct = carretera[506][0][2];
	float yAct;
	for (int i = 0; i < 400; i++)
	{
		zAct += 0.1f;
		carretera[i + 507][0][0] = extX;
		carretera[i + 507][0][2] = zAct;
		carretera[i + 507][1][0] = intX;
		carretera[i + 507][1][2] = zAct;

		yAct = pow(2.5*sin((zAct + 30)*preCalc), 3);
		carretera[i + 507][0][1] = yAct;
		carretera[i + 507][1][1] = yAct;
	}
	//printf("%f, %f\n", carretera[507][0][0], carretera[507][0][2]);
	//printf("%f, %f\n", carretera[906][0][0], carretera[906][0][2]);

	


	/*
	5º tramo
	mismo que tramo 3
	*/
	zAct = carretera[906][0][2];
	for (int i = 0; i < 99; i++)
	{
		zAct += 0.2f;
		carretera[i + 907][0][0] = extX;
		carretera[i + 907][0][2] = zAct;
		carretera[i + 907][1][0] = intX;
		carretera[i + 907][1][2] = zAct;
	}
	//printf("%f, %f\n", carretera[907][0][0], carretera[907][0][2]);
	//printf("%f, %f\n", carretera[1005][0][0], carretera[1005][0][2]);


	/*
	6º tramo
	mismo que tramo 2
	*/

	vectorAmplitud[0] = -3;
	vectorAmplitud[1] = 0;
	tramo[0] = 0;
	tramo[1] = .2f;
	actual[0] = carretera[1005][0][0]+3;
	actual[1] = carretera[1005][0][2]+0.2f;
	carretera[1006][0][0] = extX;
	carretera[1006][1][0] = intX;
	carretera[1006][0][2] = actual[1];
	carretera[1006][1][2] = actual[1];

	for (int i = 0; i < 157; i++)
	{
		aux[0] = tramo[0] * cosG - tramo[1] * sinG;
		aux[1] = tramo[0] * sinG + tramo[1] * cosG;
		tramo[0] = aux[0];
		tramo[1] = aux[1];
		aux[0] = vectorAmplitud[0] * cosG - vectorAmplitud[1] * sinG;
		aux[1] = vectorAmplitud[0] * sinG + vectorAmplitud[1] * cosG;
		vectorAmplitud[0] = aux[0];
		vectorAmplitud[1] = aux[1];
		actual[0] += tramo[0];
		actual[1] += tramo[1];
		carretera[i + 1007][0][0] = actual[0] + vectorAmplitud[0];
		carretera[i + 1007][0][2] = actual[1] + vectorAmplitud[1];
		carretera[i + 1007][1][0] = actual[0] - vectorAmplitud[0];
		carretera[i + 1007][1][2] = actual[1] - vectorAmplitud[1];
	}
	//printf("%f, %f\n", carretera[1006][0][0], carretera[1006][0][2]);
	//printf("%f, %f\n", carretera[1163][0][0], carretera[1163][0][2]);


	/*
	7º tramo
	vuelve al 0 0 0
	necesita 147 tramo de 0.2
	*/
	zAct = carretera[1163][0][2];
	extX = 3;
	intX = -3;
	for (int i = 0; i < 147; i++)
	{
		zAct -= 0.2f;
		carretera[i + 1164][0][0] = extX;
		carretera[i + 1164][0][2] = zAct;
		carretera[i + 1164][1][0] = intX;
		carretera[i + 1164][1][2] = zAct;
	}
	//printf("%f, %f\n", carretera[1164][0][0], carretera[1164][0][2]);
	//printf("%f, %f\n", carretera[1310][0][0], carretera[1310][0][2]);


	//general fondo
	float angulo = 2 * PI / 8;
	for (int i = 0; i < 8; i++)
	{
		fondo[i][0][0] = 128 * cos(i * angulo);
		fondo[i][0][1] = -64;
		fondo[i][0][2] = 128 *sin(i * angulo );
		fondo[i][1][0] = 128 * cos(i * angulo );
		fondo[i][1][1] = 64;
		fondo[i][1][2] = 128 * sin(i * angulo );
	}


	//inicializar luces
	float alto = 10;
	puntoLuz[0][0] = 3;
	puntoLuz[0][1] = alto;
	puntoLuz[0][2] = 0;
	puntoLuz[1][0] = -10;
	puntoLuz[1][1] = alto;
	puntoLuz[1][2] = -63;
	puntoLuz[2][0] = -23;
	puntoLuz[2][1] = 17+alto;
	puntoLuz[2][2] = -10;
	puntoLuz[3][0] = -10;
	puntoLuz[3][1] = alto;
	puntoLuz[3][2] = 43;
	GLfloat A[] = { 0.2,0.2,0.2,1.0 };
	GLfloat D[] = { 0.4,0.4,0.4,1.0 };
	GLfloat S[] = { 0.5,0.5,0.5,1.0 };
	for (int i = 0; i < 4; i++)
	{
		puntoLuz[i][1] += 4;
		puntoLuz[i][3] = 1;
		//printf("%f  %f   %f \n", puntoLuz[i][0], puntoLuz[i][1], puntoLuz[i][2]);
		glEnable(GL_LIGHT0 + i);
		
		glLightfv(GL_LIGHT0+i, GL_AMBIENT, A);
		glLightfv(GL_LIGHT0+i, GL_DIFFUSE, D);
		glLightfv(GL_LIGHT0+i, GL_SPECULAR, S);
	}
	puntoLuz[4][3] = 1;
	glLightfv(GL_LIGHT4, GL_AMBIENT, BLANCO);
	glLightfv(GL_LIGHT4, GL_DIFFUSE, BLANCO);
	glLightfv(GL_LIGHT4, GL_SPECULAR, BLANCO);
}

void dibujarHUD()
{
	//dibuja elementos solidarios a la camara
	glPushAttrib(GL_ALL_ATTRIB_BITS);

	//cambio de camara a una ortografica
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(-1, 1, -1, 1, -1, 1);

	//Cambio la situacion de la camara
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	//dibujar un poligono que ocupe todo el viewport
	glDisable(GL_LIGHTING);

	glColor3f(1, 1, 1);
	glPushMatrix();
	glBegin(GL_LINE_LOOP);
	glVertex2f(-0.8, -0.9);
	glVertex2f(-0.8, -0.8);
	glVertex2f(-0.5, -0.8);
	glVertex2f(-0.5, -0.9);
	
	glEnd();
	glPopMatrix();
	
	glColor3f(0, 1, 0);
	glBegin(GL_QUAD_STRIP);
	glVertex2f(-0.8, -0.9);
	glVertex2f(-0.8, -0.8);
	float longitud = -0.5 + 0.8;
	longitud = v / MAXVELOCIDAD * longitud;
	glVertex2f(-0.8 + longitud, -0.9);
	glVertex2f(-0.8 + longitud, -0.8);
	
	
	glEnd();

	// volver a la camara original
	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);

	glPopAttrib();

}

void display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	
	
	//gluLookAt(-10,150,-10,-10,0,-10, 0, 0, 1);
	gluLookAt(posCamara[0], posCamara[1], posCamara[2],
		posCoche[0], posCoche[1] + 1, posCoche[2],
		0, 1, 0);

	
	


	GLfloat v0[3] = { 0,-10,10 }, v1[3] = { 20,-10,10 }, v2[3] = { 20,0,-5 }, v3[3] = { 0,0,-5 };

	if (modo == GL_FILL)
	{
		glEnable(GL_TEXTURE_2D);
	}
	else
	{
		glDisable(GL_TEXTURE_2D);
	}
	if(niebla)
	{
		glEnable(GL_FOG);
	}
	else
	{
		glDisable(GL_FOG);
	}
	if (dia)
	{
		glDisable(GL_LIGHTING);
		glFogfv(GL_FOG_COLOR, AMARILLO);
		
	}
	else
	{
		glEnable(GL_LIGHTING);
		GLfloat dir_central[] = { 0.0, -1.0, 0.0 };
		for (int i = 0; i < 4; i++)
		{
			glLightfv(GL_LIGHT0 + i, GL_POSITION, puntoLuz[i]);
			glLightfv(GL_LIGHT0 + i, GL_SPOT_DIRECTION, dir_central);
			glLightf(GL_LIGHT0 + i, GL_SPOT_CUTOFF, 50.0);
			glLightf(GL_LIGHT0 + i, GL_SPOT_EXPONENT, 5.0);
		}
		puntoLuz[4][0] = posCoche[0];
		puntoLuz[4][1] = posCoche[1];
		puntoLuz[4][2] = posCoche[2];
		glEnable(GL_LIGHT4);
		glLightfv(GL_LIGHT4, GL_POSITION, puntoLuz[4]);
		glLightfv(GL_LIGHT4, GL_SPOT_DIRECTION, acceleracionN);
		glLightf(GL_LIGHT4, GL_SPOT_CUTOFF, 30.0);
		glLightf(GL_LIGHT4, GL_SPOT_EXPONENT, 20.0);
		glFogfv(GL_FOG_COLOR, nieblaNoche);
	}
	if (ui)
	{
		dibujarHUD();
	}
	
	
	glPolygonMode(GL_FRONT_AND_BACK, modo);
	//dibuja fondo
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
	glBindTexture(GL_TEXTURE_2D, texFondo);
	

	glBegin(GL_QUAD_STRIP);
	for (int i = 0; i < 7; i++)
	{
		glTexCoord2f(i*0.125, 1);
		glVertex3f(fondo[i][1][0], fondo[i][1][1], fondo[i][1][2]);
		glTexCoord2f(i*0.125, 0);
		glVertex3f(fondo[i][0][0], fondo[i][0][1], fondo[i][0][2]);
		glTexCoord2f((i + 1)*0.125, 1);
		glVertex3f(fondo[i + 1][1][0], fondo[i + 1][1][1], fondo[i + 1][1][2]);
		glTexCoord2f((i + 1)*0.125, 0);
		glVertex3f(fondo[i + 1][0][0], fondo[i + 1][0][1], fondo[i + 1][0][2]);
		
		
		
	}
	glTexCoord2f(1, 1);
	glVertex3f(fondo[0][1][0], fondo[0][1][1], fondo[0][1][2]);
	glTexCoord2f(1, 0);
	glVertex3f(fondo[0][0][0], fondo[0][0][1], fondo[0][0][2]);
	
	
	glEnd();

	//dibuja carretera
	glBindTexture(GL_TEXTURE_2D, texCarretera);
	for (int i = 0; i < 1310; i++)
	{
		quad(carretera[i + 1][0],carretera[i + 1][1], carretera[i][1] , carretera[i][0], 5, 1);
	}
	quad(carretera[0][0], carretera[0][1], carretera[1310][1], carretera[1310][0],  5, 1);
	

	
	//dibujar cocher
	glDisable(GL_TEXTURE_2D);
	
	float infIzqDel[3] = { posCoche[0] + dirCoche[0] * 0.5, posCoche[1], posCoche[2] + dirCoche[2] * 0.5 }
	, infDerDel[3] = { posCoche[0] - dirCoche[0] * 0.5, posCoche[1], posCoche[2] - dirCoche[2] * 0.5 }
	, supIzqDel[3] = { posCoche[0] + dirCoche[0] * 0.5, posCoche[1] + 0.5, posCoche[2] + dirCoche[2] * 0.5 }
	, supDerDel[3] = { posCoche[0] - dirCoche[0] * 0.5, posCoche[1] + 0.5, posCoche[2] - dirCoche[2] * 0.5 }
	, supIzqAtr[3] = { posCoche[0] + dirCoche[0] * 0.5 - acceleracionN[0], posCoche[1] + 0.5, posCoche[2] + dirCoche[2] * 0.5 - acceleracionN[2] }
	, supDerAtr[3] = { posCoche[0] - dirCoche[0] * 0.5 - acceleracionN[0], posCoche[1] + 0.5, posCoche[2] - dirCoche[2] * 0.5 - acceleracionN[2] }
	, infIzqAtr[3] = { posCoche[0] + dirCoche[0] * 0.5 - acceleracionN[0], posCoche[1], posCoche[2] + dirCoche[2] * 0.5 - acceleracionN[2] }
	, infDerAtr[3] = { posCoche[0] - dirCoche[0] * 0.5 - acceleracionN[0], posCoche[1], posCoche[2] - dirCoche[2] * 0.5 - acceleracionN[2] };
	
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, ROJO);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, BLANCO);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 30);
	glShadeModel(GL_SMOOTH);
	glColor3f(1,0,0);
	//delante
	quad(infIzqDel, infDerDel, supDerDel, supIzqDel, 5, 5);
	//techo
	quad(supIzqDel, supDerDel, supDerAtr, supIzqAtr, 5, 5);
	//detras
	quad(supIzqAtr, supDerAtr, infDerAtr, infIzqAtr, 5, 5);
	//parte derecha
	quad(supDerAtr, supDerDel, infDerDel, infDerAtr, 5, 5);
	//parte izquierda
	quad(supIzqDel, supIzqAtr, infIzqAtr, infIzqDel, 5, 5);
	glPopAttrib();

	/*
	glBegin(GL_QUAD_STRIP);
	//inferior izq delante
	glVertex3f(posCoche[0] + dirCoche[0] * 0.5, posCoche[1], posCoche[2] + dirCoche[2] * 0.5);
	//inferior der delante
	glVertex3f(posCoche[0] - dirCoche[0] * 0.5, posCoche[1], posCoche[2] - dirCoche[2] * 0.5);
	//superio izq delante
	glVertex3f(posCoche[0] + dirCoche[0] * 0.5, posCoche[1] + 0.5, posCoche[2] + dirCoche[2] * 0.5);
	//superio der delante
	glVertex3f(posCoche[0] - dirCoche[0] * 0.5, posCoche[1] + 0.5, posCoche[2] - dirCoche[2] * 0.5);
	//superio izq atras
	glVertex3f(posCoche[0] + dirCoche[0] * 0.5 - acceleracionN[0], posCoche[1] + 0.5, posCoche[2] + dirCoche[2] * 0.5 - acceleracionN[2]);
	//superio der atras
	glVertex3f(posCoche[0] - dirCoche[0] * 0.5 - acceleracionN[0], posCoche[1] + 0.5, posCoche[2] - dirCoche[2] * 0.5 - acceleracionN[2]);
	//inferior izq atras
	glVertex3f(posCoche[0] + dirCoche[0] * 0.5 - acceleracionN[0], posCoche[1], posCoche[2] + dirCoche[2] * 0.5 - acceleracionN[2]);
	//inferior der atras
	glVertex3f(posCoche[0] - dirCoche[0] * 0.5 - acceleracionN[0], posCoche[1], posCoche[2] - dirCoche[2] * 0.5 - acceleracionN[2]);
	
	glEnd();
	*/

	/*
	//acceleracion
	glColor3f(0, 1, 0);
	glBegin(GL_LINES);
	glVertex3f(posCoche[0], posCoche[1] + 0.5, posCoche[2]);
	glVertex3f(posCoche[0] + acceleracionN[0] , posCoche[1] + acceleracionN[1] + 0.5, posCoche[2] + acceleracionN[2]);
	glEnd();

	//direccion
	glColor3f(0, 1, 0);
	glBegin(GL_LINES);
	glVertex3f(posCoche[0], posCoche[1] + 0.5, posCoche[2]);
	glVertex3f(posCoche[0] + velocidadN[0] , posCoche[1] + velocidadN[1] + 0.5, posCoche[2] + velocidadN[2]);
	glEnd();
	*/

	
	glutSwapBuffers();

}


void reshape(GLint w, GLint h)
{
	float ra = (float)w / h;

	// Fijamos el marco dentro de la ventana de dibujo
	glViewport(0, 0, w, h);

	//seleccionar la camara
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	//camara ortografica

	/*
	if (ra < 1) {
		glOrtho(-2, 2, -2 / ra, 2 / ra, -1, 10);
	}
	else {
		glOrtho(-2*ra, 2*ra, -2, 2, -1, 10);
	}
	*/


	//camara perspectiva(angulo,relacione entre w/h,near,far)
	gluPerspective(40, ra, 0.1, 500);



}

bool approximate(float valor,float objetivo, float tolerancia)
{
	return objetivo - tolerancia <valor && objetivo + tolerancia > valor;
}
void onKey(unsigned char tecla, int x, int y)
{
	//callback de atencion al pulsado de letras y numeros
	switch (tecla)
	{
	case 'S':
	case 's': modo = modo == GL_FILL ? GL_LINE: GL_FILL;
		break;
	case 'N':
	case'n':niebla = !niebla;
		break;
	case 'L':
	case'l':dia = !dia;
		break;
	case 'C':
	case'c':ui = !ui;
		break;
	case 27: exit(0);
	}

}


static void normalizar(float vector[3],float modulo, float output[3])
{
	if (modulo)
	{
		output[0] = vector[0] / modulo;
		output[1] = vector[1] / modulo;
		output[2] = vector[2] / modulo;
	}
	else
	{
		output[0] = 0;
		output[1] = 0;
		output[2] = 0;

	}

}

static float modulo(float vector[3])
{
	return sqrtf(vector[0] * vector[0] + vector[1] * vector[1] + vector[2] * vector[2]);
}

static float dot(float vector1[3], float vector2[3])
{
	return vector1[0] * vector2[0] + vector1[1] * vector2[1] + vector1[2] * vector2[2];
}

static void cross(float vector1[3], float vector2[3],float out[3])
{
	out[0] = vector1[1] * vector2[2] - vector1[2] * vector2[1];
	out[1] = vector1[0] * vector2[2] - vector1[2] * vector2[0];
	out[2] = vector1[0] * vector2[1] - vector1[1] * vector2[0];
}

void calcularVelocidad()
{
	float aux[2] = { acceleracion[0],acceleracion[2] };
	int girar = !approximate(v, 0, 0.05f) ? 1 : 0;
	float grado = horizontal * VGIRAR *deltaTime*girar ;
	float cosG = cos(grado *rad2grad), sinG = sin(grado*rad2grad);
	acceleracion[0] = aux[0] * cosG - aux[1] * sinG;
	acceleracion[2] = aux[0] * sinG + aux[1] * cosG;
	normalizar(acceleracion, ACCELERACION, acceleracionN);
	dirCoche[0] = -acceleracionN[2];
	dirCoche[2] = acceleracionN[0];
	

	/*
	float cosG = cos(grado *rad2grad), sinG = sin(grado*rad2grad);
	aux[0] = velocidad[0];
	aux[1] = velocidad[2];
	velocidad[0] = aux[0] * cosG - aux[1] * sinG;
	velocidad[2] = aux[0] * sinG + aux[1] * cosG;
	*/
	/*
	velocidad[0] += direccion[0] * acce;
	velocidad[2] += direccion[2] * acce;
	*/
	velocidad[0] += acceleracion[0] * vertical * deltaTime;
	velocidad[2] += acceleracion[2] * vertical * deltaTime;
	

	v = modulo(velocidad);
	
	normalizar(velocidad, v, velocidadN);


	//girar2
	
	if (!approximate(v,0,0.05f) && posCoche[1] == carretera[N][0][1])
	{
		float resta[3];
		resta[0] = acceleracionN[0] - velocidadN[0];
		resta[1] = acceleracionN[1] - velocidadN[1];
		resta[2] = acceleracionN[2] - velocidadN[2];
		velocidad[0] += resta[0] * VANGULAR * deltaTime;
		velocidad[2] += resta[2] * VANGULAR * deltaTime;
		
	}
	
	
	velocidad[1] -= GRAVEDAD * deltaTime;
	v = modulo(velocidad);
	normalizar(velocidad, v, velocidadN);
	//girar
	/*
	float res[3];
	cross(velocidadN, acceleracionN, res);
	float diferencia = modulo(res);
	grado = res[1] >= 0 ? 1 : -1;
	diferencia = asin(diferencia);
	grado = grado * diferencia;
	grado *= deltaTime;
	
	cosG = cos(grado);
	sinG = sin(grado);
	aux[0] = velocidad[0];
	aux[1] = velocidad[2];
	velocidad[0] = aux[0] * cosG - aux[1] * sinG;
	velocidad[2] = aux[0] * sinG + aux[1] * cosG;
	
	*/
	
	
	


	double rozamiento = 1.5f * deltaTime;

	
	if (v < rozamiento)
	{
		
		velocidad[0] = 0;
		velocidad[1] = 0;
		velocidad[2] = 0;
		v = 0;
		
	}
	else
	{
		velocidad[0] -= velocidadN[0] * rozamiento;
		velocidad[1] -= velocidadN[1] * rozamiento;
		velocidad[2] -= velocidadN[2] * rozamiento;
		v -= rozamiento;
	}

	
}

float distancia(float vector1[3],float vector2[3])
{
	//
	//return abs(vector2[0] - vector1[0])  + abs(vector2[2] - vector1[2]);
	float res[3] = { abs(vector2[0] - vector1[0]) , 0 , abs(vector2[2] - vector1[2]) };
	return res[0]*res[0]+res[2]*res[2];
}

void buscaTramoMasCerca(float punto[3])
{
	bool encontrado = false;
	float l = distancia(carretera[N][0], punto);
	float aux = distancia(carretera[N][1], punto);
	int i = 1;
	int ultN = N;
	while (!encontrado)
	{
		encontrado = true;
		int indiceAux = ultN + i;
		if (indiceAux >= LENGTHCAR)
		{
			indiceAux -= LENGTHCAR;
		}
		aux = distancia(carretera[indiceAux][0], punto);
		if (aux < l)
		{
			l = aux;
			N = indiceAux;
			encontrado = false;
		}
		indiceAux = ultN - i;
		if (indiceAux < 0)
		{
			indiceAux += LENGTHCAR;
		}
		aux = distancia(carretera[indiceAux][0], punto);
		
		if (aux < l)
		{
			l = aux;
			N = indiceAux;
			encontrado = false;
		}
		i++;
	}

}

void detectarColision(float punto[3])
{
	float amplitud[3];
	amplitud[0] = carretera[N][1][0] - carretera[N][0][0];
	amplitud[1] = carretera[N][1][1] - carretera[N][0][1];
	amplitud[2] = carretera[N][1][2] - carretera[N][0][2];
	punto[0] = punto[0] - carretera[N][0][0];
	punto[1] = punto[1] - carretera[N][0][1];
	punto[2] = punto[2] - carretera[N][0][2];

	//proyectar puntoIzq a amplitud
	// (u*v/|v^2|) * v
	float longitud = dot(punto, amplitud);
	float m = modulo(amplitud);
	m = m * m;
	longitud = longitud / m;
	if (longitud < 0)
	{
		amplitud[0] *= longitud;
		amplitud[2] *= longitud;
		posCoche[0] -= amplitud[0];
		posCoche[2] -= amplitud[2];
		velocidad[0] -= amplitud[0] ;
		velocidad[0] -= amplitud[2] ;
	}
	if (longitud > 1)
	{
		longitud -= 1;
		amplitud[0] *= longitud;
		amplitud[2] *= longitud;
		posCoche[0] -= amplitud[0];
		posCoche[2] -= amplitud[2];
		velocidad[0] -= amplitud[0] ;
		velocidad[0] -= amplitud[2] ;
	}
}

void calcularColision()
{

	posCoche[0] += velocidad[0]*deltaTime;
	posCoche[1] += velocidad[1]*deltaTime;
	posCoche[2] += velocidad[2] * deltaTime;
	float puntoIzq[3] = { posCoche[0] + dirCoche[0] * .5 , posCoche[1],posCoche[2] };
	buscaTramoMasCerca(puntoIzq);
	
	//calcular si ha colisionado con el suelo
	if (puntoIzq[1] < carretera[N][0][1])
	{
		float offset = carretera[N][0][1] - puntoIzq[1];
		puntoIzq[1] += offset;
		posCoche[1] += offset;
		velocidad[1] =0;
	}

	
	//calcular si ha salido del bolde
	detectarColision(puntoIzq);

	puntoIzq[0] = posCoche[0] - dirCoche[0] * 0.5 - acceleracionN[0]; 
	puntoIzq[1] = posCoche[1];
	puntoIzq[2] = posCoche[2] - dirCoche[2] * 0.5 - acceleracionN[2];
	buscaTramoMasCerca(puntoIzq);

	detectarColision(puntoIzq);

	float puntoDer[3] = { posCoche[0] - dirCoche[0] * .5 , posCoche[1],posCoche[2] };
	buscaTramoMasCerca(puntoDer);
	detectarColision(puntoDer);
	
	puntoDer[0] = posCoche[0] + dirCoche[0] * 0.5 - acceleracionN[0];
	puntoDer[1] = posCoche[1];
	puntoDer[2] = posCoche[2] + dirCoche[2] * 0.5 - acceleracionN[2];

	buscaTramoMasCerca(puntoDer);
	detectarColision(puntoDer);

	v = modulo(velocidad);
	normalizar(velocidad, v, velocidadN);
	if (v > MAXVELOCIDAD)
	{
		float offset = v - MAXVELOCIDAD;
		velocidad[0] -= velocidadN[0] * offset;
		velocidad[1] -= velocidadN[1] * offset;
		velocidad[2] -= velocidadN[2] * offset;
		v = MAXVELOCIDAD;
	}



}

void Update(int tiempo) 
{
	static int antes = glutGet(GLUT_ELAPSED_TIME);
	int ahora = glutGet(GLUT_ELAPSED_TIME);
	deltaTime = float(ahora - antes) / 1000;
	antes = ahora;
	calcularVelocidad();
	calcularColision();
	if (v)
	{
		normalizar(velocidad, v, direccion);
	}
	posCamara[0] = posCoche[0] - direccion[0]*5;
	posCamara[1] = posCoche[1] +2 -direccion[1]*5;
	posCamara[2] = posCoche[2] - direccion[2]*5;
	normalizar(acceleracion, modulo(acceleracion),acceleracionN);
	
	
	glutPostRedisplay();
	glutTimerFunc(tiempo, Update, tiempo);
}

void onArrow(int key, int x, int y)
{
	switch (key)
	{
	case GLUT_KEY_LEFT:
		horizontal = -1;
		break;
	case GLUT_KEY_UP:
		vertical =1;
		break;
	case GLUT_KEY_RIGHT:
		horizontal= 1;
		break;
	case GLUT_KEY_DOWN:
		vertical = -1;
		break;
	}
}

void onArrowUp(int key, int x, int y)
{
	switch (key)
	{
	case GLUT_KEY_LEFT:
	case GLUT_KEY_RIGHT:
		horizontal = 0;
		break;
	case GLUT_KEY_UP:
	case GLUT_KEY_DOWN:
		vertical = 0;
		break;
	}
}

int main(int argc, char** argv)
{
	FreeImage_Initialise();

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(600, 600);
	glutCreateWindow("Juego de coche");

	init();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(onKey);
	glutSpecialFunc(onArrow);
	glutSpecialUpFunc(onArrowUp);
	//glutIdleFunc(Update);
	glutTimerFunc(1000 / 60, Update,1000/60);
	glutMainLoop();

	FreeImage_DeInitialise();

	return 0;
}