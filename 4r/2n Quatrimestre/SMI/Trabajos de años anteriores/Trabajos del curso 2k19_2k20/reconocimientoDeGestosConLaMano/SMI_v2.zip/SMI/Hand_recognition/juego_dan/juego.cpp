/*
* Interfaz_de_conduccion.cpp
* Autor: Dan Anitei
*/

#include <iostream>
#include <sstream>
#include "Utilidades.h"


#define PROYECTO "ISGI::Video Juego"
#define tasaFPS 60

using namespace std;

float at_x = 0.0, at_z = 0.0;
float look_at_x = 0.0, look_at_z = 0.0;
float velocidad = 0.0;
float incr_velocidad = 0.0;

int longitud_quad = 4;
int amplitud = 3;
float pos_farola = 0.0;
float pos_carretera = 0.0;
float pos_anuncio = 0.0;

int stoplight = 0;
float old_velocidad = 0.0;
float direccion = 0.0;
float old_dir = 0.0;
float dir_coche = 0.0;
float rotate_tire = 0.0;

int gira_aguja = -45;
int angleB = 0;
int dia = 0;
int alambrico = 0;
int colision = 1;
int fog = 0;
int dificultad = 0;
int hud = 1;

float width = 960, height = 540, r = 0;
float angle = 0;
float giro_coche;



GLfloat red[] = { 70.0 / 255, 0.0, 0.0, 1 };

GLfloat vq[40][3]; // horizonte

GLuint farola, star, ruedas, ruedas_delanteras, ruedas_traseras, aguja, triangle;
GLuint stop_lights, coche, disc, anuncio, poste_anuncio, quads, quadsWire, quad_tunel, quad_tunel_wire;

GLuint road_tex, car_tex, backg_tex, backg_tex_N, anuncio_cola_tex, offroad_tex, beam_tex, HUD_tex, speedometer_tex, compass_tex, aguja_tex, aguja_brujula_tex;

void loadTexture()
// Funcion de carga de texturas e inicializacion
{
	glEnable(GL_TEXTURE_2D);

	glGenTextures(1, &road_tex);
	glBindTexture(GL_TEXTURE_2D, road_tex);
	loadImageFile((char*)"road_texture.jpg");
	
	glGenTextures(1, &car_tex);
	glBindTexture(GL_TEXTURE_2D, car_tex);
	loadImageFile((char*)"car_texture.jpg");

	glGenTextures(1, &backg_tex);
	glBindTexture(GL_TEXTURE_2D, backg_tex);
	loadImageFile((char*)"hills.jpg");

	glGenTextures(1, &backg_tex_N);
	glBindTexture(GL_TEXTURE_2D, backg_tex_N);
	loadImageFile((char*)"hills_night.jpg");
	
	glGenTextures(1, &anuncio_cola_tex);
	glBindTexture(GL_TEXTURE_2D, anuncio_cola_tex);
	loadImageFile((char*)"cocacola.jpg");

	glGenTextures(1, &offroad_tex);
	glBindTexture(GL_TEXTURE_2D, offroad_tex);
	loadImageFile((char*)"frozen_grass.jpg");

	glGenTextures(1, &beam_tex);
	glBindTexture(GL_TEXTURE_2D, beam_tex);
	loadImageFile((char*)"beam.jpg");

	glGenTextures(1, &HUD_tex);
	glBindTexture(GL_TEXTURE_2D, HUD_tex);
	loadImageFile((char*)"ventana.png");

	glGenTextures(1, &speedometer_tex);
	glBindTexture(GL_TEXTURE_2D, speedometer_tex);
	loadImageFile((char*)"speedom.png");

	glGenTextures(1, &compass_tex);
	glBindTexture(GL_TEXTURE_2D, compass_tex);
	loadImageFile((char*)"compass.png");

	glGenTextures(1, &aguja_tex);
	glBindTexture(GL_TEXTURE_2D, aguja_tex);
	loadImageFile((char*)"needle.png");

	glGenTextures(1, &aguja_brujula_tex);
	glBindTexture(GL_TEXTURE_2D, aguja_brujula_tex);
	loadImageFile((char*)"compass_needle.png");

}

void modelarCoche() {
	// Modelar rueda
	ruedas = glGenLists(1);
	glNewList(ruedas, GL_COMPILE);	

	// Material brillante
	glColor4fv(NEGRO);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, NEGRO);
	glMaterialfv(GL_FRONT, GL_SPECULAR, GRISCLARO);
	glMaterialf(GL_FRONT, GL_SHININESS, 50);
	
	glutSolidTorus(0.15, 0.5, 30, 30);

	glPushMatrix();
	glColor4fv(GRISCLARO);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, GRISCLARO);
	glMaterialfv(GL_FRONT, GL_SPECULAR, GRISCLARO);
	glutWireTorus(0.15, 0.505, 20, 20);

	glColor4fv(NEGRO);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, NEGRO);
	glMaterialfv(GL_FRONT, GL_SPECULAR, NEGRO);
	glScalef(0.35, 0.35, 0.35);
	glCallList(star);
	glPopMatrix();
	glEndList();

	// Modelar ruedas delanteras
	ruedas_delanteras = glGenLists(1);
	glNewList(ruedas_delanteras, GL_COMPILE);

	glPushMatrix();
	glRotatef(90, 0, 1, 0);
	glScalef(0.3, 0.3, 0.4);
	glCallList(ruedas);
	glPopMatrix();

	glPushMatrix();
	glRotatef(-90, 0, 1, 0);
	glScalef(0.3, 0.3, 0.4);
	glCallList(ruedas);
	glPopMatrix();

	glEndList();

	ruedas_traseras = glGenLists(1);
	glNewList(ruedas_traseras, GL_COMPILE);

	// Ruedas traseras
	glPushMatrix();
	glRotatef(90, 0, 1, 0);
	glScalef(0.4, 0.4, 0.7);
	glCallList(ruedas);
	glPopMatrix();

	glEndList();

	// Stop Lights
	stop_lights = glGenLists(1);
	glNewList(stop_lights, GL_COMPILE);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, NEGRO);
	glMaterialfv(GL_FRONT, GL_SPECULAR, NEGRO);

	glColor4fv(red);
	glPushMatrix();
	glTranslatef(0.13, 0.2, -0.44);
	glScalef(0.025, 0.025, 0.025);
	glutSolidDodecahedron();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-0.13, 0.2, -0.44);
	glScalef(0.025, 0.025, 0.025);
	glutSolidDodecahedron();
	glPopMatrix();

	glEndList();
}

void dibujarCoche() {

	// Dibujar el coche (teapot)
	glPushMatrix();
	
	glTranslatef(0, -0.75, -2);
	glScalef(-1,1,-1);

	glPushMatrix();
	
	float angle_x = look_at_x - at_x,
		angle_z = look_at_z - at_z;

	float angulo_rad = atan2(angle_x, angle_z);
	angle =  angulo_rad * 180 / PI;

	giro_coche = abs(tan(angulo_rad)*2.35); // extremo del coche al girar

	if (angle > 35) angle = 35;
	if (angle < -35) angle = -35;
	glRotatef(angle / 4, 0,1,0);

	// Ruedas delanteras	
	glPushMatrix();
	glTranslatef(0.3, -0.06, 0.35);
	glRotatef(rotate_tire, 1, 0, 0);
	glCallList(ruedas_delanteras);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-0.3, -0.06, 0.35);
	glRotatef(rotate_tire, 1, 0, 0);
	glCallList(ruedas_delanteras);
	glPopMatrix();

	// Eje rueda
	glPushMatrix();
	glTranslatef(0.3, -0.06, 0.35);
	glRotatef(rotate_tire, 1, 0, 0);
	glRotatef(-90, 0, 1, 0);

	glColor4fv(BLANCO);
	glutWireCylinder(0.025, 0.6, 10, 10);

	glColor4fv(NEGRO);
	glutSolidCylinder(0.025, 0.6, 30, 30);
	glPopMatrix();

	glPopMatrix();

	// Ruedas traseras
	glPushMatrix();
	glTranslatef(0.35, 0, -0.35);
	glRotatef(rotate_tire, 1, 0, 0);
	glCallList(ruedas_traseras);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-0.35, 0, -0.35);
	glRotatef(rotate_tire, 1, 0, 0);
	glCallList(ruedas_traseras);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0.3, 0, -0.35);
	glRotatef(rotate_tire, 1, 0, 0);
	glRotatef(-90, 0, 1, 0);
	glColor4fv(BLANCO);
	glutWireCylinder(0.025, 0.7, 10, 30);
	glColor4fv(NEGRO);
	glutSolidCylinder(0.025, 0.7, 30, 30);
	glPopMatrix();

	// Coche
	glBindTexture(GL_TEXTURE_2D, car_tex);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	// Chasis
	glPushMatrix();
	glTranslatef(0, 0.1, 0);
	glRotatef(-90, 0, 1, 0);
	glRotatef(-5, 0, 0, 1);
	glScalef(1.8, 1.3, 0.8);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, GRISOSCURO);
	glMaterialfv(GL_FRONT, GL_SPECULAR, GRISCLARO);
	if (alambrico == 0) glutSolidTeapot(0.3);
	else glutWireTeapot(0.3);
	glPopMatrix();

	glMaterialfv(GL_FRONT, GL_DIFFUSE, NEGRO);
	glMaterialfv(GL_FRONT, GL_SPECULAR, NEGRO);
	glPushMatrix();
	glTranslatef(0.13, 0.2, -0.45);
	glScalef(0.026, 0.026, 0.026);
	glutWireDodecahedron();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-0.13, 0.2, -0.45);
	glScalef(0.026, 0.026, 0.026);
	glutWireDodecahedron();
	glPopMatrix();

	if (stoplight == 1) {
		glMaterialfv(GL_FRONT, GL_EMISSION, ROJO);
		glColor4fv(ROJO);
	}
	else {
		glMaterialfv(GL_FRONT, GL_EMISSION, red);
		glColor4fv(red);
	}

	glCallList(stop_lights);

	glMaterialfv(GL_FRONT, GL_EMISSION, NEGRO);

	glPopMatrix();
}

void initLight() {
	glEnable(GL_LIGHTING);

	// Luz direccional (caracteristicas cromaticas)
	GLfloat luz_dif[] = { 0.05, 0.05, 0.05, 1.0 };
	GLfloat luz_esp[] = { 0.0, 0.0, 0.0, 1.0 };

	glLightfv(GL_LIGHT0, GL_AMBIENT, luz_dif);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, luz_dif);
	glLightfv(GL_LIGHT0, GL_SPECULAR, luz_esp);
	glEnable(GL_LIGHT0);


	// Luz focal (caracteristicas cromaticas)
	GLfloat dif_faro[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat esp_faro[] = { 0.3, 0.3, 0.3, 1.0 };
	GLfloat amb_faro[] = { 0.2, 0.2, 0.2, 1.0 };

	glLightfv(GL_LIGHT1, GL_AMBIENT, amb_faro);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, dif_faro);
	glLightfv(GL_LIGHT1, GL_SPECULAR, esp_faro);
	glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 20.0);
	glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 10.0);
	glEnable(GL_LIGHT1);


	// Luz focal 2,3,4,5 (caracteristicas cromaticas)
	GLfloat dif_farola[] = { 0.5, 0.5, 0.2, 1.0 };
	GLfloat amb_farola[] = { 0.0, 0.0, 0.0, 1.0 };

	glLightfv(GL_LIGHT2, GL_AMBIENT, amb_farola);
	glLightfv(GL_LIGHT2, GL_DIFFUSE, dif_farola);
	glLightfv(GL_LIGHT2, GL_SPECULAR, amb_farola);
	glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, 50.0);
	glLightf(GL_LIGHT2, GL_SPOT_EXPONENT, 3.0);


	glLightfv(GL_LIGHT3, GL_AMBIENT, amb_farola);
	glLightfv(GL_LIGHT3, GL_DIFFUSE, dif_farola);
	glLightfv(GL_LIGHT3, GL_SPECULAR, amb_farola);
	glLightf(GL_LIGHT3, GL_SPOT_CUTOFF, 50.0);
	glLightf(GL_LIGHT3, GL_SPOT_EXPONENT, 3.0);


	glLightfv(GL_LIGHT4, GL_AMBIENT, amb_farola);
	glLightfv(GL_LIGHT4, GL_DIFFUSE, dif_farola);
	glLightfv(GL_LIGHT4, GL_SPECULAR, amb_farola);
	glLightf(GL_LIGHT4, GL_SPOT_CUTOFF, 50.0);
	glLightf(GL_LIGHT4, GL_SPOT_EXPONENT, 3.0);


	glLightfv(GL_LIGHT5, GL_AMBIENT, amb_farola);
	glLightfv(GL_LIGHT5, GL_DIFFUSE, dif_farola);
	glLightfv(GL_LIGHT5, GL_SPECULAR, amb_farola);
	glLightf(GL_LIGHT5, GL_SPOT_CUTOFF, 50.0);
	glLightf(GL_LIGHT5, GL_SPOT_EXPONENT, 3.0);

	glLightfv(GL_LIGHT6, GL_AMBIENT, amb_farola);
	glLightfv(GL_LIGHT6, GL_DIFFUSE, dif_farola);
	glLightfv(GL_LIGHT6, GL_SPECULAR, amb_farola);
	glLightf(GL_LIGHT6, GL_SPOT_CUTOFF, 30.0);
	glLightf(GL_LIGHT6, GL_SPOT_EXPONENT, 5.0);

	glLightfv(GL_LIGHT7, GL_AMBIENT, amb_farola);
	glLightfv(GL_LIGHT7, GL_DIFFUSE, dif_farola);
	glLightfv(GL_LIGHT7, GL_SPECULAR, amb_farola);
	glLightf(GL_LIGHT7, GL_SPOT_CUTOFF, 30.0);
	glLightf(GL_LIGHT7, GL_SPOT_EXPONENT, 5.0);

	glEnable(GL_LIGHT2);
	glEnable(GL_LIGHT3);
	glEnable(GL_LIGHT4);
	glEnable(GL_LIGHT5);
	glEnable(GL_LIGHT6);
	glEnable(GL_LIGHT7);
	

}

void init() {
	glClearColor(0.0, 0.0, 0.0, 1.0);

	glEnable(GL_DEPTH_TEST);
	glShadeModel(GL_SMOOTH);
	
	glEnable(GL_CULL_FACE);

	// Culling
	glCullFace(GL_BACK);

	initLight();
	loadTexture();

	modelarCoche();

	// triangle
	triangle = glGenLists(1);
	glNewList(triangle, GL_COMPILE);

	glPushMatrix();
	float radio_ext = 1.0;
	float radio_int = 0.3;
	glPolygonMode(GL_FRONT, GL_FILL);
	glBegin(GL_TRIANGLE_STRIP);
	for (int i = 0; i < 4; i++) {
		glVertex3f(radio_ext*cos(i * 2 * PI / 3.0 + PI / 2), radio_ext*sin(i * 2 * PI / 3.0 + PI / 2), 0);
		glVertex3f(radio_int*cos(i * 2 * PI / 3.0 + PI / 2), radio_int*sin(i * 2 * PI / 3.0 + PI / 2), 0);
	}

	glEnd();

	glPopMatrix();

	glEndList();

	aguja = glGenLists(1);
	glNewList(aguja, GL_COMPILE);

	glEnable(GL_DEPTH_TEST);
	glPushMatrix();
	glTranslatef(0, 0.25, 0);
	glScalef(0.5, 0.5, 1);
	glCallList(triangle);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, -0.25, 0);
	glRotatef(180, 0, 0, 1);
	glScalef(0.5, 0.5, 1);
	glCallList(triangle);
	glPopMatrix();

	glEndList();

	GLfloat col_dif[] = { 0.2, 0.2, 0.2, 1.0 };

	// horizonte

	float radio = 100;
	for (int i = 0; i < 40; i += 2) {
		vq[i][0] = at_x + radio * sin(i * 2 * PI / 20.0);
		vq[i][1] = -tan(45 * PI / 180.0) * radio / 2;
		vq[i][2] = at_z + radio * cos(i * 2 * PI / 20.0);

		vq[i + 1][0] = vq[i][0];
		vq[i + 1][1] = tan(45 * PI / 180.0) * radio / 2;
		vq[i + 1][2] = vq[i][2];
	}

	// Modelar Farola
	farola = glGenLists(1);
	glNewList(farola, GL_COMPILE);

	glPushMatrix();
	glMaterialfv(GL_FRONT, GL_DIFFUSE, ORO);
	glMaterialfv(GL_FRONT, GL_SPECULAR, ORO);
	glMaterialfv(GL_FRONT, GL_EMISSION, ORO);
	glMaterialf(GL_FRONT, GL_SHININESS, 30);
	glTranslatef(-1.8, 3.65, 0);
	glutSolidSphere(0.13, 30, 30);
	glPopMatrix();

	glMaterialfv(GL_FRONT, GL_EMISSION, NEGRO);

	// Material poste

	glMaterialfv(GL_FRONT, GL_DIFFUSE, col_dif);
	glMaterialfv(GL_FRONT, GL_SPECULAR, col_dif);
	glMaterialf(GL_FRONT, GL_SHININESS, 3);

	glPushMatrix();
	glTranslatef(-1.8, 3.6, 0);
	glRotatef(-90, 1, 0, 0);
	glRotatef(15, 0, 1, 0);
	glutSolidCone(0.3,0.3,10,10);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0.075, 4, 0);
	glRotatef(-90, 0, 1, 0);
	glutSolidCylinder(0.1, 2, 30, 30);
	glPopMatrix();

	glPushMatrix();
	glRotatef(-90, 1, 0, 0);
	glutSolidCylinder(0.1, 4, 30, 30);
	glPopMatrix();
	glEndList();

	// Modelar un disco
	disc = glGenLists(1);

	glNewList(disc, GL_COMPILE);
	float radio_d = 1;
	glBegin(GL_POLYGON);
	for (int i = 0; i < 40; i++) {
		glVertex3f(radio_d*cos(i * 2 * PI / 40.0), radio_d*sin(i * 2 * PI / 40.0), 0);
	}
	glEnd();
	glEndList();

	// Modelar una estrella
	star = glGenLists(1);
	glNewList(star, GL_COMPILE);

	radio_ext = 1.0;
	radio_int = 0.7;
	glPolygonMode(GL_FRONT, GL_FILL);
	glBegin(GL_TRIANGLE_STRIP);
	for (int i = 0; i < 4; i++) {
		glVertex3f(radio_ext*cos(i * 2 * PI / 3.0 + PI / 2), radio_ext*sin(i * 2 * PI / 3.0 + PI / 2), 0);
		glVertex3f(radio_int*cos(i * 2 * PI / 3.0 + PI / 2), radio_int*sin(i * 2 * PI / 3.0 + PI / 2), 0);
	}

	for (int i = 0; i < 4; i++) {
		glVertex3f(radio_ext*cos(i * 2 * PI / 3.0 + 3 * PI / 2), radio_ext*sin(i * 2 * PI / 3.0 + 3 * PI / 2), 0);
		glVertex3f(radio_int*cos(i * 2 * PI / 3.0 + 3 * PI / 2), radio_int*sin(i * 2 * PI / 3.0 + 3 * PI / 2), 0);
	}
	glEnd();

	glEndList();

	// Panel anuncio
	poste_anuncio = glGenLists(1);
	glNewList(poste_anuncio, GL_COMPILE);

	glMaterialfv(GL_FRONT, GL_DIFFUSE, col_dif);
	glMaterialfv(GL_FRONT, GL_SPECULAR, col_dif);
	glMaterialf(GL_FRONT, GL_SHININESS, 3);

	// poste
	glPushMatrix();
	glTranslatef(0, 0, 0.21);
	glRotatef(-90, 1, 0, 0);
	glutSolidCylinder(0.2, 4.5, 30, 30);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 4.01, -0.45);
	glRotatef(-90, 1, 0, 0);
	glRotatef(-30, 1, 0, 0);
	glutSolidCone(0.3, 0.3, 10, 10);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 4.3, -0.6);
	glutSolidCylinder(0.02, 0.6, 30, 30);
	glPopMatrix();

	glPushMatrix();
	glMaterialfv(GL_FRONT, GL_EMISSION, ORO);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, ORO);
	glMaterialfv(GL_FRONT, GL_SPECULAR, ORO);
	glMaterialf(GL_FRONT, GL_SHININESS, 30);
	glTranslatef(0, 4.1, -0.48);
	glutSolidSphere(0.13, 30, 30);
	glMaterialfv(GL_FRONT, GL_EMISSION, NEGRO);
	glPopMatrix();

	glEndList();

	anuncio = glGenLists(1);
	glNewList(anuncio, GL_COMPILE);

	glMaterialfv(GL_FRONT, GL_DIFFUSE, BLANCO);
	glMaterialfv(GL_FRONT, GL_SPECULAR, BLANCO);
	glMaterialfv(GL_FRONT, GL_EMISSION, GRISOSCURO);
	glMaterialf(GL_FRONT, GL_SHININESS, 100);

	GLfloat v4[3] = { -2.5, 2, 0 },
		v5[3] = { -2.5, 4, 0 },
		v6[3] = { 2.5, 4, 0 },
		v7[3] = { 2.5, 2, 0 };

	quadtex(v7, v4, v5, v6, 0, 1, 0, 1, 30, 30);
	glMaterialfv(GL_FRONT, GL_EMISSION, NEGRO);
	glMaterialf(GL_FRONT, GL_SHININESS, 3);
	glEndList();
}

void FPS()
// Calcula la frecuencia y la muestra en el t�tulo de la ventana
// cada segundo
{
	int ahora, tiempo_transcurrido;
	static int antes = 0;
	stringstream titulo;
	//Cuenta de llamadas a esta funci�n en el �ltimo segundo

	ahora = glutGet(GLUT_ELAPSED_TIME); //Tiempo transcurrido desde el inicio
	tiempo_transcurrido = ahora - antes; //Tiempo transcurrido desde antes

	if (tiempo_transcurrido > 100) { //Acaba de rebasar el segundo
		titulo << "Velocidad: " << velocidad << " m/s"; //Se muestra una vez por segundo
		glutSetWindowTitle(titulo.str().c_str());
		antes = ahora; //Ahora ya es antes
	}
}

float calcV(float pos, float amp) {
	return amp * sin(pos * 2 * PI / 140);
}

void display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Borra la pantalla
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//glBindTexture(GL_TEXTURE_2D, backg_tex);
	//texturarFondo();

	glLightModeli(GL_LIGHT_MODEL_COLOR_CONTROL, GL_SEPARATE_SPECULAR_COLOR);

	// Direccion y posicion de los faros
	GLfloat dir_central[] = { 0, -0.4, -1 };
	glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, dir_central);

	GLfloat faros[] = { 0.0, 0.0, -2.0, 1.0 };
	glLightfv(GL_LIGHT1, GL_POSITION, faros);
		
	dibujarCoche();
	
	if (colision == 1) {
		float border = calcV(at_z + 2.35, amplitud);
		if (at_x > border + 4 - giro_coche) {
			at_x = border + 4 - giro_coche; // left border
		}
		
		if (at_x < border - 4 + giro_coche) {
			at_x = border - 4 + giro_coche;
		}
	}
	// Situa la camara
	gluLookAt(at_x, 1, at_z, look_at_x, 1, look_at_z, 0, 1, 0);
	
	/*
	// Ejes
	glPushMatrix();
	glTranslatef(0, 0.4, 5);
	ejes();
	glPopMatrix();
	*/

	// Posicion de la luna
	GLfloat pos_luna[] = { 0.0, 10.0, 0.0, 0.0 };
	glLightfv(GL_LIGHT0, GL_POSITION, pos_luna);
	

	glPushAttrib(GL_ALL_ATTRIB_BITS);

	if (alambrico == 0) glPolygonMode(GL_FRONT, GL_FILL);
	else glPolygonMode(GL_FRONT, GL_LINE);

	
	// Material Carretera
	GLfloat col_esp[] = { 0.3, 0.3, 0.3, 1.0 };
	GLfloat col_dif[] = { 0.9, 0.9, 0.9, 1.0 };

	glMaterialfv(GL_FRONT, GL_DIFFUSE, col_dif);
	glMaterialfv(GL_FRONT, GL_SPECULAR, col_esp);
	glMaterialf(GL_FRONT, GL_SHININESS, 30);

	if ((25 * longitud_quad + pos_carretera - at_z) < 0) {
		pos_carretera = at_z;
	}

	GLfloat v0[3] = { calcV(pos_carretera, amplitud) + 3, 0, pos_carretera - longitud_quad }, // main road
		v3[3] = { calcV(pos_carretera, amplitud) - 3, 0, pos_carretera - longitud_quad },

		v4[3] = { calcV(pos_carretera, amplitud) + 20, 0, pos_carretera - longitud_quad }, // off road left
		v7[3] = { calcV(pos_carretera, amplitud) + 3, 0, pos_carretera - longitud_quad },

		vr4[3] = { calcV(pos_carretera, amplitud) - 20, 0, pos_carretera - longitud_quad }, // off road right
		vr7[3] = { calcV(pos_carretera, amplitud) - 3, 0, pos_carretera - longitud_quad },

		q0[3] = { calcV(pos_carretera, amplitud) + 4, 0, pos_carretera - longitud_quad },	// quitamiedos izq
		q3[3] = { calcV(pos_carretera, amplitud) + 4, 0.5, pos_carretera - longitud_quad },

		q4[3] = { calcV(pos_carretera, amplitud) - 4, 0, pos_carretera - longitud_quad },	// quitamiedos der
		q7[3] = { calcV(pos_carretera, amplitud) - 4, 0.5, pos_carretera - longitud_quad };

	// Carretera
	for (float i = pos_carretera - longitud_quad; i < (100 * longitud_quad + pos_carretera - longitud_quad); i += longitud_quad) {

		GLfloat	v1[3] = { calcV(i, amplitud) + 3, 0, i + longitud_quad },
			v2[3] = { calcV(i, amplitud) - 3, 0, i + longitud_quad },

			v5[3] = { calcV(i, amplitud) + 20, 0, i + longitud_quad },
			v6[3] = { calcV(i, amplitud) + 3, 0, i + longitud_quad },

			vr5[3] = { calcV(i, amplitud) - 20, 0, i + longitud_quad },
			vr6[3] = { calcV(i, amplitud) - 3, 0, i + longitud_quad },
			
			q1[3] = { calcV(i, amplitud) + 4, 0, i + longitud_quad }, // quitamiedo izq
			q2[3] = { calcV(i, amplitud) + 4, 0.5, i + longitud_quad },

			q5[3] = { calcV(i, amplitud) - 4, 0, i + longitud_quad }, // quitamiedo der
			q6[3] = { calcV(i, amplitud) - 4, 0.5, i + longitud_quad };

		glColor4fv(BLANCO);
		glBindTexture(GL_TEXTURE_2D, beam_tex);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		
		glDisable(GL_CULL_FACE);

		quadtex(q1, q2, q3, q0, 0.8, 1, 0, 1, 10, 10); // quitamiedos
		quadtex(q6, q5, q4, q7, 0.8, 1, 0, 1, 10, 10);

		glEnable(GL_CULL_FACE);

		q0[0] = q1[0];
		q0[2] = q1[2];
		q3[0] = q2[0];
		q3[2] = q2[2];

		q4[0] = q5[0];
		q4[2] = q5[2];
		q7[0] = q6[0];
		q7[2] = q6[2];

		glColor4fv(BLANCO);
		glBindTexture(GL_TEXTURE_2D, road_tex);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

		quadtex(v1, v0, v3, v2, 0, 1, 0, 1, 60, 60);

		v0[0] = v1[0];
		v0[2] = v1[2];
		v3[0] = v2[0];
		v3[2] = v2[2];

		glBindTexture(GL_TEXTURE_2D, offroad_tex);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

		glColor4fv(red);
		quadtex(v7, v6, v5, v4, 0, 1, 0, 3, 1, 1); // bottom left
		quadtex(vr6, vr7, vr4, vr5, 0, 1, 0, 3, 1, 1); // bottom right

		v4[0] = v5[0];
		v4[2] = v5[2];
		v7[0] = v6[0];
		v7[2] = v6[2];

		vr4[0] = vr5[0];
		vr4[2] = vr5[2];
		vr7[0] = vr6[0];
		vr7[2] = vr6[2];

	}
	
	if (dia == 1) {
		glBindTexture(GL_TEXTURE_2D, backg_tex);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	}
	else {
		glBindTexture(GL_TEXTURE_2D, backg_tex_N);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	}
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	
	

	int rev = 0;

	for (int i = 0; i < 38; i += 2) {
		glPushMatrix();
		glTranslatef(at_x, 0, at_z);

		int pos = i % 4; //pos * 0.25, pos * 0.25 + 0.5

		quadtex(vq[i + 2], vq[i], vq[i + 1], vq[i + 3], pos * 0.25, pos * 0.25 + 0.5, 0, 1, 2, 1);

		glPopMatrix();
	}

	glPopAttrib();


	// Direccion del foco de las farolas
	GLfloat dir_far2[] = { 0, -1.0, 0.0 };
	glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, dir_far2);
	GLfloat dir_far3[] = { 0, -1.0, 0.0 };
	glLightfv(GL_LIGHT3, GL_SPOT_DIRECTION, dir_far3);
	GLfloat dir_far4[] = { 0, -1.0, 0.0 };
	glLightfv(GL_LIGHT4, GL_SPOT_DIRECTION, dir_far4);
	GLfloat dir_far5[] = { 0, -1.0, 0.0 };
	glLightfv(GL_LIGHT5, GL_SPOT_DIRECTION, dir_far5);

	// Situar las farolas en el mundo
	int light_par = 0, light_impar = 0;
	glColor4f(0.55, 0.55, 0.55,1);

	for (int i = pos_farola; i < 84 + pos_farola; i += 21) {

		float pos = calcV(i, amplitud);
		glPushMatrix();

		if (i % 2 == 0) {
			if (light_par == 0) {
				GLfloat pos_far2[] = { pos, 3.8, i, 1.0 };
				if (i > 0) glLightfv(GL_LIGHT2, GL_POSITION, pos_far2);
				light_par = 1;
			}
			else {
				GLfloat pos_far3[] = { pos, 3.8, i, 1.0 };
				if (i > 0) glLightfv(GL_LIGHT3, GL_POSITION, pos_far3);
				light_par = 0;
			}
			glTranslatef(pos - 5, 0, i);
			glRotatef(180, 0, 1, 0);
		}
		else {
			if (light_impar == 0) {
				GLfloat pos_far4[] = { pos, 3.8, i, 1.0 };
				if (i > 0) glLightfv(GL_LIGHT4, GL_POSITION, pos_far4);
				light_impar = 1;
			}
			else {
				GLfloat pos_far5[] = { pos, 3.8, i, 1.0 };
				if (i > 0) glLightfv(GL_LIGHT5, GL_POSITION, pos_far5);
				light_impar = 0;
			}

			glTranslatef(pos + 5, 0, i);
		}


		glCallList(farola);
		glPopMatrix();
	}

	if (int(at_z) % 21 == 0) pos_farola = at_z;

	// Anuncios
	GLfloat dir_far6[] = { 0, -1, 0.6 };
	glLightfv(GL_LIGHT6, GL_SPOT_DIRECTION, dir_far6);

	GLfloat dir_far7[] = { 0, -1, 0.6 };
	glLightfv(GL_LIGHT7, GL_SPOT_DIRECTION, dir_far7);

	glPushAttrib(GL_ALL_ATTRIB_BITS);

	for (int i = pos_anuncio; i < 118 + pos_anuncio; i += 59) {
		float position = calcV(i, amplitud);

		glPushMatrix();

		if (i % 2) {
			
			GLfloat pos_far6[] = { position + 7, 6, i - 2.5, 1.0 };
			if (i > 0) glLightfv(GL_LIGHT6, GL_POSITION, pos_far6);

			glTranslatef(position + 7, 0, i);
			glRotatef(10, 0, 1, 0);
		}
		else {
			GLfloat pos_far7[] = { position - 7, 6, i - 2.5, 1.0 };
			if (i > 0) glLightfv(GL_LIGHT7, GL_POSITION, pos_far7);

			glTranslatef(position - 7, 0, i);
			glRotatef(-10, 0, 1, 0);
		}
		glCallList(poste_anuncio);

		glBindTexture(GL_TEXTURE_2D, anuncio_cola_tex);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glCallList(anuncio);
		glPopMatrix();
	}
	if ((int)at_z % 59 == 0) pos_anuncio = at_z;
	
	
	// HUD
	if (hud == 1) {
		// *_________________________________________
		// Objetos traslucidos que van pegados a la camara
		glPushMatrix();		// Apilar la modelview
		glLoadIdentity();	// Camara en posicion de defecto
		glMatrixMode(GL_PROJECTION);
		glPushMatrix();		// Apilar la projection
		glLoadIdentity();	// Vista por defecto

		if (width < height)
			glOrtho(-0.65, 0.65, -1 / r, 1 / r, -1, 1);
		else
			glOrtho(-0.65 * r, 0.65 * r, -1, 1, -1, 1);

		glMatrixMode(GL_MODELVIEW);
		gluLookAt(0, 0, 0, 0, 0, -1, 0, 1, 0);

		// Blending
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	
		// Z-Buffer Readonly
		glDepthMask(GL_FALSE);
		glPushAttrib(GL_ENABLE_BIT);

		glDisable(GL_LIGHTING);

		glPushMatrix();
		// aguja velocimetro
		GLfloat va0[3] = { -0.15, -0.15, 0 },
			va1[3] = { -0.15, 0.15, 0 },
			va2[3] = { 0.15, 0.15, 0 },
			va3[3] = { 0.15, -0.15, 0 };
		glColor4fv(BLANCO);
		glBindTexture(GL_TEXTURE_2D, aguja_tex);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		glTranslatef(-0.75,-0.55,0);
		glRotatef(gira_aguja,0,0,1);
		quadtex(va3, va2, va1, va0, 0, 1, 0, 1, 30, 30);
		glPopMatrix();

		// aguja brujula
		glPushMatrix();
		GLfloat va4[3] = { -0.15, -0.15, 0 },
			va5[3] = { -0.15, 0.15, 0 },
			va6[3] = { 0.15, 0.15, 0 },
			va7[3] = { 0.15, -0.15, 0 };
		glColor4fv(BLANCO);
		glBindTexture(GL_TEXTURE_2D, aguja_brujula_tex);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		glTranslatef(0.75, -0.5, 0);
		quadtex(va4, va7, va6, va5, 0, 1, 0, 1, 30, 30);
		glPopMatrix();

		// brujula
		glPushMatrix();
		glBindTexture(GL_TEXTURE_2D, compass_tex);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

		GLfloat v0[3] = { 0.25, -0.25, 0 },
			v1[3] = { 0.25, 0.25, 0 },
			v2[3] = { -0.25, 0.25, 0 },
			v3[3] = { -0.25, -0.25, 0 };
		
		glColor4f(184 / 255.0, 61 / 255.0, 186 / 255.0, 0.5);
		glTranslatef(0.75, -0.5, 0);
		glRotatef(angleB, 0, 0, 1);
		quadtex(v3, v0, v1, v2, 0, 1, 0, 1, 30, 30);
		glPopMatrix();

		// velocimetro
		glBindTexture(GL_TEXTURE_2D, speedometer_tex);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

		GLfloat v4[3] = { -1, -0.75, 0 },
			v5[3] = { -1, -0.25, 0 },
			v6[3] = { -0.5, -0.25, 0 },
			v7[3] = { -0.5, -0.75, 0 };
		
		glColor4f(184 / 255.0, 61 / 255.0, 186 / 255.0, 0.5);
		quadtex(v4, v7, v6, v5, 0, 1, 0, 1, 30, 30);

		
		glPopAttrib();

		glBindTexture(GL_TEXTURE_2D, HUD_tex);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		glBegin(GL_POLYGON);
		glNormal3f(0, 0, 1);
		glTexCoord2f(0, 0);
		glVertex3f(-1, -1, 0);
		glTexCoord2f(1, 0);
		glVertex3f(1, -1, 0);
		glTexCoord2f(1, 1);
		glVertex3f(1, 1, 0);
		glTexCoord2f(0, 1);
		glVertex3f(-1, 1, 0);
		glEnd();

		// Z-Buffer a estado normal
		glDepthMask(GL_TRUE);

		glMatrixMode(GL_PROJECTION);
		glPopMatrix();
		glMatrixMode(GL_MODELVIEW);
		glPopMatrix();
		// *__________________________________________________________
	}
	glPopAttrib();
	glutSwapBuffers();
	FPS();
}


void reshape(GLint w, GLint h)
// Funcion de atencion al redimensionamiento
{
	glViewport(0, 0, w, h);
	// Definimos la camara (matriz de proyeccion)
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	float razon = (float)w / h;
	
	gluPerspective(45, razon, 0.1, 100);

	width = w;
	height = h;
	r = razon;
	
	glutPostRedisplay();
}

void update() {
	static int antes = 0;
	int ahora;
	float tiempo;

	ahora = glutGet(GLUT_ELAPSED_TIME);
	tiempo = (ahora - antes) / 10.0;

	at_z += (velocidad * 0.01) * cos(direccion) * tiempo;
	at_x += (velocidad * 0.01) * -sin(direccion) * tiempo;

	look_at_z = at_z + cos(direccion) * tiempo;
	look_at_x = at_x - sin(direccion) * tiempo;

	antes = ahora;
	if (velocidad > 0) {
		rotate_tire = int(rotate_tire + velocidad) % 360;
	}
	else {
		rotate_tire = 0;
	}

	glutPostRedisplay();
}

void onSpecialKey(int specialKey, int x, int y) {
	//Callback de atencion al pulsado de letras y numeros

	switch (specialKey) {
	case GLUT_KEY_UP:
		velocidad = min(velocidad + 0.5, 90);
		stoplight = 0;
		gira_aguja = max (gira_aguja - 3, -315);
		break;
	case GLUT_KEY_DOWN:
		velocidad = max(0, velocidad - 0.5);
		stoplight = 1;		
		gira_aguja = min(gira_aguja + 3, -45);
		break;
	case GLUT_KEY_LEFT:
		if (velocidad > 10) {
			if (dificultad == 0) direccion -= 1 * PI / 180;
			if (dificultad == 1) direccion -= 1 * PI / 180;
			if (dificultad == 2) direccion -= 1 * PI / 180;
		}
		else {
			direccion -= 1 * PI / 180;
		}
		angleB -= 1;
		break;
	case GLUT_KEY_RIGHT:
		if (velocidad > 10) {
			if (dificultad == 0) {
				direccion += 1 * PI / 180;
			}
			if (dificultad == 1) {
				direccion += 1 * PI / 180;
			}
			if (dificultad == 2) {
				direccion += 1 * PI / 180;
			}
		}
		else {
			direccion += 1 * PI / 180;			
		}
		angleB += 1;
		break;
	}

	// Encolar
	glutPostRedisplay();

}

void onKey(unsigned char tecla, int x, int y) {
	static int lightOn = 0;

	switch (tecla) {
	case 'l':
	case 'L':
		if (dia == 0) {
			GLfloat luz_dif[] = { 1, 1, 251 / 255.0, 1.0 };
			GLfloat luz_esp[] = { 0.0, 0.0, 0.0, 1.0 };

			glLightfv(GL_LIGHT0, GL_AMBIENT, luz_dif);
			glLightfv(GL_LIGHT0, GL_DIFFUSE, luz_dif);
			glLightfv(GL_LIGHT0, GL_SPECULAR, luz_esp);

			dia = 1;
			glFogfv(GL_FOG_COLOR, BLANCO);
		}
		else {
			GLfloat luz_dif[] = { 0.05, 0.05, 0.05, 1.0 };
			GLfloat luz_esp[] = { 0.0, 0.0, 0.0, 1.0 };

			glLightfv(GL_LIGHT0, GL_AMBIENT, luz_dif);
			glLightfv(GL_LIGHT0, GL_DIFFUSE, luz_dif);
			glLightfv(GL_LIGHT0, GL_SPECULAR, luz_esp);

			dia = 0;
			glFogfv(GL_FOG_COLOR, GRISOSCURO);
		}
		break;
	case 's':
	case 'S':
		if (alambrico == 0) {
			glDisable(GL_TEXTURE_2D);
			glDisable(GL_LIGHTING);
			alambrico = 1;
		}
		else {
			glEnable(GL_TEXTURE_2D);
			glEnable(GL_LIGHTING);
			alambrico = 0;
		}
		break;

	case 'x':
	case 'X':
		if (colision == 0) colision = 1;
		else colision = 0;
		break;

	case 'n':
	case 'N':
		if (fog == 0) {
			glEnable(GL_FOG);
			if (dia == 0) glFogfv(GL_FOG_COLOR, GRISOSCURO);
			else glFogfv(GL_FOG_COLOR, BLANCO);			
			glFogf(GL_FOG_DENSITY, 0.1);
			fog = 1;
		}
		else {
			glDisable(GL_FOG);
			if (dia == 0) glFogfv(GL_FOG_COLOR, GRISOSCURO);
			else glFogfv(GL_FOG_COLOR, BLANCO);
			glFogf(GL_FOG_DENSITY, 0.1);
			fog = 0;
		}
		break;

	case 'd':
	case 'D':
		if (dificultad == 0) {
			amplitud = 6; // dificultad media
			dificultad = 1;
		}
		else if(dificultad == 1){
			amplitud = 9;
			dificultad = 2;
		}
		else if (dificultad == 2) {
			amplitud = 3;
			dificultad = 0;
		}

		at_z = 0;
		at_x = 0;
		velocidad = 0;
		pos_farola = 0.0;
		pos_carretera = 0.0;
		pos_anuncio = 0.0;
		gira_aguja = -45;
		angleB = 0;

		break;

	case 'c':
	case 'C':
		if (hud == 0) hud = 1;
		else hud = 0;
		break;

	case 27:
		exit(0);
	}

	glutPostRedisplay();
}



void onTimer(int valor)
// Funcion de atencion al timer periodico
{
	glutTimerFunc(valor, onTimer, valor); // Se encola un nuevo timer
	update();
}


int main(int argc, char ** argv)
{
	//Inicializaciones
	FreeImage_Initialise();
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(960, 540);

	//Crear la ventana
	glutCreateWindow("PROYECTO");

	init();
	std::cout << PROYECTO << " running" << std::endl;
	std::cout << "Flechas: " "Giro y acceleracion" << std::endl;
	std::cout << "'L': Cambio dia/noche" << std::endl;
	std::cout << "'N': Cambio visibilidad escasa/buena" << std::endl;	
	std::cout << "'S': Cambio alambrico/solido" << std::endl;
	std::cout << "'C': Cambio instrumentacion ON/OFF" << std::endl;
	std::cout << "'X': Cambio colision ON/OFF" << std::endl;
	std::cout << "'D': Cambio dificultad circuito EASY/MEDIUM/HARD" << std::endl;
	std::cout << "ESC: Salir" << std::endl;

	//Callbacks
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutSpecialFunc(onSpecialKey);
	glutKeyboardFunc(onKey);
	glutTimerFunc(1000 / tasaFPS, onTimer, 1000 / tasaFPS);

	//Poner en marcha el bucle de atenci�n a eventos
	glutMainLoop();
	FreeImage_DeInitialise();

	return 0;

}
