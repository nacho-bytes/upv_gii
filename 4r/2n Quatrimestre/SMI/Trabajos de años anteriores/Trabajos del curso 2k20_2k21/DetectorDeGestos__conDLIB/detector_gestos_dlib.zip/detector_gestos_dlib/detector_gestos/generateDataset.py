# Import libraries
import glob
import cv2
import os
import sys
import time
import shutil

def main(args):

    if(len(args) < 3):
        print("Modo de uso:\n   python3 generateDataset.py <arg1> <arg2>\n   arg1: directorio donde se guardaran las imágenes\n   arg2: archivo de texto dondese guardarán las coordenadas de cada imagen")
        return

    # directorio donde guardaremos las imagenes y las bounding box
    # carpeta/gestoX
    directory = args[1] #'./train_images/gesto1'
    box_file = args[2] #'./train_images/boxes_gesto1.txt'
    # si cleanup==true, las nuevas imagenes no sobreescribiran las anteriores
    cleanup = False
    # ventana de opencv tamaño normal
    cv2.namedWindow('frame', cv2.WINDOW_NORMAL)
    # resizea la ventana y se ajusta al centro
    cv2.resizeWindow('frame', 1920, 1080)
    cv2.moveWindow('frame',0,0)
    # inicializa la webcam
    cap = cv2.VideoCapture(0)
    # inicializar ventana deslizante para capturar frames del gesto, altura y anchura
    x1, y1 = 0,0
    w_width = 190#140
    w_height = 190
    # guardar imágenes cada 4 frames para no tener muchos duplicados
    skip_frames = 3
    frame_gap = 0
    
    # si hay cleanup borramos todo lo anterior
    if cleanup:
        if os.path.exists(directory):
            shutil.rmtree(directory)
        open(box_file, 'w').close()
        counter = 0
    elif os.path.exists(box_file):
        # hay que añadir las nuevas imágenes a las anteriores
        with open(box_file, 'r') as text_file:
            box_content = text_file.read()
        # el contador empieza en el punto más alto
        counter = int(box_content.split(':')[-2].split(',')[-1])
    else: 
        counter = 0
    # abre o crea el text file
    fr = open(box_file, 'a')
    # crea el directorio si no existe
    if not os.path.exists(directory):
        os.mkdir(directory)
    ####
    initial_wait = 0
    while(True):

        # Abre la cámara
        ret, frame = cap.read()
        if not ret:
            break
        # # Visión espejo de la cámara
        frame = cv2.flip (frame, 1 )
        # Copia del frame original
        orig = frame.copy()
        # Espera de los rimeros 60 frames para colocar la mano correctamente
        if initial_wait > 60:
            frame_gap += 1
            # Mueve la bounding box a la derecha
            if x1 + w_width < frame.shape[1]:
                x1 += 4
                time.sleep(0.1)
            elif y1 + w_height + 270 < frame.shape[1]:
                # si la bounding box ha llegado al límite de la fila,
                # baja una columna
                y1 += 80
                x1 = 0
                # Se pone el frame_gap y la initial_wait a 0
                # para tener tiempo a recolocar la mano
                frame_gap = 0
                initial_wait = 0

            else:
                # Toda la pantalla ha sido recorrida
                break
        else:
            initial_wait += 1
        # Guarda la imagen del frame
        if frame_gap == skip_frames:
            # El nombre de la imagen es igual al contador
            img_name = str(counter) + '.png'
            # Guarda la imagen en el directorio
            img_full_name = directory + '/' + str(counter) + '.png'
            cv2.imwrite(img_full_name, orig)
            # Guarda las coordenadas de la bounding box en un archivo de texto
            fr.write('{}:({},{},{},{}),'.format(counter, x1, y1, x1 + w_width, y1 + w_height))
            counter += 1
            frame_gap = 0
        # Dibuja el rectangulo
        cv2.rectangle(frame, (x1,y1), (x1 + w_width, y1 + w_height), (0,255,0),3)
        # Display the frame
        cv2.imshow('frame', frame)
        if cv2.waitKey(1) == ord('q'):
            break
    # Libera la cámara y cierra el fichero y la ventana
    cap.release()
    cv2.destroyAllWindows()
    fr.close()


if __name__ == "__main__":
    main(sys.argv)