//----------------------------------------------------------------------
//	Información del código
//----------------------------------------------------------------------
//
// Este juego Endless run parte de la modificación del ejemplo Snowman.c
// dentro de este código se encuentran las funciones que permiten al usuario
// moverse por lo carriles y, además, contiene todas las operaciones
// para adaptar la cámara al movimiento escogido,
//
//----------------------------------------------------------------------

#include <stdlib.h> // standard definitions
#include <math.h> // math definitions
#include <stdio.h> // standard I/O

#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/freeglut.h>

#include <time.h>
#include <stdbool.h>

#include <AL/al.h>
#include <AL/alc.h>
#include <AL/alut.h>


// escape key (for exit)
#define ESC 27

//definir un identificador de los carriles
#define ladoDerecho 58
#define ladoIzquierdo 57
#define central 66
#define KEY_LEFT 105

//new
int xpos = 0;
int ypos = 0;
int newy = 0;
int newx = 0;

#define PI 3.14159265f

//Estados del juego
#define PAUSA 5
#define JUEGO 6
int estado = PAUSA;
int negativo = 255;
float distancia = 0;

unsigned short scoreVueltas[7][7];
int indexV = 0;
int vueltas = 0;


bool muerto = false;
bool controles = true;

//Estructura que se emplee para almacenar las posiciones de los obejtos, esto permite detectar las colisiones
struct Renderizados {
	float x;
	float y;
	float z;
	int type; //0 son Vallas, 1 son PowerUps
}objetosMapa[16];
//28: 8 Powerups 20 vallas
//23: 8 Powerups 15 Vallas
//16: 6 Powerups 10 Vallas

//Variables para controlar las vidas
bool escudo = false; //Empezamos con escudo siempre + una cantidad de vidas
int hits = 3; //La cantidad de vidas con las que empezamos
int hitsInteraccion=0; //Servirá para guardar con que objeto se ha golpeado previamente el jugador

//Sonidos
#define NUM_BUFFERS 8
#define NUM_SOURCES 8

#define SONIDO_AMBIENTE 0
#define SONIDO_GOLPE 1
#define SONIDO_MUERTE 2
#define SONIDO_PAUSA 3
#define SONIDO_POWERUP 4
#define SONIDO_ULTI 5
#define SONIDO_ROMPER 6
#define SONIDO_VEL 7

//Buffers y sus posiciones
// Buffers hold sound data.
ALuint Buffers[NUM_BUFFERS];

// Sources are points of emitting sound.
ALuint Sources[NUM_SOURCES];

// Position of the source sounds.
ALfloat SourcesPos[NUM_SOURCES][3];

// Velocity of the source sounds.
ALfloat SourcesVel[NUM_SOURCES][3];

// Position of the listener.
ALfloat ListenerPos[] = { 0.0, 0.0, 0.0 };

// Velocity of the listener.
ALfloat ListenerVel[] = { 0.0, 0.0, 0.0 };
// Orientation of the listener. (first 3 elements are "at", second 3 are "up")
ALfloat ListenerOri[] = { 0.0, 0.0, 1.0, 0.0, 1.0, 0.0 };

//----------------------------------------------------------------------
// Global variables
//----------------------------------------------------------------------
// Camera position
float x = 0.0, y = -5.0; // initially 5 units south of origin
float moverLados = 0.0;
int opcion = central;
float velocidad = 0.1;

//
// Cargar Datos de sonido
//
ALboolean LoadALData()
{
	
   alGenBuffers(NUM_BUFFERS, Buffers);

    if(alGetError() != AL_NO_ERROR){return AL_FALSE;}
    
    Buffers[SONIDO_AMBIENTE] = alutCreateBufferFromFile( "sounds/fondo.wav" );
    Buffers[SONIDO_GOLPE] = alutCreateBufferFromFile( "sounds/golpe.wav" );
    Buffers[SONIDO_MUERTE] = alutCreateBufferFromFile( "sounds/muerte.wav" );
    Buffers[SONIDO_PAUSA] = alutCreateBufferFromFile( "sounds/pausa.wav" );
    Buffers[SONIDO_POWERUP] = alutCreateBufferFromFile( "sounds/powerup.wav" );
    Buffers[SONIDO_ULTI] = alutCreateBufferFromFile( "sounds/lastchance.wav" );
    Buffers[SONIDO_ROMPER] = alutCreateBufferFromFile( "sounds/romperescudo.wav" );
    Buffers[SONIDO_VEL] = alutCreateBufferFromFile( "sounds/masvel.wav" );

    
    alGenSources(NUM_SOURCES, Sources);

    if(alGetError() != AL_NO_ERROR)
    	return AL_FALSE;
    
    for(int i=0; i < 8; i++) {
	    alSourcei (Sources[i], AL_BUFFER,   Buffers[i]   );
	    
	    alSourcef (Sources[i], AL_PITCH,    1.0f              );
	    
	    if(i==0) {alSourcef (Sources[i], AL_GAIN,     0.01f              );}
	    else if(i==3|| i==5) {alSourcef (Sources[i], AL_GAIN,     0.1f              );}
	    else {alSourcef (Sources[i], AL_GAIN,     1.5f              );}
	    
	    alSourcefv(Sources[i], AL_POSITION, SourcesPos[i]);
	     
	    alSourcefv(Sources[i], AL_VELOCITY, SourcesVel[i]);
	    
	    if(i==0) {alSourcei (Sources[i], AL_LOOPING,  AL_TRUE           );} 
	    else {alSourcei (Sources[i], AL_LOOPING,  AL_FALSE           );}
	    
    }
    
    
    // Do another error check and return.

    if(alGetError() != AL_NO_ERROR)
      return AL_FALSE;

    return AL_TRUE;
}
void SetListenerValues()
{
  alListenerfv(AL_POSITION,    ListenerPos);
  alListenerfv(AL_VELOCITY,    ListenerVel);
  alListenerfv(AL_ORIENTATION, ListenerOri);
}
void KillALData()
{
  alDeleteBuffers(NUM_BUFFERS, Buffers);
  alDeleteSources(NUM_SOURCES, Sources);
  alutExit();
}

//----------------------------------------------------------------------
// Reshape callback
//
// Window size has been set/changed to w by h pixels. Set the camera
// perspective to 45 degree vertical field of view, a window aspect
// ratio of w/h, a near clipping plane at depth 1, and a far clipping
// plane at depth 100. The viewport is the entire window.
//
//----------------------------------------------------------------------
void changeSize(int w, int h) 
{
	float ratio =  ((float) w) / ((float) h); // window aspect ratio
	glMatrixMode(GL_PROJECTION); // projection matrix is active
	glLoadIdentity(); // reset the projection
	gluPerspective(45.0, ratio, 0.1, 100.0); // perspective transformation
	glMatrixMode(GL_MODELVIEW); // return to modelview mode
	glViewport(0, 0, w, h); // set viewport (drawing area) to entire window
}

//----------------------------------------------------------------------
//Método nuevo para dibujar el cactus
//----------------------------------------------------------------------
void dibujarCactus(int opcionTronco,int opcionFlor)
{
	//abs(negativo-62)
	//Se dibuja el tronco, siendo grande o pequeño
	glColor3f(abs(negativo-91)/255.0, abs(negativo-111)/255.0, abs(negativo-85)/255.0);
	glPushMatrix();
	if(opcionTronco%2==0) {
		glScalef(0.5,0.5,5.0); //Grande
	} else {
		glScalef(1.0,1.0,2.5); //Pequeño
	}
	glutSolidCube(0.5);
	glPopMatrix();	
	
	
	//Se dibuja la flor dependiendo el tamaño del tronco
	if(opcionTronco%2==1) {
		//Flor Grande para el cactus pequeño
		glColor3f(abs(negativo-168)/255.0, abs(negativo-50)/255.0, abs(negativo-104)/255.0);
		glPushMatrix();
			glTranslatef(0.0, 0.0, 0.65);
			glScalef(2.0,2.0,1.0);
			glutSolidSphere(0.1,10.0,10.0);
		glPopMatrix();
	} else if (opcionFlor==0) {
		//Rama al lado derecho parte superior
		glColor3f(abs(negativo-73)/255.0, abs(negativo-89)/255.0, abs(negativo-68)/255.0);
		glPushMatrix();
			glTranslatef(0.2, 0.0, 1.0);
			glScalef(0.6,0.2,0.2);
			glutSolidCube(0.5);
		glPopMatrix();
		//Flor roja
		glColor3f(abs(negativo-253)/255.0, abs(negativo-94)/255.0, abs(negativo-83)/255.0);
		glPushMatrix();
			glTranslatef(0.25, 0.0, 1.05);
			glScalef(0.5,0.5,0.5);
			glutSolidSphere(0.1,10.0,10.0);
		glPopMatrix();
	} else {
		//Rama al lado izquierdo parte inferior
		glColor3f(abs(negativo-73)/255.0, abs(negativo-89)/255.0, abs(negativo-68)/255.0);
		glPushMatrix();
			glTranslatef(-0.2, 0.0, 0.3);
			glScalef(0.6,0.2,0.2);
			glutSolidCube(0.5);
		glPopMatrix();
		//Flor amarilla
		glColor3f(abs(negativo-168)/255.0, abs(negativo-164)/255.0, abs(negativo-50)/255.0);
		glPushMatrix();
			glTranslatef(-0.25, 0.0, 0.35);
			glScalef(0.5,0.5,0.5);
			glutSolidSphere(0.1,10.0,10.0);
		glPopMatrix();
	}
	
}
//
//
//
void showMessage(GLfloat x, GLfloat y, GLfloat z, char *message)
{
  glPushMatrix();
  glColor3f(abs(negativo-255),abs(negativo-255),abs(negativo-255));
  glTranslatef(x, y, z);
  glRotatef(90,1.0,0.0,0.0);
  glScalef(0.001, 0.001, 0.001);
  while (*message) {
    glutStrokeCharacter(GLUT_STROKE_ROMAN, *message);
    message++;
  }
  glPopMatrix();
}
void showMessageC(GLfloat x, GLfloat y, GLfloat z, char *message)
{
  glPushMatrix();
  glColor3f(255,255,255);
  glTranslatef(x, y, z);
  glRotatef(90,1.0,0.0,0.0);
  glScalef(0.0006, 0.0006, 0.0006);
  while (*message) {
    glutStrokeCharacter(GLUT_STROKE_ROMAN, *message);
    message++;
  }
  glPopMatrix();
}
void showMessageCR(GLfloat x, GLfloat y, GLfloat z, char *message)
{
  glPushMatrix();
  glColor3f(255,0,0);
  glTranslatef(x, y, z);
  glRotatef(90,1.0,0.0,0.0);
  glScalef(0.0006, 0.0006, 0.0006);
  while (*message) {
    glutStrokeCharacter(GLUT_STROKE_ROMAN, *message);
    message++;
  }
  glPopMatrix();
}
//new
void mostrarValores() {
	if(estado!=PAUSA) {
		char dist[20];
		sprintf(dist,"%d",(int)distancia);
		showMessage(x,y+2.0,1.6,dist);
	} else {
		
		glColor3f(0/255.0, 0/255.0, 0/255.0);
		glBegin(GL_QUADS);
			glVertex3f(x-20.0, y+3, 0);
			glVertex3f(x+20.0,  y+3, 0);
			glVertex3f(x+20.0,  y+3, 6);
			glVertex3f(x-20.0, y+3, 6);
		glEnd();
		//sprintf(dist,"%d",(int)distancia);
		if(muerto) {
			showMessageCR(x-0.6,y+2.0,1.7,"Has Perdido!");
		}
		char ctrl1[25] = "Endlessrun SMII 2020/21:";
		char ctrl2[39] = "- Controles: Teclado/Raton/Dualshock 4";
		char ctrl3[46] = "-> Flechas Laterales/Mover Raton/Pantalla DS4";
		char ctrl4[31] = "-> E/e: Empezar/Pausar Partida";
		char ctrl5[31] = "-> ESC, Q, q: Salir del juego.";
		char ctrl6[37] = "-> Recordatorio: La camara se centra";
		char ctrl7[27] = "sola al soltar las flechas";
		char ctrl8[30] = "Creditos: Pablo A. & David C.";
		showMessageC(x-1.6,y+2.0,1.7,ctrl1); showMessageC(x-1.6,y+2.0,1.5,ctrl2); showMessageC(x-1.4,y+2.0,1.3,ctrl3); showMessageC(x-1.4,y+2.0,1.1,ctrl4);
		showMessageC(x-1.4,y+2.0,0.9,ctrl5); showMessageC(x-1.4,y+2.0,0.7,ctrl6); showMessageC(x-1.2,y+2.0,0.5,ctrl7); showMessageC(x-1.2,y+2.0,0.3,ctrl8); 
		
		
		char runActual[15];
		unsigned short dst = distancia;
		sprintf(runActual,"Distancia: %hu",dst);
		showMessageC(x+0.7,y+2.0,1.6,runActual);
		
		//char scoreVueltas[10][15];
		//int vueltas = 0;
		for(unsigned short i = 0; i < indexV; i++) {
			char vueltaX[15];
			sprintf(vueltaX,"Vuelta %hu: %hu",i,scoreVueltas[i][i]);
			float ajuste = i * 0.2;
			showMessageC(x+0.7,y+2.0,(1.4-ajuste),vueltaX);
		}
	}
}

//----------------------------------------------------------------------
// Método para dibujar las vallas
//----------------------------------------------------------------------
void dibujarValla() {

	//Poste Izquierdo
	glColor3f(abs(negativo-139)/255.0, abs(negativo-69)/255.0, abs(negativo-19)/255.0);
	glPushMatrix();
		glTranslatef(-0.50, 0.0, 0.0);
		glScalef(0.5,0.5,3.0);
		glutSolidCube(0.5);
	glPopMatrix();
	
	//Poste Derecho
	glPushMatrix();
		glTranslatef(0.50, 0.0, 0.0);
		glScalef(0.5,0.5,3.0);
		glutSolidCube(0.5);
	glPopMatrix();
	
	
	//Barras Interiores
	glColor3f(abs(negativo-160)/255.0, abs(negativo-82)/255.0, abs(negativo-45)/255.0);
	glPushMatrix();
		glTranslatef(0.0, 0.0, 0.5);
		glScalef(1.50,0.3,0.3);
		glutSolidCube(0.5);
	glPopMatrix();
	glPushMatrix();
		glTranslatef(0.0, 0.0, 0.2);
		glScalef(1.50,0.3,0.3);
		glutSolidCube(0.5);
	glPopMatrix();
}

//----------------------------------------------------------------------
// Función creada para renderizar los objetos valla, cactus y powerup
//----------------------------------------------------------------------
void renderizarObjetos() {
	
	srand((unsigned) time(NULL));
	//Dibujar las vallas en el mapa de forma aleatoria
	for(int i = 1; i < 14; i++){
		int random = rand() % 3;
		
		//Prueba de renderizado sobre carril central
		float posX =0.0;
		glPushMatrix();
			if(random==0) {glTranslatef(-5.0, i*15, 0.0); posX=-5.0;}
			else if (random==1){glTranslatef(5.0, i*15, 0.0); posX=5.0;}
			else {glTranslatef(0.0, i*15, 0.0);}
			dibujarValla();
		glPopMatrix();
		
		//Solo nos interesa alamcenar los primeros objetos, los otros están para añadir profundidad al mapa
		if(i < 10) {objetosMapa[i].x=posX; objetosMapa[i].y=i*15; objetosMapa[i].z=0; objetosMapa[i].type=0;}
	}
	
	//Añadir los powerups al mapa
	for(int i = 10; i < 13; i++) {
		int randomLoc = rand() % 3;
		float randomDist = rand() % 41;
		float posX =0.0, posY=0.0;
		glPushMatrix();
			glColor3f(abs(negativo-134)/255.0, abs(negativo-33)/255.0, abs(negativo-181)/255.0);
			
			if(randomLoc==0) {glTranslatef(-5.0, 0.0+randomDist, 0.5); posX=-5.0; posY=0.0+randomDist;}
			else if (randomLoc==1){glTranslatef(5.0, 41.0+randomDist, 0.5); posX=5.0; posY=41.0+randomDist;}
			else {glTranslatef(0.0, 81.0+randomDist, 0.5); posY=81.0+randomDist;}
			
			glutSolidSphere(0.2,20,20);
		glPopMatrix();
		//Almacenar los powerups en el array de objetos renderizados
		objetosMapa[i].x=posX; objetosMapa[i].y=posY; objetosMapa[i].z=0.5; objetosMapa[i].type=1;
	}
	
	//Dibujar los cactus como entorno para el mapa
	for(int i = 0; i < 24; i++) {
		glPushMatrix();
			glTranslatef(15.0, i*8.5, 0);
			if(i%3==0) {dibujarCactus(0,0);}
			else if(i%2==0) {dibujarCactus(0,1);}
			else {dibujarCactus(1,2);}
			//dibujarCactus(opcionTronco,opcionFlor);
		glPopMatrix();
		glPushMatrix();
			glTranslatef(-15.0, i*8.5, 0);
			if(i%3==0) {dibujarCactus(0,1);}
			else if(i%2==0) {dibujarCactus(0,0);}
			else {dibujarCactus(1,2);}
		glPopMatrix();
	}
}

//----------------------------------------------------------------------
// Función creada para detectar als colisiones con los objetos de la
// carretera
//----------------------------------------------------------------------
void detectarColision() {
	for(int i = 1; i < 13; i++) {
		if( (y < (objetosMapa[i].y+1.0) && y > (objetosMapa[i].y-1.0))  && (objetosMapa[i].x==x)) {
			
			//Si ya hemos chocadp cpntra este objeto no hacemos nada
			//Se añade esta comprobación ya que la detección falla en caso
			/// de nor tenerla.
			if(hitsInteraccion!=i) {hitsInteraccion=i;} else {break;}
			
			
			//Depende del objeto hacemos x o y
			switch(objetosMapa[i].type) {
				case 0: 
					//SI tenemos escudo no perdemos vida, pero si perdemos el escudo
					//sino vemos si quedan vidas, en caso de ser afirmativo perderemos 
					//una y en caso contrario moriremos. Esto provocará que el juego se pause
					//y volvamos a la posición incial junto con la velocidad predeterminada.
					if(escudo) {
						alSourcePlay(Sources[SONIDO_ROMPER]);
						escudo=false; 
					} else {
						if(hits<=0) {
							//printf("Distancia recorrida en este intento: %d", (int)distancia); 
							scoreVueltas[indexV][indexV] = distancia;
							estado=PAUSA; y=-5.0; velocidad=0.1; distancia=0; escudo=false; hits=3;
							//MOD AQUI
							/*
							unsigned short scoreVueltas[10][10];
							int indexV = 0;
							*/
							indexV++;
							if(indexV==7) {indexV=0;}
							muerto = true;
							alSourcePlay(Sources[SONIDO_MUERTE]);
							
						}
						else { 
							hits--; alSourcePlay(Sources[SONIDO_GOLPE]);
							if(hits==1) {alSourcePlay(Sources[SONIDO_ULTI]);}
						}
					} 
					break; 
				case 1: escudo = true; alSourcePlay(Sources[SONIDO_POWERUP]);
					break;
			}
			
		}
		
	}
}
//----------------------------------------------------------------------
// Update with each idle event
//
// Se encarga de centrar el movimiento en un carril y pedir que se vuelva a renderizar.
// 
//----------------------------------------------------------------------
void update(void) 
{	
	//Si estamos jugando es oportuno analizar la situación del juego
	if(estado==JUEGO) {
		//SI llegamos a esta distancia reiniciamos la posición dando
		//la sensación de que el mapa es infinito, además, aumentamos la 
		//velocidad para dar dificultad
		distancia+=velocidad;
		if(y >=120.0) {
			y=-5.0; 
			vueltas++;
			velocidad += 0.05;
			alSourcePlay(Sources[SONIDO_VEL]);
		}else {
			//Detectamos colisiones y aumentamos la distancia según la 
			//velocidad marcada
			detectarColision();
			y+=velocidad; 
			//Mover hacía la posición
			switch(opcion) {
				case ladoIzquierdo: if(x==5.0 || x==0.0) {x-=5.0;}break;
				case ladoDerecho: if(x==-5.0 || x==0.0) {x+=5.0;} break;
				case central: x=0.0;
			}
			//--------------------------------
			//  Descomentando esto la funcionalidad sería la misma y volvería al centro, pero con el control del ratón vuelve muy rápido y no se puede jugar bien
			//-------------------------------
			// -> opcion = central;
		}
	}
	
	glutPostRedisplay(); // redisplay everything
}

//----------------------------------------------------------------------
// Draw the entire scene
//
// Dibuja la escana y adapta los colores según el estado del programa (Pausa/Juego).
// 
//----------------------------------------------------------------------
void renderScene(void) 
{
	if(estado==PAUSA) {negativo=255;} else {negativo=0;}
	
	// Limpia el buffer y el color. Establecemos el cielo con un azul nocturno
	glClearColor(abs(negativo-62)/255.0, abs(negativo-89)/255.0, abs(negativo-133)/255.0, 1.0);
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Reset transformations
	glLoadIdentity();
	
	// Set the camera centered at (x,y,1) and looking along directional
	// vector (lx, ly, 0), with the z-axis pointing up
	gluLookAt(
			x,      y,      1.0,
			x ,     y+1.0,      1.0,
			0.0,    0.0,    1.0);
		
	// Suelo exterior, representa la arena
	glColor3f(abs(negativo-219)/255.0, abs(negativo-209)/255.0, abs(negativo-180)/255.0);
	glBegin(GL_QUADS);
		glVertex3f(-30.0, -30.0, 0.0);
		glVertex3f(-30.0,  200.0, 0.0);
		glVertex3f( 30.0,  200.0, 0.0);
		glVertex3f( 30.0, -30.0, 0.0);
	glEnd();
	
	//Suelo interior, representa una carretera
	glColor3f(abs(negativo-120)/255.0, abs(negativo-122)/255.0, abs(negativo-125)/255.0);
	glBegin(GL_QUADS);
		glVertex3f(-10.0, -10.0, 0.1);
		glVertex3f(-10.0,  200.0, 0.1);
		glVertex3f( 10.0,  200.0, 0.1);
		glVertex3f( 10.0, -10.0, 0.1);
	glEnd();
	
	/* Para comprobar que se reinicia la posición -> Se borrará en la versión final
	glPushMatrix();
			glTranslatef(0.0, 0.0, 0.0);
			dibujarCactus();
	glPopMatrix();
	*/
	
	//Se aplica el renderizado de objetos
	renderizarObjetos();
	mostrarValores();
	glutSwapBuffers(); // Make it all visible
} 

//----------------------------------------------------------------------
// User-input callbacks
//
// processNormalKeys: Esc, Q, q para salir del programa. W, A, D para moverse por los carriles. P para pausar el juego.
// pressSpecialKey: Flecha Superior permite pausar, las otras tres son para el movimiento.
// releaseSpecialKey: AL liberar una tecla de movimiento posiciona al jugar en el carril central.

//----------------------------------------------------------------------
void processNormalKeys(unsigned char key, int xx, int yy)
{
	//Si el callback glutSpecialUpFunc está activado se puede comentar todo el case W y w.
	
	switch(key) {
		case ESC:
		case 'q':
		case 'Q':exit(0); break;
		/*
		case 'w':
		case 'W': moverLados = 0; opcion = central; break;
		case 'a': 
		case 'A': moverLados = -5.0; opcion= ladoIzquierdo; break;
		case 'd': 
		case 'D': moverLados = 5.0; opcion = ladoDerecho;break;
		*/
		case 'e':
		case 'E':  if(estado==PAUSA) {estado=JUEGO;} else {estado=PAUSA;} 
			   alSourcePlay(Sources[SONIDO_PAUSA]); if(muerto){muerto=false;}
			   break;
	}
} 

void pressSpecialKey(int key, int xx, int yy)
{
	//Si el callback glutSpecialUpFunc está activado se puede comentar todo el case GLUT_KEY_DOWN
	
	switch (key) {
		case GLUT_KEY_RIGHT : 
			moverLados = 5.0; 
			opcion = ladoDerecho;
			break;
		case GLUT_KEY_LEFT : 
			moverLados = -5.0;
			opcion= ladoIzquierdo;
			break;
		//case GLUT_KEY_UP:
			//if(estado==PAUSA) {estado=JUEGO;} else {estado=PAUSA;}
			//alSourcePlay(Sources[SONIDO_PAUSA]);
			//break;
		//case GLUT_KEY_DOWN:
			//moverLados = 0;
			//opcion = central;
			//break;
		
	}
} 

void releaseSpecialKey(int key, int x, int y) 
{
	switch (key) {
		case GLUT_KEY_RIGHT : moverLados = 0.0; opcion=central; break;
		//case GLUT_LEFT_BUTTON : break;
		case GLUT_KEY_LEFT : moverLados = 0.0; opcion=central; break;
 	}
} 
//----------------------------------------------------------------------
// Suponemos que el ratón está en el centro de la pantalla en el primer instante (intentar colocarlo ahí)
// Una vez guardado en la variable global, ir recuperando la nueva posición y comparando para modifica la variable opcion
// ROI izquierda: primer cuarto de GLUT_SCREEN_WIDTH
// ROI derecha: último cuarto de GLUT_SCREEN_WITH
// ROI central: 2do y 3er cuarto de ""
//----------------------------------------------------------------------
void movimiento(int x, int y) {	
	int width = glutGet(GLUT_WINDOW_WIDTH);
	//printf("{Ancho de la pantalla: %d, ", width);
	int primercuarto = width/4;
	int ultimocuarto = primercuarto * 3;
	//printf(" [1=%d|3=%d] -> pos:%d ",primercuarto,ultimocuarto,x);
	if (x <= primercuarto) { 
		opcion = ladoIzquierdo; //printf("Ratón en pos. izquierda}\n");  
	} else if (x >= ultimocuarto) { 
		opcion = ladoDerecho; //printf("Ratón en pos. derecha}\n");  
	}
	else { 
		opcion = central; //printf("Centrar!}\n");  
	}
	newx = x;
	newy = y; 
	
	/*if (newx < xpos) { 
		opcion = ladoIzquierdo;
	} else if (newx > xpos) {
		opcion = ladoDerecho;
	}
		switch (opcion){
		case central:
		if (newx < xpos && newy > ypos ) { 
			opcion = ladoIzquierdo;
			printf("Se mueve hacia la izquieda");
		} else if (newx > xpos && newy > ypos) {
			opcion = ladoDerecho;
			printf("Se mueve hacia la derecha");
		}
		break;
		case ladoIzquierdo:
		if (newx > xpos) {
			opcion = central;
		}
		break;
		case ladoDerecho:
		if (newx < xpos) {
			opcion = central;
		}

		}*/
	}
//----------------------------------------------------------------------
// Main program  - standard GLUT initializations and callbacks
//----------------------------------------------------------------------
int main(int argc, char **argv) 
{
	/*
	printf("\n\
-----------------------------------------------------------------------\n\
  Endlessrun SMII 2020/21:\n\
  - Controles:\n\
  -> Flechas Laterales: Movimiento entre carriles\n\
  -> E/e: Pausar el juego. \n\
  -> ESC, Q, q: Salir del juego.\n\
  -> Recordatorio: La camára se centra sola al soltar las flechas\n\
-----------------------------------------------------------------------\n");*/
	alutInit(NULL, 0);
	alGetError();

	if(LoadALData() == AL_FALSE)
    	return 0;

	SetListenerValues();
	atexit(KillALData);

	// general initializations
	
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(800, 400);
	glutCreateWindow("Endlessrun SMII 2020/21");
	
	alSourcePlay(Sources[SONIDO_AMBIENTE]);
	// register callbacks
	
		glutReshapeFunc(changeSize); // window reshape callback
		glutDisplayFunc(renderScene); // (re)display callback
		glutIdleFunc(update); // incremental update
		
		//CONTROLES 
		glutKeyboardFunc(processNormalKeys); // process standard key clicks
		glutSpecialFunc(pressSpecialKey); // process special key pressed
		glutSpecialUpFunc(releaseSpecialKey); // process special key release
		//new
		glutPassiveMotionFunc(movimiento);


	

	// OpenGL init
	glEnable(GL_DEPTH_TEST);

	// enter GLUT event processing cycle
	glutMainLoop();

	return 0; // this is just to keep the compiler happy
}
