# Solar System in C++ using legacy OpenGL

## How to run in Visual Studio

1. Open SolarSystem.vcxproj

2. Run

3. Look at console for interaction instructions


## Example

##### Solar System with labels on and orbital trails

![SolarSystem](http://i.imgur.com/iY0HtjV.png)
