#include <iostream>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <GL/glext.h>
#include "imageloader.h"
#pragma comment(lib, "glew32.lib")
#include <GL/glut.h>
#include <math.h>
//includes para reproducir sonido
#include <windows.h>
#include <mmsystem.h>
//includes para texto en pantalla
#include <fstream>
#include <stdlib.h>
//define para la camara
#define FPS 60
#define TO_RADIANS 3.14/180.0



using namespace std;



//definicion de la clase planeta
class Planet {
public:
	float radius, distance, orbit, orbitSpeed, axisTilt, axisAni;
	Planet(float _radius, float _distance, float _orbit, float _orbitSpeed, float _axisTilt, float _axisAni) {
		radius = _radius;
		distance = _distance;
		orbit = _orbit;
		orbitSpeed = _orbitSpeed;
		axisTilt = _axisTilt;
		axisAni = _axisAni;
	}

	void drawSmallOrbit(void) {
		glPushMatrix();
		glColor3ub(255, 255, 255);
		glRotatef(90.0, 1.0, 0.0, 0.0);
		glutWireTorus(0.001, distance, 100.0, 100.0);
		glPopMatrix();
	}

	void drawMoon(void) {
		GLUquadricObj* quadric;
		quadric = gluNewQuadric();
		glPushMatrix();
		glColor3ub(255, 255, 255);
		glRotatef(orbit, 0.0, 1.0, 0.0);
		glTranslatef(distance, 0.0, 0.0);
		gluSphere(quadric, radius, 20.0, 20.0);
		glPopMatrix();
	}

	void setSpeed(float factor) {
		orbitSpeed = orbitSpeed * factor;
		/*if (factor == 0.5) {
			glRotatef(orbit, 0.0, 1.0, 0.0);
			glTranslatef(distance, 0.0, 0.0);

			glPushMatrix();
			glRotatef(axisTilt, 1.0, 0.0, 0.0);
			glRotatef(axisAni, 0.0, 1.0, 0.0);
			glRotatef(90.0, 1.0, 0.0, 0.0);
		}*/
		
	}

};



//declaramos variables que seran utiles para la funcion de Seleccion de velocidad
Planet sun(5.0, 0, 0, 0, 0, 0);				//Sun
Planet mer(1.0, 7, 0, 4.74, 02.11, 0);		//Mercury
Planet ven(1.5, 11, 0, 3.5, 177.0, 0);		//Venus
Planet ear(2.0, 16, 0, 2.98, 23.44, 0);		//Earth
Planet mar(1.2, 21, 0, 2.41, 25.00, 0);		//Mars
Planet jup(3.5, 28, 0, 1.31, 03.13, 0);		//Jupiter
Planet sat(3.0, 37, 0, 0.97, 26.70, 0);		//Saturn
Planet ura(2.5, 45.5, 0, 0.688, 97.77, 0);	//Uranus
Planet nep(2.3, 53.6, 0, 0.54, 28.32, 0);	//Neptune
Planet plu(0.3, 59, 0, 0.47, 119.6, 0);		//Pluto
/*Planet lun(.40, 3, 0, 5.4, 0, 0);			//Luna     (Earth)
Planet pho(.20, 1.8, 0, 2.3, 0, 0);		//Phobos   (Mars)
Planet dei(.24, 2.4, 0, 3.6, 0, 0);		//Deimos   (Mars)
Planet eur(.24, 4, 0, 4.4, 0, 0);			//Europa   (Jupiter)
Planet gan(.24, 4.7, 0, 5 , 0, 0);		//Ganymede (Jupiter)
Planet cal(.24, 5.3, 0, 2.3, 0, 0);		//Callisto (Jupiter)
Planet tit(.75, 3.7, 0, 2.4, 0, 0);		//Titan	   (Saturn)
Planet nix(.10, 1.5, 0, 5, 0, 0);		//Nix	   (Pluto)
Planet puc(.26, 2.9, 0, 7, 0, 0);		//Puck	   (Uranus)
Planet tri(.36, 3.2, 0, 3.4 , 0, 0);		//Triton   (Neptune)
*/


//espacio para definir variables globales
int isAnimate = 0;
int moonsActive = 1;
int frameCount = 0;
int zoom = 50;
const int width = 16 * 50;
const int height = 9 * 50;
float pitch = 0.0, yaw = 0.0;
float camX = 0.0, camZ = 0.0;



//definimos funciones
void display();
void reshape(int w, int h);
void timer(int);
void passive_motion(int, int);
void camera();
void keyboard(unsigned char key, int x, int y);
void keyboard_up(unsigned char key, int x, int y);



struct Motion
{
	bool Forward, Backward, Left, Right;
};
Motion motion = { false,false,false,false };



//cambia la velocidad de orbita
void cambiaVelocidad(float factor)
{
	sun.setSpeed(factor);
	mer.setSpeed(factor);
	ven.setSpeed(factor);
	ear.setSpeed(factor);
	mar.setSpeed(factor);
	jup.setSpeed(factor);
	sat.setSpeed(factor);
	ura.setSpeed(factor);
	nep.setSpeed(factor);
	plu.setSpeed(factor);
	/*lun.setSpeed(factor);
	pho.setSpeed(factor);
	dei.setSpeed(factor);
	eur.setSpeed(factor);
	gan.setSpeed(factor);
	cal.setSpeed(factor);
	tit.setSpeed(factor);
	nix.setSpeed(factor);
	puc.setSpeed(factor);
	tri.setSpeed(factor);
	*/

}



//funcion para la interfaz
void writeBitmapString(void* font, char* string)
{
	char* c;
	for (c = string; *c != '\0'; c++) glutBitmapCharacter(font, *c);
}
void printInstrucciones()
{
	glRasterPos3f(0.0, 3, 0.0);
	glColor3ub(255, 255, 255);
	writeBitmapString(GLUT_BITMAP_HELVETICA_12, "HOLAAAAAA");

}



//funciones para el movimiento de la camara con el raton
void init()
{
	glutSetCursor(GLUT_CURSOR_NONE); // hace "invisible" el cursor
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glutWarpPointer(width / 2, height / 2);
}
void timer(int)
{
	glutPostRedisplay();
	glutWarpPointer(width / 2, height / 2);
	glutTimerFunc(1000 / FPS, timer, 0);
}
void passive_motion(int x, int y)
{
	/* two variables to store X and Y coordinates, as observed from the center
	  of the window
	*/
	int dev_x, dev_y;
	dev_x = (width / 2) - x;
	dev_y = (height / 2) - y;

	/* apply the changes to pitch and yaw*/
	yaw += (float)dev_x / 40.0;
	pitch += (float)dev_y / 40.0;
}
void camera()
{

	if (motion.Forward)
	{
		camX += cos((yaw + 90) * TO_RADIANS) / 5.0;
		camZ -= sin((yaw + 90) * TO_RADIANS) / 5.0;
	}
	if (motion.Backward)
	{
		camX += cos((yaw + 90 + 180) * TO_RADIANS) / 5.0;
		camZ -= sin((yaw + 90 + 180) * TO_RADIANS) / 5.0;
	}
	if (motion.Left)
	{
		camX += cos((yaw + 90 + 90) * TO_RADIANS) / 5.0;
		camZ -= sin((yaw + 90 + 90) * TO_RADIANS) / 5.0;
	}
	if (motion.Right)
	{
		camX += cos((yaw + 90 - 90) * TO_RADIANS) / 5.0;
		camZ -= sin((yaw + 90 - 90) * TO_RADIANS) / 5.0;
	}
	/*limit the values of pitch
	  between -60 and 70
	*/
	if (pitch >= 70)
		pitch = 70;
	if (pitch <= -60)
		pitch = -60;

	glRotatef(-pitch, 1.0, 0.0, 0.0); // Along X axis
	glRotatef(-yaw, 0.0, 1.0, 0.0);    //Along Y axis

	glTranslatef(-camX, 0.0, -camZ);
}
//fin de las funciones para mover la camara con el raton



//funcion para animar las esferas
void animate(int n) {
	if (isAnimate) {
		mer.orbit += mer.orbitSpeed;
		ven.orbit += ven.orbitSpeed;
		ear.orbit += ear.orbitSpeed;
		mar.orbit += mar.orbitSpeed;
		jup.orbit += jup.orbitSpeed;
		sat.orbit += sat.orbitSpeed;
		ura.orbit += ura.orbitSpeed;
		nep.orbit += nep.orbitSpeed;
		plu.orbit += plu.orbitSpeed;
		/*lun.orbit += lun.orbitSpeed;
		pho.orbit += pho.orbitSpeed;
		dei.orbit += dei.orbitSpeed;
		eur.orbit += eur.orbitSpeed;
		gan.orbit += gan.orbitSpeed;
		cal.orbit += cal.orbitSpeed;
		tit.orbit += tit.orbitSpeed;
		nix.orbit += nix.orbitSpeed;
		puc.orbit += puc.orbitSpeed;
		tri.orbit += tri.orbitSpeed;
		*/
		if (mer, ven, ear, mar, jup, sat, ura, nep, plu.orbit > 360.0) {
			mer, ven, ear, mar, jup, sat, ura, nep, plu.orbit -= 360.0;
		}
		mer.axisAni += 10.0;
		ven.axisAni += 10.0;
		ear.axisAni += 10.0;
		mar.axisAni += 10.0;
		jup.axisAni += 10.0;
		sat.axisAni += 10.0;
		ura.axisAni += 10.0;
		nep.axisAni += 10.0;
		plu.axisAni += 10.0;
		if (mer, ven, ear, mar, jup, sat, ura, nep, plu.axisAni > 360.0) {
			mer, ven, ear, mar, jup, sat, ura, nep, plu.axisAni -= 360.0;
		}
		glutPostRedisplay();
		glutTimerFunc(30, animate, 1);
	}
}




//funciones para movimiento de camara WASD
void keyboard(unsigned char key, int x, int y) {
	switch (key)
	{
	case 'W':
	case 'w':
		motion.Forward = true;
		break;
	case 'A':
	case 'a':
		motion.Left = true;
		break;
	case 'S':
	case 's':
		motion.Backward = true;
		break;
	case 'D':
	case 'd':
		motion.Right = true;
		break;
	case 27: exit(0); break;
	case ' ':
		if (isAnimate) isAnimate = 0; else { isAnimate = 1; animate(1); }
		break;
	case 'b':
		PlaySound(NULL, 0, 0); 
		break;
	case 'p':
		PlaySound(TEXT("ISmusicaFondo.wav"), NULL, SND_FILENAME | SND_ASYNC); 
		break;
	case 'n':
		cambiaVelocidad(2.0);
		glutPostRedisplay;
		break;
	case 'm':
		cambiaVelocidad(0.5);
		glutPostRedisplay;
		break;
	}
	
}
void keyboard_up(unsigned char key, int x, int y) {
	switch (key)
	{
	case 'W':
	case 'w':
		motion.Forward = false;
		break;
	case 'A':
	case 'a':
		motion.Left = false;
		break;
	case 'S':
	case 's':
		motion.Backward = false;
		break;
	case 'D':
	case 'd':
		motion.Right = false;
		break;
	}
}
//fin funciones WASD	



//cargado de texturas
GLuint loadTexture(Image* image) {
	//http://www.codeincodeblock.com/2012/05/simple-method-for-texture-mapping-on.html
	GLuint textureId;
	glGenTextures(1, &textureId);
	glBindTexture(GL_TEXTURE_2D, textureId);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image->width, image->height, 0, GL_RGB, GL_UNSIGNED_BYTE, image->pixels);
	return textureId;
}
GLuint sunTexture, merTexture, venTexture, earTexture, marTexture, jupTexture, satTexture, uraTexture, nepTexture, pluTexture, staTexture, logTexture;
void setup(void) {
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glEnable(GL_DEPTH_TEST);

	//TEXUTRING SETUP
	glEnable(GL_NORMALIZE);
	glEnable(GL_COLOR_MATERIAL);
	Image* sta = loadBMP("stars.bmp");		staTexture = loadTexture(sta);		delete sta;
	Image* sun = loadBMP("sun.bmp");		sunTexture = loadTexture(sun);		delete sun;
	Image* mer = loadBMP("mercury.bmp");	merTexture = loadTexture(mer);		delete mer;
	Image* ven = loadBMP("venus.bmp");		venTexture = loadTexture(ven);		delete ven;
	Image* ear = loadBMP("earth.bmp");		earTexture = loadTexture(ear);		delete ear;
	Image* mar = loadBMP("mars.bmp");		marTexture = loadTexture(mar);		delete mar;
	Image* jup = loadBMP("jupiter.bmp");	jupTexture = loadTexture(jup);		delete jup;
	Image* sat = loadBMP("saturn.bmp");		satTexture = loadTexture(sat);		delete sat;
	Image* ura = loadBMP("uranus.bmp");		uraTexture = loadTexture(ura);		delete ura;
	Image* nep = loadBMP("neptune.bmp");	nepTexture = loadTexture(nep);		delete nep;
	Image* plu = loadBMP("pluto.bmp");		pluTexture = loadTexture(plu);		delete plu;
	Image* log = loadBMP("logo.bmp");		logTexture = loadTexture(log);		delete log;

	//LIGHTING SETUP
	//glEnable(GL_LIGHTING);
	//float lightAmb[] = { 0.0, 0.0, 0.0, 1.0 };
	//float lightDifAndSpec[] = { 1.0, 1.0, 1.0, 1.0 };
	//float globAmb[] = { 0.5, 0.5, 0.5, 1.0 };
	//glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmb);
	//glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDifAndSpec);
	//glLightfv(GL_LIGHT0, GL_SPECULAR, lightDifAndSpec);
	//glEnable(GL_LIGHT0);
	//glLightModelfv(GL_LIGHT_MODEL_AMBIENT, globAmb);
	//glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
	//glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	//glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
	//glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, spotAngle);
	//glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, spotDirection);
	//glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, spotExponent);
}



//funcion para las orbitas
void orbitalTrails(void) {
	glPushMatrix();
	//glColor3ub(255, 255, 255);
	glColor3ub(0, 0, 0);
	glTranslatef(0.0, 0.0, 0.0);
	glRotatef(0.0, 1.0, 0.0, 0.0);
	glutWireTorus(0.001, mer.distance, 100.0, 100.0);
    glutWireTorus(0.001, ven.distance, 100.0, 100.0);
	glutWireTorus(0.001, ear.distance, 100.0, 100.0);
	glutWireTorus(0.001, mar.distance, 100.0, 100.0);
	glutWireTorus(0.001, jup.distance, 100.0, 100.0);
	glutWireTorus(0.001, sat.distance, 100.0, 100.0);
	glutWireTorus(0.001, ura.distance, 100.0, 100.0);
	glutWireTorus(0.001, nep.distance, 100.0, 100.0);
	glutWireTorus(0.001, plu.distance, 100.0, 100.0);
	glPopMatrix();
}



//funcioin Principal
void drawScene(void) {
	//inicializaPlanetas();
	gluLookAt(0.0, zoom, 50.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	glBegin(GL_QUADS);
	GLUquadric* quadric;
	quadric = gluNewQuadric();

	//Sun
	glPushMatrix();
	glRotatef(sun.orbit, 0.0, 1.0, 0.0);
	glTranslatef(sun.distance, 0.0, 0.0);

	glPushMatrix();
	glRotatef(sun.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(sun.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, sunTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, sun.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	glPopMatrix();

	//plut (sun)
	glPushMatrix();
	glRotatef(sun.orbit, 0.0, 1.0, 0.0);
	glTranslatef(sun.distance, 0.0, 0.0);
	
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, sunTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, sun.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	glPopMatrix();

	//Mercury
	glPushMatrix();
	glRotatef(mer.orbit, 0.0, 1.0, 0.0);
	glTranslatef(mer.distance, 0.0, 0.0);
	
	glPushMatrix();
	glRotatef(mer.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(mer.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, merTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, mer.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	glPopMatrix();

	//Venus
	glPushMatrix();
	glRotatef(ven.orbit, 0.0, 1.0, 0.0);
	glTranslatef(ven.distance, 0.0, 0.0);
	
	glPushMatrix();
	glRotatef(ven.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(ven.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, venTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, ven.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	glPopMatrix();

	//Earth, Orbit, Moon
	glPushMatrix();
	glRotatef(ear.orbit, 0.0, 1.0, 0.0);
	glTranslatef(ear.distance, 0.0, 0.0);
	
	glPushMatrix();
	glRotatef(ear.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(ear.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, earTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, ear.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	
	if (moonsActive == 1) {
		//lun.drawMoon();
	}
	glPopMatrix();

	//Mars, Orbits, Moons
	glPushMatrix();
	glRotatef(mar.orbit, 0.0, 1.0, 0.0);
	glTranslatef(mar.distance, 0.0, 0.0);
	
	glPushMatrix();
	glRotatef(mar.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(mar.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, marTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, mar.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	
	if (moonsActive == 1) {
		//pho.drawMoon();
		//dei.drawMoon();
	}
	glPopMatrix();

	//Jupiter, Orbits, Moons
	glPushMatrix();
	glRotatef(jup.orbit, 0.0, 1.0, 0.0);
	glTranslatef(jup.distance, 0.0, 0.0);
	
	glPushMatrix();
	glRotatef(jup.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(jup.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, jupTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, jup.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	
	if (moonsActive == 1) {
		//eur.drawMoon();
		//gan.drawMoon();
		//cal.drawMoon();
	}
	glPopMatrix();

	//Saturn, Orbit, Moon
	glPushMatrix();
	glRotatef(sat.orbit, 0.0, 1.0, 0.0);
	glTranslatef(sat.distance, 0.0, 0.0);
	
	glPushMatrix();
	glRotatef(sat.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(sat.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, satTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, sat.radius, 20.0, 20.0);
	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
	glPushMatrix();
	glColor3ub(158, 145, 137);
	glRotatef(-63.0, 1.0, 0.0, 0.0);
	glutWireTorus(0.2, 6.0, 30.0, 30.0);
	glutWireTorus(0.4, 5.0, 30.0, 30.0);
	glPopMatrix();
	
	if (moonsActive == 1) {
		//tit.drawMoon();
	}
	glPopMatrix();

	glColor3ub(255, 255, 255);		//FIXES SHADING ISSUE

	//Uranus, Orbit, Moon
	glPushMatrix();
	glRotatef(ura.orbit, 0.0, 1.0, 0.0);
	glTranslatef(ura.distance, 0.0, 0.0);
	
	glPushMatrix();
	glRotatef(ura.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(ura.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, uraTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, ura.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	
	if (moonsActive == 1) {
		//puc.drawMoon();
	}
	glPopMatrix();

	//Neptune, Orbit, Moon
	glPushMatrix();
	glRotatef(nep.orbit, 0.0, 1.0, 0.0);
	glTranslatef(nep.distance, 0.0, 0.0);
	
	glPushMatrix();
	glRotatef(nep.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(nep.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, nepTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, nep.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	
	if (moonsActive == 1) {
		//tri.drawMoon();
	}
	glPopMatrix();

	//Pluto, Orbit, Moon
	glPushMatrix();
	glRotatef(plu.orbit, 0.0, 1.0, 0.0);
	glTranslatef(plu.distance, 0.0, 0.0);
	
	glPushMatrix();
	glRotatef(plu.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(plu.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, pluTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, plu.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	
	if (moonsActive == 1) {
		//nix.drawMoon();
	}
	glPopMatrix();

	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, staTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glBegin(GL_POLYGON);
	glTexCoord2f(-1.0, 0.0); glVertex3f(-200, -200, -100);
	glTexCoord2f(2.0, 0.0); glVertex3f(200, -200, -100);
	glTexCoord2f(2.0, 2.0); glVertex3f(200, 200, -100);
	glTexCoord2f(-1.0, 2.0); glVertex3f(-200, 200, -100);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, staTexture);
	glBegin(GL_POLYGON);
	glTexCoord2f(0.0, 0.0); glVertex3f(-200, -83, 200);
	glTexCoord2f(8.0, 0.0); glVertex3f(200, -83, 200);
	glTexCoord2f(8.0, 8.0); glVertex3f(200, -83, -200);
	glTexCoord2f(0.0, 8.0); glVertex3f(-200, -83, -200);
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();

	glEnd();
	//glutSwapBuffers();
}



//funcion de actualizacion de escena
void display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	camera();
	drawScene();
	glutSwapBuffers();
}



//funcion para cambiar tama�o de ventana
void resize(int w, int h) {
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustum(-5.0, 5.0, -5.0, 5.0, 5.0, 200.0);
	glMatrixMode(GL_MODELVIEW);
}



//funcion para el control con el raton
void mouseControl(int button, int state, int x, int y)
{
	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN) exit(0);
	glutPostRedisplay();
}



//funcion para la rueda del raton
void mouseWheel(int wheel, int direction, int x, int y)
{
	if (direction > 0 && zoom < 100) zoom++;
	if (direction < 0 && zoom > -75) zoom--;
	glutPostRedisplay();
}



//instrucciones
void intructions(void) {
	cout << "SPACE para parar/reanudar la simulacion" << endl;
	cout << "ESC o click derecho para parar la simulacion." << endl;
	cout << "b para reproducir musica." << endl;
	cout << "s para parar la musica." << endl;
	cout << "W, S, A, D  para controlar el movimiento de la camara." << endl;
	cout << "Scroll para cambiar altura de la camara." << endl;	
	cout << "n para aumentar la velocidad de la simulacion en un factor de 2." << endl;
	cout << "m para disminuir la velocidad de la simulacion en un factor de 1/2." << endl;

}



//funcion main
int main(int argc, char** argv) {
	//print de las instrucciones por pantalla
	intructions();

	//inicializamos 
	glutInit(&argc, argv);
	glutInitContextVersion(4, 2);
	glutInitContextProfile(GLUT_COMPATIBILITY_PROFILE);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	
	//creamos la ventana
	glutInitWindowSize(width, height);
	glutInitWindowPosition(500, 0);
	glutCreateWindow("Solar System");
	//glutFullScreen();// ventana en pantalla completa
	
	//funcion init
	init();

	//funciones de control
	glutMouseFunc(mouseControl);
	glutKeyboardFunc(keyboard);
	glutKeyboardUpFunc(keyboard_up);
	glutMouseWheelFunc(mouseWheel);

	//funciones de escena
	glutDisplayFunc(display);
	glutReshapeFunc(resize);
	glutPassiveMotionFunc(passive_motion);
	glutTimerFunc(0, timer, 0);
	
	//acabamos la inicializacion
	glewExperimental = GL_TRUE;
	glewInit();
	setup();
	glutMainLoop();
}